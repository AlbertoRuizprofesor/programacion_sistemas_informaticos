package poo;

public class Camion extends Vehiculo {
	private String peso;
	private int ejes;
	public Camion(String modelo, String motor, int ruedas, int velocidadMax, double precio, String peso, int ejes) {
		super(modelo, motor, ruedas, velocidadMax, precio);
		this.peso = peso;
		this.ejes = ejes;
		
	}
	public String getPeso() {
		return peso;
	}
	public void setPeso(String peso) {
		this.peso = peso;
	}
	public int getEjes( ) {
		return ejes;
	}
	public void setEjes(int ejes) {
		this.ejes = ejes;
	}
	public void imprimir() {
		super.imprimir();
		System.out.println("Peso del camión: "+peso);
		System.out.println("Número de ejes: "+ejes);
	}
	
}
