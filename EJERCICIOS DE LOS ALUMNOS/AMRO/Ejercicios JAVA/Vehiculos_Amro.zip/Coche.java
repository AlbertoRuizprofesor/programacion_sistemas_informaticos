package poo;

public class Coche extends Vehiculo {
	
	private int capacidad;

	public Coche(String modelo,  int velocidadMax, double precio, int capacidad) {
		super(modelo, "Gasolina",4, velocidadMax, precio);
		this.capacidad = 5;
	}

	public int getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}
	
	public void imprimir() {
		super.imprimir();
		System.out.println("Capacidad del coche: "+capacidad);
	}	
}
