package poo;

public class Main_Vehiculos {
	public static void main(String args[]) {
		
		Vehiculo vehiculo = new Vehiculo("Base", "Eléctrico", 4, 120, 15000);
		vehiculo.imprimir();
		vehiculo.acelerar();
		vehiculo.frenar();
		
		System.out.println("***********************");
		
		Coche coche = new Coche("MiCoche", 355, 350000.1, 0);
		coche.imprimir();
		
		System.out.println("***********************");
		
		Moto moto = new Moto("MiMoto", null, 220, 0, 20000.5, 0);
		moto.imprimir();
		
		System.out.println("***********************");
		
		Camion camion = new Camion("MiCamion", null, 120, 0, 180000.5, null, 0);
		camion.imprimir();
	}

}
