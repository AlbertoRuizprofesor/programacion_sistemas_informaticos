package poo;

public class Moto extends Vehiculo {
	int capacidad;

	public Moto(String modelo, String motor, int ruedas, int velocidadMax, double precio, int capacidad) {
		super(modelo, motor, ruedas, velocidadMax, precio);
		this.capacidad = capacidad;
	}

	public int getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}
	public void imprimir() {
		super.imprimir();
		System.out.println("Capacidad de la moto: "+capacidad);
	}	
	
	

}
