package poo;

public class Vehiculo {
	private String modelo;
	private String motor;
	private int ruedas;
	private int velocidadMax;
	private double precio;
	
	public Vehiculo(String modelo, String motor, int ruedas, int velocidadMax, 
			double precio) {
		this.modelo = modelo;
		this.motor = motor;
		this.ruedas = ruedas;
		this.velocidadMax = velocidadMax;
		this.precio = precio;
	}
	
	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getMotor() {
		return motor;
	}

	public void setMotor(String motor) {
		this.motor = motor;
	}

	public int getRuedas() {
		return ruedas;
	}

	public void setRuedas(int ruedas) {
		this.ruedas = ruedas;
	}

	public int getVelocidadMax() {
		return velocidadMax;
	}

	public void setVelocidadMax(int velocidadMax) {
		this.velocidadMax = velocidadMax;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public void acelerar() {
		System.out.println("El vehículo está acelerando...");
	}
	
	public void frenar() {
		System.out.println("El vehículo está frenando...");
	}
	
	public void imprimir() {
	     System.out.println("Modelo: " + modelo);
	     System.out.println("Motor: " + motor);
	     System.out.println("Ruedas: " + ruedas);
	     System.out.println("Velocidad máxima: " + velocidadMax);
         System.out.println("Precio: " + precio + " €");
	}
	

}
