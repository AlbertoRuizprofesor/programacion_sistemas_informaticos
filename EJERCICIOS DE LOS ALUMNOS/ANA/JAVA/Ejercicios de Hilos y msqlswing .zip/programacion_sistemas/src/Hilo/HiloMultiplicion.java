package Hilo;

public class HiloMultiplicion  extends Thread{

	    private double num1, num2;

	    public void HiloMultiplicacion(double num1, double num2) {
	        this.num1 = num1;
	        this.num2 = num2;
	    }
	    public void run() {
	        System.out.println("Multiplicación: " + (num1 * num2));
	    }
	


	public HiloMultiplicion(double num1, double num2) {
		// TODO Auto-generated constructor stub
	}


	public void start() {
		// TODO Auto-generated method stub
		
	}

}
