package Hilo;

public class HiloResta extends Thread{
 
	    private double num1, num2;

	    public HiloResta(double num1, double num2) {
	        this.num1 = num1;
	        this.num2 = num2;
	    }

	    public void run() {
	        System.out.println("Resta: " + (num1 - num2));
	    }
	


	public void start() {
		// TODO Auto-generated method stub
		
	}

}
