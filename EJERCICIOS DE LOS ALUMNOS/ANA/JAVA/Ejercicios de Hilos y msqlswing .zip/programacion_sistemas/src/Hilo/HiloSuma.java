package Hilo;
import java.util.Scanner;

public class HiloSuma extends Thread {
	
   private double num1, num2;

   public HiloSuma(double num1, double num2) {
       this.num1 = num1;
       this.num2 = num2;
   }

   public void run() {
       System.out.println("Suma: " + (num1 + num2));
   }
}






