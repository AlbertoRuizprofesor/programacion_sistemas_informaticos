package Hilo; //ESTO ES EL MAIN

import java.util.Scanner;

public class Hilos_Claculadora {



    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double num1, num2;

        // Solicitar al usuario los números
        System.out.print("Introduce el primer número: ");
        num1 = scanner.nextDouble();

        System.out.print("Introduce el segundo número: ");
        num2 = scanner.nextDouble();

        // Crear y arrancar hilos para cada operación
        new HiloSuma(num1, num2).start();
        new HiloResta(num1, num2).start();
        new HiloMultiplicion(num1, num2).start();
        new HiloDivision(num1, num2).start();
        new Potencia(num1, num2).start();
        scanner.close();
    }
}
