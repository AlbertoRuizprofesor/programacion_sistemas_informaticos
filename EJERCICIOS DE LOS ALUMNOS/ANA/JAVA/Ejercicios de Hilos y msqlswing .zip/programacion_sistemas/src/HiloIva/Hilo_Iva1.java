package HiloIva;

public class Hilo_Iva1 extends Thread {
	
	 private double importe;

	   public Hilo_Iva1 (double importe) {
	       this.importe = importe;
	   }

	   public void run() {
	       System.out.println("Importe con 7% de IVA:"+(importe*0.07));
	   }
	}


