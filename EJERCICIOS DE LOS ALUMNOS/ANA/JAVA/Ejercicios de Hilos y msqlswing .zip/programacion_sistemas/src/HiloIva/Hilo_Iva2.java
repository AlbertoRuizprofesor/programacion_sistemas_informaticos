package HiloIva;

public class Hilo_Iva2 extends Thread {
	
	private double importe;
	
		public Hilo_Iva2 (double importe) {
			this.importe = importe;
			
		}
		
		public void run() {
			System.out.println("Importe con 10% de IVA" +(importe*0.010));
		
		}
}	


