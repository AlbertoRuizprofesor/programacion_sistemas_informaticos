package HiloIva;

public class Hilo_Iva3 extends Thread {

private double importe;
		
	public Hilo_Iva3(double importe) {
		this.importe = importe;
		
		}
		
		public void run () {
			System.out.println("Importe con 21 de IVA" + importe*0.021);
		}
		
	}
	




