package Array_crud;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayContainer {

	private ArrayList<String> arr;
	
	public ArrayList<String> getArr() {
 		return arr;
	}

	public void setArr(ArrayList<String> arr) {
		this.arr = arr;
	}

	public ArrayContainer(ArrayList<String> arr) {
		
		this.arr = arr;
	}
	
	//Crud
	//Añade un elemento al array
	public void aniadir(String str){
		
		arr.add(str);
		
	}
	
	//Eliminar un elemento de la lista
	public void eliminar(String str) {
		
		arr.remove(str);
		
	}
	
	//Modificar un elemento
	public void modificar(String strold, String strnew) {
		
		arr.set(arr.indexOf(strold), strnew);
		
	}
	
	//Buscar un elemento
	
	public void buscar(String str) {
		
		if (arr.contains(str)) {
			
			System.out.println(str + " se encuentra en el array");
		} else {
			
			System.out.println(str + " no se encuentra en el array");
		}
	}
	
	//Listar array por pantalla
	public void listar() {
		
		System.out.print("Elementos que se encuentran en el array: [");
		for(String s: arr) {
			
			System.out.print(s + " " );
		}
		System.out.println("]");
	}
}
