package Array_crud;

import java.util.ArrayList;
import java.util.Scanner;

public class Array_Crud {

	public static void main(String[] args) {

		ArrayList<String> arr = new ArrayList<String>();
		ArrayContainer ac = new ArrayContainer(arr);
		Scanner sc = new Scanner(System.in);
		String c, str, strnew;

		do {

			System.out.println("Programa CRUD");
			System.out.println("================\n");

			System.out.println("1.- Añadir");
			System.out.println("2.- Eliminar");
			System.out.println("3.- Modificar");
			System.out.println("4.- Buscar");
			System.out.println("5.- Listado");
			System.out.println("6.- Salir");

			System.out.print("Elija una opción: ");
			c = sc.nextLine();

			switch (c) {

			case "1":
				System.out.print("Introduzca un nuevo elemento: ");
				str = sc.nextLine();
				ac.aniadir(str);
				break;

			case "2":
				System.out.print("Introduzca el elemento a eliminar: ");
				str = sc.nextLine();
				ac.eliminar(str);
				break;

			case "3":
				System.out.print("Introduzca el elemento a modificar: ");
				str = sc.nextLine();
				System.out.print("Introduzca la nueva cadena: ");
				strnew = sc.nextLine();
				ac.modificar(str, strnew);
				break;

			case "4":
				System.out.print("Introduzca el elemento a buscar: ");
				str = sc.nextLine();
				ac.buscar(str);
				break;

			case "5":
				ac.listar();
				break;

			case "6":
				c = "q";
				System.out.println("Ha decidido salir del programa");
				break;

			default:
				System.out.println("Ha elegido una opcion incorrecta");
				break;
			}

		} while (c != "q");
	}
}
