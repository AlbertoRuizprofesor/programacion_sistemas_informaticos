package ConectarMYSQL2;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Crear_tabla {
	   
	   
	   public static void main(String[] args) throws SQLException  {
	      Connection conn = null;
	      PreparedStatement stmt=null;
	      String sql="CREATE TABLE cursos (id INT PRIMARY KEY,"
	      		+ "nif VARCHAR(10) NOT NULL,"
	      		+ "nombre VARCHAR(50) NOT NULL,"
	      		+ "profesor VARCHAR (50) NOT NULL,"
	      		+ "horas INT)";
	     try {
	 
	         conn = DriverManager.getConnection("jdbc:mysql://localhost/Academia","root","");
	         stmt=conn.prepareStatement(sql);
	         stmt.executeUpdate();
	         System.out.println("Tabla 'cursos' creada correctamente");
	         conn.close();
	         stmt.close();
	      }
	      catch(SQLException e)                   
	         {e.printStackTrace();  
	      }
	 }
}
