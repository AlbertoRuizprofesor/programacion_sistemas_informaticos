package ConectarMYSQL2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Insert_datos {


	public static void main (String[] args) throws SQLException {
		// declaramos objetos necesarios:
		Connection conn=null;
		Statement stmt=null;
		String sql="INSERT INTO proveedores (id, " 
				+ "nombre, telefono, email)" +
				"VALUES (1,'Ana',952345687,'informaticacurso@gmail.com')";
		
	try {
		conn= DriverManager.getConnection("jdbc:mysql://localhost/empresa1", "root","");
		stmt=conn.createStatement();
		stmt.execute(sql);
		System.out.println("Tabla 'clientes' creada");
		conn.close();
		stmt.close();
	}
	catch(SQLException e)
	{System.out.println("Error en la conexión "+e.getMessage());	

		}
	}
}