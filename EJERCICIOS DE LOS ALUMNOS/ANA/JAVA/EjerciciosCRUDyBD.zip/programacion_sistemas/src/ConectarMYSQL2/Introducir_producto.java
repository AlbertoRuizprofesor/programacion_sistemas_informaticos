package ConectarMYSQL2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Introducir_producto {

    public static void main (String[] args) {

        Connection conn = null;
        Statement stmt = null;

        String sql = "INSERT INTO productos (id, nombre, precio) " +
                     "VALUES (1, 'portatil', 499.99)";

        try {

            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/empresa1",
                "root",
                ""
            );

            stmt = conn.createStatement();
            stmt.executeUpdate(sql);

            System.out.println("Producto insertado correctamente");

            stmt.close();
            conn.close();

        } catch(SQLException e) {
            System.out.println("Error en la conexión " + e.getMessage());
        }
    }
}