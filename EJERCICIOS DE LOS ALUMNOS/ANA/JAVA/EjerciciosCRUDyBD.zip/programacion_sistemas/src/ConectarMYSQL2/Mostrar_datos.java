package ConectarMYSQL2;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class Mostrar_datos {

    public static void main(String[] args) {

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        String sql = "SELECT * FROM proveedores";

        try {

            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/empresa1",
                "root",
                ""
            );

            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            while (rs.next()) {

                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                int telefono = rs.getInt("telefono");
                String email = rs.getString("email");

                System.out.println("id: " + id +
                                   ", nombre: " + nombre +
                                   ", telefono: " + telefono +
                                   ", email: " + email);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch(SQLException e) {
            e.printStackTrace();
        }
    }
}

