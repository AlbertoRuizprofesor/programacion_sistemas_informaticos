package ConectarMYSQL2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Tabla_producto {

    public static void main (String[] args) {

        Connection conn = null;
        Statement stmt = null;

        String sql = "CREATE TABLE productos ("
                   + "id INT PRIMARY KEY, "
                   + "nombre VARCHAR(60) NOT NULL, "
                   + "precio DECIMAL(10,2))";

        try {

            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/empresa1",
                "root",
                ""
            );

            stmt = conn.createStatement();
            stmt.execute(sql);

            System.out.println("Tabla 'productos' creada");

            stmt.close();
            conn.close();

        } catch(SQLException e) {
            e.printStackTrace();
            System.out.println("Error en la conexión " + e.getMessage());
        }
    }
}
