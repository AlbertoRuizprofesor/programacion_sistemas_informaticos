package conectarmysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertarDatos {
	public static void main (String[] args) throws SQLException {
		// declaramos objetos necesarios:
		Connection conn=null;
		Statement stmt=null;
		String sql="CREATE TABLE IF NOT EXISTS clientes (id " 
				+ "nif, nombre, edad)" +
				"VALUES (1,'11111','Ana','29')";
		
	try {
		conn= DriverManager.getConnection("jdbc:mysql://localhost/", "root","");
		stmt=conn.createStatement();
		stmt.execute(sql);
		System.out.println("Tabla 'clientes' creada");
		conn.close();
		stmt.close();
	}
	catch(SQLException e)
	{System.out.println("Error en la conexión "+e.getMessage());	

		}
	}
}
