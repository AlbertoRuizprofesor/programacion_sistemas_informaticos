package conectarmysql.copy2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertarDatos {

    public static void main(String[] args) {

        Connection conn = null;
        PreparedStatement pstmt = null;

        String sql = "INSERT INTO productos (id, "
        		+ "nombre, precio) VALUES (?, ?, ?)";

        try {

            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost/empresa1",
                    "root",
                    "");

            pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1, 2);

            pstmt.setString(2, "Microsoft");

            pstmt.setDouble(3, 1200.00);

            pstmt.executeUpdate();

            System.out.println("Datos insertados correctamente");

        } catch (SQLException e) {

            e.printStackTrace();

        } finally {

            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }

    }
}
