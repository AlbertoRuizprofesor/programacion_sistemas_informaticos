package MVC_MYSQL3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import MVC_MYSQL3.Productos;
import MVC_MYSQL3.Vista;

public class Controlador {
	private Connection conn; //para conectar con la base de datos
	//asociacion
	private ArrayList<Productos> listaProductos;
	private Vista vista;
	
	public Controlador(Vista vista) {
		this.vista=vista;
		listaProductos=new ArrayList<>();
		
	try {
		conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/empresa1","root","");
		System.out.println("Conexion correcta");
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}
		 
	    public void cargarClientes() {  //metodo
	        try {
	            String sql = "SELECT * FROM Cliente";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ResultSet rs = ps.executeQuery();
	            //aqui estamos creando un objeto por cada registro.
	            while (rs.next()) {
	                Productos p = new Productos(
	                        rs.getInt("id"), 
	                        rs.getString("nombre"),
	                        rs.getInt("telefono"),
	                        rs.getString("email")
	                       
	                        
	                );
	                //cada objeto nuevo lo añadimos a listaclientes
	                listaProductos.add(p);  //array creado aqui se añaden
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    public void mostrarProductos() {
	        vista.mostrarProductos(listaProductos);
	}
}
	    



