package MVC_MYSQL3;

import MVC_MYSQL2.Vista;

public class Productos {

	private int id;
	private String nombre;
	private int telefono;
	private String email;
	
	public Productos (int id, String nombre, int telefono, String email) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.telefono = telefono;
		this.email = email;
		
		
		}
		public Productos(MVC_MYSQL3.Vista vista) {
		// TODO Auto-generated constructor stub
	}
		public int getId() {
		return id;
		
		}
		public String getNombre() {
		return nombre;
		
		}
		public int getTelefono() {
		return telefono;
		
		}
		public String getEmail() {
		return email;
		}
		public void mostrarProductos() {
			// TODO Auto-generated method stub
			
		}
		public void cargarProductos() {
			// TODO Auto-generated method stub
			
		}
}
		
