package MVC_MYSQL3;

import MVC_MYSQL3.Productos;
import MVC_MYSQL3.Vista;

public class Productos_main {
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
		Vista vista = new Vista();
		Productos productos = new Productos(vista);
		
		Productos p = null;
		p.cargarProductos();
		p.mostrarProductos();

		}
	}


