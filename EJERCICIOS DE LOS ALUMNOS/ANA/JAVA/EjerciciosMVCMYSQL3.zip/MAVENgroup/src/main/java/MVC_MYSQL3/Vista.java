package MVC_MYSQL3;

import java.util.ArrayList;
import MVC_MYSQL3.Productos;

public class Vista {
	
	   public void mostrarProductos(ArrayList<Productos> listaProductos) {
	        System.out.println("Listado de Proveedores");
	       
			for (Productos p : listaProductos) {
	            System.out.println(
	                "ID: " + p.getId()
	                + " | NIF: " + p.getNombre()
	                + " | Nombre: " + p.getNombre()
	                + " | Telefono: " + p.getTelefono()
	                + " | Email: " + p.getEmail()
	            );
	        }
	    }

	   public void mostrarProductos(Object listaProductos) {
		// TODO Auto-generated method stub
		
	   }
	}



