package Adapter;

public class CelsiusToFahrenheitConverter implements TemperatureConverter{

	@Override
	public double convertCelsiusToFarenheit(double celsius) {
		return (celsius * 9/5) + 32;
	}
}
