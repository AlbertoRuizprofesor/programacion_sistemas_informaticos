package Adapter;

public class Main {
	public static void main(String [] args) {
		double temp = 25;
		CelsiusTemperature celsiusTemp = new CelsiusTemperature(temp);

	     TemperatureAdapter adapter = new TemperatureAdapter(celsiusTemp);

	     double fahrenheitTemp = adapter.convertCelsiusToFarenheit(celsiusTemp.getValue());

	}
}

