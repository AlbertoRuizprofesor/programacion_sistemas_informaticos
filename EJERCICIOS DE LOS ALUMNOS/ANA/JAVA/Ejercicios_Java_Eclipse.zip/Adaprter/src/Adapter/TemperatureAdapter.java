package Adapter;

public class TemperatureAdapter implements TemperatureConverter{
	private CelsiusTemperature celsiusTemperature;
	
public TemperatureAdapter(CelsiusTemperature celsiusTemperature) {
		this.celsiusTemperature = celsiusTemperature;
	

}

@Override
public double convertCelsiusToFarenheit(double celsius) {
	// TODO Auto-generated method stub
	return 

new CelsiusToFahrenheitConverter().convertCelsiusToFarenheit(celsiusTemperature.getValue());
	

	}
}

