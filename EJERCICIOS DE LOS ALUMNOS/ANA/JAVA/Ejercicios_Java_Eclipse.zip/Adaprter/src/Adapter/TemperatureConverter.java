package Adapter;

public interface TemperatureConverter {

	double convertCelsiusToFarenheit(double celsius);
	
}
