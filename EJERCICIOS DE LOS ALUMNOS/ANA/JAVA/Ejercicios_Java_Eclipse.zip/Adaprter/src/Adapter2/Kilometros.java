package Adapter2;

public class Kilometros {
	private double value;
	
	public Kilometros(double value) {
		this.value = value;

}
	public double getValue() {
		return value;

	}

}
