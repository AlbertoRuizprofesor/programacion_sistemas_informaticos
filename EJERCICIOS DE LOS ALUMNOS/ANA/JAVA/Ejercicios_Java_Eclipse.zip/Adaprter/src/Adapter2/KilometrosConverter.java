package Adapter2;

public class KilometrosConverter implements MillasConverter {

    @Override
    public double convertKilometros(double kilometros) {
        return kilometros * 0.621371;
    }
}