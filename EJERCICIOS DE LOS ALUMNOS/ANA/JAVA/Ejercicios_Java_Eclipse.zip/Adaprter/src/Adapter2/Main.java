package Adapter2;

public class Main {

    public static void main(String[] args) {

        double kilometros = 10.0;

        KilometrosConverter converter = new KilometrosConverter();
        double millas = converter.convertKilometros(kilometros);

        System.out.println("La distancia en kilometros es: " + kilometros);
        System.out.println("La distancia en millas es: " + millas);
    }
}