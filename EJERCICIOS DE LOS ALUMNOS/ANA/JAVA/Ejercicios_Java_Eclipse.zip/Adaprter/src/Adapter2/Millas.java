package Adapter2;

public interface Millas {
	double convertKilometros(double kilometros);

}
