package Adapter2;

public class MillasAdapter implements MillasConverter {

    private KilometrosMillas kilometrosMillas;

    public MillasAdapter(KilometrosMillas kilometrosMillas) {
        this.kilometrosMillas = kilometrosMillas;
    }

    @Override
    public double convertKilometros(double kilometros) {
        return kilometrosMillas.convertKilometros(kilometros);
    }
}
