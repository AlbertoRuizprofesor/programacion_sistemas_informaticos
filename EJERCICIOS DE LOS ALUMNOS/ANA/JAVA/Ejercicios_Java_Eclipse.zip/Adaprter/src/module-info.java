/**
 * 
 */
/**
 * 
 */
module Adaprter {
}