package Builder;

public class Main {
    public static void main (String[] args) {

    	Producto producto = new ProductoBuilder()
                			.nombre("Camiseta")
                			.precio(20.0)
                			.color("Rojo")
                			.talla(44.5)
                			.fabricante("Zara")
                			.modelo("Slim")
                			.Build1();
    	
        producto.imprimirDetalle();
    }
}
