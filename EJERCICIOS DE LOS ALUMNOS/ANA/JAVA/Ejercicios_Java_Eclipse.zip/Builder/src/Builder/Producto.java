package Builder;

 public class Producto {
	 private String nombre;
	 private double precio;
	 private String color;
	 private double talla;
	 private String fabricante;
	 private String modelo;
	 
	 public Producto(String nombre, double precio, double talla2, String color, String fabricante, String modelo) {
		 this.nombre = nombre;
		 this.precio = precio;
		 this.color = color;
		 this.talla = talla2;
		 this.fabricante = fabricante;
		 this.modelo = modelo;

}
	 
	 public Producto(String nombre2, int precio2, int año, String plataforma, String sinopsis,
			String requerimientominimos) {
		// TODO Auto-generated constructor stub
	}

	 /**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
 	 * @return the precio
 	 */
	 public double getPrecio() {
		 return precio;
	 }



	 /**
 	 * @return the color
 	 */
	 public String getColor() {
		 return color;
	 }

	 /**
 	 * @return the talla
 	 */
	 public double getTalla() {
		 return talla;
	 }

	 /**
 	 * @return the fabricante
 	 */
	 public String getFabricante() {
		 return fabricante;
	 }

	 /**
 	 * @return the modelo
 	 */
	 public String getModelo() {
		 return modelo;
	 }



	 public void imprimirDetalle() {
		 System.out.println("Nombre: " + nombre);
		 System.out.println("Precio: " + precio);
		 System.out.println("Color: " + color);
		 System.out.println("Talla: " + talla);
		 System.out.println("Fabricante " + fabricante);
		 System.out.println("Modelo " + modelo);
	 }
}