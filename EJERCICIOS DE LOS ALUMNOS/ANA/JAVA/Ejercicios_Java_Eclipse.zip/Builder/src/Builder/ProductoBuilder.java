package Builder;

public class ProductoBuilder {
	private String nombre;
	private double precio;
	private String color;
	private double talla;
	private String fabricante;
	private String modelo;
	
	public ProductoBuilder nombre(String nombre) {
		this.nombre = nombre;
		return this;
	}
	
	public ProductoBuilder precio(double precio) {
		this.precio = precio;
		return this;
}
	
	
	public ProductoBuilder color(String color) {
		this.color = color;
		return this;
		
	}
	
	public ProductoBuilder talla(double talla) {
		this.talla = talla;
		return this;
	}
	
	public ProductoBuilder fabricante(String fabricante) {
		this.fabricante = fabricante;
		return this;
	
	}
	
	public ProductoBuilder modelo (String modelo) {
		this.modelo = modelo;
		return this;
	}
	
	public Producto Build1() {
		return new Producto (nombre, precio, talla, color, fabricante, modelo);
	
	}
}