package Builder2;


public class Main {
	public static void main (String[] args){
		
	Builder.Producto producto = new ProductoBuilder()
			.nombre("Resident Evil Requiem")
            .año(2026)
            .precio(79.99)
            .plataforma("Pc")
            .sinopsis("Survival horror")
            .requerimientominimos("Procesador Intel Core i5-8500")
            .Build2();

	producto.imprimirDetalle();

	}
}

