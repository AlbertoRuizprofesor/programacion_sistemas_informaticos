package Builder2;

 class Producto {
	private String nombre;
	private int año;
	private double precio;
	private String plataforma;
	private String sinopsis;
	private String requerimientominimos;

	public Producto(String nombre, int año, double precio, String plataforma, String sinopsis, String requerimientosminimos) {
		
		this.nombre = nombre;
		this.año = año;
		this.precio = precio;
		this.plataforma = plataforma;
		this.sinopsis = sinopsis;
		this.requerimientominimos = requerimientominimos;
		
		
	}
	
	public String getNombre() {
		return nombre;
	}

	public int getAño() {
		return año;
	}
	
	public double getPrecio() {
		return precio;
	}

	public String getPlataforma() {
		return plataforma;
	}
	
	public String getSinopsis() {
		return sinopsis;
	}

	public String getRequerimientominimos() {
		return requerimientominimos;
	}
	
	public void imprimirDetalle() {
		 System.out.println("Nombre: " + nombre);
		 System.out.println("Año: " + año);
		 System.out.println("Precio: " + precio);
		 System.out.println("Plataforma: " + plataforma);
		 System.out.println("Sinopsis " + sinopsis);
		 System.out.println("Requerimientominimos " + requerimientominimos);
	}
 }
