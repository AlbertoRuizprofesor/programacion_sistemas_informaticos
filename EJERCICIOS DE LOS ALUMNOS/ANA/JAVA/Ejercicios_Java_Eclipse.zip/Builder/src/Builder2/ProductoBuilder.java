package Builder2;

import Builder.Producto;

public class ProductoBuilder {
	private String nombre;
	private int año;
	private double precio;
	private String plataforma;
	private String sinopsis;
	private String requerimientominimos;
	
	public ProductoBuilder nombre (String nombre) {
		this.nombre = nombre;
		return this;
	}
	
	public ProductoBuilder año (int año) {
		this.año = año;
		return this;
		
	}
	
	public ProductoBuilder precio (double precio) {
		this.precio = precio;
		return this;
	}
	
	public ProductoBuilder plataforma (String plataforma) {
		this.plataforma = plataforma;
		return this;
	}
	
	public ProductoBuilder sinopsis (String sinopsis) {
		this.sinopsis = sinopsis;
		return this;
	}
	
	public ProductoBuilder requerimientominimos (String requerimientominimos) {
		this.requerimientominimos = requerimientominimos;
		return this;
	}
	
	public Producto Build2() {
		return new Producto(nombre, precio, año, plataforma, sinopsis, requerimientominimos);
		
	}
}
