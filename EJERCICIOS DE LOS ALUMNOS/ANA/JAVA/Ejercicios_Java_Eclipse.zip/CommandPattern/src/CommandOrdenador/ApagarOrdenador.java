package CommandOrdenador;

public class ApagarOrdenador implements Comando {
	
	private Ordenador ordenador;
	
	public ApagarOrdenador(Ordenador ordenador) {
		this.ordenador = ordenador;
	}

	@Override
	public void ejecutar() {
		ordenador.apagar();
		
	}
	
}
