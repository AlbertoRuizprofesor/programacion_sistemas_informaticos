package CommandOrdenador;

public interface Comando {
	void ejecutar();
	}


