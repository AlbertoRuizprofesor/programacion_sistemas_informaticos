package CommandOrdenador;

public class ComandoEncenderOrdenador implements Comando{
	
	private Ordenador ordenador;
	
	public ComandoEncenderOrdenador(Ordenador ordenador) {
		this.ordenador = ordenador;
		
	}

	@Override
	public void ejecutar() {
		ordenador.encender();
		
	}
	
		

}
