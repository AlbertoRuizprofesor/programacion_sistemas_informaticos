package CommandOrdenador;

public class Ordenador {
	public void encender() {
		System.out.println("El ordenador está encendido");
		
	}
	
	public void apagar() {
		System.out.println("El ordenador está apagado");
		
	}

}
