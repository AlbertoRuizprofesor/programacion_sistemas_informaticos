package CommandPattern;

public interface Comando {
	void ejecutar();
}
