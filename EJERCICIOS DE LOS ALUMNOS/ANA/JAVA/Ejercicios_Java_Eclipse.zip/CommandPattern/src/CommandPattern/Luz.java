package CommandPattern;

public class Luz {

		public void encender() {
			System.out.println("La liz está encendida");
			
		}
		
		public void apagar() {
			System.out.println("La luz está apagada");
		}
}		
		
