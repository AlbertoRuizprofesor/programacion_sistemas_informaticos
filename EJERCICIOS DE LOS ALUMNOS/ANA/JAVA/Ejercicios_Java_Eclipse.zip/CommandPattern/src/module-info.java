/**
 * 
 */
/**
 * 
 */
module CommandPattern {
}