package Composite;

public interface Componente {
    void mostrar();
}
