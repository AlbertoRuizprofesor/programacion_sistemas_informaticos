package Composite;

import java.util.ArrayList;
import java.util.List;

public class Directorio implements Componente{

		private String nombre;
		private List<Componente> componentes = new ArrayList<>();
		
		public Directorio(String nombre) {
			this.nombre = nombre;
			
	}
		
		@Override
		public void mostrar() {
			System.out.println("Directorio: " + nombre);
			for (Componente componente : componentes) {
				componente.mostrar();
		}
	}

		public void agregar(Archivo archivo1) {
			// TODO Auto-generated method stub
			
		}

}
