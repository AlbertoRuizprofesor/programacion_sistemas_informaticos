package Decorator;

public class Main {
	    public static void main(String[] args) {
	        Mensaje mensaje = new MensajeBasico("¡Hola, mundo!");

	        // Decorar el mensaje con un encabezado
	        Mensaje mensajeDecorado = new MensajeConEncabezado(mensaje, "Mensaje importante:");

	        System.out.println(mensajeDecorado.ObtenerContenido());

	        // Ejercicio adicional para el alumno:
	        // Ahora añade tú mismo otro decorador "MensajeConPieDePagina" que agregue un pie de página.
	    }
	}


