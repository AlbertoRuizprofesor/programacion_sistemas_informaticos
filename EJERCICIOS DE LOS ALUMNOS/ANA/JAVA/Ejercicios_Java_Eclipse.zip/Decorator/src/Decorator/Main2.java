package Decorator;

public class Main2 {
 
    public static void main(String[] args) {
        Mensaje mensaje = new MensajeBasico("Hola,mundo!");
        
        Mensaje mensajeDecorado = new MensajeConEncabezado(new MensajeConPieDePagina(mensaje, "saludo desde mi programa."),
        		"Mensaje importante: ");
        
        System.out.println(mensajeDecorado.ObtenerContenido());
    }
}