package Decorator;

public interface Mensaje {
	String ObtenerContenido();
	
}
