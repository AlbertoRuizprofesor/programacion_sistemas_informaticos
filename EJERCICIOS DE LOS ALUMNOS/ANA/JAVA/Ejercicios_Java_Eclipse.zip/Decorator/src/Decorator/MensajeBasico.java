package Decorator;

class MensajeBasico implements Mensaje {
    private String contenido;

    public MensajeBasico(String contenido) {
        this.contenido = contenido;
    }

    @Override
    public String ObtenerContenido() {
        return contenido;
    }
}

	
