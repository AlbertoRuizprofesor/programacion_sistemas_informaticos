package Decorator;

class MensajeConEncabezado implements Mensaje {
    private Mensaje mensaje;
    private String encabezado;

    public MensajeConEncabezado(Mensaje mensaje, String encabezado) {
        this.mensaje = mensaje; 
        this.encabezado = encabezado;
    }
    
    @Override
    public String ObtenerContenido() {
        return encabezado + "\n" + mensaje.ObtenerContenido();
    }
}
