package Decorator;

public class MensajeConPieDePagina implements Mensaje {
	
	private Mensaje mensaje;
	private String pieDePagina;
	
public MensajeConPieDePagina(Mensaje mensaje, String pieDePagina) {
	this.mensaje = mensaje;
	this.pieDePagina = pieDePagina;
}

@Override
public String ObtenerContenido() {
	// TODO Auto-generated method stub
	return mensaje.ObtenerContenido() + "\n" + pieDePagina;
	
	}
}
	
	

