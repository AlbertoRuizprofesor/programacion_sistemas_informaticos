/**
 * 
 */
/**
 * 
 */
module Decorator {
}