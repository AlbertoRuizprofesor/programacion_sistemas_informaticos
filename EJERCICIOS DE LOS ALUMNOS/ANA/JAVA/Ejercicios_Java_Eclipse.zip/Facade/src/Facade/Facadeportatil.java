package Facade;

public class Facadeportatil {
	private Portatil portatil;
	private MemoriaRamEjecutando memoriaramejecutando;
	private Teclado teclado;

	public Facadeportatil() {
		this.portatil = new Portatil();
		this.memoriaramejecutando = new MemoriaRamEjecutando();
		this.teclado = new Teclado();
	}

	public void encenderPortatil() {
		portatil.encender();
		memoriaramejecutando.encender();
		teclado.encender();
		System.out.println("portatil encendido");
	
	}
	
	public void apagarPortatil() {
		portatil.apagar();
		memoriaramejecutando.apagar();
		teclado.apagar();
		System.out.println("portatil apagado");
	
	
	
	}
	
}
		
	

