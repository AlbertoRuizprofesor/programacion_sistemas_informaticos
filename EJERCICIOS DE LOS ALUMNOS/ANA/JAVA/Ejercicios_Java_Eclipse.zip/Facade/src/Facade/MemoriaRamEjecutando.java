package Facade;

public class MemoriaRamEjecutando {
	public void memoriaram() {
		System.out.println("Ejecutando memoria Ram.");
		
	}
	
	public void encender() {
		System.out.println("Memoriaram encencida.");
		
	}
	
	public void apagar() {
		System.out.println("Memoriaram apagado.");
	}

}	

