package Facade;

public class Principal {
	public static void main(String[] args) {
	Facadeportatil portatil = new Facadeportatil(); 
	portatil.encenderPortatil();
	portatil.apagarPortatil();
	
	}
}


