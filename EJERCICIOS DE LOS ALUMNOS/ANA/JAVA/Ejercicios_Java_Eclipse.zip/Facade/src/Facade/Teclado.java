package Facade;

public class Teclado {
	public void encender() {
		System.out.println("El teclado esta encendido.");
	}
	
	public void apagar() {
		System.out.println("El teclado esta apagado.");
		
	}

}
