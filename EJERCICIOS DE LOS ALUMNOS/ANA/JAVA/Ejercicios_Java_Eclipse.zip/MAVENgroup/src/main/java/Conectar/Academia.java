package Conectar ;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Academia {

		   
public static void main(String[] args) throws SQLException  {
		      Connection conn = null;
		      Statement stmt=null; 
		      String sql="CREATE DATABASE if not exists academia";
		     try {
   
		         conn = DriverManager.getConnection("jdbc:mysql://localhost:/","root","");
		        
		         stmt=conn.createStatement(); 
		         stmt.execute(sql);
		         System.out.println("La base de datos Academia ok");
		         conn.close();
		         stmt.close();
		      }
		      catch(SQLException e)                   
		         {e.printStackTrace();  
		      }
		 }
	}



