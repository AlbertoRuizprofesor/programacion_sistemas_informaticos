package Conectar;

import java.sql.*;
import java.util.Scanner;

public class Buscar_curso {

    public static void main(String[] args) {

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Scanner sc = new Scanner(System.in);

        try {

          
            System.out.print("Ingrese el nombre del curso: ");
            String nombreCurso = sc.nextLine();

          
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/Academia",
                "root",
                ""
            );

            
            String sql = "SELECT * FROM cursos WHERE nombre = ?";
            ps = conn.prepareStatement(sql);

             ps.setString(1, nombreCurso);
            rs = ps.executeQuery();

              if (rs.next()) {

                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String profesor = rs.getString("profesor");
                int horas = rs.getInt("horas");

                System.out.println("\nCurso encontrado:");
                System.out.println("ID: " + id);
                System.out.println("Nombre: " + nombre);
                System.out.println("Profesor: " + profesor);
                System.out.println("Horas: " + horas);

            } else {
                System.out.println("El curso no existe.");
            }

            
            rs.close();
            ps.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        sc.close();
    }
}



           

            
 

           
          