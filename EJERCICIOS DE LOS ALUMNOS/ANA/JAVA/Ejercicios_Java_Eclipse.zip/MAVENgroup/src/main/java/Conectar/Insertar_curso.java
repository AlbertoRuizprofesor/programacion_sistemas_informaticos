package Conectar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class Insertar_curso {

    public static void main(String[] args) {

        Connection conn = null;
        PreparedStatement ps = null;

        String sql = "INSERT INTO cursos (nif, nombre, profesor, horas) VALUES (?, ?, ?, ?)";

        try {

            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/academia",
                "root",
                ""
            );

            System.out.println("Conexión a la base de datos 'academia' OK");

            ps = conn.prepareStatement(sql);

            //Curso 1: Informática
            ps.setString(1, "11111111A");
            ps.setString(2, "Informatica");
            ps.setString(3, "Martinez");
            ps.setInt(4, 40);
            ps.executeUpdate();
            
            //Curso 2: Java Básico
            ps.setInt(1, 2);
            ps.setString(2, "22222222B");
            ps.setString(3, "Java Basico");
            ps.setString(4, "Lopez");
            ps.setInt(4, 50);
            ps.executeUpdate();

            //Curso 3: Python
            ps.setInt(1, 3);
            ps.setString(2, "33333333C");
            ps.setString(3, "Python");
            ps.setString(4, "Garcia");
            ps.setInt(4, 45);
            ps.executeUpdate();

            System.out.println("Cursos insertados correctamente");

            ps.close();
            conn.close();

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}