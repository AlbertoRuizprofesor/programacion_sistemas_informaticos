package Conectar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.PreparedStatement;

public class Insertar_curso_2 {

    public static void main(String[] args) {

        Connection conn = null;
        PreparedStatement ps = null;

        String sql = "INSERT INTO cursos (id, nif, nombre, profesor, horas) VALUES (?, ?, ?, ?, ?)";

        try {

            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/academia",
                "root",
                ""
            );

            System.out.println("Conexión a la base de datos 'academia' OK");

            ps = conn.prepareStatement(sql);

            // Datos del curso
//            ps.setInt(1, 5);
//            ps.setString(2, "12345678Z");
//            ps.setString(3, "Base de Datos");
//            ps.setString(4, "García");
//            ps.setInt(5, 45);
            
            int num;
            String str;
            Scanner sc = new Scanner(System.in);
                       
          
            //Para cada dato
            System.out.print("Introduzca el id: ");
            num = sc.nextInt(); // Si es un numero
            ps.setInt(1,num); // Si es un numero, numero del parametro y variable num
            
            System.out.print("Introduzca el nif: ");
            str = sc.next(); // Si es una cadena
            ps.setString(2,str); // Si es una cadena
            
            System.out.print("Introduzca el nombre: ");
            str = sc.next();
            ps.setString(3,str);
            
            System.out.print("Introduzca el profesor: ");
            str = sc.next();
            ps.setString(4,str);
            
            System.out.print("Introduzca las horas: ");
            num = sc.nextInt(); // Si es un numero
            ps.setInt(5,num);
    
            ps.executeUpdate();
            
            
            System.out.println("Curso insertado correctamente");

            ps.close();
            conn.close();
            sc.close();

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}