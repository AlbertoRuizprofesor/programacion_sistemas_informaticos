package Conectar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class Mostrar_cursos {

    public static void main(String[] args) {

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {

            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/academia",
                "root",
                ""
            );

            stmt = conn.createStatement();

            String sql = "SELECT * FROM cursos";
            rs = stmt.executeQuery(sql);

            System.out.println("ID | NOMBRE | PROFESOR | HORAS");
            System.out.println("----------------------------------");

            while (rs.next()) {

                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String profesor = rs.getString("profesor");
                int horas = rs.getInt("horas");

                System.out.println(id + " , " + nombre + " , " + profesor + " , " + horas);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}