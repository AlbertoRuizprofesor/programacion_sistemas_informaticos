package Excepciones;

//ExcepcionesEjemplo4 

public class Dividir {
	
		 
	    public static void main(String[] args) {        
	    	try { 
	    		// Llamamos al método dividir   
	            String resultado = null;
				int resultado1 = dividir(30, 0); 
	            System.out.println("El resultado es: " + resultado1); 
	        } catch (ArithmeticException e) { 
	            System.out.println("Error: división entre cero."); 
	        } 
	    } 
	 
	    public static int dividir(int a, int b) throws ArithmeticException {         if (b == 0) { 
	            throw new ArithmeticException(); 
	        } 
	        return a / b; 
	    } 
	} 


