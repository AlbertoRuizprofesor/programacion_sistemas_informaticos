package MVC;

import MVC2.Productos;

public class Controlador {
	private Persona modelo;
	private Vista Vista;
	

	
	public Controlador(Persona modelo, Vista vista) {
		super();
		this.modelo = modelo;
		this.Vista = vista;
	}

	
	public void actualizarVista() {
		Vista.mostrarPersona(modelo.getNombre(), modelo.getApellido(), modelo.getEdad());
		
	}

}
