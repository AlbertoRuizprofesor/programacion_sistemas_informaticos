package MVC;

public class Persona_main {
	
	public static void main(String[] args) {
		
		Persona modelo = new Persona("Ana", "Zamora", 29 );
		Vista vista = new Vista();
		Controlador controlador =new
				Controlador(modelo, vista);
		controlador.actualizarVista();
		
	}

}
