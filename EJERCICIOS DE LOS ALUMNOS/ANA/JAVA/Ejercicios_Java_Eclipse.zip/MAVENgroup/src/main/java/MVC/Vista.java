package MVC;

public class Vista {
	//mostrar persona
	public void mostrarPersona(String nombre, String apellido, int edad) {
		System.out.println("Nombre: " + nombre);
		System.out.println("Appellido: " + apellido);
		System.out.println("Edad: " + edad);
		
		
	}

}
