package MVC2;

// el controlador es lo que une el backend y frontend

public class Controlador {
	private Productos modelo;
	private Vista vista;
	public Controlador(Productos modelo, Vista vista) {
		super();
		this.modelo = modelo;
		this.vista = vista;
	}
	
	public void actualizarVista() {
		vista.mostrarProducto(modelo.getNombre(), modelo.getCodigo(), modelo.getPrecio());

	}
}
