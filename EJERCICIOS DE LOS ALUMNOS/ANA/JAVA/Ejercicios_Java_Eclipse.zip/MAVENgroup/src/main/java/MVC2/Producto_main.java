package MVC2;

//esto seria el resultado de las tres cosas

	public class Producto_main {
		
		public static void main(String[] args) {
			
			Productos modelo = new Productos("google", 15 , 300);
			Vista vista = new Vista();
			Controlador controlador =new
				Controlador(modelo, vista);
			controlador.actualizarVista();
			
	}

}
