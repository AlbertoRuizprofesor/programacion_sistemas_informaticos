package MVC2;

//esto seria el frontend, es la interfaz grafica lo que muestra el backebnd

public class Vista { 
	
	public void mostrarProducto(String nombre, int codigo, double precio) {
		System.out.println("Nombre: " + nombre);
		System.out.println("codigo: " + codigo);
		System.out.println("double: " + precio);
		
	}
}
