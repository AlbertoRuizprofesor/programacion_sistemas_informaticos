package MVC3;

public class Alumno_main {
		
		public static void main(String[] args) {
			
			Alumno modelo = new Alumno(1, "juan" , "Godino Gamez", "Sistemas", 10);
			
			Vista vista = new Vista();
			Controlador controlador =new
				Controlador(modelo, vista);
			controlador.actualizarVista();

		}
}
