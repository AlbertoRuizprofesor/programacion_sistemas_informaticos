package MVC3;

public class Controlador {
	private Alumno modelo;
	private Vista vista;
	public Controlador(Alumno modelo, Vista vista) {
		super();
		this.modelo = modelo;
		this.vista = vista;
	}
		
		public void actualizarVista() {
			vista.mostrarAlumno(modelo.getId(),modelo.getNombre(),modelo.getAsignaturas(),null, modelo.getNota());
	

	}
	
}

