package MVC3;

public class Vista {
	
	public void mostrarAlumno(int id, String nombre, String apellidos, String asignatura, int nota) {
		System.out.println("int: " + id);
		System.out.println("Nombre: " + nombre);
		System.out.println("apellidos: " + apellidos);
		System.out.println("asignatura: " + asignatura);
		System.out.println("int: " + nota);
		
	}
}
