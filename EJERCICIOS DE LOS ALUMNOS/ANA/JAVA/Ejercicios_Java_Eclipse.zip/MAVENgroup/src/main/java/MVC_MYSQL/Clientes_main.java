package MVC_MYSQL;

public class Clientes_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Vista vista = new Vista();
	Controlador controlador = new Controlador(vista);
	
	Controlador c = null;
	c.cargarClientes();
	c.mostrarClientes();

	}

}
