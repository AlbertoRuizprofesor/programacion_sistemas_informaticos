package MVC_MYSQL;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Controlador {
	private Connection conn; //para conectar con la base de datos
	//asociacion
	private ArrayList<Clientes> listaClientes;
	private Vista vista;
	
	public Controlador(Vista vista) {
		this.vista=vista;
		listaClientes=new ArrayList<>();
		
	try {
		conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/empresa1","root","");
		System.out.println("Conexion correcta");
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}
		 
	    public void cargarClientes() {  //metodo
	        try {
	            String sql = "SELECT * FROM Cliente";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ResultSet rs = ps.executeQuery();
	            //aqui estamos creando un objeto por cada registro.
	            while (rs.next()) {
	                Clientes c = new Clientes(
	                        rs.getInt("id"),
	                        rs.getString("nif"),
	                        rs.getString("nombre"),
	                        rs.getString("edad")
	                );
	                //cada objeto nuevo lo añadimos a listaclientes
	                listaClientes.add(c);  //array creado aqui se añaden
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    public void mostrarClientes() {
	        vista.mostrarClientes(listaClientes);
	    }

	}


