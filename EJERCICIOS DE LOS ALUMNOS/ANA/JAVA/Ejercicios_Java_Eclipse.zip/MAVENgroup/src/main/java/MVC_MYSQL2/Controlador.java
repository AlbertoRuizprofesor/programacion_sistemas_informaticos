package MVC_MYSQL2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import MVC_MYSQL2.Vista;

public class Controlador {
	private Connection conn; //para conectar con la base de datos
	//asociacion
	private ArrayList<Proveedores> listaProveedores;
	private Vista vista;
	
	public Controlador(Vista vista) {
		this.vista=vista;
		listaProveedores=new ArrayList<>();
		
	try {
		conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/empresa1","root","");
		System.out.println("Conexion correcta");
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}
		 
	    public void cargarClientes() {  //metodo
	        try {
	            String sql = "SELECT * FROM Cliente";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ResultSet rs = ps.executeQuery();
	            //aqui estamos creando un objeto por cada registro.
	            while (rs.next()) {
	                Proveedores p = new Proveedores(
	                        rs.getInt("id"), 
	                        rs.getString("nombre"),
	                        rs.getInt("telefono"),
	                        rs.getString("email")
	                       
	                        
	                );
	                //cada objeto nuevo lo añadimos a listaclientes
	                listaProveedores.add(p);  //array creado aqui se añaden
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    public void mostrarProveedores() {
	        vista.mostrarProveedores(listaProveedores);
	    }

	}

