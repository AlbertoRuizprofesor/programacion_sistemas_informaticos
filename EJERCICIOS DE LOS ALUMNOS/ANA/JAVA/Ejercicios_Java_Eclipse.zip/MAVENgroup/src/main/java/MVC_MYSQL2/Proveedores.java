package MVC_MYSQL2;

public class Proveedores {
	private int id;
	private String nombre;
	private int telefono;
	private String email;
	
	public Proveedores(int id, String nombre, int telefono, String email) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.telefono = telefono;
		this.email = email;
		
		
		}
		public Proveedores(Vista vista) {
		// TODO Auto-generated constructor stub
	}
		public int getId() {
		return id;
		
		}
		public String getNombre() {
		return nombre;
		
		}
		public int getTelefono() {
		return telefono;
		
		}
		public String getEmail() {
		return email;
		
		}
		public void mostrarProveedores() {
			// TODO Auto-generated method stub
			
		}
		public void cargarProveedores() {
			// TODO Auto-generated method stub
			
		}
	
	
	}
	


