package MVC_MYSQL2;

import MVC_MYSQL2.Proveedores;
import MVC_MYSQL2.Vista;

public class Proveedores_Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Vista vista = new Vista();
	Proveedores proveedores = new Proveedores(vista);
	
	Proveedores p = null;
	p.cargarProveedores();
	p.mostrarProveedores();

	}
}
