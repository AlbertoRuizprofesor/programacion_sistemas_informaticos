package MVC_MYSQL2;
import java.util.ArrayList;

import MVC_MYSQL.Clientes;

public class Vista {

    public void mostrarProveedores(ArrayList<Proveedores> listaProveedores) {
        System.out.println("Listado de Proveedores");
       
		for (Proveedores p : listaProveedores) {
            System.out.println(
                "ID: " + p.getId()
                + " | NIF: " + p.getNombre()
                + " | Nombre: " + p.getNombre()
                + " | Telefono: " + p.getTelefono()
                + " | Email: " + p.getEmail()
            );
        }
    }
}
