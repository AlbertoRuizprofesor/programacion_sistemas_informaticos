package SERIALIZACION;

import java.io.Serializable;

public class SerializarArraylist implements Serializable{
	private int codigo;
	private String nombre;
	private String precio;
	
	public SerializarArraylist(int codigo, String nombre, String precio) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.precio = precio;
	}
	@Override
	public String toString() {		
		return "Videojuegos1 [codigo=" + codigo + ", nombre=" + nombre + ", precio=" + precio + "]";
	}

}




	


