package SERIALIZACION;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Videojuego1 {
	

		public Videojuego1(String string, String string2) {
		// TODO Auto-generated constructor stub
	}

		public static void main(String[] args) {
		// TODO Auto-generated method stub
		//crear array
		ArrayList<Videojuego1> videojuego1=new ArrayList<>();
		ArrayList<Videojuego1> videojuego2=new ArrayList<>();
		ArrayList<Videojuego1> videojuego3=new ArrayList<>();
		
		videojuego1.add(new Videojuego1 ("Resident evil","80 euros"));
		videojuego2.add(new Videojuego1 ("Overwatch","60 euros"));
		videojuego3.add(new Videojuego1 ("Assassins Creed","80 euros"));
		
		// Serializar el objeto
	     try {
	    	 
	      FileOutputStream archivoSalida = new FileOutputStream ("c:\\videojuegos\\videojuegos22.ser");
	      ObjectOutputStream objetoSalida = new ObjectOutputStream (archivoSalida);
	      objetoSalida.writeObject(videojuego1);
	      objetoSalida.close();
	      archivoSalida.close();
	         
	         System.out.println("Objeto serializado correctamente.");
	         
	     } catch (IOException e) {
	         e.printStackTrace();
	     }
	 
    // Deserializar el objeto
    try {
   	 
        FileInputStream archivoEntrada = new FileInputStream ("c:\\videojuegos\\videojuegos22.ser");
        ObjectInputStream objetoEntrada = new ObjectInputStream (archivoEntrada);
        ArrayList<Videojuego1> videojuegosDeserializada = (ArrayList<Videojuego1>) objetoEntrada.readObject();
        objetoEntrada.close();
        archivoEntrada.close();
        
        System.out.println("Objeto deserializado correctamente.");
		System.out.println(videojuegosDeserializada);
        
    } catch (IOException | ClassNotFoundException e) {
        e.printStackTrace();
    	}

	}

}



