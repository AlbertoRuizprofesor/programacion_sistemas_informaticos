package SERIALIZACION;

import java.io.*;

public class Videojuegos implements Serializable {
	
	private int codigo;
	private String nombre;
	private double precio;
	
	public Videojuegos (int codigo, String nombre, double d) {
		this.codigo=codigo;
		this.nombre=nombre;
		this.precio=d;
	}

	public Videojuegos(String string, String string2) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Videojuegos [codigo=" + codigo + ", nombre=" + nombre + ", precio=" + precio + "]";
		
		}
	}
	public class Videojuego1 {
	public Videojuego1(int i, String string, double d) {
		// TODO Auto-generated constructor stub
	}

    // Método main
    public static void main(String[] args) {

        // Crear objeto
        Videojuegos videojuego = new Videojuegos(1, "Resident Evil 9 Requiem", 80.0);

        // SERIALIZAR
        try {
            FileOutputStream archivoSalida = new FileOutputStream("c:\\prueba\\videojuegos.ser");
            ObjectOutputStream objetoSalida = new ObjectOutputStream(archivoSalida);

            objetoSalida.writeObject(videojuego); // Guardar objeto

            objetoSalida.close();
            archivoSalida.close();

            System.out.println("Objeto serializado correctamente");

        } catch (IOException e) {
            e.printStackTrace();
        }

        // DESERIALIZAR
        try {
            FileInputStream archivoEntrada = new FileInputStream("c:\\prueba\\videojuegos.ser");
            ObjectInputStream objetoEntrada = new ObjectInputStream(archivoEntrada);

            Videojuegos videojuegoLeido = (Videojuegos) objetoEntrada.readObject();

            objetoEntrada.close();
            archivoEntrada.close();

            System.out.println("Objeto deserializado correctamente");
            System.out.println(videojuegoLeido);

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
	
	
	
