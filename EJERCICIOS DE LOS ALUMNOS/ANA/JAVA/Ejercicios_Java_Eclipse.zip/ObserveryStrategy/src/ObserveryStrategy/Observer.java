package ObserveryStrategy;

public interface Observer {
	void actualizar(int cantidadVendida);
	}


