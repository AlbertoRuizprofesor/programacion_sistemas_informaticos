/**
 * 
 */
/**
 * 
 */
module ObserveryStrategy {
}