package Prototype2;

interface Ordenador extends Cloneable {
		Ordenador clonar();
		void especificaciones();
		
		}

