package Prototype2;

public class OrdenadorSobremesa implements Ordenador{

		private String procesador;
		private int ram;
		int almacenamiento;
		private String placabase;
		private String tarjetagrafica;


		public OrdenadorSobremesa(String procesador, int ram, int almacenamiento,String placabase, String tarjetagrafica) {
		   this.procesador = procesador;
		   this.ram = ram;
		   this.almacenamiento = almacenamiento;
		   this.placabase = placabase;
		   this.tarjetagrafica = tarjetagrafica;
		}

		// Constructor de copia para clonar el ordenador de sobremesa
		public OrdenadorSobremesa(OrdenadorSobremesa otroOrdenador) {
		   this.procesador = otroOrdenador.procesador;
		   this.ram = otroOrdenador.ram;
		   this.almacenamiento = otroOrdenador.almacenamiento;
		   this.placabase = otroOrdenador.placabase;
		   this.tarjetagrafica = otroOrdenador.tarjetagrafica;
		}

		@Override
		public OrdenadorSobremesa clonar() {
		   return new OrdenadorSobremesa(this);
		}

		@Override
		public void especificaciones() {
		   System.out.println("Especificaciones del ordenador de sobremesa:");
		   System.out.println("Procesador: " + procesador);
		   System.out.println("RAM: " + ram + "GB");
		   System.out.println("Almacenamiento: " + almacenamiento + "GB");
		   System.out.println("Placabase: " + placabase);
		   System.out.println("Tarjetagrafica: " + tarjetagrafica + "GPU");
		}
	}

