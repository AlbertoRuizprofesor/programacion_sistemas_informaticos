package Singleton2;

public class EjercicioSinSingleton2 {
	
	    private String talla;
	    private String color;
	    private String tipo;
	    private double precio;

	    public EjercicioSinSingleton2(String talla, String color, String tipo, double precio) {
	        this.talla = talla;
	        this.color = color;
	        this.tipo = tipo;
	        this.precio = precio;
	    }

	    public void mostrarDetalles() {
	        System.out.println("Prenda: " + tipo);
	        System.out.println("Talla: " + talla);
	        System.out.println("Color: " + color);
	        System.out.println("Precio: $" + precio);
	    }

	    public static void main(String[] args) {
	        // Crear dos instancias diferentes
	        EjercicioSinSingleton2 ejemplo1 = new EjercicioSinSingleton2("L", "VERDE", "Pantalón", 40.00);
	        EjercicioSinSingleton2 ejemplo2 = new EjercicioSinSingleton2("S", "ROJO", "Camiseta", 20.00);

	        // Mostrar detalles
	        System.out.println("Ejemplo 1:");
	        ejemplo1.mostrarDetalles();
	        System.out.println();

	        System.out.println("Ejemplo 2:");
	        ejemplo2.mostrarDetalles();
	        System.out.println();

	        // Comparar referencias
	        if (ejemplo1 == ejemplo2) {
	            System.out.println("Es la misma instancia");
	        } else {
	            System.out.println("Son instancias diferentes. Ejemplo1: " + ejemplo1 + 
	                               " Ejemplo2: " + ejemplo2);
	        }
	    }
	}


