package Singleton2;

//EJERCICIO 12º
//Referente a ROPA
//Talla, color, tipo, precio
//Ejemplo1 (“L”,”VERDE”,”PANTALON”,40.00)
//Ejemplo 2(“L”,”ROJO”,”CAMISA MANGA LARGA”,40.00)

public class Singleton2 {
	
	   private String talla;
	    private String color;
	    private String tipo;
	    private double precio;

	    // 1️⃣ Instancia privada estática (única)
	    private static Singleton2 instanciaUnica;

	    // 2️⃣ Constructor privado para que nadie pueda usar 'new' desde fuera
	    private Singleton2 (String talla, String color, String tipo, double precio) {
	        this.talla = talla;
	        this.color = color;
	        this.tipo = tipo;
	        this.precio = precio;
	    }

	    // 3️⃣ Método público para obtener la instancia
	    public static Singleton2 getInstance(String talla, String color, String tipo, double precio) {
	        if (instanciaUnica == null) {
	            instanciaUnica = new Singleton2 (talla, color, tipo, precio);
	        }
	        return instanciaUnica;
	    }

	    // Método para mostrar los detalles
	    public void mostrarDetalles() {
	        System.out.println("Prenda: " + tipo);
	        System.out.println("Talla: " + talla);
	        System.out.println("Color: " + color);
	        System.out.println("Precio: $" + precio);
	    }

	    public static void main(String[] args) {
	        // Intentamos crear dos "instancias"
	        Singleton2 ejemplo1 = Singleton2.getInstance("L", "VERDE", "Pantalón", 40.00);
	        Singleton2 ejemplo2 = Singleton2.getInstance("S", "ROJO", "Camiseta", 20.00);

	        System.out.println("Ejemplo 1:");
	        ejemplo1.mostrarDetalles();
	        System.out.println();

	        System.out.println("Ejemplo 2:");
	        ejemplo2.mostrarDetalles();
	        System.out.println();

	        // Comprobamos si son la misma instancia
	        if (ejemplo1 == ejemplo2) {
	            System.out.println("Es la misma instancia");
	        } else {
	            System.out.println("Son instancias diferentes");
	        }
	    }
	}




