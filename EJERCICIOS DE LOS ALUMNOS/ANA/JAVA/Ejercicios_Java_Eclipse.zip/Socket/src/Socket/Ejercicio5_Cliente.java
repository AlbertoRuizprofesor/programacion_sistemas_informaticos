package Socket;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;

public class Ejercicio5_Cliente {


	    public static void main(String[] args) {

	        try {
	            // Conectar al servidor
	            Socket cliente = new Socket("localhost", 12345);
	            System.out.println("Conectado al servidor.");
	          

	            // Leer mensaje del servidor
	            BufferedReader entrada = new BufferedReader(
	                    new InputStreamReader(cliente.getInputStream())
	            );

	            String mensaje = entrada.readLine();
	            System.out.println(mensaje);

	            // Cerrar conexión
	            entrada.close();
	            cliente.close();

	            System.out.println("Conexión cerrada.");

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}


