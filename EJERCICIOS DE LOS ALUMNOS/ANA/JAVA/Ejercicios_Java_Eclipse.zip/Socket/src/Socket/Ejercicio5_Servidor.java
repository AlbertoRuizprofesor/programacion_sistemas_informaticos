package Socket;


	

	import java.io.PrintWriter;
	import java.net.ServerSocket;
	import java.net.Socket;
	import java.time.LocalTime;

	
	public class Ejercicio5_Servidor {
		
	    public static void main(String[] args) {

	        try {
	            // Crear servidor en el puerto 12345
	            ServerSocket servidor = new ServerSocket(12345);
	            System.out.println("Servidor iniciado en puerto 12345...");

	            // Esperar conexión del cliente
	            Socket cliente = servidor.accept();
	            System.out.println("Cliente conectado: " + cliente.getInetAddress());

	            // Obtener la hora actual
	            LocalTime horaActual = LocalTime.now();

	            // Enviar la hora al cliente
	            PrintWriter salida = new PrintWriter(cliente.getOutputStream(), true);
	            salida.println("Hora actual del servidor: " + horaActual);

	            // Cerrar conexiones
	            salida.close();
	            cliente.close();
	            servidor.close();

	            System.out.println("Conexión cerrada.");

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}


