package Socket;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Ejercicio7_Cliente {
	

    public static void main(String[] args) {

        try {
            // Conectar al servidor
            Socket cliente = new Socket("localhost", 6789);
            System.out.println("Conectado al servidor del 6789.");
            
            //Enviar operacion al servidor 
            OutputStream salida = cliente.getOutputStream();
            PrintWriter escritor = new PrintWriter (salida, true);
            escritor.println("5+3");
            
            // Leer el resultado enviado por el servidor 
            BufferedReader entrada = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
            String mensaje = entrada.readLine();
            System.out.println("Mensake del servidor" + mensaje);

            String mensaje1 = entrada.readLine();
            System.out.println(mensaje1);

            // Cerrar conexión
            entrada.close();
            cliente.close();

            System.out.println("Conexión cerrada.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
