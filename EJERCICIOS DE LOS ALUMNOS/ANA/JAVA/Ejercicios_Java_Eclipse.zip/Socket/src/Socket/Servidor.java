package Socket;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

	    public static void main(String[] args) {
	        try {
	            // Crear un socket servidor en el puerto 12345
	            ServerSocket servidor = new ServerSocket(12345);
	            System.out.println("Servidor iniciado y escuchando en el puerto 12345...");

	            // Esperar conexión de un cliente
	            Socket cliente = servidor.accept();
	            System.out.println("Cliente conectado: " + cliente.getInetAddress());
	            System.out.println("El Puerto es:  "+cliente.getLocalPort());
	      
	            // Enviar un mensaje de bienvenida al cliente
	            OutputStream salida = cliente.getOutputStream();
	            //System.out.println("El Host es:  "+cliente.getLocalPort());
	            PrintWriter escritor = new PrintWriter(salida, true);
	            escritor.println("¡Bienvenido al servidor!");

	            // Cerrar conexiones
	            escritor.close();
	            cliente.close();
	            servidor.close();
	            System.out.println("Conexión cerrada.");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}


