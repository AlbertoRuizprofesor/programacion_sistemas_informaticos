/**
 * 
 */
/**
 * 
 */
module Socket {
}