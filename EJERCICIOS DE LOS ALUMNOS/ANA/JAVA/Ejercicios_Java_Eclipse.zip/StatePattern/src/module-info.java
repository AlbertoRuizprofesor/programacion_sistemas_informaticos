/**
 * 
 */
/**
 * 
 */
module StatePattern {
}