package Estrategia;

public class ContextoPago {
	private EstrategiaPago estrategiaPago;
	
	public ContextoPago(EstrategiaPago estrategiaPago) {
	
}

	public void pagar(double cantidad) {
		estrategiaPago.pagar(cantidad);
	}
}