package Estrategia;

public interface EstrategiaPago {
	void pagar(double cantidad);

}
