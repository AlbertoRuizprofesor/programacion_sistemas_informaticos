package Estrategia;

public class Main {
	
	public static void main(String[] args) {
		
		EstrategiaPago estrategiaTarjeta = new PagoTarjetaCredito(" 1234 5678 3456", "12/25", "123");
	
		EstrategiaPago estrategiaPaypal = new PagoPaypal("ana@gmail.com", "1234");
		
		ContextoPago contexto = new ContextoPago(estrategiaTarjeta);
		contexto.pagar(100.0);
		
		contexto = new ContextoPago(estrategiaPaypal);
		contexto.pagar(50.0);
		
		
	
	}
	

}
