package Estrategia;

public class PagoPaypal implements EstrategiaPago{
	private String correo;
	private String contraseña;
	
	public PagoPaypal( String correo, String contraseña) {
		
		this.correo = correo;
		this.contraseña = contraseña;
		
	}

	@Override
	public void pagar(double cantidad) {
		
		System.out.println("Pagando " + cantidad + "€ usando Paypal: " + correo);
		
	}
	
}


