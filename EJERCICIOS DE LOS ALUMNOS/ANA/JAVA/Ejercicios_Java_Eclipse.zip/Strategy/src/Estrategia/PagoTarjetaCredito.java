package Estrategia;

public class PagoTarjetaCredito implements EstrategiaPago{
	private String numeroTarjeta;
	private String fechaCaducida;
	private String cvv;
	
	public PagoTarjetaCredito(String numeroTarjeta, String fechaCaducidad, String cvv) {
		
	}

	@Override
	public void pagar(double cantidad) {
	System.out.println("Pagado" + cantidad + "€ con tarjeta de crédito: " + numeroTarjeta);
		
	}
	
}
	

