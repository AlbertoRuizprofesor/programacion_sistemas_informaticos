/**
 * 
 */
/**
 * 
 */
module Strategy {
}