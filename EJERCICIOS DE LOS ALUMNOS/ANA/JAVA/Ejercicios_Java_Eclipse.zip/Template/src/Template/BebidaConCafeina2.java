package Template;

public class BebidaConCafeina2 {
	
	    void preparar() {
	        System.out.println("Remojando el té");
	    }

	    void agregarCondimentos() {
	        System.out.println("Agregando limón");
	    }
	}


