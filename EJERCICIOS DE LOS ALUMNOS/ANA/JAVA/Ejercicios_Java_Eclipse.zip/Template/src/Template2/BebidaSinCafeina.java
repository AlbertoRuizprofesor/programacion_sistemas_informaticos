package Template2;

public abstract class BebidaSinCafeina {
	
	public final void prepararReceta() {
		hervirAgua();
		preparar();
		servirEnTaza();
		agregarCondimentos();
	}
		
	public void hervirAgua() {
	

	}
	
	public void servirEnTaza() {
		System.out.println("Sirviendo en la taza");
		
	}
	
	abstract void preparar();
	abstract void agregarCondimentos();
}
