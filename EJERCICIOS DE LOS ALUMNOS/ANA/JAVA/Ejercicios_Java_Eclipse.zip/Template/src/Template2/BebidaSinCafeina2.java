package Template2;

public class BebidaSinCafeina2 {

void preparar() {
		System.out.println("poniendo bolsita de Roibos");
}

void agregarCondimentos() {
		System.out.println("Agregando azúcar");
	}
}
