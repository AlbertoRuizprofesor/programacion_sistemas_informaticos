package Template2;

public class EjemploPatronMetodoPlantilla {
	  public static void main(String[] args) {
	        BebidaSinCafeina RoibosVainilla = new RoibosVainilla();
	        RoibosVainilla.prepararReceta(); // Prepara el té siguiendo los pasos de la receta

	        BebidaSinCafeina Manzanilla = new Manzanilla();
	        Manzanilla.prepararReceta(); // Prepara el café siguiendo los pasos de la receta
	    }
	}


