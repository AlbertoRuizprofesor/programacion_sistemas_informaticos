package Template2;

import Template.BebidaConCafeina;

public class Manzanilla extends BebidaSinCafeina {
	    void preparar() {
	        System.out.println("Remojando la manzanilla");
	    }

	    void agregarCondimentos() {
	        System.out.println("Agregando azucar");
	    }
	}

