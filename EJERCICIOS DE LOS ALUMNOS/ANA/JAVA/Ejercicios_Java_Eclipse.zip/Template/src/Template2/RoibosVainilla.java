package Template2;

public class RoibosVainilla  extends BebidaSinCafeina{

	@Override
	void preparar() {
		System.out.println("Filtrando el roibosvainilla");
		// TODO Auto-generated method stub
		
	}

	@Override
	void agregarCondimentos() {
		System.out.println("Agregando azúcar");
		// TODO Auto-generated method stub
		
	}

}
