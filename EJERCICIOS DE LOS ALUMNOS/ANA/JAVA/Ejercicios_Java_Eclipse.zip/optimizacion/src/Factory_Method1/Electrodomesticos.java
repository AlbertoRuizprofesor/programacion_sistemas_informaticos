package Factory_Method1;

public class Electrodomesticos implements Productos {

    @Override
    public void venta() {
        System.out.println("Venta de electrodoméstico.");
    }
}

