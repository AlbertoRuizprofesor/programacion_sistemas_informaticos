package Factory_Method1;


public abstract class Fabrica {

    public abstract Productos crearProducto();

}