package Factory_Method1;
public class Fabrica_Electrodomesticos extends Fabrica {

    @Override
    public Productos crearProducto() {
        return new Electrodomesticos();
    }
}