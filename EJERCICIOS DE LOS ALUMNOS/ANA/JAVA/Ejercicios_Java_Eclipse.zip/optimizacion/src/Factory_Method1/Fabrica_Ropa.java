package Factory_Method1;


public class Fabrica_Ropa extends Fabrica {

    @Override
    public Productos crearProducto() {
        return new Ropa();
    }
}