package Factory_Method1;

public class Fabrica_Vehiculo  extends Fabrica{
	  @Override
	    public Productos crearProducto() {
	        return new Vehiculos();
	    }
	}


