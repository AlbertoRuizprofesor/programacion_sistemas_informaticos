package Factory_Method1;


public class Main {

    public static void main(String[] args) {

        Fabrica fabricaElectrodomesticos = new Fabrica_Electrodomesticos();
        Productos electrodomestico = fabricaElectrodomesticos.crearProducto();
        electrodomestico.venta();

        Fabrica fabricaRopa = new Fabrica_Ropa();
        Productos ropa = fabricaRopa.crearProducto();
        ropa.venta();
        
        Fabrica fabriVehiculo = new Fabrica_Vehiculo();
        Productos vehiculos = fabriVehiculo.crearProducto();
        vehiculos.venta();
    }
}

