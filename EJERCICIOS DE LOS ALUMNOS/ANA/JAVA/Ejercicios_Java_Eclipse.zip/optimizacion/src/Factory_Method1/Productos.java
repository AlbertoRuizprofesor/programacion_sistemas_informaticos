package Factory_Method1;

public interface Productos {
    void venta();
}
