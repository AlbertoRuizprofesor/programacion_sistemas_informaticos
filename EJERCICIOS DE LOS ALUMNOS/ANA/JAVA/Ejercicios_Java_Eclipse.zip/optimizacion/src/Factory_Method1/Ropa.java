package Factory_Method1;


public class Ropa implements Productos {

    @Override
    public void venta() {
        System.out.println("Venta de ropa.");
    }
}