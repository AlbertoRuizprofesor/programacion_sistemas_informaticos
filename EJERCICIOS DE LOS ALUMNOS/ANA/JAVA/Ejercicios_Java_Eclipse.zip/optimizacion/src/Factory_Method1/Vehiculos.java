package Factory_Method1;

public  class Vehiculos implements Productos{
	
	@Override
	    public void venta() {
	        System.out.println("Venta de vehiculo.");
	    }
	}
