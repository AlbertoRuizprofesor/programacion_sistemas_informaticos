package Factory_Method2;

import Factory_Method1.Productos;

public class Alumnos {
	public class Personas implements Productos {

	    @Override
	    public void venta() {
	        System.out.println("Venta de electrodoméstico.");
	    }
	}



}
