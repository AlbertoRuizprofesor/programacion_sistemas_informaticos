package Factory_Method2;

public abstract class Fabrica {
	
	public abstract Personas crearPersonas();
}