package Factory_Method2;

public class Fabrica_Alumno {

}
