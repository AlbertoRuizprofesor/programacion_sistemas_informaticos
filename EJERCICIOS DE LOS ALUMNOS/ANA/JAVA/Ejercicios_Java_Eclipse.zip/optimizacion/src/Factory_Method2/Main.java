package Factory_Method2;

import Factory_Method1.Fabrica;
import Factory_Method1.Fabrica_Electrodomesticos;
import Factory_Method1.Fabrica_Ropa;
import Factory_Method1.Fabrica_Vehiculo;
import Factory_Method1.Productos;

public class Main {
	  public static void main(String[] args) {

	        Fabrica fabricaElectrodomesticos = new Fabrica_Electrodomesticos();
	        Productos electrodomestico = fabricaElectrodomesticos.crearProducto();
	        electrodomestico.venta();

	        Fabrica fabricaRopa = new Fabrica_Ropa();
	        Productos ropa = fabricaRopa.crearProducto();
	        ropa.venta();
	        
	        Fabrica fabriVehiculo = new Fabrica_Vehiculo();
	        Productos vehiculos = fabriVehiculo.crearProducto();
	        vehiculos.venta();
	    }
	}


