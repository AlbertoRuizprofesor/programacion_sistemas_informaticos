package Factory_Method2;

public class Profesores {

}
