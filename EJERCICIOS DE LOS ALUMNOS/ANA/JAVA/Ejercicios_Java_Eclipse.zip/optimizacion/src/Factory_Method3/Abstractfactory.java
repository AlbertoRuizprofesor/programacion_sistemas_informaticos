package Factory_Method3;

public class Abstractfactory {
	interface Silla{
		void describir();
	
	}
	
	interface Sofa {
		void describir();
	}
	
	
}
