package Factory_Method3;

public interface FabricaMuebles {
	
	    Silla crearSilla();
	    Sofa crearSofa();
		
	}


