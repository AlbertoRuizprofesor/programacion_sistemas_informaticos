package Factory_Method3;

class FabricaMueblesVictorianos implements FabricaMuebles {
	    @Override
	    public Silla crearSilla() {
	        return new SillaVictoriana();
	    }

	    @Override
	    public Sofa crearSofa() {
	        return new SofaVictoriano();
	    }
	}



