package Factory_Method3;

interface Mesa {
	void describir();

}
