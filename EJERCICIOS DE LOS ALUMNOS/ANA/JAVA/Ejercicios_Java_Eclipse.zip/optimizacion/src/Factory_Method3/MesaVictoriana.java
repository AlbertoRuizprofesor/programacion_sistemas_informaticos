package Factory_Method3;

public class MesaVictoriana {

}
