package Factory_Method3;

interface Silla{
	void describir();

}
