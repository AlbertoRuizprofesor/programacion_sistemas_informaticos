package Factory_Method3;

class SillaVictoriana implements Silla {
    @Override
    public void describir() {
        System.out.println("Esta es una silla victoriana.");
    }
}




