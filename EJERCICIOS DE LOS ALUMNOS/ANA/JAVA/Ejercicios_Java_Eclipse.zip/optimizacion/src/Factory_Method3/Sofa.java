package Factory_Method3;


	interface Sofa{
		void describir();


	}
