package Factory_Method3;

class SofaModerno implements Sofa {
	    public void describir() {
	        System.out.println("Este es un sofá moderno.");
	    }
	}



