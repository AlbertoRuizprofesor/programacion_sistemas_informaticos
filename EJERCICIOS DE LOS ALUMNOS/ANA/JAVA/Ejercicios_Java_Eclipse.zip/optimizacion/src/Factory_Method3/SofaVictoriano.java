package Factory_Method3;

class SofaVictoriano implements Sofa {
    @Override
    public void describir() {
        System.out.println("Este es un sofá victoriano.");
    }
}


