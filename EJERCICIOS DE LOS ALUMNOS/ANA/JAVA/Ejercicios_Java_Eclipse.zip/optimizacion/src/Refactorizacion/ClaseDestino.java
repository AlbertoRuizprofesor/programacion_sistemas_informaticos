package Refactorizacion;

public class ClaseDestino {
	
	public static void main(String[] args) {
	        ClaseOrigen origen = new ClaseOrigen();
	        origen.metodoOrigen();
	    }
	}

	


