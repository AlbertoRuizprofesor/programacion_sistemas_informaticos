package Refactorizacion;

public class ClaseDestino2 {
	public class ClaseDestino {
	    public void metodoDestino() {
	        System.out.println("Este es el método de la clase de destino");
	    }
	}
}