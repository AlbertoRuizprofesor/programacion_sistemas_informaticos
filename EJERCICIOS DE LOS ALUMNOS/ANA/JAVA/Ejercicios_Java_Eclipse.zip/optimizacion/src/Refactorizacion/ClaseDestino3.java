package Refactorizacion;

public class ClaseDestino3 {
	    public static void main(String[] args) {
	        ClaseOrigen2 origen = new ClaseOrigen2();
	        System.out.println("Dato en ClaseDestino antes del movimiento: " + origen.dato);
	        origen.metodoOrigen();
	    }
	}


