package Refactorizacion;

public class ClaseOrigen {
	public void metodoOrigen() {
	        System.out.println("Este es el método de la clase de origen");
	    }
	}


