package Refactorizacion;

public class ClaseOrigen2 {
	    int dato = 5;

	    public void metodoOrigen() {
	        System.out.println("Dato en ClaseOrigen2: " + dato);
	    }
	}

