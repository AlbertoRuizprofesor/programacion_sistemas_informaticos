package Refactorizacion;

public class CuentaBancaria {
	    private double saldo;

	    public CuentaBancaria(double saldoInicial) {
	        this.saldo = saldoInicial;
	    }

	    public void realizarRetiro(double cantidad) {
	        if (cantidad > saldo) {
	            System.out.println("Saldo insuficiente");
	        } else {
	            saldo -= cantidad;
	            System.out.println("Retiro exitoso de " + cantidad + " unidades");
	            System.out.println("Saldo restante: " + saldo);
	        }
	    }

	    public static void main(String[] args) {
	        CuentaBancaria cuenta = new CuentaBancaria(1000.0);
	        cuenta.realizarRetiro(500.0);
	    }
	}



