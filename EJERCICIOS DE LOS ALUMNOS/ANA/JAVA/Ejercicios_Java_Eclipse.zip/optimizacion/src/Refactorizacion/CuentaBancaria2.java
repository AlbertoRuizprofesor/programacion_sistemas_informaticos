package Refactorizacion;

public class CuentaBancaria2 {
    private double saldo;

    public CuentaBancaria2(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public double getSaldo() {
        return saldo;
    }

    public static void main(String[] args) {
        CuentaBancaria cuenta = new CuentaBancaria(1000.0);
        Transaccion transaccion = new Transaccion(cuenta);
        transaccion.realizarRetiro(500.0);
    }
}

public class Transaccion {

    public Transaccion(CuentaBancaria cuenta) {
        this.cuenta = cuenta;
    }
    public void realizarRetiro(double cantidad) {
        Object cuenta;
		double saldo = cuenta.getSaldo();
        if (cantidad > saldo) {
            System.out.println("Saldo insuficiente");
        } else {
            cuenta.saldo-= cantidad;
            System.out.println("Retiro exitoso de " + cantidad + " unidades");
            System.out.println("Saldo restante: " + cuenta.saldo);
        }
    }
}

