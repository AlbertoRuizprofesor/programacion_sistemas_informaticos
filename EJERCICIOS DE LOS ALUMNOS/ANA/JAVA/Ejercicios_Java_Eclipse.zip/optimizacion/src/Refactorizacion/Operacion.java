package Refactorizacion;

public class Operacion {

	    public static void main(String[] args) {
	        int resultado = sumar(3, 4);
	        System.out.println("El resultado de la suma es: " + resultado);
	    }

	    public static int sumar(int a, int b) {
	        return a + b;
	    }
	}



