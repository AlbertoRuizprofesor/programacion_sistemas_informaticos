package ABTRACTO;

public class Abstraco_electrodomestico {


	public abstract class Abstracto_electrodomesticos {
		private String color;
		private String peso;
		private String marca;
		private String fabricante;
		private double precio;
		

		public Abstracto_electrodomesticos(String color, String peso, String marca, String fabricante, double precio) {
			super();
			this.color = color;
			this.peso = peso;
			this.marca = marca;
			this.fabricante = fabricante;
			this.precio = precio;
		}
		public String getColor() {
			return color;
		}
		public void setColor(String color) {
			this.color = color;
		}
		public String getPeso() {
			return peso;
		}
		public void setPeso(String peso) {
			this.peso = peso;
		}
		public String getMarca() {
			return marca;
		}
		public void setMarca(String marca) {
			this.marca = marca;
		}
		public String getFabricante() {
			return fabricante;
		}
		public void setFabricante(String fabricante) {
			this.fabricante = fabricante;
		}
		public double getPrecio() {
			return precio;
		}
		public void setPrecio(double precio) {
			this.precio = precio;
			}
		abstract void encender();
		abstract void apagar();
		abstract void comprar();
		abstract void devolver();
		
		@Override
		public String toString() {
		    return "Abstracto_lectrodomesticos [color=" + color + ", peso=" + peso + ", marca=" + marca 
		            + ", fabricante=" + fabricante + ", precio=" + precio + "]";
		}

	}

}
