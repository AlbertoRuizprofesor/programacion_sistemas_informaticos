package ABTRACTO;

public class Abstracto_electrodomesticoMain {

}
