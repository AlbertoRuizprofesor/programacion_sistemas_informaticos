package Arraylist;

import java.util.ArrayList;

public class ArraylistExample {

    public static void main(String[] args) {

        ArrayList<Integer> lista = new ArrayList<>();
        ArrayList<String> nombre = new ArrayList<>();

        lista.add(10);
        lista.add(20);
        lista.add(30);

        nombre.add("Ana");
        nombre.add("Noemi");
        nombre.add("Nubia");

        ArrayList<Double> ingresos = new ArrayList<>();

        ingresos.add(1400.00);
        ingresos.add(500.00);
        ingresos.add(200.00);

        System.out.println("La lista sera de tamaño: " + lista.size());
        System.out.println("Lista de nombres: " + nombre);
        System.out.println("Lista de ingresos: " + ingresos);

        for (int list : lista) {
            System.out.println("Mostrar lista: " + list);
        }

        for (String name : nombre) {
            System.out.println("Mostrar nombre: " + name);
        }

        for (double ing : ingresos) {
            System.out.println("Ingresos: " + ing);
        }

        // LLAMADAS A MÉTODOS
        buscar(lista, 30);
        modificar(lista, 20, 99);
    }

    // MÉTODO BUSCAR
    public static void buscar(ArrayList<Integer> numer, int element) {

        if (numer.contains(element)) {
            System.out.println("Encontrado en la posición: " + numer.indexOf(element));
        } else {
            System.out.println("No encontrado... tengo hambre 🍔");
        }
    }

    // MÉTODO MODIFICAR
    public static void modificar(ArrayList<Integer> numer, int element, int cambiar) {

        if (numer.contains(element)) {
            System.out.println("Encontrado " + element + " modificado con " + cambiar);
            numer.set(numer.indexOf(element), cambiar);
            System.out.println(numer);
        } else {
            System.out.println("No encontrado... tengo hambre 🍕");
        }
    }
}


        

