package Arraylist2;
import java.util.ArrayList;

public class Crear_contar_lista {
	
	public static void main(String[] args) {
		
		var nombres = new ArrayList<String>();
		
	nombres.add("Ana");
	nombres.add("Luis");
	nombres.add("Marta");
	nombres.add("Pedro");
	nombres.add("Lucía");
	
	for(String nombres1: nombres);
			System.out.println(nombres);
	
	}
}
