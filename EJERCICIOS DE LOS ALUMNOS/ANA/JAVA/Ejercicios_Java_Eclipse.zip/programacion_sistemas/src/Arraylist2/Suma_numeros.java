package Arraylist2;
import java.util.ArrayList;

public class Suma_numeros {

	public static void main(String[] args) {
		
		ArrayList<Integer> numeros= new ArrayList<Integer>();
	
	
	numeros.add(10);
    numeros.add(20);
    numeros.add(30);
    numeros.add(40);
    numeros.add(50);
    numeros.add(60);
    
	int suma = 0;
	int maximo = numeros.get(0);
	int minimo = numeros.get(0);
	
	for (int num1 : numeros) {
		suma += num1;
		if (num1 > maximo) maximo = num1;
		if (num1 < minimo) minimo = num1;
	}
	
	for (int num : numeros) {
		 
		suma += num;
		
		if (num > maximo) maximo = num;
		if (num < minimo) minimo = num;
	
		
		System.out.println("La suma total es:" + suma);
		System.out.println("Maximo:" + maximo);
		System.out.println("Minimo:" + minimo);
		
		}
	
	}

}
	
