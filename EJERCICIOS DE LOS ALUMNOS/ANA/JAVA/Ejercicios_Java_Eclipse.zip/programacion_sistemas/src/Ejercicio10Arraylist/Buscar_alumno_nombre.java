package Ejercicio10Arraylist;

public class Buscar_alumno_nombre {
	String nombreBuscar = "Luis";
	boolean encontrado = false;

	for (var alumno : alumnos) {
	    if (alumno.getNombre().equals(nombreBuscar)) {
	        System.out.println("Nota: " + alumno.getNota());
	        encontrado = true;
	    }
	}

	if (!encontrado) {
	    System.out.println("Alumno no encontrado");
	}
	(Se necesitarían los getters en la clase)
	public String getNombre() {
	    return nombre;
	}

	public double getNota() {
	    return nota;
	}
