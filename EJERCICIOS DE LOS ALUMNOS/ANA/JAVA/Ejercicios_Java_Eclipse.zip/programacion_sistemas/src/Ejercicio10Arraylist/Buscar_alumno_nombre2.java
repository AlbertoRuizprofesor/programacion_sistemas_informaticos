package Ejercicio10Arraylist;

public class Buscar_alumno_nombre2 {
	
	import java.util.ArrayList;

	public class Buscar_alumno_nombre {

	    public static void main(String[] args) {

	        var alumnos = new ArrayList<Alumno>();

	        alumnos.add(new Alumno("Ana", 7.5));
	        alumnos.add(new Alumno("Luis", 8.0));
	        alumnos.add(new Alumno("Marta", 6.5));

	        String nombreBuscar = "Luis";
	        boolean encontrado = false;

	        for (var alumno : alumnos) {
	            if (alumno.getNombre().equals(nombreBuscar)) {
	                System.out.println("Nota: " + alumno.getNota());
	                encontrado = true;
	            }
	        }

	        if (!encontrado) {
	            System.out.println("Alumno no encontrado");
	        }
	    }
	}

