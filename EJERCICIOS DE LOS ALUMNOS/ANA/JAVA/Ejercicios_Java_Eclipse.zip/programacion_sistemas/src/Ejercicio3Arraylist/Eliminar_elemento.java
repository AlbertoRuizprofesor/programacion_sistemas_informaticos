package Ejercicio3Arraylist;
import java.util.ArrayList;

public class Eliminar_elemento {

  public static void main(String[] args) {
    
    var colores = new ArrayList<String>();

  
    colores.add("rojo");
    colores.add("verde");
    colores.add("amarillo");
    colores.add("azul");
    colores.add("rosa");
   
    System.out.println(colores);
    System.out.println(eliminarcolores(colores));
    
}
  
  public static ArrayList<String> eliminarcolores(ArrayList<String> lista){
     lista.remove("rojo");
     lista.remove("rosa");

     return lista;
  }
}
