package Ejercicio4Arraylist;
import java.util.Scanner;
import java.util.ArrayList;

public class Ejercicio4Arraylist {

	public static void main(String[] args) {
		
		var nombres = new ArrayList<String>();
		var sc= new Scanner(System.in);
		
		nombres.add("Ana");
		nombres.add("Juan");
		nombres.add("Maria");
	
		System.out.print("Introduce el nombre:");
		var buscar = sc.nextLine();
		
		if (nombres.contains(buscar)) {
			System.out.println("El nombre aparece en la lista");
		
		}else {
			System.out.println("No se encuentra en la lista");
			
		}
		if (nombres.indexOf(buscar) != -1) {
			System.out.println("El nombre aparece en la lista y esta en el indice " + nombres.indexOf(buscar));
			

		}
	 
	}

}
