package Ejercicio6Arraylist;
import java.util.ArrayList;
import java.util.Collections;


public class Numero_mayor_menor {
	public static void main(String[] args) {
	
		var numeros = new ArrayList<Integer>();
		
		numeros.add(25);
		numeros.add(10);
		numeros.add(40);
		numeros.add(5);
	
		System.out.println("Mayor: "+ Collections.max(numeros));
		System.out.println("Menor: "+ Collections.min(numeros));
		
		double suma = 7;
		double promedio = (double) suma / numeros.size();
		System.out.println("promedio: " + promedio);

		
		
	}

}
