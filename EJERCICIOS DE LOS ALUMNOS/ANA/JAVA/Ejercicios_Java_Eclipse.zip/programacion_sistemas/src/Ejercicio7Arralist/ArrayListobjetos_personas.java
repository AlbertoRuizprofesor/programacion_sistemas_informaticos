package Ejercicio7Arralist;

import java.util.ArrayList;

public class ArrayListobjetos_personas {

    private String nombre;
    private int edad;

    public ArrayListobjetos_personas(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getNombre() {   // ✅ Getter añadido
        return nombre;
    }

    @Override
    public String toString() {
        return nombre + " - " + edad + " años";
    }

    public static void main(String[] args) {

        var personas = new ArrayList<ArrayListobjetos_personas>();

        personas.add(new ArrayListobjetos_personas("Ana", 25));
        personas.add(new ArrayListobjetos_personas("Luis", 30));
        personas.add(new ArrayListobjetos_personas("Marta", 22));

        // Mostrar lista
        for (var persona : personas) {
            System.out.println(persona);
        }

        // Buscar persona
        String buscar = "Luis";

        for (var persona : personas) {
            if (persona.getNombre().equals(buscar)) {
                System.out.println("Encontrado: " + persona);
            }
        }
    }
}	
