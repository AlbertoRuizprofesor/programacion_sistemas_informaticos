package Ejercicio8Arraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Gestion_notas {
    public static void main(String[] args) {

        var notas = new ArrayList<Double>();
        var sc = new Scanner(System.in);

        for (int i = 0; i < 5; i++) {
            System.out.print("Introduce nota: ");
            notas.add(sc.nextDouble());
        }

        double suma = 0;

        for (var nota : notas) {
            suma += nota;
        }

        double media = suma / notas.size();  // ✅ calculamos media

        System.out.println("Media: " + media);
        System.out.println("Mayor: " + Collections.max(notas));
        System.out.println("Menor: " + Collections.min(notas));

        if (media >= 5) {
            System.out.println("Resultado: Aprobado");
        } else {
            System.out.println("Resultado: Suspenso");
        }
    }
}