package Ejercicio9Arraylist;

import java.util.ArrayList;

public class Alumno_main {

    private String nombre;
    private double nota;

    public Alumno_main(String nombre, double nota) {
        this.nombre = nombre;
        this.nota = nota;
    }

    @Override
    public String toString() {
        return nombre + " - " + nota;
    }

    public static void main(String[] args) {

        var alumnos = new ArrayList<Alumno_main>();

        alumnos.add(new Alumno_main("Ana", 7.5));
        alumnos.add(new Alumno_main("Luis", 8.0));
        alumnos.add(new Alumno_main("Marta", 6.5));

        for (var alumno : alumnos) {
            System.out.println(alumno);
        }
    }
}