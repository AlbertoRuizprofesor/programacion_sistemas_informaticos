package EjerciciosFlowLayout;

	import java.awt.BorderLayout;
	import java.awt.CardLayout;
	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JPanel;

	public class CardLayoutExample2 {

	    public static void main(String[] args) {

	        JFrame frame = new JFrame("CardLayout Example");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(300, 400);

	        JPanel cardPanel = new JPanel(new CardLayout());

	        JPanel card1 = new JPanel();
	        card1.add(new JLabel("Hola para la pantalla 1 en verdad"));

	        JPanel card2 = new JPanel();
	        card2.add(new JLabel("Hola para la pantalla 2 en verdad"));

	        JPanel card3 = new JPanel();
	        card3.add(new JLabel("Hola para la pantalla 3 en verdad"));

	        cardPanel.add(card1, "1");
	        cardPanel.add(card2, "2");
	        cardPanel.add(card3, "3");

	        CardLayout cl = (CardLayout) cardPanel.getLayout();

	        JButton nextButton = new JButton("Next");
	        nextButton.addActionListener(e -> cl.next(cardPanel));

	        JButton prevButton = new JButton("Previous");
	        prevButton.addActionListener(e -> cl.previous(cardPanel));

	        JPanel buttonPanel = new JPanel();
	        buttonPanel.add(prevButton);
	        buttonPanel.add(nextButton);

	        frame.add(cardPanel, BorderLayout.CENTER);
	        frame.add(buttonPanel, BorderLayout.SOUTH);

	        frame.setVisible(true);
	    }
	}

