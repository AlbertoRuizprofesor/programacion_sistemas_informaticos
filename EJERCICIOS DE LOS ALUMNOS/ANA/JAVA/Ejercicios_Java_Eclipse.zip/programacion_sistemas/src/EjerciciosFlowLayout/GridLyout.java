package EjerciciosFlowLayout;
import javax.swing.*;
import java.awt.*;

public class GridLyout {
	

	public static void main(String[] args) {

	        JFrame frame = new JFrame("GridLayout");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(300, 400);

	        frame.setLayout(new BorderLayout());

	        JTextField textField = new JTextField();
	        frame.add(textField, BorderLayout.NORTH);

	        JPanel panel = new JPanel();
	        panel.setLayout(new GridLayout(4, 4, 2, 2));

	        String[] buttons = {
	                "7", "8", "9", "/",
	                "4", "5", "6", "*",
	                "1", "2", "3", "-",
	                "0", "C", "=", "+"
	        };

	        for (String text : buttons) {
	            panel.add(new JButton(text));
	        }

	        frame.add(panel, BorderLayout.CENTER);

	        frame.setVisible(true);
	    }
	}
		
		
		