package Hilo5;

public class BaseDatosDual extends Thread {
	private int notas;
	
	public BaseDatosDual(int notas) {
		this.notas = notas;
		
	}
	
	//getClass().getName() devuelve el nombre del paquete seguido del nombre de la clase en la que estamos
	//Por ej => "Hilo5.BaseDatosDual"
	public void run() {
		double empresa=(notas*20)/100;
		
		System.out.println("La nota de "+ getClass().getName() + " en la empresa es: "+empresa); 
		System.out.println("La nota de "+ getClass().getName() + " el centro de formacion es: "+(notas-empresa));
	}

}
