package Hilo5; 

public class Hilos_Asignaturas {

public static void main(String[] args) {
	
	// Crear y arrancar hilos para cada operación
    // Al no asignar el hilo a una variable podemos ejecutar directamente el hilo 
    // llamando al metodo start() despues de realizar una inicializacion con new
    // por ej new BaseDatosDual(10).start();
    
	// Por el contrario, si tratamos el hilo como una clase normal mas asignada a una variable
    // no podemos ejecutarla directamente desde la asignación, sino que se debe realizar el start() en una
    // linea aparte
    // Por ej
    // BaseDatosDual b = new BaseDatosDual(10); // Variable que contiene un hilo de clase BaseDatosDual con parametro 10
    // b.start(); // Ejecución del hilo
  
    new BaseDatosDual(10).start();
    new Concurrencia(8).start();
    new FundamentosProgramacion(10).start();
    new SeguridadInf(7).start();
    	
    }
}
