package HiloIva;//ESTO ES LA CLASE MAIN

import java.util.Scanner;

public class Hilo_Iva{

public static void main(String[] args) {
	
	Scanner scanner= new Scanner(System.in);
	double importe;
	
	System.out.println("Introduce el importe: ");
	importe=scanner.nextDouble();
	
	Hilo_Iva1 Hilo_Iva1=new Hilo_Iva1(importe);
	Hilo_Iva2 Hilo_Iva2=new Hilo_Iva2(importe);
	Hilo_Iva3 Hilo_Iva3=new Hilo_Iva3(importe);
	
	Hilo_Iva1.setPriority(Thread.MIN_PRIORITY);
	Hilo_Iva2.setPriority(Thread.NORM_PRIORITY);
	Hilo_Iva3.setPriority(Thread.MAX_PRIORITY);
	
	
	scanner.close();

	}

}