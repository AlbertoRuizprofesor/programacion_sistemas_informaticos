package INTERFACESGRAFICAS;

import javax.swing.*;

public class VentanaSimple {
	public static void main (String [] args) {
		JFrame ventana = new JFrame("Mi Ventana");
		ventana.setSize(400,300);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //para que cierra la ventana si le das error
		ventana.setVisible(true);//para que no se creen ventanas ocultas
		}
	
	}


	