package INTERFACESGRAFICAS;
import javax.swing.*;
import java.awt.*;

public class Ventana_localizacion {

	public static void main(String[] args) {
	        JFrame frame = new JFrame("FlowLayout");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(300, 150);
	        JPanel panel = new JPanel(new GridLayout()); 

	        panel.add(new JButton("Uno"), BorderLayout.NORTH);
	        panel.add(new JButton("Dos"),BorderLayout.SOUTH);
	        panel.add(new JButton("Tres"),BorderLayout.EAST);
	        panel.add(new JButton("Cuatro"),BorderLayout.WEST);
	       
	        // frame.setLocationRelativeTo(null); //el mensaje sale en medio de la pantalla
	        
	        frame.add(panel);
	        frame.setVisible(true);
	    }
	}


