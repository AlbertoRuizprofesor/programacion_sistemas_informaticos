package Interface2;

public class Calculadora_Main {
	
	public static void main (String [] args) {
		Calculadora c=new Calculadora();
		c.mostrar(2, 8);
	}

}
