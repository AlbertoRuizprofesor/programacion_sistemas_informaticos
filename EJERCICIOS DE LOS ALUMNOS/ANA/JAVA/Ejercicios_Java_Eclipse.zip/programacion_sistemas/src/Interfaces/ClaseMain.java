package Interfaces;

public class ClaseMain {

	public static void main(String[] args) {
		String nombre="Ana";
		String tipo="Google";
		
		Clientes clientes=new Clientes(nombre);
		Empresa empresa=new Empresa(nombre,tipo);
		
		System.out.println(clientes.enviar_datos(nombre));
		System.out.println(clientes.firmar(nombre));
		System.out.println(clientes.mostrar_datos(nombre));
		System.out.println(clientes.pagar(nombre));
		
	
		Empresa empresa=new Empresa(google,tipo_empresa);
		System.out.println(empresa.mostrar_datos(
				google,tipo_empresa));
		System.out.println(empresa.pagar(
				enterprise));

		
	}
}
