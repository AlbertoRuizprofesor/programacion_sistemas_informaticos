package Interfaces;

public abstract class Clientes implements DatosPersonales, DatosEconomicos {
	private String nombres;
	
	public Clientes(String nombres) {
		this.nombres = nombres;
	}
	public String getNombres() {
		return nombres;
	}
	
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}
	
	@Override
	public String pagar(String nombre) {
		return "Esta pagando "+nombre;
	}
	@Override
	public String enviar_datos(String nombre) {
		
		
		return "Esta enviando datos "+nombre;
	}
	@Override
	public String firmar(String nombre) {
		return "esta firmando "+nombre;
	}
	@Override
	public String mostrar_datos(String nombre) {
		return "Cliente: "+nombre;
	}
	public String mostrar_datos(String nombre, 
			String tipo) {
		return nombre+tipo;
	}

}
