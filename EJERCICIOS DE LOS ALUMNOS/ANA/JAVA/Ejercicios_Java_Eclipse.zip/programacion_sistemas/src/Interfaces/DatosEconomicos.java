package Interfaces;

public interface DatosEconomicos {
	public void mostrasdatoseconomicos();

	String pagar(String nombre);
	
	

}
