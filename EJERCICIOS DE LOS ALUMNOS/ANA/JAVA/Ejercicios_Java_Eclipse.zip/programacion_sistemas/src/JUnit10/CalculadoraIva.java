package JUnit10;

public class CalculadoraIva {
	
		public CalculadoraIva(String string, String string2) {
		// TODO Auto-generated constructor stub
	}

		public static double calcularIVA4(double precio) {
	        return precio * 0.04;
	    }

	    public static double calcularIVA10(double precio) {
	        return precio * 0.10;
	    }

	    public static double calcularIVA21(double precio) {
	        return precio * 0.21;
	    }

	    public static double precioConIVA4(double precio) {
	        return precio + calcularIVA4(precio);
	    }

	    public static double precioConIVA10(double precio) {
	        return precio + calcularIVA10(precio);
	    }

	    public static double precioConIVA21(double precio) {
	        return precio + calcularIVA21(precio);
	    }

		public static double CalculadoraIva(int i) {
			// TODO Auto-generated method stub
			return 0;
		}
	}


