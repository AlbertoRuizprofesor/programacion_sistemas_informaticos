package JUnit10;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class Iva {

  
    @Test
    void testCalcularIVA4() {
        assertEquals(4.0, CalculadoraIva.calcularIVA4(100), 0.00001);
    }
    @Test
    void testCalcularIVA10() {
        assertEquals(20.00, CalculadoraIva.calcularIVA10(200), 0.00001);
    }	
    @Test
    void testCalcularIVA21() {
    assertEquals(10.5, CalculadoraIva.calcularIVA21(50), 0.00001);

    }
}