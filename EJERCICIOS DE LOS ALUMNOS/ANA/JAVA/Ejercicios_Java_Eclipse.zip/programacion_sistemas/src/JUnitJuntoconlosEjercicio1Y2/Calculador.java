package JUnitJuntoconlosEjercicio1Y2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Calculador {
	@Test
    public void testSum() {
         assertEquals(5, Calculadora.suma(2, 3));
     }
	@Test
    public void testRes() {
         assertEquals(3, Calculadora.resta(6, 3));

	}
	@Test
    public void testMulti() {
         assertEquals(6, Calculadora.multi(2, 3));

	}
	@Test
    public void testDivision() {
         assertEquals(3, Calculadora.division(6, 2));
	
	}
	@Test
	public void testPotenciador() {
    Object potenciador;
	assertEquals(3, potenciador.potenciador(6, 2));
    
}
}



