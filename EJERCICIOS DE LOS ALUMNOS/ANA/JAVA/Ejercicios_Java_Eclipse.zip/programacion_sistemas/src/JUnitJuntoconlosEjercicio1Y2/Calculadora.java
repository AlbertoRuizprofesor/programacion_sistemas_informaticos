package JUnitJuntoconlosEjercicio1Y2;

	 public class Calculadora{
	     public static int suma(int a, int b) {
	          return a + b;
	      }
	      public static int resta(int a, int b) {
	          return a - b;
	      }
	      public static int multi(int a, int b) {
	          return a * b;
	     }
	      public static int division(int a, int b) {
	                return a / b;
	     }
	      public static double potencia (double a, double b) {
	    	  return Math.pow(a, b);
	     }
	      public static double raizcuadrada1 (double a) {
	    	  return Math.sqrt(a);
	     }
	      public static double raizcuadrada2 (double b) {
	    	  return Math.sqrt(b);
	      }
	 }
	    
	 



