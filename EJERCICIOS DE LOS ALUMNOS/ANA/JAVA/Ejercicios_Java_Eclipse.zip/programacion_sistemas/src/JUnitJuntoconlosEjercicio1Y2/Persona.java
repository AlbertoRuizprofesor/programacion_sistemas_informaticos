package JUnitJuntoconlosEjercicio1Y2;

public class Persona {


	    private String[] nombres = {"Alberto", "Eva", "Cristina"};

	    public String[] getNombres() {
	        return nombres;
	    }
	    
	}


