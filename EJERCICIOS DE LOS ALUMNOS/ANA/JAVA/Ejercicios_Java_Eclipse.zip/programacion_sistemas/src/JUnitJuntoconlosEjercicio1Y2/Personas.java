package JUnitJuntoconlosEjercicio1Y2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Personas {

	@Test
	void test() {
Persona personas = new Persona();
		
        String[] nombresEsperados = {"Alberto", "Eva", "Cristina"};
        
        String[] nombresObtenidos = personas.getNombres();
       
        assertArrayEquals(nombresEsperados, nombresObtenidos);
	

	}

}
