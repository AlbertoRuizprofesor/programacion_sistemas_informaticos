package Joptionpane;
import javax.swing.JOptionPane;

public class Calculadora {
	 public static void main(String[] args) {
		 int num1 = Integer.parseInt(
	                JOptionPane.showInputDialog("Primer número:"));

	        int num2 = Integer.parseInt(
	                JOptionPane.showInputDialog("Segundo número:"));

	        Object[] opciones = {"+", "-", "*", "/"};

	        int opcion = JOptionPane.showOptionDialog(
	                null,
	                "Elige operación",
	                "Calculadora",
	                0,
	                0,
	                null,
	                opciones,
	                opciones[0]);

	        JOptionPane.showMessageDialog(null,
	                "Resultado: " +
	                (opcion == 0 ? num1 + num2 :
	                 opcion == 1 ? num1 - num2 :
	                 opcion == 2 ? num1 * num2 :
	                 num1 / num2));
	 
	 }

	}
