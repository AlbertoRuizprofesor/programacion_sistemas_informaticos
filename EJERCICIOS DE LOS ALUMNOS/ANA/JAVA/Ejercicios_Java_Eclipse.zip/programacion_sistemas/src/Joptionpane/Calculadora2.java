package Joptionpane;
import javax.swing.JOptionPane;

public class Calculadora2 {
	public static void main(String[] args) {
		
		String result;
		
		int option;
		do {
		option=JOptionPane.showConfirmDialog(null, 
				"opciones", "Desea salir?"
				, JOptionPane.ERROR_MESSAGE);
		
		
		if (option==0) {
			result="si";
			JOptionPane.showMessageDialog(null, 
					"Has pulsado "+result);
			break;
		}else {
			result="no";
			}
		
		JOptionPane.showMessageDialog(null, 
				"Has pulsado "+result);
		}while(option!=0);
		}	
	}


	
	

