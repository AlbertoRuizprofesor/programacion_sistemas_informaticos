package Joptionpane;
import javax.swing.JOptionPane;

public class Hello_world {

    public static void main(String[] args) {
       String int1 = JOptionPane.showInputDialog(null, "introduce un dato: ");
    }
}