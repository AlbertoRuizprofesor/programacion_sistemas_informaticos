package Joptionpane;
import javax.swing.JOptionPane;

public class piedra_papel_tijera<var> {
	String[] option = { "piedra", "papel", "tijera", "spock" };
	
	var selection = JOptionPane.showOptionDialog(null, "seleciona una", "a jugar!", 0, 3, null, options, option[]);
		

}
