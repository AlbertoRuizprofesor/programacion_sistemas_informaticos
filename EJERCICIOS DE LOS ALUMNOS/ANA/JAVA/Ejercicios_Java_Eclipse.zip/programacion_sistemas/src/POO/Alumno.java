package POO;

public class Alumno extends Persona{
	
	public Alumno (String nombre, String apellidos, int edad) {
		super(nombre, apellidos, edad);
		
		
		}

	@Override
	public String toString() {
		return "Alumno "+ super.toString();
		return "Alumn@"+super.getApellidos();int curso;int asignatura;
		+super.getNombre()+" "+super.getEdad()+
		" "+" curso "+curso+" asignatura "+asignatura;
		

	
		}
	}



