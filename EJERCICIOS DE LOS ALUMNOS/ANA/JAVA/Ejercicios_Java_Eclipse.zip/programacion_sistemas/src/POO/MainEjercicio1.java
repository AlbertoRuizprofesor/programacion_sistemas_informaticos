package POO;

public class MainEjercicio1 {
	public static void main(String[] args) {
		Ejercicio1 ejercicio1= new Ejercicio1("Ana Zamora");
		System.out.println(Ejercicio1.toString());
	
	Ejercicio Ejercicio2=new Ejercicio1("Laura", "se fue");
	
	System.out.println(Ejercicio2.toString());
	
		
	}

}
