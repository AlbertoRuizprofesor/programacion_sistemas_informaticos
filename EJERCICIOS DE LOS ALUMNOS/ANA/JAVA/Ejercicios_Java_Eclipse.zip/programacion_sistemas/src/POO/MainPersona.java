package POO;

public class MainPersona {
	public static void main(String[] args) {
		Persona persona=new Persona("Ana","Zamora",29);
		
		System.out.println(persona.toString());
		
	}

}
