package POO;

public class Paladin extends worldofwarcraft{
	private String luz;
	private String fe;
	public Paladin(String vida, String fuerza, String luz, String fe) {
		super(vida, fuerza, fe);
		this.luz = luz;
		this.fe = fe;
	}
	public String getLuz() {
		return luz;
	}
	public void setLuz(String luz) {
		this.luz = luz;
	}
	public String getFe() {
		return fe;
	}
	public void setFe(String fe) {
		this.fe = fe;
	}
	@Override
	public void intelecto() {
		System.out.println("intelecto 30%");
		
	

}
	@Override
	public String toString() {
		return super.toString()+
				"Paladin [luz=" + luz + ", fe=" + fe + "]";
	}
	
}
