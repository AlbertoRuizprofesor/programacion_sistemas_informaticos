package POO;

public class Persona {
	private String nombre;
	private String apellidos;
	private int edad;
	
	public Persona(String nombre, String apellido, int edad) {
		// TODO Auto-generated constructor stub
		
		this.nombre = nombre;
		this.apellidos = apellido;
		this.edad = edad;
		
	}
	public String getNombre() {
	return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	@Override
	public String toString() {
		return "Persona [nombre=" + nombre + ", apellidos=" + apellidos + ", edad=" + edad + ", getNombre()="
				+ getNombre() + ", getApellidos()=" + getApellidos() + ", getEdad()=" + getEdad() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
		
	}
	
}
