package POO;

public class Profesor extends Persona{
		private String asignatura;
		private int salario;
		
	public Profesor(String nombre, String apellidos, int edad, String asignatura, int salario) {
		super(nombre, apellidos, edad);
		this.asignatura = asignatura;
		this.salario = salario;
	
		
	}
	public String getAsignatua() {
		return asignatura;
		
	}
	
	public void getAsignatura(String asignatura) {
		this.asignatura = asignatura;
		
	}
	
	public int  getSalario() {
		return salario;
		
		
	
	}

}
