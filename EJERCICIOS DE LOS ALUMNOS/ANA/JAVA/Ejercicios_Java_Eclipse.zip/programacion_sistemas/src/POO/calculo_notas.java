package POO;

public class calculo_notas {
	public void calculo_notas(int [] nota) { /* int [] nota es una array de enteros, 
											dentro del array puede ir cualquier elemento,es decir, 
											para no repetir una y otra vez systems (solo se meterian 
											valores en un corchete, en este caso seria dentro del propio
											corchete que serian las notas, por ejemplo: 5,7,8,9...)*/
											
		int suma = 0; /*creamos la variable, que sera "suma" 
						y emepezara por 0 y servira para cumular las notas*/
		
		for(int i=0;i<nota.length;i++) { /*int i = 0, la i es una variable de tipo int,
										es decir, solo se usara dentro del bucle "for"
										y como contador, los arrays siempre empezaran desde 0.
										Para i < nota,lengt es la cantidad de elementos, el bucle 
										recorrera toda la array sin salirse.
										i++ aumentara de uno en uno es decir (0,1,2,3...)*/
		
			
			suma+=nota[i]; /* la suma de cada nota 
			 				recoge la nota del array y se añadira
			 				a la suma, se podria hacer de forma distinta, 
							un ejemplo de ello seria: suma = suma + nota [i];
							nota = {5, 7, 9} i = 0 -> suma = 0 +5,*/
							
		}
		System.out.println("la nota media es:"+suma/nota.length); /*la suma contendra la suma total 
																	todas las notas, nota.length seria
																	el numero de notas y suma / nota.lenght 
																	es la media aritmética es decir les la division 
																	de las dos cosas*/
		
		}
	
	}

