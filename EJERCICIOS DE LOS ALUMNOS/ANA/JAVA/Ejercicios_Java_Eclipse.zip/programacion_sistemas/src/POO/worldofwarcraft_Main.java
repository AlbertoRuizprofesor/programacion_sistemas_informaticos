package POO;

public class worldofwarcraft_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		worldofwarcraft t=new worldofwarcraft("maxima vida", "fuerza", null);
		Paladin g=new Paladin("vida","fuerza", "luz cegadora","toque de fe");
		jainavaliente y=new jainavaliente("descarga_escarcha", "elemental_agua","vida","fuerza");
		
		System.out.println(t.toString());
		System.out.println(g.toString());
		System.out.println(y.toString());
		
		t.intelecto();
		g.intelecto();
		y.intelecto();
		

	}

}
