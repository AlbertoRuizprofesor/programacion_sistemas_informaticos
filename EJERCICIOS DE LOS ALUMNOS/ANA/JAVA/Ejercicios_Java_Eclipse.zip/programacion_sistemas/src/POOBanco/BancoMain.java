package POOBanco;

public class BancoMain {

	public static void main(String[] args) {
		
		Banco banco = new Banco("Banco Ana");
		CuentaBancaria cuentaB = new CuentaBancaria("Banco Sandalio", 1000, 5000.32);
		Clientes cliente = new Clientes(cuentaB);
		
		System.out.println(banco);
		System.out.println(cliente);
		
		cliente.mostrardatoscliente();
		

	}

}
