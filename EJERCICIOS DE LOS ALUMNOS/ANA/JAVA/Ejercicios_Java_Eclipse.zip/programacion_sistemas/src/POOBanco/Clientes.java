package POOBanco;

public class Clientes implements DatosCliente {
	
	private CuentaBancaria cuenta;
	
	public Clientes(CuentaBancaria cuenta) {
		this.cuenta = cuenta;
	}

	public CuentaBancaria getCuenta() {
		return cuenta;
	}

	public void setCuenta(CuentaBancaria cuenta) {
		this.cuenta = cuenta;
	}
	
	@Override
	public String toString() {
		return "Cliente - " + this.hashCode();
	}

	@Override
	public void mostrardatoscliente() {
		
		System.out.println("Datos del cliente - " + this.hashCode());
		System.out.println(this.cuenta.toString());
		
	}
	
}
