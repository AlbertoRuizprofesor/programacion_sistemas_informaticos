package POOBanco;

public class CuentaBancaria extends Banco {

	private int numcuenta;
	private double saldo;
	
	public CuentaBancaria(String nombreBanco, int numcuenta, double saldo) {
		super(nombreBanco);
		this.numcuenta = numcuenta;
		this.saldo = saldo;

	}
	
	public int getNumcuenta() {
		return numcuenta;
	}

	public void setNumcuenta(int numcuenta) {
		this.numcuenta = numcuenta;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	@Override
	public String toString() {
		return super.toString() + " CuentaBancaria [numcuenta=" + numcuenta + ", saldo=" + saldo + "]";
	}
	
	

}
