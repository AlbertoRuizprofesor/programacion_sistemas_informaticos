package POOBanco;

public interface DatosCliente {
	
	public void mostrardatoscliente();

}
