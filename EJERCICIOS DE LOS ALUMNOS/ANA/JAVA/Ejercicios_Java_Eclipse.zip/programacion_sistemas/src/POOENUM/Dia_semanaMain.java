package POOENUM;

public class Dia_semanaMain {

    public static void main(String[] args) {
    	
    	final int valor=21; //siempre tiene que haber un valor, no se puede repetir 2
        Dia_semana hoy = Dia_semana.VIERNES;
        System.out.println("Hoy es: " + hoy);
       

    }
}

