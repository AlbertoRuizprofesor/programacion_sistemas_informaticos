package Procesos;

import java.io.IOException;

public class Ejercicio1Proceso {

    public static void main(String[] args) throws IOException, InterruptedException {

        System.out.println("Abrimos el Bloc de notas");

        ProcessBuilder proceso = new ProcessBuilder("C:\\Windows\\System32\\notepad.exe");
        Process p = proceso.start();  // Guardamos el proceso
        p.waitFor();                  // Esperamos a que se cierre

        System.out.println("El bloc de notas se ha detenido");
    }

	
	}