package Procesos;

import java.io.File;
import java.io.IOException;

public class Ejercicio4Procesos {

    public static void main(String[] args)
            throws IOException, InterruptedException {

        // TODO Auto-generated method stub

        ProcessBuilder proceso;
        System.out.println("Abriendo Holaaa");

        proceso = new ProcessBuilder("C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE"
        		,"Holaaa.docx");

        proceso.directory(new File("C:\\Users\\amzjd\\Desktop\\Prueba"));

        Process p = proceso.start();
        p.waitFor();

        System.out.println("El Bloc de notas se ha cerrado");
    }
}



