package Procesos;
import java.io.File;
import java.io.IOException;

public class Ejercicio5Procesos {

public static void main(String[] args)
	            throws IOException, InterruptedException {

	        // TODO Auto-generated method stub

	        ProcessBuilder proceso;
	        System.out.println("Abriendo EJERCICIOS HOLAA");

	        proceso = new ProcessBuilder("C:\\Program Files\\Microsoft Office\\root\\Office16\\POWERPNT.EXE"
	        		,"EJERCICIOS HOLAA.pptx");

	        proceso.directory(new File("C:\\Users\\amzjd\\Desktop\\Prueba"));

	        Process p = proceso.start();
	        p.waitFor();

	        System.out.println("El Bloc de notas se ha cerrado");
	    }
	}


