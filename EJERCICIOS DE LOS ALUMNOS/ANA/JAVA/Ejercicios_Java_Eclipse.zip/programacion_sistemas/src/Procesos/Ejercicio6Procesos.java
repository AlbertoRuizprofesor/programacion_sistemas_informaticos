package Procesos;

import java.io.IOException;

import com.mysql.cj.x.protobuf.MysqlxPrepare.PrepareOrBuilder;

public class Ejercicio6Procesos {
	public static void main(String[] args) throws IOException, InterruptedException {
	
		ProcessBuilder pb = new ProcessBuilder("cmd.exe","c/","netstat" );
				pb.inheritIO();
				pb.start();
		
		
		
	}
}
