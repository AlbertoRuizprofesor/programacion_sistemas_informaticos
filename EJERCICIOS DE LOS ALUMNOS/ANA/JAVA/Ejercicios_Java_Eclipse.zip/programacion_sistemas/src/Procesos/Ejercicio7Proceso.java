package Procesos;
import java.io.IOException;

import com.mysql.cj.x.protobuf.MysqlxPrepare.PrepareOrBuilder;

public class Ejercicio7Proceso {

	
		public static void main(String[] args) throws IOException, InterruptedException {
		
			ProcessBuilder pb = new ProcessBuilder("cmd.exe","c/","netstat");
			ProcessBuilder pb1 = new ProcessBuilder("cmd.exe","c/","ping 8.8.8.8.");
					pb.inheritIO();
					pb.start();
					pb1.inheritIO();
					pb1.start();
					
			
			
			
		}
	}



