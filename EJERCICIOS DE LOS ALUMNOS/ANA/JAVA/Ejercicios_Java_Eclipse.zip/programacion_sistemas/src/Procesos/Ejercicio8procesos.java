package Procesos; //se tiene que hacer un arraylist, bucle for each y un metodo

import java.io.IOException;

public class Ejercicio8procesos {

	public static void main(String[] args) throws IOException, InterruptedException {

        String[] comandos = { "netstat", "ping 8.8.8.8"};
       
        for (String comando : comandos) {
            ProcessBuilder pb = new ProcessBuilder("cmd.exe","c/", comando);
            pb.inheritIO();
            Process p = pb.start();
            p.waitFor();
            
    
        }
	}
}
