package Procesos;
import java.io.IOException;


public class Ejercicio9proceso {

		public static void main(String[] args) throws IOException, InterruptedException {

	        String[] comandos = { "netstat", "ping 8.8.8.8"};
System) {
	            ProcessBuilder pb = new ProcessBuilder("cmd.exe","c/", comando);
	            pb.inheritIO();
	            Process p = pb.start();
	            p.waitFor();
	            
	        
	   }
	}

	public static void main (String[] args) throws IOExceptio {
		ejecutar();
	}
}