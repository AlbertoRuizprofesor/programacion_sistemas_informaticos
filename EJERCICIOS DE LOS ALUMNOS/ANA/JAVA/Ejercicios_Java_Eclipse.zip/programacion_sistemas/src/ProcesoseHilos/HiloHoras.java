package ProcesoseHilos;

public class HiloHoras extends Thread {
	private int dias;
	
	public HiloHoras(int dias) {
		this.dias = dias;
		
}

	@Override
	public void run() {
		
		int horas = dias * 24;
		System.out.println("Horas: " + horas);
		
	}
}
