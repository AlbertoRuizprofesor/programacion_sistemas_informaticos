package ProcesoseHilos;

public class HiloMinutos extends Thread {
	private int dias;
	
	public HiloMinutos(int dias) {
		this.dias = dias;
		
}

	@Override
	public void run() {
		
		int horas = dias * 24;
		int minutos = horas * 60;
		System.out.println("Minutos: " + minutos);
		
	}
}
