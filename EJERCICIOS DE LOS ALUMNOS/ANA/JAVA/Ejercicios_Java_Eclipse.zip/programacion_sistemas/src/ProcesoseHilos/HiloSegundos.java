package ProcesoseHilos;

public class HiloSegundos extends Thread {
	private int dias;
	
	public HiloSegundos(int dias) {
		this.dias = dias;
		
}

	@Override
	public void run() {
		
		int horas = dias * 24;
		int minutos = horas * 60;
		int segundos = minutos * 60;
		System.out.println("Segundos: " + segundos);
		
	}
}
