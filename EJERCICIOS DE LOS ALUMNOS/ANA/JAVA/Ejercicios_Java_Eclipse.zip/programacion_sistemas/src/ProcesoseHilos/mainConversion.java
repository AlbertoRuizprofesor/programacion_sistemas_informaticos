package ProcesoseHilos;

public class mainConversion {

	public static void main(String[] args) {
		
		HiloHoras h = new HiloHoras(28);
		HiloMinutos m = new HiloMinutos(28);
		HiloSegundos s = new HiloSegundos(28);
		
		h.setPriority(Thread.MAX_PRIORITY);
		m.setPriority(Thread.MIN_PRIORITY);
		s.setPriority(Thread.NORM_PRIORITY);
		
		h.start();
		m.start();
		s.start();
		
		
	}

}
