package Sobrecarga;

public class SobrecargaMain {

public static void main(String[] args) {
	
	Sobrecarga sobrecarga=new Sobrecarga("Ana", 29);
	Sobrecarga sobrecarga1=new Sobrecarga("Ana",20);
	Sobrecarga sobrecarga2=new Sobrecarga("Ana");
	
	
	
	sobrecarga.mostrar();
	sobrecarga1.mostrar();
	sobrecarga2.mostrar();

		}
	}
