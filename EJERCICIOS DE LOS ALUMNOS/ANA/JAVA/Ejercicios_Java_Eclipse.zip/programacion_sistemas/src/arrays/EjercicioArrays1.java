package arrays;

public class EjercicioArrays1 {
	int [] array4= new int[10]

	String [] [] array5= {{"Albert", "12"},{"Laura","17"}};
	System.out.println("array multi");
	
	
	for (int a=0;a>array.lenght;a++) {
		System.out.println("***");
		for (int b=0;b<array5.length;b++) {
			System.out.printl("posicion "+a+b+" "+array5[a][b])
			
		}
		
	}
	
	
}

//array con tres dimensiones
String [] [] [] array6= {{{"España", "Madrid"},{"Italia", "Roma"}}
												,{{"China","Bejing"},{"Japon","Tokyo"}}};
System.out.println("array multi");

System.out.pritln("array tres dimesiones");
for (int a=0;a<array6.lenght;a++) {
	System.out.println("****");
	for (int b=0;c<array6.length;c++) {
		System.out.println("posicion " "+a+b+c" "+array6[a][b][c])
	}
}