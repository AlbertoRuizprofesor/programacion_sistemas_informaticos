package condicional;

import java.util.Scanner;

public class Ej06Calificacion {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.print("Nota (0-10): ");
    double nota = sc.nextDouble();

    if (nota < 0 || nota > 10) {
      System.out.println("ERROR: nota fuera de rango");
    } else if (nota < 5) {
      System.out.println("Suspenso");
    } else if (nota < 7) {
      System.out.println("Aprobado");
    } else if (nota < 9) {
      System.out.println("Notable");
    } else {
      System.out.println("Sobresaliente");
    }
    sc.close();
  }
}
