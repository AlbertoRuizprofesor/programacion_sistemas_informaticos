package condicional;

import java.util.Scanner;

public class Ej08DiasMes {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.print("Mes (1-12): ");
    int mes = sc.nextInt();
    System.out.print("Año: ");
    int year = sc.nextInt();

    if (mes < 1 || mes > 12) {
      System.out.println("ERROR: mes inválido");
      sc.close();
      return;
    }

    int dias;
    switch (mes) {
      case 4, 6, 9, 11 -> dias = 30;
      case 2 -> {
        boolean bisiesto = (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
        dias = bisiesto ? 29 : 28;
      }
      default -> dias = 31;
    }

    System.out.println("Días: " + dias);
    sc.close();
  }
}
