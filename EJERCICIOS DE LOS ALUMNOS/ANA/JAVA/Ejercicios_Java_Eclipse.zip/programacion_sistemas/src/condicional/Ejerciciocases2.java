package condicional;
import java.util.Scanner;

public class Ejerciciocases2 {
	
	public static void main(String[] args) {
		//Todo Auto-generated method stub
		Scanner c = new Scanner(System.in);
		
		System.out.print("Elige un numero:");
		int numero = c.nextInt();
		
		switch (numero) {
		case 1:
			System.out.println("has elegido 1");
			break;
		
		case 2:
			System.out.println("has elegido 2");
		
		case 3:
			System.out.println("No has elegido nada");
			
	
			
			
		}
		
	}

}