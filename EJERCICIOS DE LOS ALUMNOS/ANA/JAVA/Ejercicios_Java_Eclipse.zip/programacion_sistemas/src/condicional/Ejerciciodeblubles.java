package condicional;

public class Ejerciciodeblubles {
	
	public static void main(String[] args) {
		//TODO Auto-generated method stub
	
	for (int i=1;i<5;i++) {
		System.out.println(i);
		
	}
	System.out.println("bucle while");
	int a=1;
	while(a<5) {
		a++;
		System.out.println(a);
	}
	System.out.println("do while");
	int b=1;
	do {
		System.out.println(b);
		b++;
	}while(b<5);
		
		}
		
	}
	


	
