package condicional;

public class MainOperaciones {
	
	public static void main(String[] args) {
	
	int numero1 = 10;
	int numero2 = 5;
	
	MainOperaciones operaciones=new MainOperaciones();
	int suma=operaciones.sumar(numero1,numero2);
	System.out.println("la suma es" +suma);
	operaciones.resta(numero1, numero2);
	
	
	
	

}
	
	

