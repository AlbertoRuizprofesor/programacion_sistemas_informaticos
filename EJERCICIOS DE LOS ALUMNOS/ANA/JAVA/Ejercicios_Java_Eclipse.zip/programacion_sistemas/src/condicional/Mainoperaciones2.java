package condicional;

public class Mainoperaciones2 {

}
