package condicional;

public class Snippet {
	public static void main(String[] args) {
		System.out.println("Adivina los numeros de 1-10");
				
	}
}

