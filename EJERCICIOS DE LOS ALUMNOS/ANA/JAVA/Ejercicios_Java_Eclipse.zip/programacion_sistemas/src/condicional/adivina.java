package condicional;

import java.util.Scanner;

public class adivina {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		final int secreto = 7; 
		int intentos = 0;
		int  x;
		
		do {
		
			System.out.print("Adivina los numeros de 1-10");
			
			x = sc.nextInt();
			
			intentos++;
			
			if (x < secreto) System.out.println ("Mas alto");
			
			else if (x > secreto) System.out.println("Mas bajo");
			
		} while (x != secreto);
		
		
		System.out.println("¡correctos! intentos:" + intentos);
		
		sc.close();
			
			
			
		}
		
	}


