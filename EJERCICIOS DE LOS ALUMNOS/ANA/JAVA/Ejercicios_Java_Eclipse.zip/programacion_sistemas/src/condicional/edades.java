package condicional;

public class edades {
	//TODO Auto-generated method stub 5
	public static void main(String[] args) {
	
	int edad=20;
	
	 if (edad<12){
		System.out.print("Es menor de edad");
		
	}else if (edad>18){
		System.out.print("El joven adulto");
	
	}else if (edad>=65){
		System.out.print("Es una perosona mayor");
	   
			}
		}
	
	}
