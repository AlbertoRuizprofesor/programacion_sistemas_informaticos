package condicional;

public class fibonacci {
    public static void main(String[] args) {

        // -------- FOR --------
        int a = 0, b = 1, c;
        for (int i = 1; i <= 10; i++) {
            System.out.print(a + " ");
            c = a + b;
            a = b;
            b = c;
        }

        System.out.println(); // salto de línea

        // -------- WHILE --------
        a = 0;
        b = 1;
        int i = 1;

        while (i <= 10) {
            System.out.print(a + " ");
            c = a + b;
            a = b;
            b = c;
            i++;
        }

        System.out.println(); // salto de línea

        // -------- DO-WHILE --------
        a = 0;
        b = 1;
        i = 1;

        do {
            System.out.print(a + " ");
            c = a + b;
            a = b;
            b = c;
            i++;
        } while (i <= 10);
    }
}
        
		do {
            System.out.print(a + " ");
            c = a + b;
            a = b;
            b = c;
            i++;
				} while (i<= 10);
				
			
			}
			
		}
		
	}

}
