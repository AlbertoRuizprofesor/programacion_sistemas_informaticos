package condicional;

public class importe {
	//TODO Auto-generated method stub 5
	public static void main(String[] args) {
		int importe = 850;
		if (importe<0) {
			System.out.println("El importe no debe ser negativo");
		} else if (importe < 100) {
			System.out.println("No hay descuento. importe final: "+importe);
			
		}else if (importe < 1000) {
			int descuento = importe * 10 / 100;
			int total = importe - descuento;
			System.out.println("Descuento del 20%. importe final:" + total);
		}
	}

}
