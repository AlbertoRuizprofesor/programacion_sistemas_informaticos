package condicional;
import java.util.Scanner;

public class maxdos {
	  public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    System.out.print("A: ");
	    int a = sc.nextInt();
	    System.out.print("B: ");
	    int b = sc.nextInt();

	    if (a > b) {
	      System.out.println("Mayor: " + a);
	    } else if (b > a) {
	      System.out.println("Mayor: " + b);
	    } else {
	      System.out.println("Son iguales");
	    }
	    sc.close();
	  }
	}
