package condicional;

import java.util.Scanner;
//TODO Auto-generated method stub 5

public class mayoredad18 {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.print("Edad: ");
    int edad = sc.nextInt();

    if (edad >= 18) {
      System.out.println("Mayor de edad");
    } else {
      System.out.println("Menor de edad");
    }
    sc.close();
  }
}
