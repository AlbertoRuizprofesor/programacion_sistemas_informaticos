package condicional;

public class multiplicarx2 {
	public static void main(String[] args) {
		//TODO Auto-generated method stub
 
	for(int i=2;i<10;i++) {
		System.out.println(i*2);
	
	while (i<10) {
		System.out.println(i * 2);
		i++;
		
	do {
		System.out.println(i * 2);
		i++;
		
	}while (i<10);
		
			}
		
		}
	
	}

}
	
	


