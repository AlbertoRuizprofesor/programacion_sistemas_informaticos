package condicional;

public class notas {
	
	public static void main(String[] args) {
	//Todo Auto-generated method stub5
	
		int nota=10;
	
	if (nota<5) {
		System.out.print("Estas suspenso");
		
	}else if(nota<6) {
		
		System.out.print("Tienes un cinto");
		
	}else {
		System.out.print("Has sacado mas de cinco");
	}
	}	
	
}
	


