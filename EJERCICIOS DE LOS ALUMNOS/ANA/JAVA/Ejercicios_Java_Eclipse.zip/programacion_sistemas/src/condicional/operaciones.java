package condicional;

public class operaciones {
	
	// Devuelve un valor

	public int sumar (int numero1, int numero2) {
		
		return numero1+numero2;
				
		}
	
	// Metodo void
	
	public void resta(int numero1, int numero2) {
		System.out.println("la resta es" +(numero1-numero2));
		
		
	}
	
	public void operaciones(int numero1, int numero2) {
		int suma=sumar(numero1,numero2);
		System.out.println("la suma es"+suma);
		System.out.println("la resta es"+(numero1-numero2));
		
	}
	


	
}
