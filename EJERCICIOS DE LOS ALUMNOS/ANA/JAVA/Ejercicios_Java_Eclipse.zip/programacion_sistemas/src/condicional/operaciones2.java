package condicional;

public class operaciones2 {
	
	public int suma(int numero1, int numero2) {
		return suma numero1+numero2;
		
	}
	

}




public void operaciones(int numero1, int numero2) {
	int suma=sumar(numero1,numero2);
	int multi=multiplicacion(numero1,numero2);
	int resta=restar(numero1,numero2);
	double division=division(numero1,numero2);
	
	System.out.println("la suma es:" +suma);
	System.out.println("la resta es:" +resta);
	System.out.println("la multiplicacion es:" +multiplicar);
	System.out.println("la division es:" +division);
	
}
