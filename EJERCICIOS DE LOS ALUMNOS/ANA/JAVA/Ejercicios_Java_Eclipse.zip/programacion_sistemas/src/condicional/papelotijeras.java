package condicional;

import java.math.*;
import java.util.Scanner;

import javax.management.RuntimeErrorException;

public class papelotijeras {

	public static void main(String[] args) {

		// Parte Usuario
		System.out.println("Juego piedra, papel o tijeras");
		System.out.println("=============================");
		System.out.print("Elija una tirada introduciendo su numero (1:Papel)(2:Tijera)(3:Piedra): ");

		// Pedirle el numero entero de la tirada al usuario
		Scanner sc = new Scanner(System.in);
		int tirada = sc.nextInt();
		sc.close();

		// Mostrar la tirada del usuario
		if (tirada == 1) {

			System.out.println("El usuario elige papel");
		} else if (tirada == 2) {

			System.out.println("El usuario elige tijera");
		} else if (tirada == 3) {

			System.out.println("El usuario elige piedra");
		} else {

			System.out.println("Error al elegir la tirada");
			throw new RuntimeErrorException(null, "Tirada erronea");
		}

		// Parte Ordenador
		int tiradaord = (int) (Math.random() * 3) + 1;
		// Mostrar la tirada del usuario
		if (tiradaord == 1) {

			System.out.println("El ordenador elige papel");
		} else if (tirada == 2) {

			System.out.println("El ordenador elige tijera");
		} else if (tirada == 3) {

			System.out.println("El ordenador elige piedra");
		}

		// Determinar jugador
		// 1: Papel
		// 2: Tijera
		// 3: Piedra

		if (tirada == tiradaord) {
			
			System.out.println("Ambos han sacado la misma tirada, hay un empate");
			
		} else if (tirada == 1) {

			if (tiradaord == 2) {
				System.out.println("Gana el ordenador");

			} else if (tiradaord == 3) {
				System.out.println("Gana el usuario");

			}
		} else if (tirada == 2) {

			if (tiradaord == 1) {
				System.out.println("Gana el usuario");

			} else if (tiradaord == 3) {

				System.out.println("Gana el ordenador");
			}
		} else if (tirada == 3) {

			if (tiradaord == 1) {
				System.out.println("Gana el ordenador");

			} else if (tiradaord == 2) {

				System.out.println("Gana el usuario");
			}
		} 

	}
}
