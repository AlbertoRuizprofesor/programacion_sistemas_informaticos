package condicional;
import java.util.Scanner;

public class pareseimpares {
	
	public static void  main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		
	System.out.print("N: ");
	int n = sc.nextInt();
	
	int sumaPares = 0;
	int sumaImpares = 0;
	
	for (int i = 2; i <= n; i+= 2) {
		
	}
	
	for (int i = 1; i<= n;  i += 2) {
		sumaImpares += i;
	}
	
	System.out.println("Suma pares: " + sumaPares);
	System.out.println(" Suma impares: " + sumaImpares);
	sc.close();
			
	}

	

}
