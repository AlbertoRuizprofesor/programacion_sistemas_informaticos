package condicional;
import java.util.Scanner;

public class paroimpar {
	//TODO Auto-generated method stub 5
		public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Numero;");
		int n = sc.nextInt();
		
		if (n%2==0) {
			System.out.println("Par");
		}else{
			System.out.println("impar");
			
		}
			sc.close();
		}

}
