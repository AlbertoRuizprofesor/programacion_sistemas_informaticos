package condicional;
import java.math.*;
public class retopapeltijera {

}

int n=(int)(Math.random()*3)+1;
System.out.print(n);
