package ejerciciosbucles;

import java.util.Scanner;

public class ValidarNota {
	

	public static void main(String[] args) {
	// TODO Auto-generated method stub
	  Scanner sc = new Scanner(System.in);
	  double nota;
	  
	  do { 
		  System.out.print("Nota(0-10");
		  nota = sc.nextDouble();
		  
		}while (nota<0 || nota >10);
	  
	  System.out.println("Nota válida: " + nota);
	  
	  sc.close();
	  
			}

	}

	


