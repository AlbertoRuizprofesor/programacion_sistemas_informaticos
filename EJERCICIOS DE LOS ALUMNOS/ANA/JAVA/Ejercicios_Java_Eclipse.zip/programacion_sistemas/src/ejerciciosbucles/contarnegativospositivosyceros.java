package ejerciciosbucles;
	import java.util.Scanner;

public class contarnegativospositivosyceros {
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
	System.out.print("¿Cuánto números?:");
	
	int n=sc.nextInt();
	int pos=0, neg = 0, cero = 0;
			
		for (int i = 1; i<=n; i++) {
		
			int x = sc.nextInt();
			if (x>0) pos++;
			else if (x<0) neg++;
			else cero++;
			
			
		}
		System.out.println("Positivo: " + pos);
		System.out.println("Negativo: " + neg);
		System.out.println("Cero: " + cero);
		sc.close();
	}

}
