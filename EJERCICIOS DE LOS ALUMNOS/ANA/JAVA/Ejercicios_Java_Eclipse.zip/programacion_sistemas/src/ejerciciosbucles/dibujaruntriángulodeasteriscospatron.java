package ejerciciosbucles;
import java.util.Scanner;

public class dibujaruntriángulodeasteriscospatron {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Altura: ");
		int h = sc.nextInt();
		
		int i = 1;
		while (i <= h) {
			int j = 1;
			while (j <= i) {
				System.out.print("*");
				j++;
			}
			System.out.println();
			i++;
			
			}
		sc.close();
		}
		
	}


