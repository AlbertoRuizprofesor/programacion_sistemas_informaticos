package ejerciciosbucles;

public class imprimirdel1al10for {
	public static void main(String[]args) {
	
	for (int i = 1; i <=10; i++) {
		System.out.println(i);
		
		
		}	
	}
}


public class imprimirdel1al10for {
	
	public static void main(String[]args) {
	int i = 10;
	while (i >=1) {
		System.out.println(i);
	
		i--;
	
		
		
		}
	}
}
	

