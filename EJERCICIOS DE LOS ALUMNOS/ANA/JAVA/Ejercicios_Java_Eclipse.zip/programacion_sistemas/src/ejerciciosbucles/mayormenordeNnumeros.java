package ejerciciosbucles;

import java.util.Scanner;

public class mayormenordeNnumeros {

    public static void main(String[] args) { // Público, estático, vacío, principal (textos muchos argumentos
        Scanner sc = new Scanner(System.in); // Abro el teclado para pedir el dato
        System.out.print("¿Cuantos numeros hay? ");
        int n = sc.nextInt(); // Guardo el dato como entero

        System.out.print("Numero 1: ");
        int x = sc.nextInt();
        int mayor = x; // Lo pongo al valor del primer numero para poder comparar
        int menor = x;

        for (int i = 1; i < n; i++) {

            System.out.print("Numero " + (i + 1) + ": "); // Numero valor de i + 1:
            x = sc.nextInt();

            if (x > mayor) {

                mayor = x;
            } else if (x < menor) {
                menor = x;
            } else { // Son iguales o no da la comparacion
                System.out.println("El numero no es mayor o menor que los actuales");
            }

        }
        sc.close(); // Cerrar teclado
        System.out.println("El mayor es " + mayor + " y el menor es " + menor);
	}
}
