package ejerciciosbucles;
import java.util.Scanner;

public class mediade5numeros {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		
	double suma = 0;

	for (int i = 1; i<=5; i++) {
		System.out.print("Número " + i + ": ");
		suma += sc.nextDouble();
	}
	
	System.out.println("Media =" + (suma/5));
	sc.close();
	
		}
	
	}


