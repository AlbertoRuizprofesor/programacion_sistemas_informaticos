package ejerciciosbucles;
import java.util.Scanner;
public class menurepetitivohastaopcion0 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int op;
		
		do {
			System.out.println("\n1) Saludar");
			System.out.println("2) Mensaje");	
			System.out.println("0)Salir");
			System.out.println("Opcion: ");
			
			op = sc.nextInt();
		
		switch (op) {
	
			case 1 -> System.out.println("Hola");
			case 2 -> System.out.println("¡hay que practicar mas java!");
			case 0 -> System.out.println("Adios");
			default -> System.out.println ("opcion invalida");
			
			}
		
		} while (op != 0);
		
		sc.close();
			
		}
		
	}


	

