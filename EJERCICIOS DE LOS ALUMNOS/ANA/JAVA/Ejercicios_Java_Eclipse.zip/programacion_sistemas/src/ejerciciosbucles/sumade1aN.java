package ejerciciosbucles;
	import java.util.Scanner;

public class sumade1aN {
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.print("N: ");
		int n = sc.nextInt();
		
	int suma = 0;
	for (int i = 1; i <= n; i++) {
		suma +=i;
	}
	
		System.out.println("Suma =" + suma);
		
		sc.close();
		}
		
	}
	


