package metodo;

public class Clasemetodo {
	public static int nota(int nota1, int nota2, int nota3) {
		return nota1+nota2+nota3;
	
} 
public static int nota1(int nota1) {
	return nota1;
}
public static int nota2(int nota2) {
	return nota2;
}
public static int nota3 (int nota3) {
	return nota3;
}

public void mostrar(int nota1, int nota2, int nota3) {

		}
	}
}


public static void mian (String[] args) {
	notas nota=new Clasemetodo();
	
	
	
}


