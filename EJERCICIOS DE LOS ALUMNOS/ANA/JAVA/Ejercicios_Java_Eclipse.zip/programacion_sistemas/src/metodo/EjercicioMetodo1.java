package metodo;

public class EjercicioMetodo1 {
	
	public static int sumar (int numero1) {
		return numero1+10;
	}
	public static void saludar (String nombre) {
		
	}
	
	public static void main(String[] args) {
		//TODO Auto-generated method stub
		int numero=12;
		System.out.println(sumar(numero));
		saludar(" Alberto");
		
	}
	
}