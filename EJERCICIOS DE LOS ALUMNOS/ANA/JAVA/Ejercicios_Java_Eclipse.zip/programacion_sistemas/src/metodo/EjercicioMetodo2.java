package metodo;

public class EjercicioMetodo2 {
	
	//metodos hay que instanciar la clase
	public void saludarte(String nombre) {
		System.out.println("Hola"+nombre);
	}
		
	public double iva(int importe) {
		return (importe*0.21);
		
		}
		
	}


