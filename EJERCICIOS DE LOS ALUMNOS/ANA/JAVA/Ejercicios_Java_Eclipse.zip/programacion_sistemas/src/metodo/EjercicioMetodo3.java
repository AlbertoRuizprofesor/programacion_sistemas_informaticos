package metodo;

public class EjercicioMetodo3 {

}public static void main(String args) {
	//Todo Auto-generated method stub
	public void mostrar(int numero1, int numero2) {
	System.out.println("Numero 1: " + numero1);
	System.out.println("Numero 2: " + numero2);
	int numero1=10;
	int numero2=5;
	EjercicioMetodo3 Ejer3=new EjercicioMetodo3();
	Ejer3.mostrar(numero1,numero2);
	
		}
	}

