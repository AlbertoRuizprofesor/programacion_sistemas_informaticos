package metodo; // que pida la edad y el nombre 

public class Ejerciciometodo4 {
	
	public int edad(int fecha) {
		return 1997-fecha;
		
	}
	
		
	
	
	
		
		
		
		
	

}
