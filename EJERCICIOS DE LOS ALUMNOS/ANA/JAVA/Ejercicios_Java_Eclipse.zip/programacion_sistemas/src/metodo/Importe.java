package metodo;

public class Importe {
	public void importe(String importe) {
		
	
	}

}
