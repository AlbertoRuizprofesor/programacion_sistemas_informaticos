package metodo;

public class MainEjercicioMetodo2 {
	
	public static void main(String[] args) {
		
		ejer2.saludarte("Alberto es el imperator");
		
		double iva=ejer2.iva(100);
		
		System.out.println("el iva es: "+iva);
		
	}

}
