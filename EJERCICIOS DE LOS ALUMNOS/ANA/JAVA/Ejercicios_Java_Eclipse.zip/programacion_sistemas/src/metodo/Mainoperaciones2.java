package metodo;

public class Mainoperaciones2 {
	
	public static void main(String[] args) {
		
	MainOperaciones2 operaciones=new MainOperaciones2();
	int[] numero=operaciones.pedirDatos();
	operaciones.lista_Operaciones(numero[0],numero[1]);
	
	
	}

}
