package metodo;

public class calculadora {
		
		public static int sumar (int a, int b) {
			return a + b;
		}
		public static void restar (int a, int b) {
			return a - b;
			
		}
		public s
		
		public static void main(String[] args) {
			//TODO Auto-generated method stub
			int numero=12;
			System.out.println(sumar(numero));
			saludar(" Alberto");
			
		}
		
	}

