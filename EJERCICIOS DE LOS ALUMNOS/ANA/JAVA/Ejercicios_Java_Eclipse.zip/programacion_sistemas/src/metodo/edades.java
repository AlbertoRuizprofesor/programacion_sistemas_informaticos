package metodo;

public class edades {
	public static int[] edades(int edad1, int edad2, int edad3) {
			int [] edades = new int[3];
			
			edades[0] = edad1;
			edades[1] = edad2;
			edades[2] = edad3;
			
			return edades;
	
	}
}


public class edades{
	public static void mostrar_edades(int edad1, int edad2, int edad3) {
		double media = (edad1)
		
	}
}