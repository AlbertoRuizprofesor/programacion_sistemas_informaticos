package metodo;

import java.util.Scanner;

public class edades2 {

	public class Importe {

	public void mayor_edad(int [] meyor_edad) {
			
			int suma=0;
			for(int i=0;i<edades.length;i++) {
		
				edad+=edades[i];
			}
			double media=s (double) suma /edades.lenght;
			
			}
	
			System.out.println("la edad media es:"+ media);
			
			
		}


}
