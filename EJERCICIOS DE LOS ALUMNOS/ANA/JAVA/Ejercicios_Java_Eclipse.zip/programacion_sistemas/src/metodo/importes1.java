package metodo;
import java.util.Scanner;

public class importes1 {
	
	public int pedir_importe (int [] importe) {
		int suma = 0
		for(int i=0;
	}
	

}
