package metodo;
import java.util.Scanner;

public class operaciones {
	public int sumar(int numero1, int numero2) {
		return numero1+numero2;
	}
	
	public int restar(int numero1, int numero2) {
		return numero1-numero2;
		
	}
	
	public int multiplicacion(int numero1, int numero2) {
		return numero1*numero2;
		
	}
	
	public double division(int numero1, int numero2) {
		return numero1/numero2;
		
	}
	
}


public void lista_Operaciones (int numero1, int numero2) {
	double [] operacion=new double[4];
	String []nombre_opera= {"Suma","Resta","multiplicación","División"}; 
	
	operacion[0]=sumar(numero1,numero2);          
	operacion[1]=restar(numero1,numero2);
	operacion[2]=multiplicacion(numero1,numero2);
	operacion[3]=division(numero1,numero2);
	
	int i=0;
	for (double numer: op) {
		
		System.out.println(" la " +nombre_opera[i]+ " es: " + numer);
		i++;
		}
	
	}
	
}




//tambien se puede hacer de otra forma
public class operaciones2 {
	public int sumar(int numero1, int numero2) {
		return numero1+numero2;
	}
	
	public int restar(int numero1, int numero2) {
		return numero1-numero2;
		
	}
	
	public int multiplicacion(int numero1, int numero2) {
		return numero1*numero2;
		
	}
	
	public double division(int numero1, int numero2) {
		return numero1/numero2; {
	


public void lista_Operaciones (int numero1, int numero2) {
	Strin []nombre_opera= {"Suma","Resta","multiplicación","División","multiplo", "sumar_cuadrado"}; 
	double[] op= {sumar(numero1,numero2),restar(numero1, numero2),
			multiplicacion(numero1,numero2),division(nuemero1,numero2),
			multiplicacion(numero1,numero2), sumar_cuadrado(numero1,numero2)};
	}
	
	private double sumar_cuadrado(int numero1, int numero2) {
	// TODO Auto-generated method stub
	return 0;
}

	int i=0;{
	double[] op;
	for (double numer:op) {
		
		String[] nombre_opera;
		System.out.println( "la "+ nombre_opera[i]+ " es: "+numer);
		i++;
		}
	}
}


