package programacion_sistemas;

public class HolaMundo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nombre;
		int edad=34;
		nombre="Alberto";
		boolean casado=false;
		System.out.println("Hola "+nombre+ "suedad es " +edad); 
		System.out.printf("Hola %s suedad es %d casado? %b",nombre,edad, casado); 

	}
}
