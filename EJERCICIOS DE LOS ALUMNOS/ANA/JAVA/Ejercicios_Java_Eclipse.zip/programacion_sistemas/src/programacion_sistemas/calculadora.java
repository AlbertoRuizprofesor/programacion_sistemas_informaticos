package programacion_sistemas;
import java.util.Scanner;

public class calculadora {
	
	public static void main(String[] args) {
		// TODO Auto_generated method stub
		//crear scanner 
		Scanner c=new Scanner(System.in);
		//pedir datos por consola
		System.out.println("introduce numero 1:");
		int numero1=c.nextInt();
		System.out.println("introduce numero2:");
		int numero2=c.nextInt();
		
		
		
	
		int numero11,numero21;
		int suma,resta,multi,divi;
		numero11=10;
		numero21=5;
		suma=numero11+numero21;
		resta=numero11-numero21;
		multi=numero11*numero21;
		divi=numero11/numero21;
		System.out.println("la suma es " +suma);
		
		c.close();
	}
	
	

}


