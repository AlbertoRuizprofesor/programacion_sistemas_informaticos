package programacion_sistemas;

import java.util.Scanner;

public class calculadora3 {
	
	public static void main(String[] args) {
		// TODO Auto_generated method stub
		//crear scanner 
		//pedir el importe 
		
	
		
	 

	}

}
