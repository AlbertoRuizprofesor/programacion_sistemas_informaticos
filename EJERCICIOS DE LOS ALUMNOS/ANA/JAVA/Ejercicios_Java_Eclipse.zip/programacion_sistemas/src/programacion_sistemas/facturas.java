package programacion_sistemas;
import java.util.Scanner;



public class facturas {
	
	public static void main(String[] args) {
		//operaciones
	Scanner c=new Scanner(System.in);
		
		
			
		
}
}
