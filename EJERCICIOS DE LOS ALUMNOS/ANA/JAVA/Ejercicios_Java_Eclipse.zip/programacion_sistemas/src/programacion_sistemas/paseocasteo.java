package programacion_sistemas;

public class paseocasteo {
	//TODO Auto-generated method stub
	double x;{
	x=6.90;
	int y=(int)x;
	System.out.println("el resultado es "+y);
	
	int n= Integer.parseInt("123");
	Double d=Double.parseDouble("3.14");
	System.out.println("El resultado es "+d);
}

}
