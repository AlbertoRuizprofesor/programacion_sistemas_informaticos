package GESTIONDEFICHEROS;
import java.io.*;

public class Array {

	    public static void main(String[] args) throws IOException {

	        File fichero = new File(".\\src\\fileBytes.dat");

	        FileOutputStream fileout = new FileOutputStream(fichero, true);

	        // 🔹 Array de enteros
	        int[] numeros = new int[99];

	        for (int i = 0; i < 99; i++) {
	            numeros[i] = i + 1;
	        }

	        // 🔹 Escribir el array
	        for (int num : numeros) {
	            fileout.write(num);  // se convierte automáticamente a byte
	        }

	        fileout.close();

	        // -------- LEER --------

	        FileInputStream filein = new FileInputStream(fichero);

	        System.out.println("Contenido del archivo:");

	        int dato;
	        while ((dato = filein.read()) != -1) {
	            System.out.println(dato);
	        }

	        filein.close();
	    }
	}

