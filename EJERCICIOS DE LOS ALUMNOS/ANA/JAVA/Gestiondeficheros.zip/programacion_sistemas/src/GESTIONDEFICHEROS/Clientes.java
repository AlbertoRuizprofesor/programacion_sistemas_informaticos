package GESTIONDEFICHEROS;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

//creamos la carpeta
public class Clientes {
	public static void main(String[] args) {
		String ruta = "C:\\Users\\amzjd\\Desktop\\Prueba";
		String carpeta = "Clientes";
		String ruta1 = "C:\\Users\\amzjd\\Desktop\\Prueba\\clientes";
		String nombreFichero = "clientes.txt";
		String rutaFichero = ruta1 + File.separator + nombreFichero;

		File directorio = new File(ruta + File.separator + carpeta);
		if (directorio.exists() == true) {
			System.out.println("la carpeta existe ");
		} else {
			directorio.mkdir();
			System.out.println("carpeta creada");
		}

		File fichero = new File(rutaFichero);

		if (fichero.exists()) {
			System.out.println("El fichero ya existe.");
		} else {
			try {
				boolean creado = fichero.createNewFile();
				if (creado) {
					System.out.println("El fichero ha sido creado con éxito.");
				} else {
					System.out.println("No se pudo crear el fichero.");
				}
			} catch (IOException e) {
				System.out.println("Error al crear el fichero: " + e.getMessage());
			}

		}

		// Array de cadenas
		String[] clientes = { "Ayto Málaga", "Erosky", "Carrefour" };

		try {
		// -------- ESCRIBIR EN EL FICHERO --------
		BufferedWriter bw = new BufferedWriter(new FileWriter(fichero, true));

		bw.write("Clientes: ");
		bw.newLine();

		for (String cliente1 : clientes) {
			bw.write(cliente1);
			bw.newLine();
		}

		bw.close(); // cerrar escritura

		// -------- LEER EL FICHERO --------
		BufferedReader br = new BufferedReader(new FileReader(fichero));

		String linea;
		System.out.println("Contenido del fichero:");

		while ((linea = br.readLine()) != null) {
			System.out.println(linea);
		}

		br.close(); // cerrar lectura
		} catch (IOException e) {
			System.out.println("Error al escribir en el fichero: " + e.getMessage());
		}
		
	}

}
