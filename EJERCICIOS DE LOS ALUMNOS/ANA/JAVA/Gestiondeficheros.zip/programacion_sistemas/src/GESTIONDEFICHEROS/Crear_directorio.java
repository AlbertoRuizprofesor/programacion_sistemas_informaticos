package GESTIONDEFICHEROS;

import java.io.File;

public class Crear_directorio {
	public static void main(String[] args) {
		String ruta="C:\\Users\\amzjd\\Desktop";
		String carpeta = "ejercicio1";
		File directorio = new File(ruta+File.separator+carpeta); //esto es para poner la carpeta en el escritorio
		if (directorio.exists()==true) {
			System.out.println("la carpeta existe ");
		} else {
		directorio.mkdir();
		System.out.println("carpeta creada");
		}
	}


}
