package GESTIONDEFICHEROS;

import java.io.*;

public class Crear_palabras_dentro_fichero {
    public static void main(String[] args) {
        // Usamos try-with-resources para que el fichero se cierre solo automáticamente
        try (BufferedWriter fichero = new BufferedWriter(new FileWriter("C:\\Users\\amzjd\\Desktop\\fichero.txt", true))){

            
            // 1. Metemos un texto personalizado al principio
            fichero.write("--- INICIO DEL REPORTE PERSONALIZADO ---");
            fichero.newLine();
            
            // 2. El bucle que ya tenías para generar filas
            for (int i = 1; i < 21; i++) {
                fichero.write("Fila numero: " + i); // escribe una línea
                fichero.newLine(); // escribe un salto de línea
            }
            
            // 3. Metemos un texto de cierre
            fichero.write("--- FIN DEL DOCUMENTO ---");
            fichero.newLine();
            
            System.out.println("El texto se ha guardado correctamente.");

        } catch (FileNotFoundException fn) {
            System.out.println("No se encuentra el fichero: " + fn.getMessage());
        } catch (IOException io) {
            System.out.println("Error de E/S: " + io.getMessage());
        }
    }
}