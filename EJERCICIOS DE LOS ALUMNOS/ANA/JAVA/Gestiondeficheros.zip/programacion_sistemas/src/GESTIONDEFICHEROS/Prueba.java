package GESTIONDEFICHEROS;
import java.io.File;
import java.io.IOException;


public class Prueba {
 public static void main(String[] args) {
	    String ruta="C:\\Users\\amzjd\\Desktop";
	    String carpeta = "Prueba";
	    File directorio = new File(ruta+File.separator+carpeta);
	    if (directorio.exists()==true) {
	      System.out.println("la carpeta existe ");
	    } else {
	    directorio.mkdir();
	    System.out.println("carpeta creada");
	    }
	  }
	}

