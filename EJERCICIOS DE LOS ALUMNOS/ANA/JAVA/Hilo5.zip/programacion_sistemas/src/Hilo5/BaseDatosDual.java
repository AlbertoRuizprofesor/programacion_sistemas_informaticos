package Hilo5;

public class BaseDatosDual extends Thread {
	private int notas;
	
	public BaseDatosDual(int notas) {
		this.notas = notas;
		
	}
	public void run() {
		double empresa=(notas*20)/100;
		
		System.out.println("La nota de "+ getClass().getName() + " en la empresa es: "+empresa); 
		System.out.println("La nota de "+ getClass().getName() + " el centro de formacion es: "+(notas-empresa));
	}

}
