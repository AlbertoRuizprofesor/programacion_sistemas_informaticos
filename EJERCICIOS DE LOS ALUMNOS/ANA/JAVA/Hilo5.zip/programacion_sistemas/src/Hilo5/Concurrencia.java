package Hilo5;

public class Concurrencia extends Thread {
	private int notas;
	
	public Concurrencia(int notas) {
		this.notas = notas;
		
		
	}
	public void run() {
		double universidad=(notas*60)/100;
		System.out.println("La nota de "+ getClass().getName() +" en la universidad es: "+ universidad);
		System.out.println("La nota de "+ getClass().getName() + " en el centro de formacion es: "+(notas-universidad));
	}

}
