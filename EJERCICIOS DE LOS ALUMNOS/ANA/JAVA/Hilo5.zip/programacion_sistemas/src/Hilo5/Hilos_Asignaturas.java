package Hilo5; 

public class Hilos_Asignaturas {

public static void main(String[] args) {
  
    new BaseDatosDual(10).start();
    new Concurrencia(8).start();
    new FundamentosProgramacion(10).start();
    new SeguridadInf(7).start();
    	
    }
}
