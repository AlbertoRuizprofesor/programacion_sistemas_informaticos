package Hilo5;

public class SeguridadInf extends Thread {
	private int notas;
	
	public SeguridadInf(int notas) {
		this.notas = notas;
		
		
	}
	public void run() {
		double universidad=(notas*50)/100;
		System.out.println("La nota de "+ getClass().getName() +" en la universidad es: "+ universidad);
		System.out.println("La nota de "+ getClass().getName() + " en el centro de formacion es: "+(notas-universidad));
	}

}
