package Hilo5;

public class Telematicos extends Thread {
	private int notas;
	
	public Telematicos(int notas) {
		this.notas = notas;
		
		
	}
	public void run() {
		double universidad=(notas*50)/100;
		System.out.println("La nota de "+ getClass().getName() +" en la universidad es: "+ universidad);
		System.out.println("La nota de "+ getClass().getName() + " en el centro de formacion es: "+(notas-universidad));
	}

}
