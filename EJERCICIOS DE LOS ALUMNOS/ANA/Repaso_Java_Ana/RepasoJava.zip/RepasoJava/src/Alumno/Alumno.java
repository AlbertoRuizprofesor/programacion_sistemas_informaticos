package Alumno;

public class Alumno {
	String nombre;
	Double nota1;
	Double nota2;
	
	public Alumno(String nombre, double nota1, double nota2) {
		this.nombre = nombre;
		this.nota1 = nota1;
		this.nota2 = nota2;
		
}
	public double calcularMedia() {
		return(nota1 + nota2) / 2;
		
	}
}
