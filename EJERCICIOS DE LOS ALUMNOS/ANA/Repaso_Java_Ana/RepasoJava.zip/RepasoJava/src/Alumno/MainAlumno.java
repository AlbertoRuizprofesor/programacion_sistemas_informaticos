package Alumno;

public class MainAlumno {
	public static void main(String[] args) {
		
		Alumno alumno1 = new Alumno("Pedro", 5.5, 7.5);
		
		double media = alumno1.calcularMedia();
		
		System.out.println("La media de " + alumno1.nombre + "es: " + media);
		
	}

}
