package Animal;

public class Animal {
	
	    String nombre;
	    String tipo;


	    public Animal(String nombre, String tipo) {
	        this.nombre = nombre;
	        this.tipo = tipo;
	    }

	    public void hacerSonido() {
	        System.out.println(nombre + " hace sonidos.");
	    }

	
			
	}
	


