package Animal;

public class MainAnimal {
	public static void main(String[] args) {

	      
	    Animal animal1 = new Animal("PastorAlemán", "Perro");
	    Animal animal2 = new Animal("Siames", "Gato");
	    Animal animal3 = new Animal("Canario", "Pájaro");    

	    animal1.hacerSonido();
	    animal2.hacerSonido();
	    animal3.hacerSonido();
	    }
	}
