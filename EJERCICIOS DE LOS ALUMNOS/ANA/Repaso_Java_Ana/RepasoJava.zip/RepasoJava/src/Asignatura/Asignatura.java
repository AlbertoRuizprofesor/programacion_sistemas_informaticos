package Asignatura;

public class Asignatura{

		private String nombre;        
	    private String profesor;       
	    private int horasSemanales;    

	   
	    public Asignatura(String nombre, String profesor, int horasSemanales) {
	        this.nombre = nombre;             
	        this.profesor = profesor;         
	        this.horasSemanales = horasSemanales; 
	    }

		public String getNombre() {
			return nombre;
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public String getProfesor() {
			return profesor;
		}

		public void setProfesor(String profesor) {
			this.profesor = profesor;
		}

		public int getHorasSemanales() {
			return horasSemanales;
		}

		public void setHorasSemanales(int horasSemanales) {
			this.horasSemanales = horasSemanales;
		}
		public void mostrarAsignatura() {
	        System.out.println("Asignatura: " + nombre);
	        System.out.println("Profesor: " + profesor);
	        System.out.println("Horas semanales: " + horasSemanales);

		
		}
		
		
}

	   
	
	

	
