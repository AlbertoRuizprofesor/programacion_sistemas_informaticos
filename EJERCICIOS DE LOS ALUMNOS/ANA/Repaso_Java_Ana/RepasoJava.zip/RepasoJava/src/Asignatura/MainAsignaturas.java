package Asignatura;

public class MainAsignaturas {
	public static void main(String[] args) {
        
        Asignatura mat = new Asignatura("Ciberseguridad", "Marina Gómez", 8);
        Asignatura historia = new Asignatura("Sistemas", "Álvaro Jiménez", 6);

        mat.mostrarAsignatura();
        historia.mostrarAsignatura();

	}
}
