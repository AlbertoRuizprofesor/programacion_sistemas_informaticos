package Coche;

public class MainCoche {
	public static void main(String[] args) {
		
		Coche coche1 = new Coche("BMW", "320i", "Gris");
		Coche coche2 = new Coche("Mercedes", "Clase A", "Blanco");
		
		coche1.arrancar();
		coche2.arrancar();
	}

}
