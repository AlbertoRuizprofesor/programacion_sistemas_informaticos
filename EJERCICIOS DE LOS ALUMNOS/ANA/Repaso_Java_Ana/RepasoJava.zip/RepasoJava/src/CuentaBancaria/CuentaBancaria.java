package CuentaBancaria;

public class CuentaBancaria {

	    String titular;
	    double saldo;

	    public CuentaBancaria(String titular, double saldoInicial) {
	        this.titular = titular;
	        this.saldo = saldoInicial;
	    }

	    public void ingresar(double cantidad) {
	        if (cantidad > 0) {
	            saldo += cantidad;
	            System.out.println("Se ingresaron " + cantidad + "€");
	        } else {
	            System.out.println("Cantidad inválida");
	        }
	    }

	    // Método para retirar dinero
	    public void retirar(double cantidad) {
	        if (cantidad > 0 && cantidad <= saldo) {
	            saldo -= cantidad;
	            System.out.println("Se retiraron " + cantidad + "€");
	        } else {
	            System.out.println("No se puede retirar esa cantidad");
	        }
	    }

	    public void mostrarSaldo() {
	        System.out.println("Titular: " + titular);
	        System.out.println("Saldo actual: " + saldo + "€");
	    }
	}

	
