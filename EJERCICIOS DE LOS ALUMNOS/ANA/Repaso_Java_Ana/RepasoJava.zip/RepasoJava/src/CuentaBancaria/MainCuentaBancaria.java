package CuentaBancaria;

public class MainCuentaBancaria {
	public static void main(String[] args) {
		// Crear cuenta
        CuentaBancaria cuenta = new CuentaBancaria("Roberto", 2000);

       
        cuenta.mostrarSaldo();
        cuenta.ingresar(300);
        cuenta.retirar(100);
        cuenta.retirar(1000);
        cuenta.mostrarSaldo();
	}
}
