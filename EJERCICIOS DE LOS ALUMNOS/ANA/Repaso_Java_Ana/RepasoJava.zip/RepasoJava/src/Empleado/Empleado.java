package Empleado;

public class Empleado {
	
	    String nombre;
	    double sueldoBase;

	    // Constructor
	    public Empleado(String nombre, double sueldoBase) {
	        this.nombre = nombre;
	        this.sueldoBase = sueldoBase;
	    }

	    public double calcularSueldoAnual() {
	        return sueldoBase * 12;
	    }

	   
	    public void mostrarInformacion() {
	        System.out.println("Nombre: " + nombre);
	        System.out.println("Sueldo mensual: " + sueldoBase + "€");
	        System.out.println("Sueldo anual: " + calcularSueldoAnual() + "€");
	    }
	}


