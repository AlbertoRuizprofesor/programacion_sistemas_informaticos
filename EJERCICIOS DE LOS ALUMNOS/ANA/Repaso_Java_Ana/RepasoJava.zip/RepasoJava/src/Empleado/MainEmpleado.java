package Empleado;

public class MainEmpleado {
	public class Main {
	    public static void main(String[] args) {
	        
	        Empleado empleado = new Empleado("Raquel", 1000);
	        empleado.mostrarInformacion();
	        
	    }
	}
}
