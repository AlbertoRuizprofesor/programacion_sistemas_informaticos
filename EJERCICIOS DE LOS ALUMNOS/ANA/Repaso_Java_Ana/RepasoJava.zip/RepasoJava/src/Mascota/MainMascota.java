package Mascota;

public class MainMascota {
	public static void main(String[] args) {

   
        Mascota mascota = new Mascota("Chulo", "Perro", 2);

 
        mascota.mostrarInformacion();
        mascota.cumplirAños();
        mascota.mostrarInformacion();

	}
}
