package Movil;

public class MainMovil {

    public static void Main(String[] args) {
  
        Movil miMovil = new Movil("Redmi", "Note11pro5G", 70);

     
        miMovil.mostrarEstado();
        miMovil.usarBateria(30);
        miMovil.cargarBateria(60);
        miMovil.mostrarEstado();
    }
}
