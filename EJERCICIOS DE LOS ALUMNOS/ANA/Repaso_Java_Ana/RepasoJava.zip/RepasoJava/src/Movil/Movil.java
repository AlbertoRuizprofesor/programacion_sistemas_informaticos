package Movil;

public class Movil {

	    private String marca;    
	    private String modelo;  
	    private int bateria;     

	   
	    public Movil(String marca, String modelo, int bateria) {
	        this.marca = marca;           
	        this.modelo = modelo;         
	        if(bateria < 0) {             
	            this.bateria = 0;         
	        } else if(bateria > 100) {    
	            this.bateria = 100;       
	        } else {
	            this.bateria = bateria;   
	        }
	    }

	    public void cargarBateria(int cantidad) {
	        bateria += cantidad;           
	        if(bateria > 100) {            
	            bateria = 100;         
	        }
	        System.out.println("Batería cargada. Nivel actual: " + bateria + "%");
	    }

	    // Método para usar batería
	    public void usarBateria(int cantidad) {
	        bateria -= cantidad;           
	        if(bateria < 0) {              
	            bateria = 0;           
	        }
	        System.out.println("Batería usada. Nivel actual: " + bateria + "%");
	    }

	    public void mostrarEstado() {
	        System.out.println("Marca: " + marca);
	        System.out.println("Modelo: " + modelo);
	        System.out.println("Batería: " + bateria + "%");
	    }

	   
	    }
	


