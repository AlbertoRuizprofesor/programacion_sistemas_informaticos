package Ordenador;

public class MainOrdenador {
	
    public static void main(String[] args) {

        // Crear tres objetos Ordenador
        Ordenador pc1 = new Ordenador("LG", 8, 512);
        Ordenador pc2 = new Ordenador("ASUS", 16, 1024);
        Ordenador pc3 = new Ordenador("Lenovo", 32, 2048);

 
        pc1.mostrarCaracteristicas();
        pc2.mostrarCaracteristicas();
        pc3.mostrarCaracteristicas();

}
}
