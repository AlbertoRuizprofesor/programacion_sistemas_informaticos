package Ordenador;

public class Ordenador {

	    private String marca;        
	    private int memoriaRAM;      
	    private int discoDuro;       

	    public Ordenador(String marca, int memoriaRAM, int discoDuro) {
	        this.marca = marca;             
	        this.memoriaRAM = memoriaRAM;  
	        this.discoDuro = discoDuro;     
	    }

	    public void mostrarCaracteristicas() {
	        System.out.println("Marca: " + marca);                 
	        System.out.println("Memoria RAM: " + memoriaRAM + " GB"); 
	        System.out.println("Disco duro: " + discoDuro + " SSD");
	        
	        
	    	}

	    }
	


