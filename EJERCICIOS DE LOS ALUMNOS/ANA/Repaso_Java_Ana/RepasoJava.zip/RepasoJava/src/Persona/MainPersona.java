package Persona;

public class MainPersona {
	public static void main(String[] args) {
		Persona persona=new Persona("María", 18);
		persona.mostrarDatos();
	}
}
