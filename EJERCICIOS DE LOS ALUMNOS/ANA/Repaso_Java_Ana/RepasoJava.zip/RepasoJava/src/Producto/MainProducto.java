package Producto;

public class MainProducto {
	public class Main {
	    public static void main(String[] args) {

	        // Crear varios productos
	        Producto p1 = new Producto("Ordenador", 800, 5);
	        Producto p2 = new Producto("Raton", 20, 50);
	        Producto p3 = new Producto("Teclado", 45, 30);

	        // Mostrar información
	        p1.mostrarInformacion();
	        p2.mostrarInformacion();
	        p3.mostrarInformacion();
	    }
	}

}
