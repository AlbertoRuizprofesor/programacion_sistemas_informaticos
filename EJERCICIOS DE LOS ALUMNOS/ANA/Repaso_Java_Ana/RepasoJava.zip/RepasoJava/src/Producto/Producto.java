package Producto;

public class Producto {
	    String nombre;
	    double precio;
	    int cantidad;

	    public Producto(String nombre, double precio, int cantidad) {
	        this.nombre = nombre;
	        this.precio = precio;
	        this.cantidad = cantidad;
	    }

	
	    public double calcularValorTotal() {
	        return precio * cantidad;
	    }

	    public void mostrarInformacion() {
	        System.out.println("Producto: " + nombre);
	        System.out.println("Precio: " + precio + "€");
	        System.out.println("Cantidad: " + cantidad);
	        System.out.println("Valor total: " + calcularValorTotal() + "€");
	      
	    }
	}


