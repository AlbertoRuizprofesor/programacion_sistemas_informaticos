package Rectangulo;

public class MainRectangulo { 
	
	public static void main(String[] args) {
		
		Rectangulo r1 = new Rectangulo(9.78, 4.68);
		
		System.out.println("Area: " + r1.calcularArea());
		System.out.println("Perimetro: " + r1.calcularPerimetro());
	}
}
