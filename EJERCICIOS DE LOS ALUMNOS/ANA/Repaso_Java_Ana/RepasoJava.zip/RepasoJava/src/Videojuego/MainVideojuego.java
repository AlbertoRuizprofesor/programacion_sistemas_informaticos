package Videojuego;

public class MainVideojuego {
	
	public static void Main(String[] args) {

       
        Videojuego juego1 = new Videojuego("Resident Evil Requiem", "PS5");

      
        juego1.mostrarInformacion();

        juego1.jugar(2);   
        juego1.jugar(3);   

       
        juego1.mostrarInformacion();
    }
}
	

	
	
