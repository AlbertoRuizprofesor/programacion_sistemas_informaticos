package Videojuego;

public class Videojuego {
    private String titulo;        
    private String plataforma;    
    private int horasJugadas;   
    
    public  Videojuego(String titulo, String plataforma) {
        this.titulo = titulo;          
        this.plataforma = plataforma;   
        this.horasJugadas = 0;         
    }

    
    public void jugar(int horas) {
        if (horas > 0) {                        
            horasJugadas += horas;             
            System.out.println("Has jugado " + horas + " horas");
        } else {
            System.out.println("Demasiadas horas jugadas"); 
        }
    }

   
    public void mostrarInformacion() {
        System.out.println("Título: " + titulo);              
        System.out.println("Plataforma: " + plataforma);      
        System.out.println("Horas jugadas: " + horasJugadas);  
     
    }

}

