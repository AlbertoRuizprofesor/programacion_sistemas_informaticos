package arrays;

public class Ejercicio1 {

    public static void main(String[] args) {

        // Array de Strings que contiene nombres de frutas
        String[] frutas = { "Manzana", "Naranja", "Plátano" };

        // Array de enteros con algunos números
        int[] numero = { 1, 12, 45 };

        // Bucle for-each: recorre cada elemento del array 'frutas'
        for (String fruta : frutas) {
            // Imprime cada fruta
            System.out.println("Fruta: " + fruta);
        }

        // Otro for-each: recorre cada número del array 'numero'
        for (int number : numero) {
            // Imprime cada número
            System.out.println("numeros: " + number);
        }
    }
}

