package arrays;

public class Ejercicio2 {

    public static void main(String[] args) {

        // Array de enteros con valores pares
        int[] array1 = { 2, 4, 6, 8, 10 };

        // Array de Strings con frases sobre Alberto
        String[] array2 = { "Alberto es el mejor", "Alberto imperator", "Alberto invencible" };

        // Bucle for-each: recorre cada número del array1
        for (int array : array1) {
            // Imprime cada número
            System.out.println(" Array " + array);
        }

        // Modificación del tercer elemento del array2 (posición 2)
        array2[2] = "Alberto es un Dios";

        // Segundo for-each: recorre todas las frases del array2
        for (String arrayNombre : array2) {
            // Imprime cada frase en la misma línea separada por un punto
            System.out.print(" . " + arrayNombre);
        }
    }
}

