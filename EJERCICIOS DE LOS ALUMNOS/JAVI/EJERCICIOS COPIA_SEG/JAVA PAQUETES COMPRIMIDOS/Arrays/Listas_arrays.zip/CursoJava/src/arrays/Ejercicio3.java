package arrays;

public class Ejercicio3 {

    public static void main(String[] args) {

        // Se crea un array de enteros con espacio para 5 elementos
        int[] array2 = new int[5];

        // Se asignan valores a cada posición del array
        array2[0] = 15;
        array2[1] = 25;
        array2[2] = 35;
        array2[3] = 45;
        array2[4] = 55;

        // Bucle for-each: recorre todos los elementos del array
        // array.length sería la forma genérica de saber cuántos elementos tiene
        for (int array : array2) {
            System.out.println(" Array " + array);
        }
    }
}

