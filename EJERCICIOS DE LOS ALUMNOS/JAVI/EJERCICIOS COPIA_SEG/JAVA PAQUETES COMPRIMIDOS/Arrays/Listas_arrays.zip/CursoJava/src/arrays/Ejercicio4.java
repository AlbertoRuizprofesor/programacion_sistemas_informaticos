package arrays;

public class Ejercicio4 {

    public static void main(String[] args) {


        // Primer array: nombres de personas
        String[] array1 = { "Eva", "Ana", "Cristina", "Pablo", "Maria", "Isabel" };

        // Segundo array: se crea con tamaño 6 y luego se rellenan sus posiciones
        String[] array2 = new String[6];

        array2[0] = "España";
        array2[1] = "Francia";
        array2[2] = "Estados Unidos";
        array2[3] = "Italia";
        array2[4] = "Irlanda";
        array2[5] = "Rep.Checa";

        // Llamadas al método para mostrar ambos arrays con un título
        mostrarArray("Array1 Nombres", array1);
        mostrarArray("Array2 Paises", array2);
    }

    // Método que recibe un texto y un array, y los imprime
    public static void mostrarArray(String texto, String[] array) {

        // Imprime el título del array
        System.out.println(texto + "******");

        // Recorre el array con un for-each
        for (String array1 : array) {
            System.out.println(" Array " + array1);
        }
    }
}

