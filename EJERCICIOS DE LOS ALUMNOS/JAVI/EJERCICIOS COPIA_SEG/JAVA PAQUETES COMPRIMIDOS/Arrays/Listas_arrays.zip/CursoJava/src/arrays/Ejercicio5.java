package arrays;

public class Ejercicio5 {

	public static void main(String[] args) {

		String[][] array1 = {{"España", "Madrid"}, {"Italia", "Roma"}, {"Francia", "Paris"}};

		mostrarArray(array1); 

	}

	public static void mostrarArray(String[][] array1) {

		for (int a = 0; a < array1.length; a++) { 
			
			System.out.print(" pais: " + array1[a][0]);
			System.out.println(" capital: " + array1[a][1]);
		}

	}

}
