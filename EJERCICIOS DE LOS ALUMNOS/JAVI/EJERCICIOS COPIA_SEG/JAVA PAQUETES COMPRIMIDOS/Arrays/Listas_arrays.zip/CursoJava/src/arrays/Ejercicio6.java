package arrays;

public class Ejercicio6 {

	public static void main(String[] args) {

		// Creamos un array bidimensional de 3 filas y 2 columnas
		// Cada fila tendrá: [0] = país, [1] = capital
		String[][] array1 = new String[3][2];

		// Rellenamos la columna 0 (países)
		array1[0][0] = "España";
		array1[1][0] = "Italia";
		array1[2][0] = "Francia";

		// Rellenamos la columna 1 (capitales)
		array1[0][1] = "Madrid";
		array1[1][1] = "Roma";
		array1[2][1] = "Paris";

		// Mostramos el array de forma simple (país + capital)
		mostrarArray(array1);

		// Mostramos el array con más detalle (filas, columnas y longitudes)
		mostrarArray2(array1);
	}

	// Método que recorre el array por filas y muestra país y capital
	public static void mostrarArray(String[][] array1) {

		for (int a = 0; a < array1.length; a++) { // array1.length = número de filas
			System.out.print(" pais: " + array1[a][0]); // Columna 0 → país
			System.out.println(" capital: " + array1[a][1]); // Columna 1 → capital
		}
	}

	// Método que muestra información más detallada del array
	public static void mostrarArray2(String[][] array1) {

		System.out.println(" length del array1: " + array1.length); // Número de filas

		for (int a = 0; a < array1.length; a++) {

			for (int b = 0; b < array1[a].length; b++) { // array1[a].length = columnas de esa fila

				System.out.println(" array1[a].length " + array1[a].length);
				System.out.println(" fila " + a + " columna " + b + ": " + array1[a][b]);
			}
		}
	}
}
