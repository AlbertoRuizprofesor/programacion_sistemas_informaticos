package arrays;

public class EjercicioArray1 {

	public static void main(String[] args) {
		String [] array3= new String[5];
		System.out.println("array 3 vacio y añadir datos, luego mostrar datos con bucle for each***");
		array3[0]="Hola";
		array3[1]="Mundo";
		
		for(String z:array3) {
			System.out.println(z);
		}
		
		System.out.println("Intentando que no salgan los null*********");
		int i = 0;
		
		while(array3[i] != null) {
			System.out.println(array3[i]);
			
			i++;
		}
	}
}
