package arrays;

public class EjercicioArray2 {

	public static void main(String[] args) {
		int[] array1 = { 1, 34, 56, 67 };

		String[] array2 = { "Albert", "12", "Laura", "17" };

		String[] array3 = new String[5];
		
		int [] array4 = new int[5];

		System.out.println("array 1 con bucle for");
		for (int i = 0; i < 3; i++) {
			System.out.println(array1[i]);
		}

		System.out.println("array 1 con bucle for each********");
		for (int y : array1) {
			System.out.println(y);
		}

		System.out.println("array 1 con bucle for y parseo*********");
		int suma = 0;
		for (int i= 1; i < array2.length; i += 2) {
			
			array4[i] = Integer.parseInt(array2[i]);
			System.out.println("el valor n es " + array4[i]);
			suma += array4[i];
		}
		System.out.println("la suma es " + suma);
		
		System.out.println("array 3 vacío y añadir datos, luego mostrar datos con bucle for each********");
		array3[0] = "Hola";
		array3[1] = "Mundo";
		
		for(String z:array3) {
			System.out.println(z);
		}
		
		System.out.println("intentando que no salgan los null**********");
		int i = 0;
		while (array3[i] != null) {
			System.out.println(array3[i]);
			
		i++;
		}
	}

}
