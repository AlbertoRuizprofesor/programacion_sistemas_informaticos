package arrays;

public class Reto1 {
	public static void main(String[] args) {

		// Array que mezcla asignaturas (posición par) y notas en texto (posición impar)
		String[] datos = { "Programación", "7.9", "Base de datos", "8.9", "lenguaje de marcas", "5.6" };

		double sumaNotas = 0; // Acumulará todas las notas
		int contadorNotas = 0; // Contará cuántas notas hay

		// Recorremos solo las posiciones donde están las notas:
		// i = 1, 3, 5... (por eso empezamos en 1 y sumamos 2 cada vez)
		for (int i = 1; i < datos.length; i += 2) {

			// Convertimos el String de la nota a double
			double nota = Double.parseDouble(datos[i]);

			sumaNotas += nota; // Sumamos la nota
			contadorNotas++; // Contamos una nota más
		}

		// Calculamos la media si hay notas
		if (contadorNotas > 0) {
			double media = sumaNotas / contadorNotas;
			System.out.printf("La nota media es: %.2f", media);
		}
	}
}
