package listCRUD;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class CRUD {

	public static void main(String[] args) {
		ArrayList<Integer> numeros = new ArrayList<>();
		
		ArrayList<String> nombres = new ArrayList<>();
		int contador;
		
		
		do {
			contador = mostrarMenu();
			
			switch (contador) {
				case 1: añadirNumero(numeros);
						añadirNombre(nombres);
						break;
				case 2: eliminarNumero(numeros);
						eliminarNombre(nombres);
						break;
				case 3: modificarNumero(numeros);
						modificarNombre(nombres);
						break;
				case 4: buscarNumero(numeros);
						buscarNombre(nombres);
						break;
				case 5: listarNumero(numeros);
						listarNombre(nombres);
						break;
				case 6:	JOptionPane.showMessageDialog(null, "Saliendo del programa...");
						break;
				default: JOptionPane.showMessageDialog(null, "Opción no válida");
			}	
		}while (contador != 6);
	}
		
		
		//--------------------------
		//FUNCIÓN MENU
		//--------------------------
		
		public static int mostrarMenu() {
			return Integer.parseInt(JOptionPane.showInputDialog(
			"CRUD de ArrayList\n\n"
			+ "1. Añadir\n"
			+ "2. Eliminar\n"
			+ "3. Modificar\n"
			+ "4. Buscar\n"
			+ "5. Listado\n"
			+ "6. Salir\n"
			+"Elige una opción: "
		));
		}
		
		//--------------------------
		//AÑADIR
		//--------------------------
		
		public static void añadirNumero(ArrayList<Integer> listaNumero) {
			int nuevoNumero = Integer.parseInt(JOptionPane.showInputDialog("Introduce un número para añadir: "));
			listaNumero.add(nuevoNumero);
		}
			
		public static void añadirNombre(ArrayList<String> listaNombre) {
			
			String nuevoNombre = JOptionPane.showInputDialog("Introduce un nombre para añadir: ");
			listaNombre.add(nuevoNombre);
		}
		
		//-------------------------
		//ELIMINAR
		//-------------------------
		
		public static void eliminarNumero(ArrayList<Integer> listaNumero) {
			int eliminar = Integer.parseInt(JOptionPane.showInputDialog("Número a eliminar:"));
			
			if(listaNumero.contains(eliminar)) {
				listaNumero.remove(Integer.valueOf(eliminar));
				JOptionPane.showMessageDialog(null, "Número eliminado.");
			} else {
				JOptionPane.showMessageDialog(null, "El número no existe.");
			}
		}
		
		public static void eliminarNombre(ArrayList<String> listaNombre) {
			String eliminar = JOptionPane.showInputDialog("Nombre a eliminar:");
			
			if(listaNombre.contains(eliminar)) {
				listaNombre.remove(eliminar);
				JOptionPane.showMessageDialog(null, "Nombre eliminado.");
			} else {
				JOptionPane.showMessageDialog(null, "El nombre no existe.");
			}
		}
		
		//---------------------------
		//MODIFICAR
		//---------------------------
		
		public static void modificarNumero(ArrayList<Integer> listaNumero) {
			int viejo = Integer.parseInt(JOptionPane.showInputDialog("Número a modificar"));
			
			if(listaNumero.contains(viejo)) {
				int nuevoValor = Integer.parseInt(JOptionPane.showInputDialog("Nuevo valor: "));
				int pos = listaNumero.indexOf(viejo);
				listaNumero.set(pos, nuevoValor);
				JOptionPane.showMessageDialog(null, "Número modificado");
				}else {
					JOptionPane.showMessageDialog(null, "Ese número no existe");
				}
		}
		
		public static void modificarNombre(ArrayList<String> listaNombre) {
			String viejo = JOptionPane.showInputDialog("Nombre a modificar");
			
			if(listaNombre.contains(viejo)) {
				String nuevoValor = JOptionPane.showInputDialog("Nuevo valor: ");
				int pos = listaNombre.indexOf(viejo);
				listaNombre.set(pos, nuevoValor);
				JOptionPane.showMessageDialog(null, "Nombre modificado");
				}else {
					JOptionPane.showMessageDialog(null, "Ese nombre no existe");
				}
		}
		
		//---------------------------
		//BUSCAR
		//---------------------------
		
		public static void buscarNumero(ArrayList<Integer> listaNumero) {
			int buscar = Integer.parseInt(JOptionPane.showInputDialog("Número a buscar:"));
			
			if(listaNumero.contains(buscar)) {
				int pos = listaNumero.indexOf(buscar);
				JOptionPane.showMessageDialog(null, "Número encontrado en la posición: " + pos);
			}else {
				JOptionPane.showMessageDialog(null, "Número no encontrado");
			}
		}
		
		public static void buscarNombre(ArrayList<String> listaNombre) {
			String buscar = JOptionPane.showInputDialog("Nombre a buscar:");
			
			if(listaNombre.contains(buscar)) {
				int pos = listaNombre.indexOf(buscar);
				JOptionPane.showMessageDialog(null, "Nombre encontrado en la posición: " + pos);
			}else {
				JOptionPane.showMessageDialog(null, "Nombre no encontrado");
			}
		}


		//--------------------------
		//LISTAR
		//--------------------------
		
		public static void listarNumero(ArrayList<Integer> listaNumeros) {
			 JOptionPane.showMessageDialog(null, "Contenido actual de numeros" + listaNumeros);
		}
		
		public static void listarNombre(ArrayList<String> listaNombres) {
			 JOptionPane.showMessageDialog(null, "Contenido actual de nombres" + listaNombres);
		}
		
}
	

	
		
					
					
					
					
					
					
					
	
	



