package serializacion;

import java.io.*;

//Clase que implementa Serializable
class Videojuego implements Serializable {

 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
 private int codigo;
 private String nombre;
 private String precio;
 public Videojuego(int codigo, String nombre, String precio) {
	 this.codigo = codigo;
     this.nombre = nombre;
     this.precio = precio;
 }
 public String toString() {
     return "Código:" + codigo + ". Nombre: " + nombre + ". Precio: " + precio;
 }
}
public class EjercicioSerializacion2 {
 public static void main(String[] args) {
     // Crear un objeto Persona
     Videojuego videojuego = new Videojuego(23, "Sniper Elite", "60€");
     // Serializar el objeto
     try {
    	 
         FileOutputStream archivoSalida = new FileOutputStream
        		 ("c:\\prueba1\\videojuego.ser");
         ObjectOutputStream objetoSalida = new ObjectOutputStream
        		 (archivoSalida);
         
         objetoSalida.writeObject(videojuego);
         objetoSalida.close();
         archivoSalida.close();
         
         System.out.println("Objeto serializado correctamente.");
         
     } catch (IOException e) {
         e.printStackTrace();
     }
     // Deserializar el objeto
     try {
    	 
         FileInputStream archivoEntrada = new FileInputStream
        		 ("c:\\prueba1\\videojuego.ser");
         ObjectInputStream objetoEntrada = new ObjectInputStream
        		 (archivoEntrada);
         Videojuego videojuegoDeserializada = (Videojuego) objetoEntrada.readObject();
         objetoEntrada.close();
         archivoEntrada.close();
         System.out.println("Objeto deserializado correctamente.");
         System.out.println(videojuegoDeserializada);
         
     } catch (IOException | ClassNotFoundException e) {
         e.printStackTrace();
     }
 }
}
