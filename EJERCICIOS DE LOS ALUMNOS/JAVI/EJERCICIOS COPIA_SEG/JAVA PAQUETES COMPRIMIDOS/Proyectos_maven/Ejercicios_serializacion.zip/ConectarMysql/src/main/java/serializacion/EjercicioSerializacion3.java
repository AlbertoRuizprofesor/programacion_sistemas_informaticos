package serializacion;

import java.io.*;
import java.util.ArrayList;

//Clase Persona SIN public
class Persona1 implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nombre;
    private int edad;

    public Persona1(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    @Override
    public String toString() {
        return nombre + " - " + edad + " años";
    }
}

public class EjercicioSerializacion3 {

    public static void main(String[] args) {

        ArrayList<Persona> lista = new ArrayList<>();

        lista.add(new Persona("Ana", 20));
        lista.add(new Persona("Luis", 22));
        lista.add(new Persona("Marta", 19));

        // Guardar lista
        try (ObjectOutputStream oos =
                     new ObjectOutputStream(new FileOutputStream("C:\\prueba3\\personas.dat"))) {

            oos.writeObject(lista);
            System.out.println("Lista guardada");

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Leer lista (misma ruta)
        try (ObjectInputStream ois =
                     new ObjectInputStream(new FileInputStream("C:\\prueba3\\personas.dat"))) {

            @SuppressWarnings("unchecked")
			ArrayList<Persona> listaLeida =
                    (ArrayList<Persona>) ois.readObject();

            System.out.println("\nContenido leído:");
            for (Persona p : listaLeida) {
                System.out.println(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}



