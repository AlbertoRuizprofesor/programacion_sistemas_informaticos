package mvcMysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProductosControlador {
	 private Connection conn;
	    // Asociación
	    private ArrayList<Productos> listaProductos;
	    private ProductosVista vista;
	    public ProductosControlador(ProductosVista vista) {
	        this.vista = vista;
	        listaProductos = new ArrayList<>(); //esto es un arraylist

	        try {
	            conn = DriverManager.getConnection(
	                    "jdbc:mysql://localhost:3306/empresa1",
	                    "root",
	                    "");
	            System.out.println("Conexión correcta");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }  
	    
	    public void cargarProductos() {
	        try {
	            String sql = "SELECT * FROM productos";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ResultSet rs = ps.executeQuery();
	            //aqui estamos creando un objeto por cada registro.
	            while (rs.next()) {
	                Productos c = new Productos(
	                        rs.getInt("id"),
	                        rs.getString("nombre"),
	                        rs.getDouble("precio")
	                );
	                //cada objeto nuevo lo añadimos a listaclientes
	                listaProductos.add(c);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    public void mostrarProductos() {
	        vista.mostrarProductos(listaProductos);
	    }
}
