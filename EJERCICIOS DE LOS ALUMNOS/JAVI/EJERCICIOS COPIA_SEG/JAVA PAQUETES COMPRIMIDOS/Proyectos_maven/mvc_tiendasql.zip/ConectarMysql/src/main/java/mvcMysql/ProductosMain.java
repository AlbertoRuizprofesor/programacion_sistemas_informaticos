package mvcMysql;

public class ProductosMain {
	public static void main(String[] args) {
		ProductosVista vista = new ProductosVista();
		ProductosControlador controlador = new ProductosControlador(vista);
		controlador.cargarProductos();
		controlador.mostrarProductos();
	}
}
	
