package mvcMysql;

import java.util.ArrayList;

public class ProductosVista {
    public void mostrarProductos(ArrayList<Productos> listaProductos) {

        System.out.println("LISTADO DE PRODUCTOS");

        for (Productos c : listaProductos) {

            System.out.println(
                    "ID: " + c.getId()
                    + " | Nombre: " + c.getNombre()
                    + " | Precio: " + c.getPrecio()
            );
        }
    }
}
