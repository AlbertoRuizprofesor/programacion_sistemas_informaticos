package javadoc;

/**
 * La clase Estudiante representa a un estudiante universitario,
 * almacenando información básica como su nombre, edad, carrera
 * y promedio académico.
 */
public class Estudiante {

    /** Nombre del estudiante. */
    private String nombre;

    /** Edad del estudiante. */
    private int edad;

    /** Carrera universitaria que estudia el estudiante. */
    private String carrera;

    /** Promedio académico del estudiante. */
    private double promedio;

    /**
     * Constructor de la clase Estudiante.
     * Inicializa todos los atributos con los valores proporcionados.
     *
     * @param nombre   Nombre del estudiante.
     * @param edad     Edad del estudiante.
     * @param carrera  Carrera que estudia el estudiante.
     * @param promedio Promedio académico del estudiante.
     */
    public Estudiante(String nombre, int edad, String carrera, double promedio) {
        this.nombre = nombre;
        this.edad = edad;
        this.carrera = carrera;
        this.promedio = promedio;
    }

    /**
     * Devuelve el nombre del estudiante.
     *
     * @return Nombre del estudiante.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Devuelve la edad del estudiante.
     *
     * @return Edad del estudiante.
     */
    public int getEdad() {
        return edad;
    }

    /**
     * Devuelve la carrera que estudia el estudiante.
     *
     * @return Carrera del estudiante.
     */
    public String getCarrera() {
        return carrera;
    }

    /**
     * Devuelve el promedio académico del estudiante.
     *
     * @return Promedio académico del estudiante.
     */
    public double getPromedio() {
        return promedio;
    }
}

