package integrarPowerShell;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Ejercicio1 {

    public static void main(String[] args) throws Exception {

        ProcessBuilder pb = new ProcessBuilder(
                "powershell.exe",
                "-Command",
                "Get-Process"
        );

        Process process = pb.start();

        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(process.getInputStream())
                );

        String linea;
        while ((linea = reader.readLine()) != null) {
            System.out.println(linea);
        }
    }

}


