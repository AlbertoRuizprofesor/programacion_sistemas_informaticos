
package ficheros;

import java.io.*;

public class WriteFileBytes {

    public static void main(String[] args) throws IOException {

        File fichero = new File("src/ficheros/fileBytes.dat"); // declara el fichero

        // Crea flujo de salida hacia el fichero. Si no existe, se crea.
        // El parámetro 'true' indica que se añade al final sin sobrescribir.
        FileOutputStream fileout = new FileOutputStream(fichero, true);

        // Crea flujo de entrada. Si el fichero no existe, lanzará FileNotFoundException.
        FileInputStream filein = new FileInputStream(fichero);
        
 

        // Escribir bytes del 1 al 99
        for (int i = 1; i < 100; i++) {
            fileout.write(i);
        }

        fileout.close(); // cerrar stream de salida

        // Leer y mostrar los bytes del fichero
        while (filein.available() != 0) {
            System.out.println(filein.read());
        }

        filein.close(); // cerrar stream de entrada
    }
}

