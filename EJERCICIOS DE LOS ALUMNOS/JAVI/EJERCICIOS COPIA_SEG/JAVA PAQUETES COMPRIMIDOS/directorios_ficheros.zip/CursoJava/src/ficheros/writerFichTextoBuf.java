package ficheros;
import java.io.*;

public class writerFichTextoBuf {
    public static void main(String[] args) {
        try {
            BufferedWriter fichero = new BufferedWriter(
                    new FileWriter("src/ficheros/myfile.txt"));

            // Array de nombres
            String[] nombres = {"Ana", "Luis", "María", "Carlos", "Elena"};

            // Escribir cada nombre en una línea
            for (String nombre : nombres) {
                fichero.write(nombre);
                fichero.newLine();
            }

            fichero.close();
        }
        catch (FileNotFoundException fn) {
            System.out.println("No se encuentra el fichero");
        }
        catch (IOException io) {
            System.out.println("Error de E/S");
        }
    }
}

