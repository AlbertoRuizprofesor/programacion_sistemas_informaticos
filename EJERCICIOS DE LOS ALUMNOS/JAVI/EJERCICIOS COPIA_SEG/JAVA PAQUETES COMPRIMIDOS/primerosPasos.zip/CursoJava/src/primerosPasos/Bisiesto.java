package primerosPasos;

import java.util.Scanner; // Importamos la clase Scanner para poder leer datos del teclado

public class Bisiesto {

    public static void main(String[] args) {
        
        Scanner a = new Scanner(System.in); 
        // Creamos un objeto Scanner llamado "a" para leer lo que escriba el usuario
        
        System.out.print("Introduzca el año: ");
        // Mostramos un mensaje pidiendo el año
        
        int fecha = a.nextInt();
        // Guardamos en la variable "fecha" el número que el usuario escribe
        
        // Aquí calculamos si el año es bisiesto usando la regla oficial:
        // - Si es divisible entre 400 → bisiesto (true)
        // - O si es divisible entre 4 PERO no entre 100 → bisiesto (true)
        // Si no cumple ninguna de esas → no es bisiesto (false)
        boolean bisiesto = (fecha % 400 == 0) || (fecha % 4 == 0 && fecha % 100 != 0);
        
        // Operador ternario:
        // Si bisiesto es true → imprime "Es bisiesto"
        // Si bisiesto es false → imprime "No es bisiesto"
        System.out.println(bisiesto ? "Es bisiesto": "No es bisiesto");
        
        a.close();//Cierre del objeto Scanner
    }
}

