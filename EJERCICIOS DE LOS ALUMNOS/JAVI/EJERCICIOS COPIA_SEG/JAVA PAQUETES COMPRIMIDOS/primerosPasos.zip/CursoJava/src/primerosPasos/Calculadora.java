package primerosPasos;

public class Calculadora {

	public static void main(String[] args) {
		int numero1, numero2;
		int suma, resta, producto, cociente;
		numero1 = 10;
		numero2 = 5;
		
		suma = numero1 + numero2;
		resta = numero1 - numero2;
		producto = numero1 * numero2;
		cociente = numero1 / numero2;
		
		System.out.println("La suma es igual a: " + suma);
		System.out.println("La resta es igual a: " + resta);
		System.out.println("El producto es igual a: " + producto);
		System.out.println("La division es igual a: " + cociente);
		
	}

}
