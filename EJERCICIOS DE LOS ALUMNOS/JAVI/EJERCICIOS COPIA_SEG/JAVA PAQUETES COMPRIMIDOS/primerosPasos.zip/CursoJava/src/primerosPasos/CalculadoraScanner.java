package primerosPasos;
import java.util.Scanner;//Importamos la clase Scanner que pertenece al paquete java.util

public class CalculadoraScanner {

	public static void main(String[] args) {
		
		Scanner c = new Scanner(System.in);//Creamos un objeto Scanner
		
		System.out.println("Introduce numero 1: ");//Pedimos al usuario que introduzca un número
		int numero1 = c.nextInt();//Almacena el numero introducido en numero1
		
		System.out.println("Introduce numero 2: ");//Pedimos al usuario que introduzca un número
		int numero2 = c.nextInt();//Almacenamos el numero introducido en numero2
		
		
		//Realizamos los cálculos para hacer las operaciones
		int suma, resta, producto, cociente;
		suma = numero1 + numero2;
		resta = numero1 - numero2;
		producto = numero1 * numero2;
		cociente = numero1 / numero2;
		
		
		//Imprimimos en pantalla los resultados
		System.out.println("La suma es igual a: " + suma);
		System.out.println("La resta es igual a: " + resta);
		System.out.println("El producto es igual a: " + producto);
		System.out.println("La division es igual a: " + cociente);/*Esto*/
		
		//Cerramos el objeto 
		c.close();
	}

}
