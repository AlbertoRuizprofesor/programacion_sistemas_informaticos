package primerosPasos;
import java.util.Scanner;

public class CalcularIVA {

	public static void main(String[] args) {
		//
		Scanner i = new Scanner(System.in); 
		
		System.out.println("Introduce el importe: ");
		double importe = i.nextDouble();
		
		double IVA = importe * 0.21;
		double total = importe + IVA;
		
		System.out.println("El IVA es igual a: " + IVA);
		System.out.println("El total es igual a: " + total);		
		
		i.close();	
	}

}
