package primerosPasos;
import java.util.Scanner;

public class CalculoEdad {

	public static void main(String[] args) {
		
		Scanner i = new Scanner(System.in);//Cramos un objeto Scanner
		System.out.println("Introduzca su año de nacimiento: ");//Pedimos la introduccion de la edad al usuario
		int nacimiento = i.nextInt();//Almacenamos el año de nacimiento de la persona en la variable nacimiento
		
		int actual = 2026;//Almacenamos el año actual en la variable actual
		
		int edad = actual - nacimiento;//Calculamos la edad de la persona y la almacenamos en la variable edad
		System.out.println("Su edad es de " + edad + " años");//Imprimimos la edad de la persona sin formato
		System.out.printf("Su edad es de %d años%n", edad);//Imprimimos la edad de la persona con formato
		
		int meses = edad * 12;//Calculamos la edad de la persona en meses
		System.out.println("Su edad en meses es: " + meses + " meses");//Imprimimos la edad en meses sin formato
		System.out.printf("Su edad en meses es: %d meses", meses);//Imprimimos la edad en meses con formato
		
		
		int horas = edad * 8760;//Calculamos la edad de la persona en horas
		System.out.println("Su edad en horas es: " + horas + " horas");//Imprimimos la edad en horas de la persona sin formato
		System.out.printf("Su edad en horas es %,d horas", horas);//Imprimimos la edad en horas de la persona con formato
		
		int minutos = edad * 525600;//Calculamos la edad de la persona en minutos
		System.out.println("Su edad en minutos es: " + minutos + " minutos");//Imprimimos la edad en minutos de la persona sin formato
		System.out.printf("Su edad en minutos es %,d minutos", minutos);//Imprimimos la edad en minutos de la persona con formato
		
		
		
i.close();		

	}

}
