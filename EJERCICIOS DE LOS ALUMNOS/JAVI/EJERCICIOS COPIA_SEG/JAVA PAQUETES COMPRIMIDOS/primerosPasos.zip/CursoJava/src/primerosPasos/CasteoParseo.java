package primerosPasos;

public class CasteoParseo {

    public static void main(String[] args) {

        // CASTEAR = convertir un tipo de dato en otro.
        // Ejemplo de CASTEO IMPLÍCITO (automático):
        // Java convierte un int a double sin pedir permiso porque no hay pérdida de información.

        int a = 12;        // a es un entero
        double b = a;      // a se convierte automáticamente en 12.0 (double)

        System.out.println(a); // Imprime 12
        System.out.println(b); // Imprime 12.0


        // CASTEO EXPLÍCITO (forzado):
        // Aquí sí puede haber pérdida de información (se pierden decimales),
        // por eso Java te obliga a poner (int) delante.

        double x = 9.8;    // x es un double con decimales
        int y = (int) x;   // Se fuerza la conversión: 9.8 → 9 (se pierde el .8)

        System.out.println(y); // Imprime 9


        // PARSEAR = convertir un String (texto) a un número.
        // Esto NO es castreo, porque texto y números no son tipos compatibles.
        // Para parsear se usan métodos especiales como parseInt o parseDouble.

        int n = Integer.parseInt("123");   // Convierte el texto "123" en el número 123
        double d = Double.parseDouble("3.14"); // Convierte "3.14" en 3.14 (double)

        System.out.println(n); // Imprime 123
        System.out.println(d); // Imprime 3.14
    }
}

