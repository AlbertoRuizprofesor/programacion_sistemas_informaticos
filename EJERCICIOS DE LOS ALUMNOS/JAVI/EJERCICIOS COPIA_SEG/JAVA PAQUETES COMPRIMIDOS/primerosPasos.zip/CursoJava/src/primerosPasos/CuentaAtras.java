package primerosPasos;

import java.util.Scanner; // Importamos Scanner para poder leer datos del teclado

public class CuentaAtras {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); // Creamos el objeto Scanner para leer lo que escriba el usuario
        String repetir; // Variable que guardará si el usuario quiere repetir el programa                        

     // El bloque del do se ejecuta SIEMPRE al menos una vez
        do {
            System.out.print("Introduce un número para la cuenta atrás: ");
            int numero = sc.nextInt(); // Leemos el número desde el que empezará la cuenta atrás              

            // Bucle for que empieza en el numero introducido y va bajando hasta 0
            for (int i = numero; i >= 0; i--) {     
                System.out.print(i + " "); // Imprime cada número en la misma línea separado por espacios
                
            }
            System.out.println();// Salto de línea después de la cuenta atrás
            
            System.out.print("¿Quieres hacer otra? (s/n): ");
            repetir = sc.next();      // Leemos la respuesta del usuario: "s" para repetir, "n" para salir         

            // Mientras el usuario escriba "s" (mayúscula o minúscula), el menú se repite 
            // Si escribe cualquier otra cosa, la condición es falsa y sale del bucle
        } while (repetir.equalsIgnoreCase("s")); 

        System.out.println("Fin del programa.");
        
        sc.close(); //Cierre del objeto Scanner
    }
}
