package primerosPasos;

import java.util.Scanner; 
// Importamos Scanner para poder leer datos del teclado

public class DiasMes {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in); 
        // Creamos un Scanner llamado "sc" para leer lo que escriba el usuario

        System.out.print("Mes (1-12): ");
        int mes = sc.nextInt(); 
        // Guardamos el número del mes introducido (1 a 12)

        System.out.print("Año: ");
        int year = sc.nextInt(); 
        // Guardamos el año introducido

        // Comprobamos si el mes es válido
        if (mes < 1 || mes > 12) {
            System.out.println("ERROR: mes inválido");
            sc.close();
            return; 
            // Salimos del programa si el mes no existe
        }

        int dias; 
        // Variable donde guardaremos el número de días del mes

        // Usamos un switch moderno (Java 14+) para decidir los días según el mes
        switch (mes) {

            // Meses que siempre tienen 30 días
            case 4, 6, 9, 11 -> dias = 30;

            // Febrero: depende de si el año es bisiesto
            case 2 -> {
                // Regla del año bisiesto:
                // - divisible entre 400 → bisiesto
                // - o divisible entre 4 pero NO entre 100 → bisiesto
                boolean bisiesto = (year % 400 == 0) 
                                   || (year % 4 == 0 && year % 100 != 0);

                // Si es bisiesto → 29 días, si no → 28
                dias = bisiesto ? 29 : 28;
            }

            // Todos los demás meses tienen 31 días
            default -> dias = 31;
        }

        // Mostramos el resultado
        System.out.println("Días: " + dias);

        sc.close(); 
        // Cerramos el Scanner
    }
}

