package primerosPasos;
import java.util.Scanner;


public class Factura {

	public static void main(String[] args) {
		
		Scanner i = new Scanner(System.in);//Crea objeto Scanner
		System.out.println("Introduzca el importe: ");//Pedimos introducir el importe
		double importe = i.nextDouble();
		
		Scanner z = new Scanner(System.in);//Crea objeto Scanner
		System.out.println("Introduzca las unidades: ");//Pedimos al usuario que introduzca las unidades
		int unidades = z.nextInt();//Almacenamos las unidades introducidas por el usuario en la variable unidades
		
		double total = importe * unidades;//Calculamos el total
		System.out.println("El total es: " + total + "€");//Imprimimos en consola el total sin formato
		System.out.printf("El total es: %.2f€%n", total);//Imprimimos en consola el total con formato
		
		double descuento = total * 0.1;//Calculamos el descuento del 10 por ciento
		System.out.println("El descuento es: " + descuento + "€");//Imprimimos en consola el descuento sin formato
		System.out.printf("El descuento es: %.2f€%n",descuento);//Imprimimos en consola el descuento con formato
		
		double total_pagar = total - descuento;//Calculamos el total a pagar
		System.out.println("El total a pagar es: " + total_pagar + "€");//Imprimimos en consola el total sin formato
		System.out.printf("El total a pagar es: %.2f€%n", total_pagar);//Imprimimos en consola el total con formato
		
		
		
		
		i.close();
		z.close();
	}

}
