package primerosPasos;

public class Imprimir {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int edad; 
		edad = 34;
		String nombre;
		nombre = "Alberto";
		System.out.println("Hola " + nombre + " su edad es " + edad);
		System.out.printf("Hola %s su edad es %d", nombre, edad);
		
	}

}
