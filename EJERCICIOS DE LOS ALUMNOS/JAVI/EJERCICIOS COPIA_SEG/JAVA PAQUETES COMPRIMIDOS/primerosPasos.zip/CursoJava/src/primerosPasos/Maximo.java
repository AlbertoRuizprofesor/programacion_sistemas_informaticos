package primerosPasos;

import java.util.Scanner; //Importamos la clase Scanner

public class Maximo {

	public static void main(String[] args) {
		Scanner a = new Scanner(System.in); //Creamos un objeto Scanner
		System.out.print("Introduzca el primer número: "); //Pedimos al usuario que introduzca el primer número
		int numero1 = a.nextInt(); //Almacenamos el primer número en numero1
		
		System.out.print("Introduzca el segundo número: "); //Pedimos al usuario que introduzca el segundo número
		int numero2 = a.nextInt(); //Almacenamos el segundo número en numero2
		
		System.out.print("Introduzca el tercer número: "); //Pedimos al usuario que introduzca el tercer número
		int numero3 = a.nextInt(); //Almacenamos el tercer número en numero3
		
		int maximo = numero1; //Suponemos que numero1 es el maximo
		
		if (numero2 > maximo) //Si numero2 es mayor que maximo
			maximo = numero2; //almacenamos en maximo el valor de numero2
			
		if(numero3 > maximo) //Si numero3 es mayor que máximo
			maximo = numero3; //Almacenamos en maximo el valor de numero3
			
		System.out.printf("El numero %d es el mayor", maximo); //Imprimimos en pantalla el valor de maximo que es el número mayor
		a.close(); //Cerramos el objeto Scanner
	}
}
