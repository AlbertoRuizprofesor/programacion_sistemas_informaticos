package primerosPasos;

import java.util.Scanner; //Importamos la clase Scanner
public class MayorMenor {

	public static void main(String[] args) {
		Scanner a = new Scanner(System.in); //Creamos un objeto Scanner
		System.out.println("Introduzca el primer número: "); //Pedimos al usuario que introduzca el primer número
		int numero1 = a.nextInt(); //Almacenamos el primer número en en la variable numero1
		
		System.out.println("Introduzca el segundo número: "); //Pedimos al usuario que introduzca el segundo número
		int numero2 = a.nextInt(); //Almacenamos el segundo número en la variable numero2
		
		String resultado = ""; //Inicializamos una variable tipo String para almacenar el resultado
		
		
		//Realizamos las comparaciones y almacenamos el resultado en la variable resultado
		if(numero1 > numero2) {
			resultado = "El numero %d es mayor que el número %d".formatted(numero1,numero2); //Formateo con el metodo .formatted de la clase String
			
		}else if(numero1 < numero2){
			resultado = "El numero %d es menor que el número %d".formatted(numero1,numero2); //Formateo con el metodo .formatted de la clase String
			
		}else {
			resultado = "Los numeros %d y %d son iguales".formatted(numero1, numero2); //Formateo con el metodo .formatted de la clase String
		}
		
		System.out.println(resultado); //Imprimimos el resultado en consola
		a.close(); //Cerramos el objeto Scanner
	}
}
