package primerosPasos;

import java.util.Scanner; //Importa Scanner para poder leer datos del teclado

public class MenuSimple {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); //Creamos el objeto Scanner para leer lo que escriba el usuario
		int opcion; //Variable donde guardaremos la opción elegida en el menú

		do {
			//El bloque del do se ejecuta SIEMPRE al menos una vez
			System.out.println("===========================");
			System.out.println("1. Saludar");
			System.out.println("2. Cantar una canción");
			System.out.println("3. Salir");
			System.out.print("Elige una opción: ");
			opcion = sc.nextInt();	// Leemos la opción que escribe el usuario
			System.out.println("===========================");
			
			//Si elige 1, mostramos un saludo
			if (opcion == 1)
				System.out.println("¡Hola que tal!");
			//Si elige 2, mostramos un texto simulando una canción
			if (opcion == 2)
				System.out.println("Lerelerelerelereeeeee....");

		}while (opcion != 3);
		//Mientras no elija 3, el menú se repite
		//Si elige 3, la condición es falsa y sale del bucle
		
		System.out.println("Que tenga usted un buen día"); //Mensaje final cuando el usuario decide salir
		
		sc.close(); //Cerramos el objeto Scanner
	}
}
