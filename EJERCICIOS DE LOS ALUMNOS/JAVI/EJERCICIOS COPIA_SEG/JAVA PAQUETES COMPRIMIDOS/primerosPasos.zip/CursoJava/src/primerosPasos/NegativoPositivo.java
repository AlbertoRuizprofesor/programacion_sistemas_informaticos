package primerosPasos;

import java.util.Scanner;//Importamos la clase Scanner del paquete java.util

public class NegativoPositivo {

	public static void main(String[] args) {
		
		Scanner a = new Scanner(System.in); //Creamos un objeto Scanner
		System.out.println("Introduzca un número que sea negativo, positivo o cero"); //Pedimos al usuario que introduzca un número
		int numero = a.nextInt(); //Almacenamos el número introducido en la variable numero
		String resultado = ""; //Inicializamos la variable resultado 
		
		
		//Realizamos las comparaciones y almacenamos el resultado
		if(numero > 0) {
			resultado = "El número " + numero + " es positivo";
		}else if(numero < 0) {
			resultado = "El número " + numero + " es negativo";
		}else {
			resultado = "El numero " + numero + " es igual a cero";
		}
		
		
		System.out.println(resultado); //Imprimimos en consola el resultado
		a.close(); //Cerramos el objeto Scanner
	}

}
