package primerosPasos;

import java.util.Scanner; //Importación de la clase Scanner
public class Nota {

	public static void main(String[] args) {
		
		Scanner n = new Scanner(System.in); //Creamos un objeto Scanner
		
		System.out.print("Introduzca su nota por favor: "); //Pedimos al usuario que introduzca una nota
		
		double nota = n.nextDouble(); //Almacenamos la nota introducida por el usuario en la variable nota
		
		String resultado = ""; //Creamos una variable tipo String para almacenar el resultado
		
		
		//Hacemos todas las comparaciones. El resultado de la comparacion lo almacenamos en la variable resultado
		if(nota > 0 && nota <= 5) {
			resultado = String.format("Su nota es %.2f. Usted está \"SUSPENSO\"", nota);
			
		}else if(nota >= 5 && nota < 6) {
			resultado = String.format("Su nota es %.2f. Usted tiene un \"SUFICIENTE\"",nota);
			
		}else if(nota >= 6 && nota < 7) {
			resultado = String.format("Su nota es %.2f. Usted tiene un Bien \"BIEN\"", nota);
			
		}else if(nota >= 7 && nota < 9) {
			resultado = String.format("Su nota es %.2f. Usted tiene un \"NOTABLE\"", nota);
			
		}else if(nota >= 9 && nota <= 10) {
			resultado = String.format("Su nota es %.2f. Usted tiene un \"SOBRESALIENTE\"", nota);
			
		}else {
			resultado = String.format("Usted ha introducico %.2f. Es un \"DATO INCORRECTO", nota);
		}
		
		System.out.print(resultado); //Imprimimos el resultado en consola
		
		n.close(); //Cerramos el objeto Scanner
	}

}
