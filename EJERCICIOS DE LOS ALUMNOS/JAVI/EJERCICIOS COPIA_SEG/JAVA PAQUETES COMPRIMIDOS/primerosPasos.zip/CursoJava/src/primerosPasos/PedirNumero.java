package primerosPasos;


import java.util.Scanner; //Importamos la clase Scanner para introducir datos por consola



public class PedirNumero {


	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); //Permite leer los datos del teclado
		int numero;							//Variable donde vamos a guardar el número
		
		do {								//El bloque se ejecuta al menos una vez
			System.out.print("Introduce un número positivo: ");	//Pedimos al usuario que introduzca un numero positivo
			numero = sc.nextInt();			//Leemos el numero y lo almacenamos
		}while (numero < 0);				//Repetimos mientras sea negativo
		
		System.out.println("Correcto, número aceptado: " + numero); //Informa al usuario que el número es correcto y finaliza

		sc.close();//Cerramos el objeto Scanner
	}

}
