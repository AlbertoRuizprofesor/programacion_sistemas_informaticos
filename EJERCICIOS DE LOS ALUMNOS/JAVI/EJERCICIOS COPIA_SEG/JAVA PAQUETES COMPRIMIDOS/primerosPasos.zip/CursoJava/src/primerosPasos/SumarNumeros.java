package primerosPasos;

import java.util.Scanner; //Importamos la clase Scanner

public class SumarNumeros {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); //Creamos objeto Scanner
		int numero;		//Número introducido por el usuario
		int suma = 0;	//Acumulador para almacenar la suma de los números
		
		do {
			System.out.print("Introduzca un número (0 para salir): ");
			numero = sc.nextInt();	//Lee el número
			suma += numero;			//Suma los números
			
		}while(numero != 0);	//El bucle se repite mientra el numero introducido no sea 0
		
		System.out.println("La suma de todos los números introducidos es " + suma); //Mensaje final con la suma de los números
		
		sc.close(); //Cierre del objeto Scanner
	}
}
