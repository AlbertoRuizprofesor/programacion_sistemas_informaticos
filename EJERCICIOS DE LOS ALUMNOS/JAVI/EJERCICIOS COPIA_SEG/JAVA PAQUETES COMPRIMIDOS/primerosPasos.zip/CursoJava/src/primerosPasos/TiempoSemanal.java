package primerosPasos;
import java.util.Scanner;

public class TiempoSemanal {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("¿Cuántos minutos dedicas a estudiar cada día? ");
        int estudiar = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a tus hobbies cada día? ");
        int hobbies = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a hacer ejercicio cada día? ");
        int ejercicio = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a las redes sociales cada día? ");
        int redes = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a ver series o películas cada día? ");
        int series = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a practicar música cada día? ");
        int musica = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a jugar videojuegos cada día? ");
        int videojuegos = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a cocinar cada día? ");
        int cocinar = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a descansar cada día? ");
        int descansar = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a tus amigos o familia cada día? ");
        int familia = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a tus proyectos personales cada día? ");
        int proyectos = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a aprender programación cada día? ");
        int programacion = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a limpiar o hacer tareas de casa cada día? ");
        int tareas = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a desplazarte cada día? ");
        int desplazamiento = sc.nextInt();

        System.out.print("¿Cuántos minutos dedicas a dormir cada día? ");
        int dormir = sc.nextInt();

        sc.close();

        System.out.println("\n--- Tiempo semanal (en minutos) ---");
        System.out.println("Estudiar: " + (estudiar * 7));
        System.out.println("Hobbies: " + (hobbies * 7));
        System.out.println("Ejercicio: " + (ejercicio * 7));
        System.out.println("Redes sociales: " + (redes * 7));
        System.out.println("Series/películas: " + (series * 7));
        System.out.println("Música: " + (musica * 7));
        System.out.println("Videojuegos: " + (videojuegos * 7));
        System.out.println("Cocinar: " + (cocinar * 7));
        System.out.println("Descansar: " + (descansar * 7));
        System.out.println("Amigos/familia: " + (familia * 7));
        System.out.println("Proyectos personales: " + (proyectos * 7));
        System.out.println("Programación: " + (programacion * 7));
        System.out.println("Tareas de casa: " + (tareas * 7));
        System.out.println("Desplazamiento: " + (desplazamiento * 7));
        System.out.println("Dormir: " + (dormir * 7));
    }
}

