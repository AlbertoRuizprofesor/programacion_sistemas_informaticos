package primerosPasos;

import java.util.Scanner;	// Importa la clase Scanner para poder leer texto del teclado

public class ValidarPassword {

	public static void main(String[] args) {
			Scanner sc = new Scanner(System.in); // Creamos un objeto Scanner llamado "sc" para leer lo que escriba el usuario
			String password; // Variable donde guardaremos la contraseña que escriba el usuario
			
			do {
				// El bloque del do se ejecuta SIEMPRE al menos una vez
				System.out.print("Introduce la contraseña secreta: ");
				password = sc.next(); // Leemos la línea completa que escribe el usuario y la guardamos en "pass"
				
			}while (!password.equals("java1234"));
			// La condición dice: 
			// "Mientras la contraseña NO sea igual a 'java123', repetir el bucle" 
			// Si el usuario escribe algo distinto, vuelve al do 
			// Si escribe "java123", la condición es falsa y sale del bucle
			
			System.out.println("Puede usted continuar"); // Mensaje final cuando la contraseña es correcta
			
			sc.close(); //Cerramos el objeto Scanner
	}
}
