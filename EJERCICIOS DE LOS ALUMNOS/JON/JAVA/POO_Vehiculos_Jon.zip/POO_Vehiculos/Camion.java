package POO_Vehiculos;

public class Camion extends Vehiculos {
	private String combustible;
	private String categoria;
	private double precio;
	
		
	


	public Camion(String marca, String modelo, String motor, String color, String combustible, String categoria,
			double precio) {
		super(marca, modelo, motor, color);
		this.combustible = combustible;
		this.categoria = categoria;
		this.precio = precio;
	}
	
	
	/**
	 * @return the combustible
	 */
	public String getCombustible() {
		return combustible;
	}


	/**
	 * @param combustible the combustible to set
	 */
	public void setCombustible(String combustible) {
		this.combustible = combustible;
	}


	/**
	 * @return the categoria
	 */
	public String getCategoria() {
		return categoria;
	}


	/**
	 * @param categoria the categoria to set
	 */
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}


	/**
	 * @return the precio
	 */
	public double getPrecio() {
		return precio;
	}


	/**
	 * @param precio the precio to set
	 */
	public void setPrecio(double precio) {
		this.precio = precio;
	}


	@Override
	public String toString() {
		return super.toString() +"Camion combustible= " + combustible + ", categoria=" + categoria + ", precio=" + precio ;
	}


	@Override
	public void acelerar() {
		System.out.println("La velocidad máxima del camión es 120 km/h. ");
	}
	@Override
	public void frenar() {
		System.out.println("El camión tiene frenos ABS. ");
	}
	

}
