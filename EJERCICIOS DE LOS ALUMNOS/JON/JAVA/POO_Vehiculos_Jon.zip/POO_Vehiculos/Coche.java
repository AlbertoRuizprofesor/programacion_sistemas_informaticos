package POO_Vehiculos;

public class Coche extends Vehiculos {
	private String combustible;
	private double precio;
	public Coche(String marca, String modelo, String motor, String color, String combustible, double precio) {
		super(marca, modelo, motor, color);
		this.combustible = combustible;
		this.precio = precio;
	}
	/**
	 * @return the combustible
	 */
	public String getCombustible() {
		return combustible;
	}
	/**
	 * @param combustible the combustible to set
	 */
	public void setCombustible(String combustible) {
		this.combustible = combustible;
	}
	/**
	 * @return the precio
	 */
	public double getPrecio() {
		return precio;
	}
	/**
	 * @param precio the precio to set
	 */
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	@Override
	public void acelerar() {
		System.out.println("Velocidad punta del coche 235 km/h");
	}
	@Override
	public void frenar() {
		System.out.println("El coche tiene frenos ABS");
	}
	@Override
	public String toString() {
		return super.toString()+"Coche combustible=" + combustible + ", precio=" + precio + "";
	}
	

}
