package POO_Vehiculos;

public class Moto extends Vehiculos {
	private String categoria;
	private double precio;
	private String extra1;
	private String extra2;
		
	/**
	 * @return the categoria
	 */
	public String getCategoria() {
		return categoria;
	}
	/**
	 * @param categoria the categoria to set
	 */
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	/**
	 * @return the precio
	 */
	public double getPrecio() {
		return precio;
	}
	/**
	 * @param precio the precio to set
	 */
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	/**
	 * @return the extra1
	 */
	public String getExtra1() {
		return extra1;
	}
	/**
	 * @param extra1 the extra1 to set
	 */
	public void setExtra1(String extra1) {
		this.extra1 = extra1;
	}
	/**
	 * @return the extra2
	 */
	public String getExtra2() {
		return extra2;
	}
	/**
	 * @param extra2 the extra2 to set
	 */
	public void setExtra2(String extra2) {
		this.extra2 = extra2;
	}
	public Moto(String marca, String modelo, String motor, String color, String categoria, double precio, String extra1,
			String extra2) {
		super(marca, modelo, motor, color);
		this.categoria = categoria;
		this.precio = precio;
		this.extra1 = extra1;
		this.extra2 = extra2;
	}

	
	@Override
	public void acelerar() {
		System.out.println("La velocidad punta de la moto es 125 km/h.");
	}
	@Override
	public void frenar() {
		System.out.println("La moto tiene frenos ABS");
	}
	@Override
	public String toString() {
		return super.toString()+ "Moto categoria= " + categoria + ", precio=" + precio + ", extra1=" + extra1 + ", extra2=" + extra2
				+ "";
	}
	
	

}
