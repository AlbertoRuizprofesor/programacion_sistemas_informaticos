package POO_Vehiculos;

public class Vehiculo_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehiculos v=new Vehiculos("Marca ","Modelo ", "Motor ", "Color ");
		System.out.println(v.toString());
		Coche c=new Coche("Lexus ","IS 250 ", "2.5 V6 ", "Gris ", "Gasolina ", 45000);
		System.out.println(c.toString());
		Moto m=new Moto("Honda ","Forza ", "125cc ", "Negro ", "Scooter ", 5600, "Escape Arrow ", "Paramanos oscuros ");
		System.out.println(m.toString());
		Camion t=new Camion("IVECO ","DAILY ","3.0 litros 207 CV", "Blanco ", "Gasóil ", "Furgón de carga ", 67000 );
		System.out.println(t.toString());
		v.acelerar();
		v.frenar();
		c.acelerar();
		c.frenar();
		m.acelerar();
		m.frenar();
		t.acelerar();
		t.frenar();
		

	}

}
