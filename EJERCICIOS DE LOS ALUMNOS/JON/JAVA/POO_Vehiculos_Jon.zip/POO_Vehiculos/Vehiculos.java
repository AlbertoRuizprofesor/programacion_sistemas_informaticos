package POO_Vehiculos;

public class Vehiculos {
	private String marca;
	private String modelo;
	private String motor;
	private String color;
	public Vehiculos(String marca, String modelo, String motor, String color) {
		this.marca = marca;
		this.modelo = modelo;
		this.motor = motor;
		this.color = color;
	}
	/**
	 * @return the marca
	 */
	public String getMarca() {
		return marca;
	}
	/**
	 * @param marca the marca to set
	 */
	public void setMarca(String marca) {
		this.marca = marca;
	}
	/**
	 * @return the modelo
	 */
	public String getModelo() {
		return modelo;
	}
	/**
	 * @param modelo the modelo to set
	 */
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	/**
	 * @return the motor
	 */
	public String getMotor() {
		return motor;
	}
	/**
	 * @param motor the motor to set
	 */
	public void setMotor(String motor) {
		this.motor = motor;
	}
	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}
	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}
	
	public void acelerar() {
		System.out.println("El vehículo acelera. ");
	}
	
	public void frenar() {
		System.out.println("El vehículo frena. ");
		
	}
	@Override
	public String toString() {
		return "Vehiculos marca=" + marca + ", modelo=" + modelo + ", motor=" + motor + ", color=" + color + "";
	}
	

}
