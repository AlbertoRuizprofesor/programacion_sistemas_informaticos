package EjerciciosArrayList;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Ejercicio1 {

	public static void main(String[] args) {

		// Creamos una lista usando var
		var nombres = new ArrayList<String>();
		
		
		
		// Pedimos 5 nombres con JOptionPane 
		for (int i = 0; i < 5; i++) { 
			nombres.add(JOptionPane.showInputDialog("Introduce un nombre (" + (i + 1) + "/5):"));
		}

		/*
		nombres.add("Ana");
		nombres.add("Luis");
		nombres.add("Marta");
		nombres.add("Pedro");
		nombres.add("Lucia");
		*/

		for (var nombre : nombres) {
			System.out.println(nombre);
		}
	}
}
