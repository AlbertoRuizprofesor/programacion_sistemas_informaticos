package bucle_for;

public class Contar1_10 {
	
	//Bucle for que empieza en 1 y termina en 10
	//i = 1		valor inicial
	//i <= 10	condición para seguir repitiendo
	//i++		incrementa i en cada vuelta
	public static void main(String[] args) {
		
		//Bucle for que empieza en 1 y termina en 10
		//i = 1		valor inicial
		//i <= 10	condición para seguir repitiendo
		//i++		incrementa i en cada vuelta
		for(int i = 1; i <= 10; i++) {
			
			//En cada iteración imprime el valor actual de i
			//Lo imprime todo en la misma línea
			System.out.print(i + " ");
		}

	}

}
