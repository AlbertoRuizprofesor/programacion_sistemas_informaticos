package bucle_for;

public class ContarAtras {

	public static void main(String[] args) {
		
		//Bucle for que empieza en 10 y va bajando hasta 1
		//i = 10	valor inicial
		//i >= 1	condición para seguir ejecutando el bucle
		//i--		en cada vuelta resta 1 a i
		for (int i = 10; i >= 1; i--) {
			
			//Imprime el valor de i en la misma línea
			System.out.print(i + "  ");
		}
	}

}
