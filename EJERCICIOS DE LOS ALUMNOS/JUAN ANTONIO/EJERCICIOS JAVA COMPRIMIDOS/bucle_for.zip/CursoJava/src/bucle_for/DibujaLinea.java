package bucle_for;
import java.util.Scanner;//Importa la clase Scanner para introducir datos desde consola


public class DibujaLinea {
	
	
	public static void main(String[] args) {
		Scanner a = new Scanner(System.in);//Creamos un objeto Scanner para leer lo que escribe el usuario por teclado
		System.out.print("Introduzca el símbolo con el que quiere dibujar la línea: "); //Pedimos al usuario que introduza el símbolo
		String simbolo = a.next(); //Almacenamos el símbolo en una varible tipo String (simbolo)
		
		System.out.print("Introduzca la longitud de la línea: "); //Pedimos al usuario que introduzca la longitud de la línea
		int longitud = a.nextInt(); //Almacenamos el dato introducido por el usuario en la variable longitud
		
		
		//Bucle for que se ejecuta tantas veces como indique "longitud"
		//fila empieza en 1 va aumentando hasta llegar al valor de longitud
		for(int fila = 1; fila <= longitud; fila++) {
			System.out.print(simbolo);//En cada vuelta imprime el símbolo sin salto de línea
		}
		a.close();//Cerramos el Scanner porque ya no lo necesitamos
	}
}
