package bucle_for;

public class EjercicioBucles {

	public static void main(String[] args) {
		//BUCLE FOR
		//i empieza en 1
		//el bucle se repite mientras i < 5
		//en cada vuelta i aumenta en 1 (i++)
		for (int i = 1; i < 5; i++) {
			System.out.println(i);	//Imprime 1, 2, 3, 4
		}
		System.out.println("bucle while");

		//BUCLE WHILE
		//a empieza en 1
		int a = 1;
		
		//mientras a < 5, el bucle se ejecuta
		while (a < 5) {
			a++;		//primero incrementa a
			System.out.println(a);	//imprime 2, 3, 4, 5
		}
		System.out.println("do while");
		
		//BUCLE DO-WHILE
		//b empieza en 1

		int b = 1;
		
		// el do-while ejecuta el bloque al menos una vez
		do {
			System.out.println(b);	//imprime 1, luego 2, 3, 4
			b++;					//incrementa b
		} while (b < 5);			//se repite mientras b < 5

	}
}
