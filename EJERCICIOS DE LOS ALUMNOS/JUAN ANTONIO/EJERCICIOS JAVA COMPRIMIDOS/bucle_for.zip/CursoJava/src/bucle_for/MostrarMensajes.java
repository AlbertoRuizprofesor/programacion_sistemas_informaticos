package bucle_for;

public class MostrarMensajes {

	public static void main(String[] args) {
		
		//Bucle que se repite desde i = 1 hasta i = 5 (incluido)
		for (int i = 1; i <= 5; i++)
			//En cada repetición muestra un mensaje con el número actual
			System.out.println("Hola número " + i);
	}

}