package bucle_for;

public class MostrarPares {

	//Bucle for que recorre los números del 1 al 20
	//i empieza en 1 y se incrementa de 1 en 1 hasta llegar a 20
	public static void main(String[] args) {
		for (int i = 1; i <= 20; i++) {
			if (i % 2 == 0) {
				System.out.print(i + " ");
			}
		}
	}
}
