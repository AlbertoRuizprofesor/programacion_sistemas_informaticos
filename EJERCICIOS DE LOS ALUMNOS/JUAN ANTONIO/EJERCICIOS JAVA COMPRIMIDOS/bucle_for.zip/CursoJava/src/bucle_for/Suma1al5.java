package bucle_for;

public class Suma1al5 {

	public static void main(String[] args) {
		int suma = 0; // Variable acumuladora donde iremos sumando los valores del bucle

		// Bucle que empieza en 1 y llega hasta 5 (incluido)
		for (int i = 1; i <= 5; i++) {

			suma += i; // En cada vuelta, suma = suma + i

			System.out.print(i + " "); // Muestra cada número del 1 al 5 en la misma línea
		}
		System.out.println(); // Salto de línea después del bucle
		System.out.println("La suma es: " + suma); // Muestra el resultado final de la suma

	}
}
