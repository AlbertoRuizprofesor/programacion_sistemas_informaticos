package bucle_for;

import java.util.Scanner; //Importamo la clase Scanner para introducir dato por el teclado

public class TablaMultiplicar {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); //Creamos un objeto Scanner para leer el número que introduzca el usuario

		System.out.print("Introduzca el numero de la tabla de multiplicar que quiere: "); //Pedimos al usuario que introduzca un numero
		int numero = sc.nextInt();	//Guardamos el numero en la variable numero
		
		int multiplicacion = 0;	//Variable para guardar el resultado de cada multiplicación

		
		//Bucle for que recorre los valores del 1 al 10
		//i empieza en 1, y mientras i sea <= 10, el bucle sigue
		//en cada vuelta i aumenta en 1 (i++)
		for (int i = 1; i <= 10; i++) {
			multiplicacion = numero * i;	//Calculamos la multiplicación del número elegido por el usuario por i
			System.out.println(numero + " x " + i + " = " + (multiplicacion)); //Mostramos la operación completa y su resultado
		}
		sc.close();//Cierre del objeto Scanner
	}
}
