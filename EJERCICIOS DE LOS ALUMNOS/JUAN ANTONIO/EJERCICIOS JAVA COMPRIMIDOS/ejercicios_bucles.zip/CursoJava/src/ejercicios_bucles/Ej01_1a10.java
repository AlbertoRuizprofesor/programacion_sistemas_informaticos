package ejercicios_bucles;

public class Ej01_1a10  {

	public static void main(String[] args) {

		//int i = 1 crea la variable de control empezando en 1
		//i <= 10 mantiene el bucle activo mientras i no supere 10
		//i++ suma 1 a i en cada iteración
		for (int i = 1; i <= 10; i++) {
			
			System.out.print(i + " ");	//Cada vez que pasa por el bucle imprime el valor de i
		}
	}
}
