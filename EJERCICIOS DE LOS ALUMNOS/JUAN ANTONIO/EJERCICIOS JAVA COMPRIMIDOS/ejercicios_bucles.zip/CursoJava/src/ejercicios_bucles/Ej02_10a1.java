package ejercicios_bucles;

public class Ej02_10a1 {

	public static void main(String[] args) {

		int i = 10; // Variable de control que empieza en 10

		while (i >= 1) { // El bucle continúa mientras i sea mayor o igual que 1

			System.out.print(i + " "); // Imprime el valor acutal de i

			i--; // Decrementa i en 1 en cada iteración
		}

	}
}
