package ejercicios_bucles; 

import java.util.Scanner;	//Importa clase Scanner

public class Ej03_Suma1aN  {

	public static void main(String[] args) {
		
	    Scanner sc = new Scanner(System.in);	//Crea un objeto Scanner para leer los datos del teclado
	    System.out.print("N: ");				//Pide al usuario que introduzca un número
	    int n = sc.nextInt();					//Lee el número introducido y lo guarda en 'n'

	    int suma = 0;							//Variable acumuladora donde guaradaremos la suma
	    for (int i = 1; i <= n; i++) {			//bucle que va desde 1 a n
	      suma += i;							//En cada vuelta suma el valor de i a 'suma'
	    }

	    System.out.println("Suma = " + suma);	//Muestra el resultado final
	    sc.close();								//Cierra el Scanner
	}
}
