package ejercicios_bucles;

import java.util.Scanner;

public class Ej04_Media5  {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);          // Permite leer datos desde el teclado

        double suma = 0;                              // Acumulador donde iremos sumando los números
        for (int i = 1; i <= 5; i++) {                // Bucle que se repite 5 veces
            
            System.out.print("Número " + i + ": ");   // Pide el número correspondiente a la iteración
            suma += sc.nextDouble();                  // Suma el número introducido al acumulador
        }

        System.out.println("Media = " + (suma / 5));  // Calcula y muestra la media dividiendo entre 5
        sc.close();                                   // Cierra el Scanner
    }
}

