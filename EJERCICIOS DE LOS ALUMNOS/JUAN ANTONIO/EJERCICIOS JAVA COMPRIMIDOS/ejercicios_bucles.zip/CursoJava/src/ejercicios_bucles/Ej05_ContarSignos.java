package ejercicios_bucles;
import java.util.Scanner;

public class Ej05_ContarSignos   {
    
  public static void main(String[] args) {
      
    Scanner sc = new Scanner(System.in);                 // Permite leer datos del teclado
    
    System.out.print("¿Cuántos números?: ");             // Pregunta cuántos valores se van a introducir
    int n = sc.nextInt();                                // Guarda esa cantidad en 'n'

    int pos = 0, neg = 0, cero = 0;                      // Contadores para positivos, negativos y ceros

    for (int i = 1; i <= n; i++) {                       // Bucle que se repite 'n' veces
        
      System.out.print("Número " + i + ": ");            // Pide el número correspondiente a la iteración
      
      int x = sc.nextInt();                              // Lee el número introducido
      
      if (x > 0) pos++;                                  // Si es positivo, suma 1 al contador de positivos
      else if (x < 0) neg++;                             // Si es negativo, suma 1 al contador de negativos
      else cero++;                                       // Si es cero, suma 1 al contador de ceros
    }

    System.out.println("Positivos: " + pos);             // Muestra cuántos positivos hubo
    System.out.println("Negativos: " + neg);             // Muestra cuántos negativos hubo
    System.out.println("Ceros: " + cero);                // Muestra cuántos ceros hubo
    sc.close();                                          // Cierra el Scanner
  }
}
