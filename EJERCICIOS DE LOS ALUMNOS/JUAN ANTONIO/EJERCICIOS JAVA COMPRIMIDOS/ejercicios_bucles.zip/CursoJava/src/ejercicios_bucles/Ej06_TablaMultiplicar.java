package ejercicios_bucles;

import java.util.Scanner;

public class Ej06_TablaMultiplicar {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);          // Permite leer datos del teclado
    System.out.print("Número: ");                 // Pide al usuario un número
    int n = sc.nextInt();                         // Guarda ese número en la variable n

    for (int i = 1; i <= 10; i++) {               // Recorre los valores del 1 al 10
      System.out.println(n + " x " + i + " = " + (n * i));  
                                                  // Imprime la operación y su resultado
    }

    sc.close();                                   // Cierra el Scanner
  }
}



