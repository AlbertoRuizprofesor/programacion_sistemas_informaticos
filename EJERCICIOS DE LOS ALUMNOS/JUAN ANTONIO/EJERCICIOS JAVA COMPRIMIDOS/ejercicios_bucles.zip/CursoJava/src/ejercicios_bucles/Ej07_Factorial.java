package ejercicios_bucles;

import java.util.Scanner;

public class Ej07_Factorial {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);          // Permite leer datos del teclado
        System.out.print("N (>=0): ");                // Pide un número entero mayor o igual que 0
        int n = sc.nextInt();                         // Guarda ese número en la variable n

        long fact = 1;                                // Variable donde acumularemos el factorial
        for (int i = 2; i <= n; i++) {                // Recorre desde 2 hasta n
            fact *= i;                                // Multiplica fact por i en cada iteración
        }

        System.out.println("Factorial = " + fact);    // Muestra el resultado final
        sc.close();                                   // Cierra el Scanner
    }
}

