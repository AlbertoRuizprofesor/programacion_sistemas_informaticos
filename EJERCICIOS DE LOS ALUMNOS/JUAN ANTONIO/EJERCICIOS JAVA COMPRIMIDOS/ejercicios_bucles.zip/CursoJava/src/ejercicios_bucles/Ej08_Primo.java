package ejercicios_bucles;

import java.util.Scanner;

public class Ej08_Primo {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);	//Objeto Scanner
       
        System.out.print("Número: ");
        int n = sc.nextInt();                 // Lee el número introducido por el usuario

        if (n <= 1) {                          // Los números <= 1 no son primos
            System.out.println("No primo");
            sc.close();
            return;                            // Sale del programa
        }

        boolean primo = true;                  // Suponemos que es primo hasta demostrar lo contrario

        for (int i = 2; i * i <= n; i++) {     // Probamos divisores desde 2 hasta √n
            if (n % i == 0) {                  // Si n es divisible por i, no es primo
                primo = false;
                break;                         // No hace falta seguir comprobando
            }
        }

        System.out.println(primo ? "Primo" : "No primo");  // Muestra el resultado
        sc.close();
    }
}
