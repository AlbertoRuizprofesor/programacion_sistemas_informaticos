package ejercicios_bucles;

import java.util.Scanner;

public class Ej09_SumaHastaCero {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int suma = 0;                     // Acumulador donde se irán sumando los números
        int contador = 0;                 // Contador de cuántos números válidos se han introducido

        while (true) {                    // Bucle infinito que solo se detiene con 'break'
            System.out.print("Número (0 para terminar): ");
            int x = sc.nextInt();         // Lee un número del usuario

            if (x == 0)                   // Si el número es 0, se termina el bucle
                break;

            suma += x;                    // Suma el número introducido
            contador++;                   // Aumenta el contador de números
        }

        System.out.println("Cantidad: " + contador);   // Muestra cuántos números se introdujeron
        System.out.println("Suma: " + suma);           // Muestra la suma total
        sc.close();
    }
}
