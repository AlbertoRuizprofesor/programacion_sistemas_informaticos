package ejercicios_bucles;

import java.util.Scanner;

public class Ej10_ValidarNota {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double nota;

        do {                                      // El bloque se ejecuta al menos una vez
            System.out.print("Nota (0-10): ");    // Pide una nota al usuario
            nota = sc.nextDouble();               // Lee la nota introducida
        } while (nota < 0 || nota > 10);          // Repite mientras la nota NO esté en el rango válido

        System.out.println("Nota válida: " + nota); // Muestra la nota correcta
        sc.close();
    }
}
