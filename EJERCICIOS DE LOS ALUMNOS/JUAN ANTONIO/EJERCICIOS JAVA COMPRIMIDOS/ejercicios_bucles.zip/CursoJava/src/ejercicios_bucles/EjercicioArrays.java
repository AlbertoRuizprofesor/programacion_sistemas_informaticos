/*EJERCICIO: PEDIR 5 NÚMEROS Y MOSTRAR SUMA Y MAYOR USANDO MÉTODOS*/

package ejercicios_bucles;

import java.util.Scanner;

public class EjercicioArrays {

	int[] datos; // array donde guardaremos los números

	// Método NO estático que pide 5 números y los guarda en el array
	public void pedirNumeros() {
		Scanner sc = new Scanner(System.in);
		datos = new int[5];

		for (int i = 0; i < datos.length; i++) {
			System.out.print("Número " + (i + i) + ": ");
			datos[i] = sc.nextInt();
		}
		sc.close();
	}

	// Método NO estático que suma los valores del array
	public void suma() {
		int suma = 0;

		for (int i = 0; i < datos.length; i++) {
			suma += datos[i];
		}

		System.out.println("La suma es: " + suma);
	}

	// Método NO estático que devuelve el mayor número del array
	public void mayor() {
		int mayor = datos[0];

		for (int i = 1; i < datos.length; i++) {
			if (datos[i] > mayor) {
				mayor = datos[i];
			}
		}
		System.out.println("El mayor es: " + mayor);
	}

	public static void main(String[] args) {

		EjercicioArrays obj = new EjercicioArrays();

		obj.pedirNumeros();

		obj.suma();
		obj.mayor();
	}
}
