package interfacesGraficas;

import javax.swing.*;
import java.awt.*;

public class Ejemplo1BoxLayout {
    public static void main(String[] args) {
        // Crear el marco principal de la aplicación
        JFrame frame = new JFrame("BoxLayout Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200); // Establecer el tamaño de la ventana

        // Crear un JPanel que utilizará BoxLayout
        JPanel panel = new JPanel();
        // Establecer BoxLayout en el panel con orientación vertical (Y_AXIS)
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Crear botones que se añadirán al panel
        JButton button1 = new JButton("Botón 1");
        JButton button2 = new JButton("Botón 2");
        JButton button3 = new JButton("Botón 3");

        // Establecer la alineación horizontal de los botones en el centro
        button1.setAlignmentX(Component.CENTER_ALIGNMENT);
        button2.setAlignmentX(Component.CENTER_ALIGNMENT);
        button3.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Añadir el primer botón al panel
        panel.add(button1);
        // Añadir un espacio rígido (dimensión fija) de 10 píxeles de alto entre el primer y segundo botón
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        // Añadir el segundo botón al panel
        panel.add(button2);
        // Añadir otro espacio rígido de 10 píxeles de alto entre el segundo y tercer botón
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        // Añadir el tercer botón al panel
        panel.add(button3);

        // Añadir el panel al marco principal
        frame.add(panel);

        // Hacer visible la ventana
        frame.setVisible(true);
    }
}


