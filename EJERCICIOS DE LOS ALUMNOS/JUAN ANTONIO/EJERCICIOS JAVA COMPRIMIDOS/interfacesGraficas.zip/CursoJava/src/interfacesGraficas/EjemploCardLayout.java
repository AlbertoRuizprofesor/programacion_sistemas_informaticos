package interfacesGraficas;

import javax.swing.*;
import java.awt.*;


public class EjemploCardLayout {
    @SuppressWarnings("unused")
	public static void main(String[] args) {
        // Crear el marco principal de la aplicación
        JFrame frame = new JFrame("CardLayout Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
	  // para el borderlayout se usa el joption pane implícito
        // Crear un panel que utiliza CardLayout
        JPanel cardPanel = new JPanel(new CardLayout());

        // Crear el primer "card" (pantalla 1)
        JPanel card1 = new JPanel();
        card1.add(new JLabel("Welcome to Screen 1"));  // Añadir una etiqueta al card1

        // Crear el segundo "card" (pantalla 2)
        JPanel card2 = new JPanel();
        card2.add(new JLabel("Welcome to Screen 2"));  // Añadir una etiqueta al card2

        // Crear el tercer "card" (pantalla 3)
        JPanel card3 = new JPanel();
        card3.add(new JLabel("Welcome to Screen 3"));  // Añadir una etiqueta al card3
	
     // Crear el tercer "card" (pantalla 4)
        JPanel card4 = new JPanel();
        card4.add(new JLabel("Welcome to Screen 4"));  // Añadir una etiqueta al card3


        // Añadir cada "card" al panel que usa CardLayout, identificando cada uno con una cadena ("1", "2", "3")
        cardPanel.add(card1, "1");
        cardPanel.add(card2, "2");
        cardPanel.add(card3, "3");
        cardPanel.add(card4, "4");

        // Obtener el layout para poder controlar los "cards", hay que castearlo
  // a CardLayout para poder usar sus métodos. De esa manera podremos
// usar los metodos next y previous
      
  CardLayout cl = (CardLayout) cardPanel.getLayout(); 

        // Crear un panel para los botones de navegación (siguiente y anterior)
        JPanel buttonPanel = new JPanel();
        // aqui estamos usando funciones lambda
        // Crear botón "Next" y añadirle un ActionListener
        JButton nextButton = new JButton("Next");
    
    nextButton.addActionListener(e -> cl.next(cardPanel)); // Al hacer clic, se muestra el siguiente card

        // Crear botón "Previous" y añadirle un ActionListener
        JButton prevButton = new JButton("Previous");

        prevButton.addActionListener(e -> cl.previous(cardPanel)); // Al hacer clic, se muestra el card anterior
        
        // Añadir los botones al panel de botones
        buttonPanel.add(prevButton);
        buttonPanel.add(nextButton);

        // Añadir el panel de cards al centro del frame
        frame.add(cardPanel, BorderLayout.CENTER);
        
        // Añadir el panel de botones a la parte inferior del frame
        frame.add(buttonPanel, BorderLayout.SOUTH);

        // Hacer visible la ventana
        frame.setVisible(true);
    }
}

