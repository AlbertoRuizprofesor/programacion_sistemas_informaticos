package interfacesGraficas;
import javax.swing.*;
import java.awt.*;


public class EjemploFlowLayout {
    public static void main(String[] args) {
        JFrame frame = new JFrame("FlowLayout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 150);
        
        frame.setLocationRelativeTo(null);


        JPanel panel = new JPanel(new FlowLayout());//Centrar la ventana al ejecutar

        /*panel.add(new JButton("Uno"));
        panel.add(new JButton("Dos"));
        panel.add(new JButton("Tres"));
        panel.add(new JButton("Cuatro"));
        panel.add(new JButton("Cinco"));*/
        
        String[] nombres = {"Uno", "Dos", "Tres", "Cuatro", "Cinco"};

        for (String nombre : nombres) {
            panel.add(new JButton(nombre));
        }


        frame.add(panel);
        frame.setVisible(true);
    }
}

