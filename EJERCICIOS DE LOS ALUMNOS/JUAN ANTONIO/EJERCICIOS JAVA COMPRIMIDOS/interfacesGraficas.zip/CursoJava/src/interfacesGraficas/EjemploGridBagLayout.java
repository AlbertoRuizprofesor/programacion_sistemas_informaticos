package interfacesGraficas;

import javax.swing.*;
import java.awt.*;

public class EjemploGridBagLayout {
    public static void main(String[] args) {
        // Crear el marco principal de la aplicación
        JFrame frame = new JFrame("GridBagLayout Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300); // Establecer el tamaño de la ventana

        // Crear un JPanel con GridBagLayout
        JPanel panel = new JPanel(new GridBagLayout());
    
    GridBagConstraints gbc = new GridBagConstraints(); // Crear un objeto GridBagConstraints para gestionar las posiciones

        // Crear los componentes de la interfaz de usuario
        JLabel nameLabel = new JLabel("Nombre:");
        JTextField nameField = new JTextField(15); // Campo de texto para el nombre
        
        JLabel surnameLabel = new JLabel("Apellidos:");
        JTextField surnameField = new JTextField(15); // Campo de texto para los apellidos
        
        
        
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(15); // Campo de texto para el email
        
        JLabel phoneLabel = new JLabel("Teléfono:");
        JTextField phoneField = new JTextField(15); // Campo de texto para el teléfono
        
        JLabel cityLabel = new JLabel("Ciudad");
        JTextField cityField = new JTextField(15);// Campo de texto para la ciudad
        
        JLabel messageLabel = new JLabel("Mensaje:");
        JTextArea messageArea = new JTextArea(5, 15); // Área de texto para el mensaje
        
        JButton submitButton = new JButton("Enviar"); // Botón de envío

        // Establecer los márgenes (espaciado) entre los componentes
// new Insets(int top, int left, int bottom, int right)
        gbc.insets = new Insets(5, 5, 5, 5);

        // Añadir y posicionar los componentes utilizando GridBagConstraints

        // Posicionar la etiqueta "Nombre"
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 0; // Fila 0
        panel.add(nameLabel, gbc);

        // Posicionar el campo de texto para "Nombre"
        gbc.gridx = 1; // Columna 1
        panel.add(nameField, gbc);
        
     // Posicionar la etiqueta "Apellidos"
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 1; // Fila 0
        panel.add(surnameLabel, gbc);

        // Posicionar el campo de texto para "Nombre"
        gbc.gridx = 1; // Columna 1
        panel.add(surnameField, gbc);

        // Posicionar la etiqueta "Email"
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 2; // Fila 1
        panel.add(emailLabel, gbc);

        // Posicionar el campo de texto para "Email"
        gbc.gridx = 1; // Columna 1
        panel.add(emailField, gbc);

        // Posicionar la etiqueta "Teléfono"
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 3; // Fila 2
        panel.add(phoneLabel, gbc);

        // Posicionar el campo de texto para "Teléfono"
        gbc.gridx = 1; // Columna 1
        panel.add(phoneField, gbc);
        
        
     // Posicionar la etiqueta "Ciudad"
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 4; // Fila 2
        panel.add(cityLabel, gbc);

        // Posicionar el campo de texto para "Ciudad"
        gbc.gridx = 1; // Columna 1
        panel.add(cityField, gbc);

        // Posicionar la etiqueta "Mensaje"
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 3; // Fila 3
        gbc.gridwidth = 2; // Ocupa dos columnas
        panel.add(messageLabel, gbc);

        // Posicionar el área de texto para "Mensaje" dentro de un JScrollPane
        gbc.gridy = 5; // Fila 4
        gbc.fill = GridBagConstraints.BOTH; // Expandir el área de texto para llenar tanto en horizontal como en vertical
        panel.add(new JScrollPane(messageArea), gbc);

        // Posicionar el botón "Enviar"
        gbc.gridy = 5; // Fila 5
        gbc.fill = GridBagConstraints.NONE; // No expandir el botón
        gbc.anchor = GridBagConstraints.CENTER; // Centrar el botón horizontalmente
        panel.add(submitButton, gbc);

        // Añadir el panel al marco principal
        frame.add(panel);

        // Hacer visible la ventana
        frame.setVisible(true);
    }
}

