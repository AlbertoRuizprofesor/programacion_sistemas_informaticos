package interfacesGraficas;
import javax.swing.*;
import java.awt.*;

public class EjercicioBorderLayout {

	public static void main(String[] args) {
		JFrame capa = new JFrame("Ejercicio Border Layout");
		capa.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		capa.setSize(500, 500);
		capa.setLayout(new BorderLayout());
		
		
		capa.add(new JButton("Pause"), BorderLayout.NORTH);
		capa.add(new JButton("Previus"), BorderLayout.WEST);
		capa.add(new JButton("Next"), BorderLayout.EAST);
		capa.add(new JButton("Play"), BorderLayout.CENTER);
		capa.add(new JButton("Stop"), BorderLayout.SOUTH);
		
		capa.setLocationRelativeTo(null);
		capa.setVisible(true);
	}
}

