package interfacesGraficas;

import javax.swing.*;
import java.awt.*;

public class EjercicioFlowLayout {
    public static void main(String[] args) {

        JFrame ventana = new JFrame("Ejercicio con FlowLayout");
        ventana.setSize(1000, 400);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // FlowLayout centrado con separación horizontal y vertical
        ventana.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

        // 3 Labels
        JLabel label1 = new JLabel("Nombre:");
        JLabel label2 = new JLabel("Apellidos:");
        JLabel label3 = new JLabel("Comentario:");

        // 3 TextAreas
        JTextArea area1 = new JTextArea(2, 15);
        JTextArea area2 = new JTextArea(2, 15);
        JTextArea area3 = new JTextArea(4, 15);

        // Para que las áreas tengan borde visible
        area1.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        area2.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        area3.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        // 3 Botones
        JButton boton1 = new JButton("Enviar");
        JButton boton2 = new JButton("Limpiar");
        JButton boton3 = new JButton("Salir");

        // Añadir componentes al FlowLayout
        ventana.add(label1);
        ventana.add(area1);

        ventana.add(label2);
        ventana.add(area2);

        ventana.add(label3);
        ventana.add(area3);

        ventana.add(boton1);
        ventana.add(boton2);
        ventana.add(boton3);

        ventana.setVisible(true);
    }
}



