package interfacesGraficas;

import javax.swing.*;

public class EventoBoton {
	public static void main(String[] args) {

		JFrame ventana = new JFrame("Evento");
		ventana.setSize(500, 200);
		ventana.setLayout(null);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JButton boton = new JButton("Botón1");
		boton.setBounds(50, 50, 100, 30);

		JButton boton2 = new JButton("Botón2");
		boton2.setBounds(160, 50, 110, 30);

		JButton boton3 = new JButton("Boton3");
		boton3.setBounds(278, 50, 110, 30);

		JLabel etiqueta = new JLabel();
		etiqueta.setBounds(50, 100, 120, 30);

		boton.addActionListener(e -> {
			
			JOptionPane.showMessageDialog(ventana, "Has pulsado el botón 1", "Mensaje",
					JOptionPane.INFORMATION_MESSAGE);
		});
		

		boton2.addActionListener(e -> {

			JOptionPane.showMessageDialog(ventana, "Has pulsado el botón 2", "Mensaje",
					JOptionPane.INFORMATION_MESSAGE);
		});

		boton3.addActionListener(e -> {

			JOptionPane.showMessageDialog(ventana, "Has pulsado el botón 3", "Mensaje",
					JOptionPane.INFORMATION_MESSAGE);
		});

		ventana.add(boton);
		ventana.add(boton2);
		ventana.add(boton3);
		ventana.add(etiqueta);

		ventana.setLocationRelativeTo(null);
		ventana.setVisible(true);
	}
}
