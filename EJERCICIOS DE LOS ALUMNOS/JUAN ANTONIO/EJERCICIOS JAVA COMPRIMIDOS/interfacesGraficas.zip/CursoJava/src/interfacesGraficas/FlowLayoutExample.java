package interfacesGraficas;

import javax.swing.*;
import java.awt.*;

public class FlowLayoutExample {
    public static void main(String[] args) {
        // Crear el marco principal de la aplicación
        JFrame frame = new JFrame("FlowLayout Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        // Crear un JPanel y establecer FlowLayout como su Layout Manager
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());

        // Crear algunos botones para añadir al panel
        JButton button1 = new JButton("Botón 1");
        JButton button2 = new JButton("Botón 2");
        JButton button3 = new JButton("Botón 3");
        JButton button4 = new JButton("Botón 4");
        JButton button5 = new JButton("Botón 5");
        JButton button6 = new JButton("Botón 6");
        
        button1.addActionListener(e -> {
			
			JOptionPane.showMessageDialog(frame, "El botón1 ahora es rojo", "Mensaje",
					JOptionPane.INFORMATION_MESSAGE);
					button1.setBackground(Color.RED);

		});
  
        // Añadir los botones al panel
        panel.add(button1);
        panel.add(button2);
        panel.add(button3);
        panel.add(button4);
        panel.add(button5);
        panel.add(button6);

        // Añadir el panel al marco principal
        frame.add(panel);

        
        frame.setLocationRelativeTo(null);
        // Hacer visible la ventana
        frame.setVisible(true);
    }
}

