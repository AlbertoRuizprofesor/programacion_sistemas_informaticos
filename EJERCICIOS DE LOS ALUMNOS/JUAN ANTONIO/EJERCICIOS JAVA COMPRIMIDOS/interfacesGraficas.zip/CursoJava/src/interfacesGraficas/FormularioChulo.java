
package interfacesGraficas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FormularioChulo {

    public static void main(String[] args) {

        // Ventana
        JFrame ventana = new JFrame("Formulario Súper Chulo");
        ventana.setSize(450, 350);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setLocationRelativeTo(null);

        // Panel principal con BorderLayout
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(200, 230, 255));

        // Título
        JLabel titulo = new JLabel("Formulario de Registro", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 22));
        titulo.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        panel.add(titulo, BorderLayout.NORTH);

        // Panel central con GridBagLayout (perfecto para formularios)
        JPanel centro = new JPanel(new GridBagLayout());
        centro.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        // Campos del formulario
        JLabel lblNombre = new JLabel("Nombre:");
        JTextField txtNombre = new JTextField(20);

        JLabel lblEmail = new JLabel("Email:");
        JTextField txtEmail = new JTextField(20);

        JLabel lblEdad = new JLabel("Edad:");
        JTextField txtEdad = new JTextField(5);

        // Añadir componentes al panel central
        gbc.gridx = 0; gbc.gridy = 0;
        centro.add(lblNombre, gbc);
        gbc.gridx = 1;
        centro.add(txtNombre, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        centro.add(lblEmail, gbc);
        gbc.gridx = 1;
        centro.add(txtEmail, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        centro.add(lblEdad, gbc);
        gbc.gridx = 1;
        centro.add(txtEdad, gbc);

        panel.add(centro, BorderLayout.CENTER);

        // Botón enviar
        JButton btnEnviar = new JButton("Enviar");
        btnEnviar.setFont(new Font("Arial", Font.BOLD, 16));
        btnEnviar.setBackground(Color.WHITE);
        btnEnviar.setFocusPainted(false);

        JPanel sur = new JPanel();
        sur.setOpaque(false);
        sur.add(btnEnviar);

        panel.add(sur, BorderLayout.SOUTH);

        // Mensaje final
        JLabel mensaje = new JLabel("", SwingConstants.CENTER);
        mensaje.setFont(new Font("Arial", Font.PLAIN, 16));
        mensaje.setForeground(new Color(0, 70, 140));
        panel.add(mensaje, BorderLayout.SOUTH);

        // Acción del botón
        btnEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String nombre = txtNombre.getText();
                String email = txtEmail.getText();
                String edad = txtEdad.getText();

                if (nombre.isEmpty() || email.isEmpty() || edad.isEmpty()) {
                    mensaje.setText("Rellena todos los campos");
                } else {
                    mensaje.setText("¡Registro completado! Bienvenido, " + nombre);
                }
            }
        });

        ventana.add(panel);
        ventana.setVisible(true);
    }
}
