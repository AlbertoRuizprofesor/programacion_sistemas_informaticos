package interfacesGraficas;

import javax.swing.*;
import java.awt.*;

public class TecladoLetras {
    public static void main(String[] args) {
        JFrame frame = new JFrame("GridLayout Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 400);
        //estamos combinando tanto el borderlayout, 
        //lo vamos a utilizar para el Jtextfield
        JTextField textField = new JTextField();
        frame.add(textField, BorderLayout.NORTH);
        
        //creamos un jpane
        JPanel panel = new JPanel();
        //creamos el layout, indicamos fila, columna, hgap, vgap
        panel.setLayout(new GridLayout(3, 3,2,2));
        // creamos un string de buttons
        String[] buttons = {
            "A", "B", "C",
            "D", "E", "F",
            "G", "H", "I",  
        };
        // creamos una erie de buttons
        for (String text : buttons) {
            panel.add(new JButton(text));
        }
        frame.setLocationRelativeTo(null);
        //añadimos el panel al borderlayout
        frame.add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}
