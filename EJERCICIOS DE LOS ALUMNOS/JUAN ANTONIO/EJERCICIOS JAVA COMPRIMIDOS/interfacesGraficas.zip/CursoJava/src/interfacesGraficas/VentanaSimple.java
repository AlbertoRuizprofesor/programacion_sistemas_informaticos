package interfacesGraficas;
import javax.swing.*;

public class VentanaSimple {
	public static void main(String[]args) {
		JFrame ventana = new JFrame("Mi ventana");
		ventana.setSize(400, 300);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setVisible(true);
	}
}
