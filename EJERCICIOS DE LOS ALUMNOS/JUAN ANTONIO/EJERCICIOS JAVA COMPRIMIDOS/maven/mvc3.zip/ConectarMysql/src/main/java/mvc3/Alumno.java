package mvc3;

public class Alumno {
	private int id;
	private String nombre;
	private String apellido;
	private int edad;
	private String asignaturas;
	
	public Alumno(int id,String nombre, String apellido, int edad, String asignaturas) {
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
		this.asignaturas = asignaturas;
	}
	public int getId() {
		return id;
	}
	public String getNombre() {
		return nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public int getEdad() {
		return edad;
	}
	public String getAsignaturas() {
		return asignaturas;
	}	
}
