package mvc3;

public class Controlador {
	private Alumno modelo;
	private Vista vista;
	public Controlador(Alumno modelo, Vista vista) {
		this.modelo = modelo;
		this.vista = vista;
	}
	public void actualizarVista() {
		vista.mostrarAlumno(modelo.getId(), modelo.getNombre(), modelo.getApellido(), modelo.getEdad(), modelo.getAsignaturas());
	}
}
