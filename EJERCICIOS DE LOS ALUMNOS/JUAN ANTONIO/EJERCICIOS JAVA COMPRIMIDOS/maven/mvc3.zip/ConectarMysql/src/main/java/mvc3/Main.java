package mvc3;

public class Main {

	public static void main(String[] args) {
		Alumno modelo = new Alumno(34, "Juan", "Soto", 17, "Matemáticas, Literatura, Física");
		Vista vista = new Vista();
		Controlador controlador = new Controlador(modelo, vista);
		controlador.actualizarVista();
	}
}
