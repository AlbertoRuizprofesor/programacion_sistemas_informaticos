package mvc3;

public class Vista {
	//mostrar persona
	public void mostrarAlumno(int id, String nombre, String apellido, int edad, String asignaturas) {
		System.out.println("ID: " + id);
		System.out.println("Nombre: " + nombre);
		System.out.println("Apellido: " + apellido);
		System.out.println("Edad: " + edad);
		System.out.println("Asignaturas: " + asignaturas);
	}
}
	
