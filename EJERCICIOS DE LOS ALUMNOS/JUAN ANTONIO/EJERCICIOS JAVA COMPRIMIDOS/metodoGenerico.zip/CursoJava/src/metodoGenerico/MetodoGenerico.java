package metodoGenerico;

public class MetodoGenerico {

	public static void main(String[] args) {
		
		
		mostrar(10);	
		mostrar("Ana");
		mostrar(3.14);
		mostrar(true);
		
		mostrarNumero(5);
	//	mostrarNumero(20.4); //Da fallo mientras que con el método genérico podemos pasar cualquier dato
	
	}

	//Método genérico
	//Acepta cualquier tipo de dato
	public static <T> void mostrar(T dato) {
		System.out.println("El dato es: " + dato);
		
	}
	

	
	
	//Este método solo sirve para números
	//No acepta Strings
	//No acepta otros tipos
	public static void mostrarNumero(int n) {
		System.out.println("El número es " + n);
	}
}
