package metodos;
import java.util.Scanner;//Importa la clase Scanner

//Clase que contiene los métodos de la calculadora
public class Calculadora {
	//Suma dos números y devuelve el resultado
	public double sumar(double a, double b) {return a + b;}
	
	//Resta el segundo número al primero
	public double restar(double a, double b) {return a - b;}
	
	//Multiplica dos números
	public double multiplicar( double a, double b) {return a * b;}
	
	//Divide el primer número entre el segundo
	public double dividir( double a, double b) {return a / b;}
	
/*=================================================================*/

	//Método principal donde se ejecuta el programa
	public static void main(String[] args) {
		
		//Objeto Scanner para leer datos del teclado
		Scanner sc = new Scanner(System.in);
		
		//Solicita el primer número y lo almacena en numero1
		System.out.print("Introduce el primer número: "); 
		double numero1 = sc.nextDouble();		
		
		//Solicita el segundo número y lo almacena en numero2
		System.out.print("Introduce el segundo número: "); 
		double numero2 = sc.nextDouble();		
		
		//Crea un objeto de la clase Calculadora para usar sus métodos
		Calculadora calc = new Calculadora();
		
		//Llama a los métodos y guarda los resultados
		double suma = calc.sumar(numero1, numero2);
		double resta = calc.restar(numero1, numero2);
		double producto = calc.multiplicar(numero1, numero2);
		double cociente = calc.dividir(numero1, numero2);
		
		//Muestra los resultados formateados con dos decimales
		System.out.printf("La suma es: %.2f%n", suma); 
		System.out.printf("La resta es: %.2f%n", resta);
		System.out.printf("El producto es: %.2f%n", producto);
		System.out.printf("El cociente es: %.2f%n", cociente);
		
		//Cierra el Scanner
		sc.close();
	}
}
