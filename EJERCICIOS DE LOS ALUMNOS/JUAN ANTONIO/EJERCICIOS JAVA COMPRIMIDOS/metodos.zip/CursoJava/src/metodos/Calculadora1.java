package metodos;
import java.util.Scanner; //Importa la clase Scanner

//Clase con el método main: aquí se ejecuta el programa
public class Calculadora1 {

	
	public static void main(String[] args) {
		
		//Objeto para leer datos del teclado
		Scanner sc = new Scanner(System.in);
		
		//Se pide el primer número al usuario
		System.out.print("Introduzca el primer número: ");
		double numero1 = sc.nextDouble();
		
		//Se pide el segundo número al usuario
		System.out.print("Introduzca el segundo número: ");
		double numero2 = sc.nextDouble();
		
		//Crear un objeto de Calculadora para usar sus métodos
		Calculadora1Metodos calc = new Calculadora1Metodos();
		
		//Se llaman los métodos de la calculadora y se guardan los resultados
		double suma = calc.sumar(numero1, numero2);
		double resta = calc.restar(numero1, numero2);
		double multiplicacion = calc.multiplicar(numero1, numero2);
		double division = calc.dividir(numero1, numero2);
		
		//Se muestran los resultados por pantalla con formato para que salgan dos decimales
		System.out.printf("La suma es: %.2f%n", suma);
		System.out.printf("La resta es: %.2f%n", resta);
		System.out.printf("El producto es: %.2f%n", multiplicacion);
		System.out.printf("La división es: %.2f%n", division);
	
		sc.close(); //Cierre del Scanner
	}
}
