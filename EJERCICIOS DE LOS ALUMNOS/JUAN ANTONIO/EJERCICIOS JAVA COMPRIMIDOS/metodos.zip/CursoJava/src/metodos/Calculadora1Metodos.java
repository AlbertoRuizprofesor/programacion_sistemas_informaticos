package metodos;

//Clase que agrupa operaciones matemáticas básicas
public class Calculadora1Metodos {
	
	//Suma dos numeros y devuelve el resultado
	public double sumar(double a, double b) {
		return a + b;
	}
	
	//Resta el segundo número al primero
	public double restar(double a, double b) {
		return a - b;
	}
	
	//Multiplica dos números
	public double multiplicar(double a, double b) {
		return a * b;
	}
	
	//Divide el primer número entre el segundo
	public double dividir(double a, double b) {
		return a / b;
	}
}
