package metodos; 
// El paquete donde se encuentra esta clase. Sirve para organizar el proyecto.

public class Calculos {
    // Declaración de la clase principal llamada "Calculos".

    
    // MÉTODO QUE REALIZA LAS OPERACIONES
    public void operaciones(int numero1, int numero2) {
        // Este método recibe dos números y calcula suma, resta, multiplicación y división.

        int suma = numero1 + numero2;              // Suma
        int resta = numero1 - numero2;             // Resta
        int multiplicacion = numero1 * numero2;    // Multiplicación
        int division = numero1 / numero2;          // División

        // Imprime los resultados en pantalla
        System.out.println("La suma es: " + suma);
        System.out.println("La resta es: " + resta);
        System.out.println("La multiplicación es: " + multiplicacion);
        System.out.println("La división es: " + division);
    }


    // MÉTODO PRINCIPAL (punto de entrada del programa)
    public static void main(String[] args) {

        int numero1 = 10;   // Primer número
        int numero2 = 2;    // Segundo número

        // Crear un objeto de la clase Calculos
        Calculos n = new Calculos();

        // Llamar al método operaciones usando el objeto creado
        n.operaciones(numero1, numero2);
    }
}
