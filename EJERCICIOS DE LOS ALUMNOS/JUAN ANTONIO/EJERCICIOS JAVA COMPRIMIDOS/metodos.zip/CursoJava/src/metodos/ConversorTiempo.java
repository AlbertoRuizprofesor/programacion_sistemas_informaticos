package metodos;

import java.util.Scanner;

public class ConversorTiempo {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        // Creamos un Scanner para leer datos del teclado

        System.out.print("Introduzca los días: ");
        int dias = sc.nextInt();
        // Leemos cuántos días introduce el usuario

        System.out.print("Introduzca las horas: ");
        int horasIntroducidas = sc.nextInt();
        // Leemos cuántas horas introduce el usuario
        
        

        ConversorTiempoMetodos c = new ConversorTiempoMetodos();
        // Creamos un objeto para poder usar los métodos NO estáticos

        int dias_horas = c.diasAHoras(dias);
        // Convertimos los días a horas usando el método correspondiente

        int horas_minutos = c.horasAMinutos(horasIntroducidas);
        // Convertimos las horas introducidas a minutos

        int dias_minutos = c.diasAMinutos(dias);
        // Convertimos los días directamente a minutos usando el método encadenado
        
        

        System.out.println(dias + " dia/s = " + dias_horas + " horas");
        // Mostramos la conversión de días a horas

        System.out.println(horasIntroducidas + " hora/s = " + horas_minutos + " minutos");
        // Mostramos la conversión de horas a minutos

        System.out.println(dias + " dia/s = " + dias_minutos + " minutos");
        // Mostramos la conversión de días a minutos (usando los dos métodos internos)

        sc.close();
        // Cerramos el Scanner
    }

}

