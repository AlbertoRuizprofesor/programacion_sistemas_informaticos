package metodos;

public class ConversorTiempoMetodos {

    // Convierte días a horas
    // Si dias = 2 → devuelve 48
    public int diasAHoras(int dias) {
        return dias * 24;
    }

    // Convierte horas a minutos
    // Si horas = 48 → devuelve 2880
    public int horasAMinutos(int horas) {
        return horas * 60;
    }

    // Convierte días a minutos usando los dos métodos anteriores
    // 1) Pasa los días a horas
    // 2) Pasa esas horas a minutos
    public int diasAMinutos(int dias) {

        // Primer paso: convertir días → horas
        int horas = diasAHoras(dias);

        // Segundo paso: convertir horas → minutos
        return horasAMinutos(horas);
    }
}
