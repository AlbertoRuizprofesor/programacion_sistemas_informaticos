package metodos;

public class Datos {

    public static void main(String[] args) {
        
        // Se crea un objeto de la clase DatosMetodos
        // para poder usar sus métodos no estáticos
        DatosMetodos pd = new DatosMetodos();
                
        // Se llama al método pideNombre enviando "Juan"
        // y se guarda el resultado en la variable 'nombre'
        String nombre = pd.pideNombre("Juan");

        // Se muestra un saludo usando el nombre recibido
        System.out.print("Hola " + nombre + ". ");    
                
        // Se llama al método calcularEdad enviando el año de nacimiento
        // y se guarda el resultado en la variable 'edad'
        int edad = pd.calcularEdad(1973);

        // Se muestra la edad calculada
        System.out.println("Su edad es " + edad + " años ");
    }
}
