package metodos;

public class DatosMetodos {
    
    // Método que recibe un nombre y lo devuelve tal cual.
    // No realiza ninguna transformación, solo retorna el valor recibido.
    public String pideNombre(String nombre) {
        return nombre;
    }
    
    // Método que calcula la edad aproximada.
    // Resta el año de nacimiento al año 2026 y devuelve el resultado.
    public int calcularEdad(int nacimiento) {
        return 2026 - nacimiento;
    }
}
