package metodos;
import java.util.Scanner;

public class Edades {
    
    // Método que pide una edad y muestra un mensaje según el rango
    public void mostrarEdades() {
        
        // Se crea un Scanner para leer datos del teclado
        Scanner entrada = new Scanner(System.in);

        // Se pide la edad al usuario
        System.out.print("Introduzca su edad: ");
        int edad = entrada.nextInt();

        // Condiciones para determinar el mensaje según la edad
        if (edad <= 15) {
            System.out.println("Usted es muy joven todavía");

        } else if (edad > 15 && edad <= 20) {
            System.out.println("Usted es un adolescente");

        } else if (edad > 20 && edad <= 30) {
            System.out.println("Usted está en edad de ligoteo");

        } else if (edad > 30 && edad <= 40) {
            System.out.println("Usted ya tiene menos ganas de ligoteo");

        } else if (edad > 40 && edad <= 50) {
            System.out.println("Usted tiene ganas de ligoteo pero ya no es lo mismo");

        } else if (edad > 50 && edad <= 60) {
            System.out.println("Usted está en la edad de no me comas el tarro");

        } else if (edad > 60 && edad <= 70) {
            System.out.println("Usted ya no tiene filtros y se la suda todo");

        } else {
            System.out.println("Ya le queda poco de vida");
        }

        // Se cierra el Scanner
        entrada.close();
    }

    public static void main(String[] args) {
        // Se crea un objeto de la clase Edades
        Edades n = new Edades();

        // Se llama al método que evalúa la edad
        n.mostrarEdades();
    }
}

