package metodos;

public class EjercicioMetodo1 {

    // Método que recibe un número y devuelve ese número + 10
    public static int sumar(int numero1) {
        return numero1 + 10;
    }

    // Método que recibe un nombre (aunque no lo usa) y muestra un saludo por pantalla
    public static void saludar(String nombre) {
        System.out.println("Hola que tal");
    }

    public static void main(String[] args) {

        // Variable que se pasa como argumento al método sumar
        int numero = 12;

        // Llamada al método sumar: imprime 12 + 10 = 22
        System.out.println(sumar(numero));

        // Llamada al método saludar: imprime el saludo
        saludar("Alberto");
    }
}
