package metodos;
import java.util.Scanner;

public class HorasMinutos {

    public static void main(String[] args) {
        
        // Se crea un Scanner para leer datos desde el teclado
        Scanner n = new Scanner(System.in);
        
        // Se pide al usuario que introduzca un número de días
        System.out.println("Introduce el número de días: ");
        
        // Se lee el número introducido y se guarda en 'dias'
        int dias = n.nextInt();
        
        // Se crea un objeto de la clase HorasMinutosMetodos
        // para poder usar sus métodos no estáticos
        HorasMinutosMetodos c = new HorasMinutosMetodos();
        
        // Se llama al método calcularHoras pasando los días
        // y se guarda el resultado en 'horas'
        int horas = c.calcularHoras(dias);
        
        // Se llama al método calcularMinutos pasando los días
        // y se guarda el resultado en 'minutos'
        int minutos = c.calcularMinutos(dias);
        
        // Se muestran los resultados por pantalla
        System.out.println("El número de horas es " + horas);
        System.out.println("El número de minutos es " + minutos);

        // Se cierra el Scanner
        n.close();
    }
}
