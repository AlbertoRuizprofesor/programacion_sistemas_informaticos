package metodos;

public class HorasMinutosMetodos {

    // Método que recibe un número de días y devuelve cuántas horas son
    public int calcularHoras(int dias){
        return dias * 24;
    }
    
    // Método que recibe un número de días y devuelve cuántos minutos son
    public int calcularMinutos(int dias) {
        return (dias * 24) * 60;
    }
}

