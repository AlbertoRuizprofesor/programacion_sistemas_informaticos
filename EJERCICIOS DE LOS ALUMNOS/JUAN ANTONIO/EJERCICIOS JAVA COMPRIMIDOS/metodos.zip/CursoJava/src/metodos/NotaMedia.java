package metodos;
import java.util.Scanner;

public class NotaMedia {

    // Método que pide tres notas y muestra la media
    public void mostrar_Notas() {

        // Se crea un objeto Scanner para leer datos del teclado
        Scanner entrada = new Scanner(System.in);

        // Se pide la primera nota y se guarda en nota1
        System.out.print("Introduzca la primera nota: ");
        double nota1 = entrada.nextDouble();

        // Se pide la segunda nota
        System.out.print("Introduzca la segunda nota: ");
        double nota2 = entrada.nextDouble();

        // Se pide la tercera nota
        System.out.print("Introduzca la tercera nota: ");
        double nota3 = entrada.nextDouble();

        // Se calcula la media sumando las tres notas y dividiéndolas entre 3
        double media = (nota1 + nota2 + nota3) / 3;

        // Se muestra el resultado por pantalla
        System.out.printf("La nota media es igual a: %.2f ", media);

        // Se cierra el Scanner para liberar recursos
        entrada.close();
    }

    public static void main(String[] args) {

        // Se crea un objeto de la clase NotaMedia
        NotaMedia n = new NotaMedia();

        // Se llama al método que pide las notas y calcula la media
        n.mostrar_Notas();
    }
}

