package metodos;
import java.util.Scanner;

public class Operaciones {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in); 
        // Creamos un objeto Scanner para poder leer datos del teclado

        System.out.print("Introduzca el primer número: ");
        int numero1 = sc.nextInt(); 
        // Leemos el primer número introducido por el usuario

        System.out.print("Introduzca el segundo número: ");
        int numero2 = sc.nextInt(); 
        // Leemos el segundo número

        System.out.print("Introduzca su nombre: ");
        String nombre = sc.next(); 
        // Leemos un String (una palabra) con el nombre del usuario

        // Llamamos al método estático sumar de la clase OperacionesMetodos
        // No hace falta crear objetos porque el método es static
        OperacionesMetodos.sumar(numero1, numero2);

        // Llamamos al método estático saludo de la misma clase
        OperacionesMetodos.saludo(nombre);

        sc.close(); 
        // Cerramos el Scanner para liberar recursos
    }
}

