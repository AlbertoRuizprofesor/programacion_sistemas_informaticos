package metodos;

public class OperacionesMetodos {
    
    // Método estático que devuelve un entero
    // 'static' significa que se puede llamar desde la clase sin crear objetos
    // Recibe dos números enteros (a y b)
    // Como NO es void, debe devolver un valor con 'return'
    public static int sumar(int a, int b) {
        return (a + b); // Devuelve la suma de los dos números
    }
    
    // Método estático que NO devuelve nada (void)
    // Solo muestra un mensaje por pantalla
    // Recibe un String llamado 'nombre'
    public static void saludo(String nombre) {
        System.out.println("Hola como estás " + nombre);
        // Imprime un saludo usando el nombre recibido
    }
}

