package metodos;
import java.util.Scanner;

public class Persona {
    
    // Método NO estático: pertenece a cada objeto Persona
    // Recibe un nombre y devuelve un mensaje de presentación
    public String presentarse(String nombre) {
        return "Hola, soy " + nombre;
    }

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        // Creamos un Scanner para leer datos del teclado

        System.out.print("Introduzca su nombre: ");
        String nombreIntroducido = sc.next();
        // Leemos el nombre que escribe el usuario (una palabra)

        Persona p = new Persona();
        // Creamos un objeto Persona porque presentarse NO es static

        String nombre = p.presentarse(nombreIntroducido);
        // Llamamos al método presentarse usando el objeto 'p'
        // Guardamos el mensaje devuelto en la variable 'nombre'

        System.out.println(nombre);
        // Mostramos el mensaje por pantalla

        sc.close();
        // Cerramos el Scanner
    }
}
