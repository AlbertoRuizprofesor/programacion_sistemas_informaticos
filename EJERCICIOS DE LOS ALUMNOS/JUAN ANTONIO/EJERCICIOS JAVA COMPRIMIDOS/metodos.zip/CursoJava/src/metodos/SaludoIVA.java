
package metodos;

public class SaludoIVA {
    public static void main(String[] args) {

        // Se crea un objeto de la clase SaludoIVAMetodos
        // Esto permite usar sus métodos NO estáticos
        SaludoIVAMetodos ejer2 = new SaludoIVAMetodos();

        // Llamada al método saludarte, enviando un mensaje como argumento
        ejer2.saludarte("Esto es un mensaje de prueba");

        // Llamada al método iva, que devuelve un valor double
        double iva = ejer2.iva(100);

        // Se muestra el resultado por pantalla
        System.out.println("el iva es: " + iva);
    }
}
