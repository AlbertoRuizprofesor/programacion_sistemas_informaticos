package metodos;

public class SaludoIVAMetodos {

    // Método que recibe un nombre y muestra un saludo personalizado
    public void saludarte(String nombre) {
        System.out.println("Hola " + nombre);
    }

    // Método que calcula el 21% de IVA sobre un importe recibido
    public double iva(int importe) {
        return (importe * 0.21);
    }
}
