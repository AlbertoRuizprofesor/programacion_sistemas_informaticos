package poo;

public class Alumno extends Persona {
	private String curso;

	public Alumno(String nombre, String apellidos, int edad, String curso) {
		super(nombre, apellidos, edad);
		this.curso = curso;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	@Override
	public String toString() {
		return "Alumno [Curso=" + getCurso() + ", Nombre=" + getNombre() + ", Apellidos="
				+ getApellidos() + ", Edad=" + getEdad() + "]";
	}	
}
