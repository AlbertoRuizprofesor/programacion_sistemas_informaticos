package poo;

public class AlumnoPiano extends Persona {
	private String nivel;
	private int horasEstudioSemanal;
	
	public AlumnoPiano(String nombre, String apellidos, int edad, String nivel, int horasEstudioSemanal) {
		super(nombre, apellidos, edad);
		this.nivel = nivel;
		this.horasEstudioSemanal = horasEstudioSemanal;
	}

	public String getNivel() {
		return nivel;
	}

	public void setNivel(String nivel) {
		this.nivel = nivel;
	}

	public int getHorasEstudioSemanal() {
		return horasEstudioSemanal;
	}

	public void setHorasEstudioSemanal(int horasEstudioSemanal) {
		this.horasEstudioSemanal = horasEstudioSemanal;
	}
	
	public void tocar() {
		System.out.println("Los alumnos de piano están aprendiendo a tocar.");
	}

	@Override
	public String toString() {
		return "Alumno || " + "Nombre: " + getNombre() + ". Apellidos: " + getApellidos() + ". Edad: " + getEdad() + " años "
				+ ". Nivel: " + getNivel() + ". Horas Estudio Semanal: " + getHorasEstudioSemanal() + " horas.";
	}

	
	
	
	
	
	

}
