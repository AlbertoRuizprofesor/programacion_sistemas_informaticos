package poo;

public class Camion extends Vehiculo {
			private String altura;

			public Camion(String marca, String modelo, String color, String altura) {
				super(marca, modelo, color);
				this.altura = altura;
			}

			public String getAltura() {
				return altura;
			}

			public void setAltura(String altura) {
				this.altura = altura;
			}
			
			public void acelerar() {
				System.out.println("El camión acelera");
			}
			
			public void frenar() {
				System.out.println("El camión frena");
			}

			@Override
			public String toString() {
				return "Camion [Marca=" + getMarca() + ", Modelo="
						+ getModelo() + ", Color=" + getColor() + " Altura" + getAltura() + "]";
			}
			
			
			
}
