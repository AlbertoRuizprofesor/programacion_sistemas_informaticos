package poo;

public class Coche extends Vehiculo {
		private String cilindrada;

		public Coche(String marca, String modelo, String color, String cilindrada) {
			super(marca, modelo, color);
			this.cilindrada = cilindrada;
		}

		public String getCilindrada() {
			return cilindrada;
		}

		public void setCilindrada(String cilindrada) {
			this.cilindrada = cilindrada;
		}
		
		public void acelerar() {
			System.out.println("El coche acelera");
		}
		
		public void frenar() {
			System.out.println("El coche frena");
		}
		

		@Override
		public String toString() {
			return "Coche [Marca=" + getMarca() + ", Modelo="  + getModelo() 
			+ ", Color=" + getColor() + " Cilindrada=" + getCilindrada() + "]";
		}

}
