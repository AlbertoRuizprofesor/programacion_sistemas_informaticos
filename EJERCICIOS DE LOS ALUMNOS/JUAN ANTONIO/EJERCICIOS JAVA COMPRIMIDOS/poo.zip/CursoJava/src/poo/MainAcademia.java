package poo;

public class MainAcademia {

	public static void main(String[] args) {
		
		AlumnoPiano alumno = new AlumnoPiano("Juan","García Hernandez", 17, "Intermedio", 12);
		ProfesorPiano profesor = new ProfesorPiano("María", "Sanchez López", 56, 25, "Piano Clásico");
		Recepcionista recepcionista = new Recepcionista("Rosario", "Martín Flores", 34, "Mañana", "Inglés y Francés");
		
		
		System.out.println(alumno.toString());
		alumno.tocar();
		
		System.out.println(profesor.toString());
		profesor.trabajo();
		
		System.out.println(recepcionista.toString());
		recepcionista.trabajo();
		
	}
}
