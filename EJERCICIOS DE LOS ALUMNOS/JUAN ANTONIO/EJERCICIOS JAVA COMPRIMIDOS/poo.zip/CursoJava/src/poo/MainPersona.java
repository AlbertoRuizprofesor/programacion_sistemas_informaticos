package poo;

public class MainPersona {

	public static void main(String[] args) {
		Persona persona = new Persona("Alberto", "Ruiz", 45 );
		Alumno alumno = new Alumno("Pedro", "Fernández", 34 , "Matemáticas");
		Profesor profesor = new Profesor("Juan","Hernández",23, "Literatura");
		System.out.println(persona.toString());
		System.out.println(alumno.toString());
		System.out.println(profesor.toString());
		
		
	}

}
