package poo;

public class MainVehiculo {

	public static void main(String[] args) {
		Vehiculo vehiculo = new Vehiculo("Seat", "Ibiza", "Blanco");
		Coche coche = new Coche("Seat", "León", "Rojo", "2000c.c.");
		Moto moto = new Moto("Yamaha", "CRX", "Amarillo", "120kg");
		Camion camion = new Camion("Pegaso", "H5000", "Rojo", "2m.");
		
		
		System.out.println(vehiculo.toString());
		System.out.println(coche.toString());
		coche.acelerar();
		coche.frenar();
		
		System.out.println(moto.toString());
		moto.acelerar();
		moto.frenar();
		
		System.out.println(camion.toString());
		camion.acelerar();
		camion.frenar();	
	}

}
