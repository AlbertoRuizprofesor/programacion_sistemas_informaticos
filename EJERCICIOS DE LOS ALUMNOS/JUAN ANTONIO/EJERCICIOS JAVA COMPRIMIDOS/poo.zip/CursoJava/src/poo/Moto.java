package poo;

public class Moto extends Vehiculo {
	
		private String peso;
		Moto(String marca, String modelo, String color, String peso) {
			super(marca, modelo, color);
			this.peso = peso;
		}
		

		public String getPeso() {
			return peso;
		}

		public void setPeso(String peso) {
			this.peso = peso;
		}
		
		public void acelerar() {
			System.out.println("La moto acelera");
		}
		
		public void frenar() {
			System.out.println("La moto frena");
		}

		@Override
		public String toString() {
			return "Moto [Marca=" + getMarca() + ", Modelo=" + getModelo()
					+ ", Color=" + getColor() + ", Peso=" + getPeso() + "]";
		}
		
		
}
