package poo;

public class Profesor extends Persona {
		private String asignatura;

		public Profesor(String nombre, String apellidos, int edad, String asignatura) {
			super(nombre, apellidos, edad);
			this.asignatura = asignatura;
		}

		public String getAsignatura() {
			return asignatura;
		}

		public void setAsignatura(String asignatura) {
			this.asignatura = asignatura;
		}

		@Override
		public String toString() {
			return "Profesor [Asignatura=" + getAsignatura() + ", Nombre=" + getNombre() + ", Apellidos="
					+ getApellidos() + ", Edad=" + getEdad() + "]";
		}		
}
