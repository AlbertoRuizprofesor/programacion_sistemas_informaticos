package poo;

public class ProfesorPiano extends Persona {
	private int tiempoExperiencia;
	private String especialidad;
	public ProfesorPiano(String nombre, String apellidos, int edad, int tiempoExperiencia, String especialidad) {
		super(nombre, apellidos, edad);
		this.tiempoExperiencia = tiempoExperiencia;
		this.especialidad = especialidad;
	}
	public int getTiempoExperiencia() {
		return tiempoExperiencia;
	}
	public void setTiempoExperiencia(int tiempoExperiencia) {
		this.tiempoExperiencia = tiempoExperiencia;
	}
	public String getEspecialidad() {
		return especialidad;
	}
	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}
	
	public void trabajo() {
		System.out.println("El trabajo de los profesores es enseñar a los alumnos.");
	}
	@Override
	public String toString() {
		return "Profesor || " + "Nombre: " + getNombre() + ". Apellidos: " + getApellidos()
				+ ". Edad: " + getEdad() + " años. Experiencia " + getTiempoExperiencia() + " años. Especialidad: " + getEspecialidad() + ".";
	}
	
	
}
