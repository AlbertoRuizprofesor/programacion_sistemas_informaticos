package poo;

public class Recepcionista extends Persona {
	private String turno;
	private String idiomas;
	public Recepcionista(String nombre, String apellidos, int edad, String turno, String idiomas) {
		super(nombre, apellidos, edad);
		this.turno = turno;
		this.idiomas = idiomas;
	}
	public String getTurno() {
		return turno;
	}
	public void setTurno(String turno) {
		this.turno = turno;
	}
	public String getIdiomas() {
		return idiomas;
	}
	public void setIdiomas(String idiomas) {
		this.idiomas = idiomas;
	}
	public void trabajo() {
		System.out.println("La recepcionista se ocupa de las matrículas de los alumnos.");
	}
	@Override
	public String toString() {
		return "Recepcionista || " + "Nombre: " + getNombre() + ". Apellidos: " + getApellidos() + ". Edad: " + getEdad() + " años"
		+ ". Turno: " + getTurno() + ". Idiomas: " + getIdiomas() + ".";
	}
	
	
}
