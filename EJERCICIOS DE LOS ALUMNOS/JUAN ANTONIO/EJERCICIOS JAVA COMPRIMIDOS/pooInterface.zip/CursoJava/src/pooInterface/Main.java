package pooInterface;

public class Main {

	public static void main(String[] args) {
		
		Calculadora cal = new Calculadora();
		
		cal.mostrar(5, 4);

	}

}
