package pooInterface;

public interface Operaciones {
	int sumar(int a, int b);
	int restar(int a, int b);
	int multi(int a, int b);
	int dividir(int a, int b);
	void mostrar(int a, int b);
	
}
