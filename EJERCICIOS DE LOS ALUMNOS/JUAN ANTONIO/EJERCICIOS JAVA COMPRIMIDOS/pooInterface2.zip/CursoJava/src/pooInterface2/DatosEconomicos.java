package pooInterface2;

public interface DatosEconomicos {
	String pagar(String nombre);
}

	

