package pooInterface2;

public interface DatosPersonales {	
	String enviar_datos(String nombre);
	String firmar(String nombre);
	String mostrar_datos(String nombre);
	
}
