package retoFichero;

import java.io.File;

public class CrearCarpeta {
    public static void main(String[] args) {

    	// Ruda donde se van a crear las carpetas
        String ruta = "C:/prueba/";  

        // Array con los nombres de las carpetas que debemos crear
        String[] carpetas = {"CLIENTES", "PROVEEDORES", "PRODUCTOS"};

        // Recorremos el array con un bucle for-each
        for (String nombreCarpeta : carpetas) {

        	//Creamos un objeto File que representa la ruta completa de la carpeta
            File directorio = new File(ruta + nombreCarpeta);

            //Comprobamos si la carpeta existe
            if (directorio.exists()) {
                System.out.println("La carpeta " + nombreCarpeta + " ya existe");
            } else {
                directorio.mkdir();
                System.out.println("Carpeta " + nombreCarpeta + " creada");
            }
        }
    }
}

