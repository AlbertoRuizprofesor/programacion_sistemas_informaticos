package retoFichero;

import java.io.File;
import java.io.IOException;

public class CrearFichero {
    public static void main(String[] args) {

    	// Ruta donde están las carpetas
        String ruta = "C:/prueba/";  

        // Nombres de carpetas y ficheros asociados
        String[][] datos = {
                {"CLIENTES", "CLIENTES.TXT"},
                {"PROVEEDORES", "PROVEEDORES.TXT"},
                {"PRODUCTOS", "PRODUCTOS.TXT"}
        };
        
        for (String[] elemento : datos) {

            String carpeta = elemento[0];
            String fichero = elemento[1];

            File archivo = new File(ruta + carpeta + "/" + fichero);

            try {
                if (archivo.exists()) {
                    System.out.println("El fichero " + fichero + " ya existe");
                } else {
                    archivo.createNewFile();
                    System.out.println("Fichero " + fichero + " creado en " + carpeta);
                }
            } catch (IOException e) {
                System.out.println("Error al crear el fichero " + fichero);
                e.printStackTrace();
            }
        }
    }
}