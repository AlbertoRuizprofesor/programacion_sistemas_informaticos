package retoFichero;

public class MostrarDatos {
    public static void main(String[] args) {

        // Arrays con los datos
        String[] clientes = {"Ayto Málaga", "Erosky", "Carrefour"};
        String[] proveedores = {"Microsoft", "Google", "Apple"};
        String[] productos = {"Office", "Gemini", "Iphone 17 pro"};

        // Mostrar datos
        System.out.println("=== CLIENTES ===");
        for (String c : clientes) {
            System.out.println(c);
        }

        System.out.println("\n=== PROVEEDORES ===");
        for (String p : proveedores) {
            System.out.println(p);
        }

        System.out.println("\n=== PRODUCTOS ===");
        for (String pr : productos) {
            System.out.println(pr);
        }
    }
}
