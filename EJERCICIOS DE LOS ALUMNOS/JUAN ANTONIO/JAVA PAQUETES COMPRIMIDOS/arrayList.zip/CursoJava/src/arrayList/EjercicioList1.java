package arrayList;

import java.util.ArrayList;

public class EjercicioList1 {

	public static void main(String[] args) {
		
		ArrayList<Integer> lista = new ArrayList<>();
		ArrayList<String> nombres = new ArrayList<>();
		ArrayList<Double> decimal = new ArrayList<>();
		
		lista.add(10);
		lista.add(20);
		
		nombres.add("Alberto");
		nombres.add("Laura");
		
		decimal.add(20.12);
		decimal.add(10.45);
		
		for(int list:lista) {
			System.out.println("valor " + list);
		}
		
		for(String name:nombres) {
			System.out.println("valor " + name);
		}
		
		for(Double dec:decimal) {
			System.out.println("valor " + dec);
		}
	}
}
