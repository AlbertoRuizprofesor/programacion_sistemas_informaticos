package arrayList;

import java.util.ArrayList;

public class EjercicioList2 {

	public static void main(String[] args) {
		
		//Creamos una lista de Strings para almacenar nombres
		ArrayList<String> nombres = new ArrayList<>();
		
		//Creamos una lista de Boolean para almacenar valores verdaderos/falso
		ArrayList<Boolean> verdaderoFalso = new ArrayList<>(); 
		
		//Añadimos elementos a la lista de nombres
		nombres.add("Juan");
		nombres.add("María");
		nombres.add("José");
		nombres.add("Jose María");
		
		//Añadimos elementos a la lista de booleanos
		verdaderoFalso.add(true);
		verdaderoFalso.add(false);
		verdaderoFalso.add(false);
		verdaderoFalso.add(true);
		
		
		//Mostramos cuantos elementos tiene la lista de nombres
		System.out.println("El número de elementos es igual a "  + nombres.size());
		
		//Mostramos todos los elementos de la lista de nombres
		System.out.println("Los elementos de la lista son: " + nombres);
		
		//Eliminamos el elemento de la posición 1 (segundo elemento: María)
		nombres.remove(1);
		
		
		//Mostramos el nuevo tamaño de la lista de nombres
		System.out.println("El número de elementos ahora es igual a: "  + nombres.size());
		
		//Mostramos la lista de nombres después de eliminar un elementos
		System.out.println("Los elementos de la lista ahora son: " + nombres);
		
		
		//Mostramos cuántos elementos tiene la lista de booleanos
		System.out.println("El número de elementos es igual a: " + verdaderoFalso.size());
		
		//Mostramos todos los elementos de la lista booleanos
		System.out.println("Los elementos de la lista son: " + verdaderoFalso);
		
		//Eliminamos el elemento en la posición 2 (tercer elemento: false)
		verdaderoFalso.remove(2);
		
		//Mostramos el nuevo tamaño de la lista de booleanos
		System.out.println("El número de elementos ahora es igual a: " + verdaderoFalso.size());
		
		//Mostramos la lista de booleanos después de eliminar un elemento
		System.out.println("Los elementos de la lista ahora son: " + verdaderoFalso);

	}

}
