package arrayList;

import java.util.ArrayList;

public class EjercicioList3 {

	public static void main(String[] args) {
		//Creamos una lista de números
		ArrayList<Integer> numeros = new ArrayList<>();
		
		numeros.add(10);
		numeros.add(20);
		numeros.add(30);
		numeros.add(40);
		
		
		System.out.println("Los elementos de la lista son: " + numeros);
		
		//BUSCAR un número dentro de una lista
		buscar(numeros,30);
		
		//Modificar un número de la lista
		modificar(numeros,30, 2000);
		
		//Intento de buscar algo que no existe
		buscar(numeros, 99);
		
		//Intento de modificar algo que no existe
		modificar(numeros, 99, 5000);
	}
	
	//----------------------------------------------------------------------
	// FUNCIÓN BUSCAR
	//----------------------------------------------------------------------
	
	public static void buscar(ArrayList<Integer> lista, int elemento) {
		
		// contains() comprueba si el elemento está en la lista
		if(lista.contains(elemento)) {
			int posicion = lista.indexOf(elemento);
			
			System.out.println("✔Encontrado: " + elemento + " en la posición " + posicion);
		}else {
			System.out.println("No encontrado... tengo hambre");
		}
	}
	
	public static void modificar(ArrayList<Integer> lista, int elemento, int nuevoValor) {
		
		// Primero comprobamos si existe
		if(lista.contains(elemento)) {
			
			//Obtenemos la posicion donde está
			int posicion = lista.indexOf(elemento);
			
			// set() reemplaza el valor en esa posición
			lista.set(posicion, nuevoValor);
			
			System.out.println("✔ " + elemento + " ha sido reemplazado por " + nuevoValor);
			System.out.println("Lista actualizada:" + lista);
			
		}else {
			System.out.println("✘ No se puede modificar porque no existe... sigo teniendo hambre");
		}
	}
}
