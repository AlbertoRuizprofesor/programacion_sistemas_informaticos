package baseDatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Ej1_CrearBaseDeDatos {
    public static void main(String[] args) {

        String sql = "CREATE DATABASE IF NOT EXISTS empresa1";

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost/", "root", "");
             Statement st = con.createStatement()) {

            st.execute(sql);
            System.out.println("BD empresa1 creada/ya existía.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
