package baseDatos;

import java.sql.Connection;
import java.sql.Statement;

public class Ej2_CrearTablaClientes {
    public static void main(String[] args) {

        String sql = "CREATE TABLE IF NOT EXISTS clientes (" +
                "id INT PRIMARY KEY," +
                "nif VARCHAR(10) NOT NULL," +
                "nombre VARCHAR(60) NOT NULL," +
                "edad VARCHAR(2))";

        try (Connection con = DB.conectar();
             Statement st = con.createStatement()) {

            st.execute(sql);
            System.out.println("Tabla clientes creada/ya existía.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

