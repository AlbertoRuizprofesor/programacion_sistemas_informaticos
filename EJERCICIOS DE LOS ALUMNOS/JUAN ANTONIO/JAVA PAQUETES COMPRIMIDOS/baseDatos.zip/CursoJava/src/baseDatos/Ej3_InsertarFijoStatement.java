package baseDatos;

import java.sql.Connection;
import java.sql.Statement;

public class Ej3_InsertarFijoStatement {
    public static void main(String[] args) {

        String sql = "INSERT INTO clientes (id, nif, nombre, edad) " +
                     "VALUES (10,'99999','ClienteFijo','30')";

        try (Connection con = DB.conectar();
             Statement st = con.createStatement()) {

            int filas = st.executeUpdate(sql);
            System.out.println("Insertados: " + filas);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
