package baseDatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Ej4_InsertarPrepared {
    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in);
             Connection con = DB.conectar()) {

            System.out.print("ID: ");
            int id = Integer.parseInt(sc.nextLine());

            System.out.print("NIF: ");
            String nif = sc.nextLine();

            System.out.print("Nombre: ");
            String nombre = sc.nextLine();

            System.out.print("Edad: ");
            String edad = sc.nextLine();

            String sql = "INSERT INTO clientes (id, nif, nombre, edad) VALUES (?,?,?,?)";

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, id);
                ps.setString(2, nif);
                ps.setString(3, nombre);
                ps.setString(4, edad);

                int filas = ps.executeUpdate();
                System.out.println("Insertados: " + filas);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
