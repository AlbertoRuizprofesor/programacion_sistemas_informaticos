package baseDatos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Ej5_ListarClientes {
    public static void main(String[] args) {

        String sql = "SELECT * FROM clientes";

        try (Connection con = DB.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println(
                        rs.getInt("id") + " | " +
                        rs.getString("nif") + " | " +
                        rs.getString("nombre") + " | " +
                        rs.getString("edad")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
