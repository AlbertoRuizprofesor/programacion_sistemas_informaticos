package baseDatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Ej6_UpdateYDeletePrepared {
    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in);
             Connection con = DB.conectar()) {

            // A) UPDATE
            System.out.print("ID a actualizar: ");
            int idUpdate = Integer.parseInt(sc.nextLine());

            System.out.print("Nueva edad: ");
            String nuevaEdad = sc.nextLine();

            String sqlUpdate = "UPDATE clientes SET edad = ? WHERE id = ?";
            try (PreparedStatement ps = con.prepareStatement(sqlUpdate)) {
                ps.setString(1, nuevaEdad);
                ps.setInt(2, idUpdate);
                System.out.println("Filas actualizadas: " + ps.executeUpdate());
            }

            // B) DELETE
            System.out.print("ID a borrar: ");
            int idDelete = Integer.parseInt(sc.nextLine());

            String sqlDelete = "DELETE FROM clientes WHERE id = ?";
            try (PreparedStatement ps = con.prepareStatement(sqlDelete)) {
                ps.setInt(1, idDelete);
                System.out.println("Filas borradas: " + ps.executeUpdate());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

