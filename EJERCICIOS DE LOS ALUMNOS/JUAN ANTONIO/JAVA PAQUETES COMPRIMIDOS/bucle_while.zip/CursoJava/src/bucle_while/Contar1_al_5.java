package bucle_while;

public class Contar1_al_5 {

	public static void main(String[] args) {
		
		int i = 1; //Variable de control del bucle. Empieza en 1
		
		//Mientras i sea menor o igual que 5, el bucle sigue ejecutandose
		while (i <= 5) {
			
			System.out.print(i + " "); //Imprime el valor actual de i en la misma línea
			
			i++;
			//Incrementa i en 1 para acercarse a la condición de salida
			//Si no se incrementa, el bucle es infinito
		}
	}
}
