package bucle_while;

public class ContarAtras {

	public static void main(String[] args) {
		int numero = 10;
		//Variable de control del bucle
		//Empieza en 10 porque queremos contar hacia atrás
		
		//Mientras numero sea mayor o igual que 1 el bucle sigue ejecutandose
		while(numero >= 1) {
			
			System.out.print(numero + " "); //Imprime el valor actual de numero en la misma línea
			
			numero--; 
			//Decrementa "numero" restándole 1 en cada vuelta
			//Esto acerca la variable a la condición de salida del bucle
		}
	}
}
