package bucle_while;
import java.util.Scanner;

public class MayoresDe10 {

	public static void main(String[] args) {
		
		Scanner c = new Scanner(System.in);

		int contador = 0;
		int valor = 1;
		
		while(valor != 0) {
			System.out.print("Escriba un número (0 para terminar): ");
			valor = c.nextInt();
			
			if (valor > 10) {
				contador++;
			}
			
		}
		System.out.println("Ha escrito " + contador + " números mayores que 10");
		c.close();
	}

}
