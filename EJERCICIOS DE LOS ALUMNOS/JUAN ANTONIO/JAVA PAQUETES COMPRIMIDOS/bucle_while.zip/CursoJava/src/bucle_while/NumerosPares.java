package bucle_while;

public class NumerosPares {

	public static void main(String[] args) {

		int p = 1; //Variable de control del bucle. Empieza en 1
		
		//El bucle se ejecuta mientras p sea menor o igual a 20
		while (p <= 20) {
			
			//p % 2 calcula el resto de dividir p entre 2
			//Si el resto es 0, significa que p es un número par
			if (p % 2 == 0) {
				System.out.print(p + " "); //Si es par lo imprimimos en la misma línea
			}
			p++; // Incrementamos p en 1 para avanzar hacia el final del bucle
		}
	}
}


