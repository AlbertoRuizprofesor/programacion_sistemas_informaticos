package bucle_while;
import java.util.Scanner; //Importación de la clase Scanner

public class Password {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); //Objeto Scanner para leer lo que escriba el usuario
		String password = "java"; //Contraseña correcta que queremos comprobar
		
		//Variable donde guardaremos lo que escribe el usuario
		//Empieza vacía para que el while pueda ejecutarse al menos una vez
		String intento = ""; 
		
		
		//El bucle se repite mientras "intento" no sea igual a "password"
		//! significa "no", así que la condición es:
		// "mientras intento NO sea igual a password"
		while (!intento.equals(password)) {

			System.out.print("Introduzca una contraseña: "); //Pedimos al usuario que introduzca una contraseña
			intento = sc.next(); //Leemos un nuevo intento del usuario en cada vuelta
			
		}
		System.out.println("Acceso permitido");
		//Este mensaje solo se ejecuta cuando el while termina, es decir, cuanto el usuario escribe "java"
		sc.close(); //Cerramos el objeto Scanner
	}

}
