package bucle_while;
import java.util.Scanner; //Importa la clase Scanner

public class PedirNumeros {

	public static void main(String[] args) {
		Scanner a = new Scanner(System.in); //Constructor del objeto Scanner
		int numero = -1; //Inicializa la variable numero con un numero distinto de 0 para que se ejecute el bucle
		
		//Mientras numero no sea 0 se ejecuta el bucle
		while(numero != 0) {
			System.out.print("Introduce un número(0 para salir): "); //Pide al usuario que introduzca un numero y 0 para salir
			numero = a.nextInt();	//Almacena el numero introuducido por el usuario en la variable numero
		}
		System.out.print("Gracias por su visita, que tenga un buen día"); //Imprime un mensaje de despedida en la consola
		a.close(); // Cierra el objeto Scanner ya que no lo vamos a utilizar más
	}
}
