package bucle_while;

public class SumarNumeros {

	public static void main(String[] args) {
		
		int x = 1; //Variable de control del bucle. Empieza en 1
		
		int suma = 0; //Acumulador donde iremos sumando todos los valores de x
		
		//Mientras x sea menor o igual a 10 el bucle sigue ejecutandose
		while(x <= 10) {
			
			suma += x; 
			//Equivale a: suma = suma + x
			//Va acumulando todos los números del 1 al 10
		
			System.out.print(x + " "); //Muestra el valor actual de x en la misma línea
			x++; //Incrementa x en 1 para avanzar hacia la condición de salida.
		}
		System.out.println("La suma de todos los numeros es : " + suma);// Cuando el while termina, mostramos el resultado total
	}
}
