package condicional;//Pertenece al paquete condicional
import java.util.Scanner;//Importacion clase Scanner del paquete java.util
public class Edades {

	public static void main(String[] args) {
		
		
		Scanner c = new Scanner(System.in);//Cración del objeto Scanner
		System.out.println("Introduzca su edad: ");//Pedimos al usuario que introduzca una edad
		int edad = c.nextInt();//Almacenamos la edad introducida en la variable edad
		
		
		//Realizamos las comparaciones y sacamos los resultados por consola
		if(edad < 18) {
			System.out.println("Usted es menor de edad");
			
		}else if(edad >= 18 && edad <= 40) {
			System.out.println("Es usted joven");
			
		}else if(edad >= 40 && edad <= 60) {
			System.out.println("Usted es una persona madura");
			
		}else if(edad >= 60 && edad <= 70) {
			System.out.println("Usted es una persona mayor pero tiene vida por delante");
			
		}else if(edad >= 70 && edad <= 80) {
			System.out.println("Usted ya es mayor tiene que cuidarse");
			
		}else {
			System.out.println("Vaya, vaya, ya le queda poco para despedirse");
		}
		c.close();//Cerramos el objeto Scanner
	}

}
