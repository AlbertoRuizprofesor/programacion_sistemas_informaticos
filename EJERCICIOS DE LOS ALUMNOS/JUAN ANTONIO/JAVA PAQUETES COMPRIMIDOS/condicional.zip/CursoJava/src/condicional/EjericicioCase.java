package condicional; //Paquete donde vive la clase. Sirve para organizar le código

import java.util.Scanner; //Importamos la clase Scanner para leer datos del teclado

public class EjericicioCase {

	public static void main(String[] args) {
		Scanner c = new Scanner(System.in); ////Creamos un objeto Scanner llamado "c" para leer números del usuario

		System.out.println("Introduzca un número: "); //Pedimos un número al usuario
		int numero = c.nextInt(); 

		
		switch (numero) {
		case 1:
			System.out.println("Usted eligió el número :" + numero);
			break;
		case 2:
			System.out.println("Usted eligió el número: " + numero);
			break;
		case 3:
			System.out.println("Usted eligió el número: " + numero);
			break;
		default:
			System.out.println("Usted eligió: " + numero + " no es correcto");

		c.close();
		}

	}

}
