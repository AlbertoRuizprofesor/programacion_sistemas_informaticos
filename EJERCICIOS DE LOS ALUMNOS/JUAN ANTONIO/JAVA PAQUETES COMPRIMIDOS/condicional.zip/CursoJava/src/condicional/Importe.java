/*
EJERCICIO PROPUESTO
Escribe un programa que pida al usuario un importe.
Según el importe introducido, se aplicará un descuento:

Menos de 50€ → 0% de descuento

Entre 50€ y 100€ → 5% de descuento

Entre 100€ y 200€ → 10% de descuento

Más de 200€ → 15% de descuento

El programa debe mostrar:

El importe original

El descuento aplicado

El precio final
 */


package condicional;
import java.util.Scanner;

public class Importe {

	public static void main(String[] args) {
		
		Scanner i = new Scanner(System.in); //Creamos el objeto Scanner
        System.out.println("Introduzca un importe: ");
        double importe = i.nextDouble(); //Almacenamos el importe introducido en la variable importe
        
        double descuento = 0;//Variable para guardar el porcentaje de descuento
        
        
        if(importe < 50) {
        	descuento = 0;
        	
        }else if(importe >= 50 && importe < 100){
        	descuento = 5;
        	
        }else if(importe >= 100 && importe < 200) {
        	descuento = 10;
        	
        }else {
        	descuento = 15;
        }
		
		//Calculamos el precio final
		double cantidadDescontada = importe * (descuento / 100);//Calculamos la cantidad a descontar
		double precioFinal = importe - cantidadDescontada;//Calculamos el precio final
		
		
		//Imprimimos el resultado:
		//-importe original
		//-el descuento aplicado
		//-el precio final
		System.out.println("El importe original es: " + importe);
		System.out.println("El descuento aplicado es: " + descuento + "%");
		System.out.println("El precio final es: " + precioFinal + "€");
		
		i.close();//Cerramos el objeto Scanner
	}

}
