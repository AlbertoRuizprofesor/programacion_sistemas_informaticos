 package condicional;
 import java.util.Scanner;//Importamos la clase Scanner

public class MayorEdad {

	public static void main(String[] args) {
		
		Scanner a = new Scanner (System.in);//Creamos el objeto Scanner
		System.out.println("Introduzca su edad: ");//Pedimos al usuario que introduzca su edad
		int edad = a.nextInt();//Almacenamos la edad introducida
		String resultado = "";//Declaramos e inicializamos una variable tipo string para almacenar el resultado
		
		
		//Se hacen las comparaciones para determinar si el usuario es mayor o menor
		if(edad >= 18) {
			resultado = "Es usted mayor de edad";
		}else {
			resultado = "Es usted menor de edad";
		}
		
		//Se imprime el resultado
		System.out.println(resultado);
		
		a.close();//Se cierra el objeto Scanner
	}

}