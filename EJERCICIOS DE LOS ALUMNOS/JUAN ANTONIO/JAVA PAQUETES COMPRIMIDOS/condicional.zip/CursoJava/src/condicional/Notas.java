package condicional; //Pertenece al paquete condicional
import java.util.Scanner; //Importación de la clase Scanner del paquete java.util

public class Notas {

    public static void main(String[] args) {
        
        Scanner i = new Scanner(System.in); //Creamos el objeto Scanner
        System.out.println("Introduzca una nota: ");
        double nota = i.nextDouble(); //Almacenamos la nota introducida en la variable nota
        
        
        //Realizamos las comparaciones e imprimimos el resultado
        if (nota < 5) {
            System.out.println("Usted está suspenso");
            
        } else if (nota >= 5 && nota < 6) {
            System.out.println("Usted tiene un suficiente");
            
        } else if (nota >= 6 && nota < 7) {
            System.out.println("Usted tiene un bien");
            
        } else if (nota >= 7 && nota < 9) {
            System.out.println("Usted tiene un notable");
            
        } else if (nota >= 9 && nota <= 10) {
            System.out.println("Usted tiene un sobresaliente");
            
        } else {
            System.out.println("Nota no válida");
        }

        i.close(); //Cerramos el Scanner
    }
}
