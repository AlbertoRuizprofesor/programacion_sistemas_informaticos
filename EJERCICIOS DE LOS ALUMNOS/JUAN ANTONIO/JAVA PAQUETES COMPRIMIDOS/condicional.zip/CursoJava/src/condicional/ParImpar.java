package condicional;
import java.util.Scanner;//Importacion de la clase Scanner del paquete java.util

public class ParImpar {

	public static void main(String[] args) {
		
		Scanner num = new Scanner(System.in);//Creamos el objeto Scanner
		System.out.println("Introduzca un número: ");//Pedimos al usuario que introduzca un número
		double numero = num.nextDouble();//Almacenamos el numero introducido en la variable numero
		
		String resultado = "";//Declaramos una variable tipo String para almacenar el resultado 
		
		
		//Realizamos las comparaciones para saber si el número introducido es par o impar
		if(numero % 2 == 0) {
			resultado = "El número introducido es par";
		}else {
			resultado = "El número es impar";
		}
		
		//Mostramos en la consola el resultado
		System.out.println(resultado);
		
		num.close();//Cerramos el objeto Scanner
	}

}
