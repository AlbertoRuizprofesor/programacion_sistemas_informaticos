//Conectar con la base de datos

package conectarMysql;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;

public class ConectarDbStatement {
	   //declaramos los diferentes objetos necesarios para nuestra conexión
	   
	   public static void main(String[] args) throws SQLException  {
	      Connection conn = null;
	      Statement sent = null;
	      String sql = "CREATE DATABASE techacademy_db";
	     try {
	    	 //Desde aquí se encarga del driver JDBC    
	         conn = DriverManager.getConnection("jdbc:mysql://localhost/techacademy_db","root","");
	         sent = conn.createStatement();
	         sent.execute(sql);
	         System.out.println("La base de datos techacademy ok");
	         conn.close();
	         sent.close();
	         //controlamos que la conexión ha sido ok
	      }
	      catch(SQLException e)                   
	         {System.out.println("Error en la conexión "+e.getMessage());  
	      }
	 }
}
