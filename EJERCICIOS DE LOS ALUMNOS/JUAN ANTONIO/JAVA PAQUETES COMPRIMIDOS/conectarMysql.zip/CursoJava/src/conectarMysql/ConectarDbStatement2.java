//Insertar datos

package conectarMysql;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class ConectarDbStatement2 {

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;

        String sql = "INSERT INTO Ejemplo (id, nif, nombre, edad) "
                   + "VALUES (1, '11111', 'Alberto', '40')";

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/techacademy_db", "root", "");
            stmt = conn.createStatement();
            stmt.executeUpdate(sql);

            System.out.println("Datos insertados en la tabla Ejemplo");

            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
