//Crear la tabla proveedores  

package conectarMysql;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CrearTablaProveedores {
	   //declaramos los diferentes objetos necesarios para nuestra conexión
	   
	   public static void main(String[] args) throws SQLException  {
	      Connection conn = null;
	      Statement stmt=null;

	      String sql="CREATE TABLE Proveedores ("
	      		+ "id INT PRIMARY KEY,"
	      		+ "nombre VARCHAR(60) NOT NULL, "
	      		+ "telefono VARCHAR(20) NOT NULL, "
	      		+ "email VARCHAR(60) NOT NULL"
	      		+ ")";
	     try {
	    	 //Desde aquí se encarga del driver JDBC    
	         conn = DriverManager.getConnection("jdbc:mysql://localhost/techacademy_db","root","");
	         //controlamos que la conexión ha sido ok
	         stmt=conn.createStatement();
	         stmt.execute(sql);
	         System.out.println("Creada la tabla Proveedores");
	         conn.close();
	         stmt.close();
	      }
	      catch(SQLException e)                   
	         {e.printStackTrace();  
	      }
	 }
}