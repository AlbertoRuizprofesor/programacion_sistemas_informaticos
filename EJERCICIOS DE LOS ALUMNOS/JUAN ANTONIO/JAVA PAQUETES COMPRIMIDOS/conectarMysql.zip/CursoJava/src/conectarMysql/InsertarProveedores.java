//Inserta datos en la tabla Proveedores

package conectarMysql;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertarProveedores {

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;

        String sql = "INSERT INTO Proveedores (id, nombre, telefono, email) "
        		   + "VALUES"
                   + "(1, 'Juan Pérez', '600123123', 'juan@gmail.com'),"
                   + "(2, 'Esteban Ruíz', '903986574', 'correo@hotmail.com')";
        		
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/techacademy_db", "root", "");
            stmt = conn.createStatement();
            stmt.executeUpdate(sql);

            System.out.println("Proveedor insertado correctamente");

            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
