//Mostrar los datos de la tabla Proveedores

package conectarMysql;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class MostrarProveedores {

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;

        String sql = "SELECT * FROM Proveedores";
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/techacademy_db", "root", "");
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String telefono = rs.getString("telefono");
                String email = rs.getString("email");

                System.out.println(
                    "ID: " + id +
                    ", Nombre: " + nombre +
                    ", Teléfono: " + telefono +
                    ", Email: " + email
                );
            }
            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}