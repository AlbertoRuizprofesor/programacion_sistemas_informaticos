package interfacesGraficas;

import javax.swing.*;

import java.awt.*;

public class Calculadora {
    public static void main(String[] args) {
        JFrame frame = new JFrame("GridLayout Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 400);
        //estamos combinando tanto el borderlayout, 
        //lo vamos a utilizar para el Jtextfield
        JTextField textField = new JTextField();
        frame.add(textField, BorderLayout.NORTH);
        
        //creamos un jpane
        JPanel panel = new JPanel();
        //creamos el layout, indicamos fila, columna, hgap, vgap
        panel.setLayout(new GridLayout(4, 4,2,2));
        // creamos un string de buttons
        String[] buttons = {
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "0", "C", "=", "+",
            "\u221A","\u03C0","\u221B","\u221C"         
        };

        // creamos una serie de buttons
        for (String text : buttons) {
            panel.add(new JButton(text));
        }
        
        
        
        //añadimos el panel al borderlayout
        frame.add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null); // La ventana aparece centrada en la pantall
    }
}

