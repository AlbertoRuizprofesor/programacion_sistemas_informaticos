package interfacesGraficas;

import javax.swing.*;
import java.awt.*;

public class Calculadora1 extends JFrame {
    public Calculadora1() {
        // Configura la ventana
        setTitle("Calculadora B�sica");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Pantalla
        JTextField pantalla = new JTextField();
        pantalla.setEditable(false);
        panel.add(pantalla, BorderLayout.NORTH);

        // Panel de botones
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(4, 4));

        // Botones
        String[] botones = {
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "0", "C", "=", "+"
        };

        for (String textoBoton : botones) {
            JButton boton = new JButton(textoBoton);
            boton.setFont(new Font("Arial", Font.PLAIN, 18));
            
            //----------------------------------
            //	AÑADIR FUNCIONALIDAD AQUÍ
            //----------------------------------
            boton.addActionListener(e->{
            	
            	// Obtiene el texto del botón pulsado
            	String valor = e.getActionCommand();
            	
            	// Si el botón es "C", borra la pantalla
            	if(valor.equals("C")) {
            		pantalla.setText("");	//Borra pantalla
            	}else {
            		// Si no es "C" añade el texto a la pantalla
            		pantalla.setText(pantalla.getText() + valor);
            	}
            });
            panelBotones.add(boton);
        }

        panel.add(panelBotones, BorderLayout.CENTER);

        // Agrega el panel principal a la ventana
        add(panel);

        // Muestra la ventana
        setVisible(true);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Calculadora1();
        });
    }
}
