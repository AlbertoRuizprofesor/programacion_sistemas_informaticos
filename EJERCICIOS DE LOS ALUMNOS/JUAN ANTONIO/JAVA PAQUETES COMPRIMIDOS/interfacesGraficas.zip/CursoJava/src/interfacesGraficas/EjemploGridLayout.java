package interfacesGraficas;

import javax.swing.*;
import java.awt.*;

public class EjemploGridLayout {
    public static void main(String[] args) {
    	
        JFrame frame = new JFrame("Formulario");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        frame.setLayout(new GridLayout(2, 3));

        frame.add(new JButton("Uno"));
        frame.add(new JButton("Dos"));
        frame.add(new JButton("Tres"));
        frame.add(new JButton("Cuatro"));
        frame.add(new JButton("Cinco"));
        frame.add(new JButton("Seis"));

        frame.setVisible(true);   
    }
}

