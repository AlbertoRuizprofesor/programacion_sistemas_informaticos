package interfacesGraficas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class EjemploInvoke extends JFrame {

	
	private static final long serialVersionUID = 1L;

	public EjemploInvoke() {
		setTitle("Ventana segura");
		setSize(300, 150);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		add(new JButton("Hola"));
	}
	
	public static void main(String[] args) {

		
		SwingUtilities.invokeLater(() -> new EjemploInvoke().setVisible(true));
	}
}
