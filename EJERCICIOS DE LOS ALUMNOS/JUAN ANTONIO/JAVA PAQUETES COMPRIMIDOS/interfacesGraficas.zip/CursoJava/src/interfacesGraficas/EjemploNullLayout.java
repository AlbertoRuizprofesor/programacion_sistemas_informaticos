package interfacesGraficas;
import javax.swing.*;

public class EjemploNullLayout {

	public static void main(String[] args) {
		
		

	}

}
