package interfacesGraficas;

import javax.swing.*;


public class Ejercicio3CheckBox extends JFrame {

    
	private static final long serialVersionUID = 1L;
	private JCheckBox checkBox, checkBox2, checkBox3, checkBox4, checkBox5;

    public Ejercicio3CheckBox() {

        setTitle("Ejemplo JCheckBox");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null); // ⭐ IMPORTANTE

        checkBox = new JCheckBox("Aceptar términos y condiciones");
        checkBox.setBounds(30, 30, 220, 30);

        checkBox2 = new JCheckBox("Acepta que estás alelao");
        checkBox2.setBounds(30, 70, 220, 30);
        
        checkBox3 = new JCheckBox("Nuevo Check");
        checkBox3.setBounds(30, 110, 220, 30);
        
        checkBox4 = new JCheckBox("Nuevo Check1");
        checkBox4.setBounds(30, 150, 220, 30);
        
        checkBox5 = new JCheckBox("Nuevo Check2");
        checkBox5.setBounds(30, 190, 220, 30);

        add(checkBox);
        add(checkBox2);
        add(checkBox3);
        add(checkBox4);
        add(checkBox5);

        setSize(300, 200);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new Ejercicio3CheckBox().setVisible(true);

        });

    }

}
