package interfacesGraficas;

import java.awt.GridLayout;

import javax.swing.*;

public class EjercicioRadioButton5 extends JFrame {
   
	private static final long serialVersionUID = 1L;

	public EjercicioRadioButton5() {
        setTitle("Ejemplo JRadioButton");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JRadioButton radioButton1 = new JRadioButton("Opción 1");
        JRadioButton radioButton2 = new JRadioButton("Opción 2");
        JRadioButton radioButton3 = new JRadioButton("Opción 3");

        JRadioButton radioButton4 = new JRadioButton("Opción 4");
        JRadioButton radioButton5 = new JRadioButton("Opción 5");
        JRadioButton radioButton6 = new JRadioButton("Opción 6");

        ButtonGroup group = new ButtonGroup();
        group.add(radioButton1);
        group.add(radioButton2);
        group.add(radioButton3);

        JPanel panel = new JPanel();
        panel.add(radioButton1);
        panel.add(radioButton2);
        panel.add(radioButton3);

        ButtonGroup group1 = new ButtonGroup();
        group1.add(radioButton4);
        group1.add(radioButton5);
        group1.add(radioButton6);

        JPanel panel1 = new JPanel();
        panel1.add(radioButton4);
        panel1.add(radioButton5);
        panel1.add(radioButton6);

        setLayout(new GridLayout(2, 1)); // ← Solución
        add(panel);
        add(panel1);

        pack();
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EjercicioRadioButton5().setVisible(true));
    }
}
