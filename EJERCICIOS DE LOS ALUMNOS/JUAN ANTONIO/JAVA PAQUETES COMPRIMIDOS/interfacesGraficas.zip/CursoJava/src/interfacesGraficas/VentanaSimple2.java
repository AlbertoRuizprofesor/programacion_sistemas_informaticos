package interfacesGraficas;
import javax.swing.*;

public class VentanaSimple2 extends JFrame {

	private static final long serialVersionUID = 1L;
	public VentanaSimple2() {
		super("Mi Ventana");
		setSize(400, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setLocationRelativeTo(null);	
	}
	public static void main(String[]args) {
		new VentanaSimple2();
	}
}
