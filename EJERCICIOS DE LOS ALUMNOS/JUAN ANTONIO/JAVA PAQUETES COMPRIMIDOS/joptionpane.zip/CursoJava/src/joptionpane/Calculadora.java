package joptionpane;

import javax.swing.JOptionPane;

public class Calculadora {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String numero1 = JOptionPane.showInputDialog("Introduce el primer número");
		
		String numero2 = JOptionPane.showInputDialog("Introduce el segundo número");
		
		double num1 = Double.parseDouble(numero1);
		double num2 = Double.parseDouble(numero2);
		
		
		double resultado = num1 + num2;
		System.out.println(resultado);
		
		
		
	}

}
