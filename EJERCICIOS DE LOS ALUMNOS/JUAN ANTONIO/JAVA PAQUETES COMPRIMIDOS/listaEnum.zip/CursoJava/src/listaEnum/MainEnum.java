package listaEnum;

public class MainEnum {

	public static void main(String[] args) {
		
		DiaSemana hoy = DiaSemana.VIERNES;
		System.out.println("Hoy es: " + hoy);

	}

}
