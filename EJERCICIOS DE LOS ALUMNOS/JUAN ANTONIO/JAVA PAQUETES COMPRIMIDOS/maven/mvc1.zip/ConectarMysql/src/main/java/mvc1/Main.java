package mvc1;

public class Main {

	public static void main(String[] args) {
		
		Persona modelo = new Persona("Alberto imperator", "Ruiz", 60);
		Vista vista = new Vista();
		Controlador controlador = new Controlador(modelo, vista);
		controlador.actualizarVista();
	}
}
