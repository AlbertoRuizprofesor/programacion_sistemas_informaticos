package mvc2;

public class Main {

	public static void main(String[] args) {
		
		Producto modelo = new Producto(25, "SmartPhone", 600.65 );
		Vista vista = new Vista();
		Controlador controlador = new Controlador(modelo, vista);
		controlador.actualizarVista();

	}

}
