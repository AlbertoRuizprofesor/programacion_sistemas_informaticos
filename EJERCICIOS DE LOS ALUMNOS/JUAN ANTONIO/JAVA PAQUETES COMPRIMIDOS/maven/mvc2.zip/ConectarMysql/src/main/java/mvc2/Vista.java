package mvc2;

public class Vista {
	public void mostrarProducto(int codigo, String nombre, double precio) {
		System.out.println("Código: " + codigo);
		System.out.println("Nombre: " + nombre);
		System.out.println("Precio: " + precio);
	}
}
