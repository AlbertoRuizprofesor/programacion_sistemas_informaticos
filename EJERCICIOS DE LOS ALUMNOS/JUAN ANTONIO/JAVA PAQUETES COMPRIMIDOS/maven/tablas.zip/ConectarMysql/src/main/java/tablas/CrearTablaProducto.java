package tablas;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
public class CrearTablaProducto {

	//declaramos los diferentes objetos necesarios para nuestra conexión
	   
	   public static void main(String[] args) throws SQLException  {
	      Connection conn = null;
	      Statement stmt=null;
	      String sql="CREATE TABLE productos (id INT PRIMARY KEY,"
	      		+ "nombre VARCHAR(60) NOT NULL,"
	      	    + "precio decimal(10,2))";
	     try {
	    	 //Desde aquí se encarga del driver JDBC    
	         conn = DriverManager.getConnection("jdbc:mysql://localhost/empresa1","root","");
	         //controlamos que la conexión ha sido ok
	         stmt=conn.createStatement();
	         stmt.execute(sql);
	         System.out.println("Creada la tabla productos");
	         conn.close();
	         stmt.close();
	      }
	      catch(SQLException e)                   
	         {e.printStackTrace();  
	      }
	 }
	
}
