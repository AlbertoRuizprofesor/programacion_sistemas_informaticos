package tablas;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class CrearTablaProveedores {
	   //declaramos los diferentes objetos necesarios para nuestra conexión
	   
	   public static void main(String[] args) throws SQLException  {
	      Connection conn = null;
	      PreparedStatement stmt=null;
	      String sql="CREATE TABLE proveedores (id INT PRIMARY KEY,"
	      		+ "nombre VARCHAR(60) NOT NULL,"
	      		+ "telefono VARCHAR(12),"
	      		+ "email VARCHAR(20))";
	     try {
	    	 //Desde aquí se encarga del driver JDBC    
	         conn = DriverManager.getConnection("jdbc:mysql://localhost/empresa1","root","");
	         //controlamos que la conexión ha sido ok
	         stmt=conn.prepareStatement(sql);
	         stmt.execute(sql);
	         System.out.println("Creada la tabla PROVEEDORES");
	         conn.close();
	         stmt.close();
	      }
	      catch(SQLException e)                   
	         {e.printStackTrace();  
	      }
	 }
}
