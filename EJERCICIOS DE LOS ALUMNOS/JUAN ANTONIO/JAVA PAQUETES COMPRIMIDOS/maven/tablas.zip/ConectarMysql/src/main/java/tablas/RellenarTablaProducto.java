package tablas;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class RellenarTablaProducto {
	//declaramos los diferentes objetos necesarios para nuestra conexión
	   
	   public static void main(String[] args) throws SQLException  {
	      Connection conn = null;
	      Statement stmt=null;
	      String sql="INSERT INTO productos (id, "
	      		+ "nombre, precio)"+
	      " VALUES (1,'Microsoft',1200.00)";
	     try {
	    	 //Desde aquí se encarga del driver JDBC    
	         conn = DriverManager.getConnection("jdbc:mysql://localhost/empresa1","root","");
	         //controlamos que la conexión ha sido ok
	         stmt=conn.createStatement();
	         stmt.executeUpdate(sql);
	         System.out.println("Datos insertados en "
	         		+ "la tabla productos");
	         conn.close();
	         stmt.close();
	      }
	      catch(SQLException e)                   
	         {e.printStackTrace();  
	      }
	   }	   
}
