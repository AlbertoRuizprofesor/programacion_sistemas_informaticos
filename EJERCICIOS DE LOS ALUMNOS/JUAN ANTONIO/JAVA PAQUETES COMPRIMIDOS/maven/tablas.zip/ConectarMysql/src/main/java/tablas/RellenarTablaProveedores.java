package tablas;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class RellenarTablaProveedores {

    public static void main(String[] args) throws SQLException  {

        Connection conn = null;
        PreparedStatement stmt = null;

        String sql = "INSERT INTO proveedores (id, nombre, telefono, email) VALUES (?,?,?,?)";

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/empresa1", "root", "");

            stmt = conn.prepareStatement(sql);

            stmt.setInt(1, 1);
            stmt.setString(2, "Microsoft");
            stmt.setString(3, "121212");
            stmt.setString(4, "info@microsof.com");

            // EJECUCIÓN CORRECTA
            stmt.executeUpdate();

            System.out.println("Datos insertados en la tabla proveedores");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }
    }
}

