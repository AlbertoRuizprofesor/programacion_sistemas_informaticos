package menus;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EjercicioMenu1 extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	// Declaración de componentes del menú
    private JMenuBar mb = new JMenuBar(); // Barra de menú
    private JMenu menuClientes, menuProveedores ,menuProductos; // Menús para clientes y proveedores
    private JMenuItem mi1; // Elemento de menú "Abrir"

   
    
    public EjercicioMenu1() {
        setTitle("Ejemplo de Menú con JFrame"); // Establece el título de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Define la operación de cierre de la ventana
        setLayout(null); // Layout nulo para posicionar manualmente los componentes

        setJMenuBar(mb); // Asigna la barra de menú al JFrame

        // Configuración del menú "Clientes"
        menuClientes = new JMenu("Clientes"); // Instancia del menú "Clientes"
        mb.add(menuClientes); // Añade el menú "Clientes" a la barra de menú

        mi1 = new JMenuItem("Abrir"); // Crea un elemento de menú "Abrir"
        mi1.addActionListener(this); // Añade un ActionListener para manejar eventos cuando se selecciona este ítem
        menuClientes.add(mi1); // Añade el ítem "Abrir" al menú "Clientes"

        JMenuItem mi2 = new JMenuItem("Guardar"); // Crea otro elemento de menú "Guardar"
        mi2.addActionListener(this); // Añade un ActionListener para manejar eventos cuando se selecciona este ítem
        menuClientes.add(mi2); // Añade el ítem "Guardar" al menú "Clientes"
        
        JMenuItem mi3 = new JMenuItem("Guardar como"); // Crea otro elemento de menú "Guardar como"
        mi3.addActionListener(this); // Añade un ActionListener para manejar eventos cuando se selecciona este ítem
        menuClientes.add(mi3); // Añade el ítem "Guardar como" al menú "Clientes"
        
        
        
        
        // Configuración del menú "Productos"
        menuProductos = new JMenu("Productos"); // Instancia del menú "Proveedores"
        mb.add(menuProductos); // Añade el menú "Proveedores" a la barra de menú
        
        JMenuItem mi4 = new JMenuItem("Teléfonos"); // Crea otro elemento de menú "Teléfonos"
        mi4.addActionListener(this); // Añade un ActionListener para manejar eventos cuando se selecciona este ítem
        menuProductos.add(mi4); // Añade el ítem "Teléfonos" al menú "Productos"
        
        JMenuItem mi5 = new JMenuItem("Tablets"); // Crea otro elemento de menú "Tablets"
        mi5.addActionListener(this); // Añade un ActionListener para manejar eventos cuando se selecciona este ítem
        menuProductos.add(mi5); // Añade el ítem "Tablets" al menú "Productos"
        
        
        

        // Configuración del menú "Proveedores"
        menuProveedores = new JMenu("Proveedores"); // Instancia del menú "Proveedores"
        mb.add(menuProveedores); // Añade el menú "Proveedores" a la barra de menú
        
        JMenuItem mi6 = new JMenuItem("Samsung"); // Crea otro elemento de menú "Samsung"
        mi6.addActionListener(this); // Añade un ActionListener para manejar eventos cuando se selecciona este ítem
        menuProveedores.add(mi6); // Añade el ítem "Samsung" al menú "Proveedores"
        
        JMenuItem mi7 = new JMenuItem("LG"); // Crea otro elemento de menú "LG"
        mi7.addActionListener(this); // Añade un ActionListener para manejar eventos cuando se selecciona este ítem
        menuProveedores.add(mi7); // Añade el ítem "LG" al menú "Proveedores"
        
     
        
        

        // Configuración final de la ventana
        setBounds(10, 20, 300, 200); // Establece las dimensiones y la posición de la ventana
        setLocationRelativeTo(null); // Centra la ventana en la pantalla
    }

    // Método que maneja los eventos de los elementos del menú
    public void actionPerformed(ActionEvent e) {
        Container contentPane = getContentPane(); // Obtiene el panel de contenido de la ventana
        if (e.getSource() == mi1) { // Comprueba si el evento proviene del ítem "Abrir"
            contentPane.setBackground(new Color(255, 0, 0)); // Cambia el color de fondo a rojo si se selecciona "Abrir"
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() { // Asegura que la creación de la GUI se haga en el hilo de despacho de eventos
            public void run() {
                EjercicioMenu1 formulario1 = new EjercicioMenu1(); // Crea una instancia de la ventana
                formulario1.setVisible(true); // Hace visible la ventana
            }    
        }); 
    }
}
