package menus;


import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuBasico extends JFrame implements ActionListener {
   
	private static final long serialVersionUID = 1L;
	// Declaración de componentes del menú
    private JMenuBar mb = new JMenuBar(); // Barra de menú
    private JMenu menuArchivo,menuEdicion,menuHerra;// 
    private JMenuItem itemAbrir, itemGuardar, itemCortar, itemCopiar, itemPegar, itemJAVADOC, itemJUNIT;
    public MenuBasico() {
        setTitle("Ejemplo de Menú con JFrame"); // Establece el título de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Define la operación de cierre de la ventana
        setLayout(null); // Layout nulo para posicionar manualmente los componentes
        setJMenuBar(mb); 
        
       
        	
        
        //creamos Archivo e items
        menuArchivo = new JMenu("Archivo"); 
        mb.add(menuArchivo);
        
        itemAbrir=new JMenuItem("Abrir");
        menuArchivo.add(itemAbrir);
        
        itemGuardar=new JMenuItem("Guardar");
        menuArchivo.add(itemGuardar);
        
        
        
        
        
        //creamos edicion e item
        menuEdicion = new JMenu("Edición"); 
        mb.add(menuEdicion);
        
        //CORTAR, COPIAR, PEGAR
        itemCortar = new JMenuItem("Cortar");
        menuEdicion.add(itemCortar);
        
        itemCopiar = new JMenuItem("Copiar");
        menuEdicion.add(itemCopiar);
        
        itemPegar = new JMenuItem("Pegar");
        menuEdicion.add(itemPegar);
        
        
        
        //creamos herramientas e item
        
        
        menuHerra = new JMenu("Herramientas"); 
        mb.add(menuHerra);
        //JAVADOC, JUNIT
        itemJAVADOC = new JMenuItem("JAVADOC");
        menuHerra.add(itemJAVADOC);
        
        itemJUNIT = new JMenuItem("JUNIT");
        menuHerra.add(itemJUNIT);

        
        
        
        // Configuración final de la ventana
        setBounds(10, 20, 300, 200); // Establece las dimensiones y la posición de la ventana
        setLocationRelativeTo(null); // Centra la ventana en la pantalla
    }
    
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() { // Asegura que la creación de la GUI se haga en el hilo de despacho de eventos
            public void run() {
               new MenuBasico().setVisible(true); // Hace visible la ventana
            }
        });
    }


//actionPerfomed se usa cuando se va a clickar opciones d menus
    @Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
