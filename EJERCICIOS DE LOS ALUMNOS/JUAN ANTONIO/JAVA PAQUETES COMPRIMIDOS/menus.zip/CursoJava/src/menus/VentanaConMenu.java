package menus;
import javax.swing.*;

public class VentanaConMenu {

	public static void main(String[] args) {
		
		// Crea la ventana principal
		JFrame ventana = new JFrame("Menú");
		ventana.setSize(400, 300);	// Tamaño de la ventana
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	//Cerrar al salir
		
		
		// Crea la barra de menú (la franja superior donde van los menús)
		JMenuBar barra = new JMenuBar();
		
		//------------------------------
		//PRIMER MENÚ: ARCHIVO
		//------------------------------
		
		JMenu archivo = new JMenu("Archivo"); // Crea el menú Archivo
		
		// Elementos dentro del menú Archivo
		JMenuItem nuevo = new JMenuItem("Nuevo");	// Opción "Nuevo"
		JMenuItem salir = new JMenuItem("Salir");	// Opción "Salir"
		
		// Acción del botón "Salir": cierra el programa
		salir.addActionListener(e-> System.exit(0));
		
		
		// Añadimos los elementos al menú Archivo
		archivo.add(nuevo);	// Añade "nuevo"
		archivo.addSeparator();	// Añade una línea separadora
		archivo.add(salir);	//Añade "Salir"
		
		//----------------------------
		//SEGUNDO MENÚ: Opciones
		//----------------------------
		JMenu opciones = new JMenu("Opciones");	//Crea el menú Opciones
		
		// Elementos dentro del menú Opciones
		JMenuItem preferencias = new JMenuItem("Preferencias");
		JMenuItem ayuda = new JMenuItem("Ayuda");
		
		// Añadimos los elementos al menú Opciones
		opciones.add(preferencias);
		opciones.add(ayuda);
		
		//---------------------------
		//	Añadir los menús a la barra
		//---------------------------
		barra.add(archivo);	// Añade el menú Archivo a la barra
		barra.add(opciones);	// Añade el menú Opciones a la barra	
		
		ventana.setJMenuBar(barra);	// Asigna la barra de menú a la ventana
		
		ventana.setVisible(true);	// Muestra al ventana
		ventana.setLocationRelativeTo(null);	// Centra la ventana en la pantalla
	}
}
