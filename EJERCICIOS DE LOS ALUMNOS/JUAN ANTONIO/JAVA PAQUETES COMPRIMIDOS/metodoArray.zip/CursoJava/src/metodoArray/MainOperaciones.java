package metodoArray;

public class MainOperaciones {

    public static void main(String[] args) {

        // Se crea un objeto de la clase Operaciones para poder usar sus métodos
        Operaciones operaciones = new Operaciones();

        // Se llama al método pedirDatos(), que devuelve un array con dos números introducidos por el usuario
        int[] numero = operaciones.pedirDatos();

        // Se llama al método lista_Operaciones() pasando los dos números del array
        // numero[0] → primer número introducido
        // numero[1] → segundo número introducido
        operaciones.lista_Operaciones(numero[0], numero[1]);
    }
}

