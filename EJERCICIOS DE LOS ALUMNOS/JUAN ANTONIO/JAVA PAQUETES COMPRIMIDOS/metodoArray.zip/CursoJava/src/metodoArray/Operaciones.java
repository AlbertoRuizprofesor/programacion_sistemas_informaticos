package metodoArray;
import java.util.Scanner;

public class Operaciones {

    // Suma dos números enteros y devuelve el resultado
    public int sumar(int numero1, int numero2) {
        return numero1 + numero2;
    }

    // Resta: primer número menos el segundo
    public int restar(int numero1, int numero2) {
        return numero1 - numero2;
    }

    // Multiplica dos números enteros
    public int multiplicacion(int numero1, int numero2) {
        return numero1 * numero2;
    }

    // Divide dos números. OJO: si no haces casting, la división sería entera.
    public double division(int numero1, int numero2) {
        return (double) numero1 / numero2;
    }

    // Muestra todas las operaciones realizadas entre dos números
    public void lista_Operaciones(int numero1, int numero2) {

        // Array donde se guardan los resultados de las 5 operaciones
        double[] operacion = new double[5];

        // Nombres de cada operación en el mismo orden que el array de resultados
        String[] nombre_opera = {"Suma","Resta","Multiplicación","División","Potencia"};

        // Guardamos cada resultado en su posición correspondiente
        operacion[0] = sumar(numero1, numero2);
        operacion[1] = restar(numero1, numero2);
        operacion[2] = multiplicacion(numero1, numero2);
        operacion[3] = division(numero1, numero2);
        operacion[4] = Math.pow(numero1, numero2); // potencia

        // Recorremos el array e imprimimos cada operación con su nombre
        for (int i = 0; i < operacion.length; i++) {
            System.out.println("La " + nombre_opera[i] + " es: " + operacion[i]);
        }
    }

    // Pide dos números por teclado y los devuelve en un array
    public int[] pedirDatos() {

        Scanner c = new Scanner(System.in);
        int[] numero = new int[2]; // array para guardar los dos números

        // Pedimos los dos valores al usuario
        for (int i = 0; i < numero.length; i++) {
            System.out.print("Dime el número " + (i + 1) + " : ");
            numero[i] = c.nextInt();
        }

        // Cerrar el Scanner aquí puede causar problemas si luego quieres leer más datos
        c.close();

        return numero;
    }
}
