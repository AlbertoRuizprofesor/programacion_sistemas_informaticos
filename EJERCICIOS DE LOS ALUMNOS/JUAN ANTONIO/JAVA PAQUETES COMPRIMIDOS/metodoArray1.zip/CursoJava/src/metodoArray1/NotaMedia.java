package metodoArray1;

import java.util.Scanner;

public class NotaMedia {

		//Método que recibe un array de enteros y calcula al nota media
		public void calculo_notas(int[] nota) {
			
			int suma = 0; // Variable para acumular la suma de todas las notas
			
			//Recorremos el array sumando cada nota
			for(int i = 0; i < nota.length; i++) {
				suma += nota[i];
			}
			
			//Mostramos la media dividiendo la suma entre le número de notas
			System.out.println("La nota media es: " + suma / nota.length);
		}
		
		
		//============================================================================
		
		
		//Método que pide 10 notas al usuario y las devuelve en un array
		public int[] pedirDatos() {
			
			Scanner c = new Scanner(System.in); //Scanner para leer datos del teclado
			
			int[] numero = new int[10]; //Array donde3 guardaremos las 10 notas
			
			//Bucle para pedir una nota en cada iteración
			for(int i = 0; i < numero.length; i++) {
				System.out.print("Dime la nota " + (i + 1) + " : "); // (i + 1) es para empezar por el indice 1 "Dime la nota 1"
				numero[i] = c.nextInt(); // Guardamos la nota introducida por el usuario
			}
			
			c.close(); // Cerramos el Scanner
			return numero; // Devolvemos el array con las notas
		}
}
