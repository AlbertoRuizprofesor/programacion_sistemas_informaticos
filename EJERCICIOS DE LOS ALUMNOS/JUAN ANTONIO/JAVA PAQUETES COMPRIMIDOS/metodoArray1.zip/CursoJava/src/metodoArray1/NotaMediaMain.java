package metodoArray1;

public class NotaMediaMain {

	public static void main(String[] args) {
		
		
		//Creamos un objeto de la clase NotaMedia para poder usar sus metodos
		NotaMedia notas = new NotaMedia();
		
		//Llamamos al método pedirDatos(), que devuelve un array con 10 notas introducidas por el usuario
		int[] nota = notas.pedirDatos();
		
		//Llamamos al método calculo_notas() y le pasamos el array para que calcule el madia
		notas.calculo_notas(nota);
	}

}
