package metodoArray1;

public class NotasMain {

    public static void main(String[] args) {

        // Creamos un objeto de la clase Notas para poder usar sus métodos
        Notas notas = new Notas();

        // Llamamos al método pedirDatos(), que devuelve un array con 10 notas introducidas por el usuario
        int[] nota = notas.pedirDatos();

        // Llamamos al método calculo_notas() y le pasamos el array de notas para que calcule la media
        notas.calculo_notas(nota);
    }
}
