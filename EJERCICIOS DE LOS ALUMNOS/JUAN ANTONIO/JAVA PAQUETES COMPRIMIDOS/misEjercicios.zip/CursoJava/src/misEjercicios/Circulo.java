package misEjercicios;

public class Circulo extends Figura {

	// Atributo privado que guarda el radio del círculo.
	// Solo esta clase puede acceder directamente a él.
	private double radio;

	// Constructor del círculo.
	// Recibe el nombre (que se envía a la clase padre Figura)
	// y el valor del radio, que se guarda en el atributo 'radio'.
	public Circulo(String nombre, double radio) {
		super(nombre); // Llama al constructor de Figura para guardar el nombre.
		this.radio = radio; // Asigna el parámetro 'radio' al atributo del objeto.
	}

	// Sobrescribe el método calcularArea() de Figura.
	// Calcula el área real del círculo: π * radio^2.
	// Además, redondea el resultado a 2 decimales.
	@Override
	public double calcularArea() {
		return Math.round(Math.PI * radio * radio * 100.0) / 100.0;
	}

	// Sobrescribe toString() para mostrar la información del círculo.
	// Cuando imprimes el objeto (System.out.println(c)), se ejecuta este método.
	@Override
	public String toString() {
		return "Circulo [radio=" + radio + ", Area=" + calcularArea() + "]";
	}
}
