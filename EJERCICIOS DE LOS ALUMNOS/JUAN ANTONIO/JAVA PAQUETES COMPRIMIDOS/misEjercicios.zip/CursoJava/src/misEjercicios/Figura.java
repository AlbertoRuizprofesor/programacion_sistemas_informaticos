package misEjercicios;

public class Figura {

	// Atributo privado que guarda el nombre de la figura.
	// Al ser private, solo esta clase puede acceder directamente a él.
	private String nombre;

	// Constructor de la clase Figura.
	// Se ejecuta cuando se crea cualquier objeto que herede de Figura.
	public Figura(String nombre) {
		this.nombre = nombre;
	}

	// Método que devuelve el área de la figura.
	// En la clase base no tiene fórmula, así que devuelve 0.
	// Las clases hijas lo sobrescribirán con @Override.
	public double calcularArea() {
		return 0;
	}

	// Getter para obtener el nombre de la figura.
	// Es necesario porque 'nombre' es private y no se puede acceder desde fuera.
	public String getNombre() {
		return nombre;
	}
}
