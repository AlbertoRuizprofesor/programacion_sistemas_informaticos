package misEjercicios;

public class Main {

	public static void main(String[] args) {

		// Crea un objeto Rectángulo usando su constructro
		// "Rectángulo" es el nombre heredado de Figura, 4 y 3 son ancho y alto
		Rectangulo r = new Rectangulo("Rectángulo", 4, 3);

		// Crea un objeto Circulo. "Círculo" es el nombre heredado, 2 es el radio
		Circulo c = new Circulo("Círculo", 2);

		// Crea un objeto Triangulo. "Triangulo" es el nombre, 5 base y 6 altura
		Triangulo t = new Triangulo("Triangulo", 5, 6);

		// Crea un objeto Trapecio. "Trapecio" es el nombre, 4 base mayor, 3 base menor
		// y 5 altura
		Trapecio tr = new Trapecio("Trapecio", 4, 3, 5);

		// LLama al método toString() de cada objeto
		// Gracias a la herencia y la sobrescritura, cada clase duvuelve su propio texto
		// Se puede indicar la llamada al método .toString() aunque si no se indica
		// funciona igualmente
		System.out.println(c.toString());
		System.out.println(t.toString());
		System.out.println(tr);
		System.out.println(r);
	}
}
