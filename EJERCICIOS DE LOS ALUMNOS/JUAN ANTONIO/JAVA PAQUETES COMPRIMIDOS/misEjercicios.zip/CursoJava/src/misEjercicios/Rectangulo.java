package misEjercicios;

public class Rectangulo extends Figura {

	// Atributos privados propios del rectángulo.
	// 'ancho' y 'alto' definen sus dimensiones.
	private double ancho;
	private double alto;

	// Constructor del rectángulo.
	// Recibe el nombre (que se envía a la clase padre Figura con super(nombre))
	// y además inicializa ancho y alto.
	public Rectangulo(String nombre, double ancho, double alto) {
		super(nombre); // Llama al constructor de Figura para guardar el nombre.
		this.ancho = ancho; // Asigna el valor del parámetro al atributo 'ancho'.
		this.alto = alto; // Asigna el valor del parámetro al atributo 'alto'.
	}

	// Sobrescribe el método calcularArea() de la clase Figura.
	// Ahora devuelve el área real de un rectángulo: base * altura.
	@Override
	public double calcularArea() {
		return ancho * alto;
	}

	// Sobrescribe el método toString() para mostrar la información del rectángulo.
	// Cuando imprimes el objeto (System.out.println(r)), se ejecuta este método.
	@Override
	public String toString() {
		return "Rectangulo [ancho=" + ancho + ", alto=" + alto + ", Area=" + calcularArea() + "]";
	}
}
