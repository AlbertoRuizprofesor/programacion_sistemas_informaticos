package misEjercicios;

public class Trapecio extends Figura {

	// Atributos privados que definen las dimensiones del trapecio.
	// baseMayor = base grande, baseMenor = base pequeña, altura = distancia entre
	// ambas.
	private double baseMayor;
	private double baseMenor;
	private double altura;

	// Constructor del trapecio.
	// Recibe el nombre (que se envía a la clase padre Figura)
	// y además inicializa baseMayor, baseMenor y altura.
	public Trapecio(String nombre, double baseMayor, double baseMenor, double altura) {
		super(nombre); // Llama al constructor de Figura para guardar el nombre.
		this.baseMayor = baseMayor; // Asigna el valor recibido al atributo baseMayor.
		this.baseMenor = baseMenor; // Asigna el valor recibido al atributo baseMenor.
		this.altura = altura; // Asigna el valor recibido al atributo altura.
	}

	// Sobrescribe el método calcularArea() de Figura.
	// Fórmula del área del trapecio: ((baseMayor + baseMenor) * altura) / 2.
	@Override
	public double calcularArea() {
		return ((baseMayor + baseMenor) * altura) / 2;
	}

	// Sobrescribe toString() para mostrar la información del trapecio.
	// Cuando imprimes el objeto (System.out.println(tr)), se ejecuta este método.
	@Override
	public String toString() {
		return "Trapecio [baseMayor=" + baseMayor + ", baseMenor=" + baseMenor + ", altura=" + altura + ", Area="
				+ calcularArea() + "]";
	}
}
