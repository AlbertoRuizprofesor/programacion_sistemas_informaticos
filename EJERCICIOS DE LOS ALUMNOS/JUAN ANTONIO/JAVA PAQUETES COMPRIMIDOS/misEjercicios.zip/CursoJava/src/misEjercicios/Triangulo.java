package misEjercicios;

public class Triangulo extends Figura {

	// Atributos privados que definen las dimensiones del triángulo.
	// 'base' y 'altura' se usan para calcular el área.
	private double base;
	private double altura;

	// Constructor del triángulo.
	// Recibe el nombre (que se envía a la clase padre Figura)
	// y además inicializa base y altura.
	public Triangulo(String nombre, double base, double altura) {
		super(nombre); // Llama al constructor de Figura para guardar el nombre.
		this.base = base; // Asigna el parámetro 'base' al atributo del objeto.
		this.altura = altura; // Asigna el parámetro 'altura' al atributo del objeto.
	}

	// Sobrescribe el método calcularArea() de Figura.
	// Fórmula del área del triángulo: (base * altura) / 2.
	@Override
	public double calcularArea() {
		return (base * altura) / 2;
	}

	// Sobrescribe toString() para mostrar la información del triángulo.
	// Cuando imprimes el objeto (System.out.println(t)), se ejecuta este método.
	@Override
	public String toString() {
		return "Triangulo [base=" + base + ", altura=" + altura + ", Area=" + calcularArea() + "]";
	}
}
