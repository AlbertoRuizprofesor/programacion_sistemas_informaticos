package pooAbstracto;

public class Coche extends Vehiculo {
	private int cilindrada;

	public Coche(String color, int ruedas, String modelo, int cilindrada) {
		super(color, ruedas, modelo);
		this.cilindrada = cilindrada;
	}

	public int getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(int cilindrada) {
		this.cilindrada = cilindrada;
	}
	
	@Override
	void acelerar() {
		System.out.println("El Coche acelera");
	}
	
	@Override
	void frenar() {
		System.out.println("El Coche frena");
	}

	@Override
	void aparcar() {
		System.out.println("El Coche Aparca");
		
	}

	@Override
	public String toString() {
		return "Coche [cilindrada=" + cilindrada + ", Color=" + getColor() + ", Ruedas=" + getRuedas()
				+ ", Modelo=" + getModelo() + "]";
	}
	
	
}
