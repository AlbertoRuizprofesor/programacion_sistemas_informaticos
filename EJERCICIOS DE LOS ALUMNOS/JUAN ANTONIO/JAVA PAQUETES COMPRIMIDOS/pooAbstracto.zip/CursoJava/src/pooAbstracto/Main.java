package pooAbstracto;

public class Main {

	public static void main(String[] args) {
		
		
		// Se crea un array de 2 posiciones que almacenará objetos de tipo Coche
		Coche [] coche = new Coche[2];
		
		// En la posición 0 se guarda un coche verde, 4 ruedas, Volkswagen, 2200cc
		coche [0] = new Coche("Verde", 4, "Volkswagen", 2200);
		
		// En la posición 1 se guarda un coche azul
		coche [1] = new Coche("Azul", 4, "Renault", 1600);
		
		
		// Recorres el array usando un for-each
		// 'car' es una variable que va tomando cada objeto array
		for(Coche car:coche) {
			// Imprime el coche usando su método to String()
			// Si toString() está bien implementado, se verán los datos del coche
			System.out.println(car);
			
			//Llamada a los métodos del coche
			car.acelerar();
			car.aparcar();
			car.frenar();
		}
		
		//De crea un array de 2 posiciones para objetos Moto
		Moto [] moto = new Moto[2];
		
		//Moto en la posición 0
		moto [0] = new Moto("Azul", 2, "Suzuki", 150);
		
		//Moto en la posición 1
		moto [1] = new Moto("Verde", 2, "Honda", 200);
		
		//Se recorre el al array de motos igual que el de coches
		for(Moto bike:moto) {
			
			//Imprime la moto usando su toString()
			System.out.println(bike);
			
			//Llamas a los métodos de la moto
			bike.acelerar();
			bike.aparcar();
			bike.frenar();
		}
 	}
		
}
