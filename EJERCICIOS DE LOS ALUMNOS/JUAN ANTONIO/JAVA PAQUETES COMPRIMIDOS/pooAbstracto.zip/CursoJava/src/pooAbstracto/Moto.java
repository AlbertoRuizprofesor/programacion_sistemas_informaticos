package pooAbstracto;

public class Moto extends Vehiculo {
	private int caballaje;

	public Moto(String color, int ruedas, String modelo, int caballaje) {
		super(color, ruedas, modelo);
		this.caballaje = caballaje;
	}

	public int getCaballaje() {
		return caballaje;
	}

	public void setCaballaje(int caballaje) {
		this.caballaje = caballaje;
	}

	
	@Override
	void acelerar() {
		System.out.println("La moto acelera");
		
	}

	@Override
	void frenar() {
		System.out.println("La moto frena");
		
	}

	@Override
	void aparcar() {
		System.out.println("La moro aparca");
		
	}

	@Override
	public String toString() {
		return "Moto [Caballaje=" + getCaballaje() + ", Color=" + getColor() + ", Ruedas=" + getRuedas()
				+ ", Modelo=" + getModelo() + "]";
	}

	
	
	
}
