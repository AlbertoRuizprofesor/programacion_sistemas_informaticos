package pooAbstracto1;

public class Frigorifico extends Electrodomestico{
	private double capacidad;
	private double altura;
	public Frigorifico(String color, double peso, String marca, String fabricante, double precio, double capacidad,
			double altura) {
		super(color, peso, marca, fabricante, precio);
		this.capacidad = capacidad;
		this.altura = altura;
	}
	public double getCapacidad() {
		return capacidad;
	}
	public void setCapacidad(double capacidad) {
		this.capacidad = capacidad;
	}
	public double getAltura() {
		return altura;
	}
	public void setAltura(double altura) {
		this.altura = altura;
	}
	@Override
	void encender() {
		System.out.println("El frigorífico enciende");
		
	}
	@Override
	void apagar() {
		System.out.println("El frigorífico se apaga");
		
	}
	@Override
	void comprar() {
		System.out.println("Si se te rompe comprate un frigorifico");
		
	}
	@Override
	void devolver() {
		System.out.println("El frigorífico devuelve cosas frias");
		
	}
	@Override
	public String toString() {
		return "Frigorifico [Capacidad=" + getCapacidad() + ", Altura=" + getAltura() + ", Color="
				+ getColor() + ", Peso=" + getPeso() + ", Marca=" + getMarca() + ", Fabricante="
				+ getFabricante() + ", Precio=" + getPrecio() + "]";
	}
	
	
	
	
}
