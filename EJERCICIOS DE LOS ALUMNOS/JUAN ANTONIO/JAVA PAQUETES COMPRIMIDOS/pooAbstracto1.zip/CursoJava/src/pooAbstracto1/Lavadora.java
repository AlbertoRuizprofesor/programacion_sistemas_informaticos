package pooAbstracto1;

public class Lavadora extends Electrodomestico {
	private double carga;

	public Lavadora(String color, double peso, String marca, String fabricante, double precio, double carga) {
		super(color, peso, marca, fabricante, precio);
		this.carga = carga;
	}
	
	public double getCarga() {
		return carga;
	}


	public void setCarga(double carga) {
		this.carga = carga;
	}
	
	

	@Override
	void encender() {
		System.out.println("La lavadora enciende");
		
	}

	@Override
	void apagar() {
		System.out.println("La lavadora se apaga");
	}

	@Override
	void comprar() {
		System.out.println("Si se te rompe comprate una lavadora");
		
	}

	@Override
	void devolver() {
		System.out.println("La lavadora devuelve ropa limpia");
		
	}

	@Override
	public String toString() {
		return "Lavadora [Carga=" + getCarga() + ", Color=" + getColor() + ", Peso="
				+ getPeso() + ", Marca=" + getMarca() + ", Fabricante=" + getFabricante() + ", Precio="
				+ getPrecio() + "]";
	}


	
	
	
	
}
