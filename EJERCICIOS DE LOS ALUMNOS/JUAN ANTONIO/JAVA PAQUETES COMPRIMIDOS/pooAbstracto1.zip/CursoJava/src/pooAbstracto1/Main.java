package pooAbstracto1;

public class Main {

	public static void main(String[] args) {
		Lavadora [] lavadora = new Lavadora[2];
		
		lavadora [0] = new Lavadora("Blanco", 20, "LG2000", "LG", 600, 50);
		lavadora [1] = new Lavadora("Blanco", 25, "Bosch2000", "Bosch", 500, 45);
		
		
		for(Lavadora lav:lavadora) {
			System.out.println(lav);
			lav.apagar();
			lav.comprar();
			lav.devolver();
			lav.encender();
		}

		Frigorifico [] frigorifico = new Frigorifico[2];
		
		frigorifico [0] = new Frigorifico("Blanco", 30, "Bosch55", "Bosch", 1000, 60, 180 );
		frigorifico [1] = new Frigorifico("Gris", 45, "SiemensXXX", "Siemens", 2000, 60, 200);
		
		for(Frigorifico fri:frigorifico) {
			System.out.println(fri);
			fri.apagar();
			fri.comprar();
			fri.devolver();
			fri.encender();
		}
		
	}

}
