package pooBanco;

public class Banco {

		private String nombreBanco;

		public Banco(String nombreBanco) {
			super();
			this.nombreBanco = nombreBanco;
		}

		public String getNombreBanco() {
			return nombreBanco;
		}

		public void setNombreBanco(String nombreBanco) {
			this.nombreBanco = nombreBanco;
		}

		@Override
		public String toString() {
			return "Banco [getNombreBanco()=" + getNombreBanco() + ", getClass()=" + getClass() + ", hashCode()="
					+ hashCode() + ", toString()=" + super.toString() + "]";
		}
}


