package pooBanco;

public interface DatosPersonales {
	void mostrarDatosCliente();
	
}
