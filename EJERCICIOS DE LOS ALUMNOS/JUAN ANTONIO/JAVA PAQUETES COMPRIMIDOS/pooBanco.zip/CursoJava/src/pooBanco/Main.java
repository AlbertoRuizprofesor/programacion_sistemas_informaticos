package pooBanco;

public class Main {

	public static void main(String[] args) {
		
		
		// Creamos una cuenta bancaria con: 
		// - Nombre del banco: "Banco CENEC" 
		// - Número de cuenta: 12345 
		// - Saldo inicial: 200.0 €
		CuentaBancaria c1 = new CuentaBancaria("Banco CENEC", 12345, 200.0);
		
		// Creamos un cliente llamado Antonio, con su DNI, teléfono 
				// y asociamos la cuenta bancaria creada arriba (c1)
		Clientes cliente1 = new Clientes("Antonio", "12345678A", "600123123", c1);
		
		
		// Mostramos todos los datos del cliente y su cuenta
		cliente1.mostrarDatosCliente();
		
		
		// Ingresamos 50 € en la cuenta de Antonio
		c1.ingresar(50);
		
		// Mostramos el saldo después del ingreso
		c1.mostrarSaldo();
		
		c1.sacar(500);
		c1.sacar(100);
		c1.mostrarSaldo();
	}
}
