package pooSobrecarga;

public class Main {

	public static void main(String[] args) {
		
		// Crea un objeto usando el constructor COMPLETO
		// nombre + apellido + edad
		Sobrecarga sobrecarga1 = new Sobrecarga("Alberto", "Garcia", 20);
		
		//Crea un objeto usando el constructor con nombre + apellido
		//edad queda con valor por defecto (0)
		Sobrecarga sobrecarga2 = new Sobrecarga("Alberto", "Garcia");
		
		// Crea un objeto usando el constructor solo con nombre
		// apellido queda null y edad queda 0
		Sobrecarga sobrecarga3 = new Sobrecarga("Alberto");
		
		// Crea un objeto usando el constructor solo con edad
		// Nombre y apellido quedan null 
		Sobrecarga sobrecarga4 = new Sobrecarga(45);
		
		
		// Llama al método mostrar() de cada objeto
		// Este método imprime los valores actuales de nombre, apellido y edad
		sobrecarga1.mostrar(); // Alberto Garcia 20
		sobrecarga2.mostrar(); // Alberto Garcia 0
		sobrecarga3.mostrar(); // Alberto null 0
		sobrecarga4.mostrar(); // null null 45
	}	
}
