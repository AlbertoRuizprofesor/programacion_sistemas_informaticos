package pooSobrecarga;

public class Sobrecarga {
	
	// Atributos privados: solo accesibles desde la clase
	private String nombre;
	private String apellido;
	private int edad;
	
	// Constructor completo: inicializa todos los campos
	public Sobrecarga(String nombre, String apellido, int edad) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
	}

	// Constructor con nombre y apellido: edad queda con valor por defecto (0)
	public Sobrecarga(String nombre, String apellido) {
		this.nombre = nombre;
		this.apellido = apellido;
		// edad no se inicializa. Java la pone a 0
	}
	
	// Constructor solo con nombre: apellido queda null y edad queda 0
	public Sobrecarga(String nombre) {
		this.nombre = nombre;
		// apellido queda null
		// edad queda 0
	}
	
	// Constructor solo con edad: nombre y apellido quedan null
	public Sobrecarga(int edad) {
		this.edad = edad;
		// nombre queda null
		// apellido queda null
	}


	//Getters y Setters: permiten leer y modificar los atributos
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}


	// Método mostrar sin parámetros: imprime los atributos del objeto
	public void mostrar() {
		System.out.println(getNombre()+" "+getApellido() + " " + getEdad());
	}
	
	// Sobrecarga del método mostrar: imprime solo el nombre del objeto
	public void mostrar(String nombre) {
		System.out.println(getNombre());
	}
	
	// Sobrecarga del método mostrar: imprime nombre y apellido del objeto
	public void mostrar(String nombre, String apellido) {
		System.out.println(getNombre() + " " + getApellido());
	}
	
	// Sobrecarga del método mostrar: imprime solo la edad del objeto
	public void mostrar(int edad) {
		System.out.println(getEdad());
	}
}






