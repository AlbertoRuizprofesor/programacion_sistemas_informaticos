//crear tabla Ejemplo

package preparedStatement;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class ConectarDbStatement1 {
	   //declaramos los diferentes objetos necesarios para nuestra conexión
	   
	   public static void main(String[] args) throws SQLException  {
	      Connection conn = null;
	      PreparedStatement stmt=null;
	      String sql="CREATE TABLE ejemplo (id INT PRIMARY KEY,"
	      		+ "nif VARCHAR(10) NOT NULL,"
	      		+ "nombre VARCHAR(60) NOT NULL,"
	      		+ "edad VARCHAR(2))";
	     try {
	    	 //Desde aquí se encarga del driver JDBC    
	         conn = DriverManager.getConnection("jdbc:mysql://localhost/techacademy_db","root","");
	         //controlamos que la conexión ha sido ok
	         stmt=conn.prepareStatement(sql);
	         stmt.execute();
	         System.out.println("Creada la tabla Ejemplo");
	         conn.close();
	         stmt.close();
	      }
	      catch(SQLException e)                   
	         {e.printStackTrace();  
	      }
	 }
}
