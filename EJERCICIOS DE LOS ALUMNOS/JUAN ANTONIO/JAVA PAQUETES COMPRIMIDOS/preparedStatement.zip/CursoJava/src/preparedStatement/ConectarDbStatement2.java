//Insertar datos

package preparedStatement;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class ConectarDbStatement2 {

    public static void main(String[] args) {
        Connection conn = null;
        PreparedStatement stmt = null;

        String sql = "INSERT INTO ejemplo (id, nif, nombre, edad) VALUES (?, ?, ?, ?)";

        try {
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost/techacademy_db",
                "root",
                ""
            );

            stmt = conn.prepareStatement(sql);

            // Asignamos los valores a los ?
            stmt.setInt(1, 1);
            stmt.setString(2, "11111");
            stmt.setString(3, "Alberto");
            stmt.setString(4, "40");

            stmt.executeUpdate();

            System.out.println("Datos insertados en la tabla Ejemplo");

            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
