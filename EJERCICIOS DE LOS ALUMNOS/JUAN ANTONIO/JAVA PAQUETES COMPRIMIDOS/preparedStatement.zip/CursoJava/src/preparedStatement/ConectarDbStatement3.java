//mostrar datos


package preparedStatement;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ConectarDbStatement3 {

    public static void main(String[] args) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "SELECT * FROM Ejemplo";

        try {
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost/techacademy_db",
                "root",
                ""
            );

            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String nif = rs.getString("nif");
                String nombre = rs.getString("nombre");
                String edad = rs.getString("edad");

                System.out.println(
                    "id: " + id +
                    ", nif: " + nif +
                    ", nombre: " + nombre +
                    ", edad: " + edad
                );
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


