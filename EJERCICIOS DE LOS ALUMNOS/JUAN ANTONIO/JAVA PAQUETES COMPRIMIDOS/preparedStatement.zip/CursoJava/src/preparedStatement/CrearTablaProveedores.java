//Crear la tabla proveedores  

package preparedStatement;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class CrearTablaProveedores {

    public static void main(String[] args) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;

        String sql = "CREATE TABLE Proveedores ("
                   + "id INT PRIMARY KEY, "
                   + "nombre VARCHAR(60) NOT NULL, "
                   + "telefono VARCHAR(20) NOT NULL, "
                   + "email VARCHAR(60) NOT NULL"
                   + ")";

        try {
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost/techacademy_db",
                "root",
                ""
            );

            stmt = conn.prepareStatement(sql);
            stmt.execute();

            System.out.println("Creada la tabla Proveedores");

            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
