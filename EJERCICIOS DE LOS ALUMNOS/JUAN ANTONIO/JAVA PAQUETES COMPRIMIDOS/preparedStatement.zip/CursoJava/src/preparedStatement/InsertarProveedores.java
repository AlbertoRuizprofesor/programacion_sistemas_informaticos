//Inserta datos en la tabla Proveedores

package preparedStatement;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class InsertarProveedores {

    public static void main(String[] args) {
        Connection conn = null;
        PreparedStatement stmt = null;

        String sql = "INSERT INTO Proveedores (id, nombre, telefono, email) "
                   + "VALUES (?, ?, ?, ?)";

        try {
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost/techacademy_db",
                "root",
                ""
            );

            stmt = conn.prepareStatement(sql);

            // Primer proveedor
            stmt.setInt(1, 1);
            stmt.setString(2, "Juan Pérez");
            stmt.setString(3, "600123123");
            stmt.setString(4, "juan@gmail.com");
            stmt.executeUpdate();

            // Segundo proveedor
            stmt.setInt(1, 2);
            stmt.setString(2, "Esteban Ruíz");
            stmt.setString(3, "903986574");
            stmt.setString(4, "correo@hotmail.com");
            stmt.executeUpdate();

            System.out.println("Proveedores insertados correctamente");

            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

