package retoBDacademia;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class Ej1_InsertarCursoFijo {
    public static void main(String[] args) {

        String sql = "INSERT INTO cursos (id, nombre, profesor, horas) VALUES (?,?,?,?)";

        try (Connection con = DB.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, 10);
            ps.setString(2, "Curso Fijo");
            ps.setString(3, "Profesor Fijo");
            ps.setInt(4, 25);

            int filas = ps.executeUpdate();
            System.out.println("Filas insertadas: " + filas);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

