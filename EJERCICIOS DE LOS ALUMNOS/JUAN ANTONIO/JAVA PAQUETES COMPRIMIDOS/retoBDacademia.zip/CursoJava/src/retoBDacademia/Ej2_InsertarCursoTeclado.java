package retoBDacademia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Ej2_InsertarCursoTeclado {
    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in);
             Connection con = DB.conectar()) {

            System.out.print("ID: ");
            int id = Integer.parseInt(sc.nextLine());

            System.out.print("Nombre: ");
            String nombre = sc.nextLine();

            System.out.print("Profesor: ");
            String profesor = sc.nextLine();

            System.out.print("Horas: ");
            int horas = Integer.parseInt(sc.nextLine());

            String sql = "INSERT INTO cursos (id, nombre, profesor, horas) VALUES (?,?,?,?)";

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, id);
                ps.setString(2, nombre);
                ps.setString(3, profesor);
                ps.setInt(4, horas);

                int filas = ps.executeUpdate();
                System.out.println("Filas insertadas: " + filas);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

