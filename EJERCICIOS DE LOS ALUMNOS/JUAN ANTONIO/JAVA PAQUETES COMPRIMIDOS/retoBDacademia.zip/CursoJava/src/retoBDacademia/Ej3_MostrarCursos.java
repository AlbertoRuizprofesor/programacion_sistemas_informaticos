package retoBDacademia;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Ej3_MostrarCursos {
    public static void main(String[] args) {

        String sql = "SELECT * FROM cursos";

        try (Connection con = DB.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println(
                        rs.getInt("id") + " | " +
                        rs.getString("nombre") + " | " +
                        rs.getString("profesor") + " | " +
                        rs.getInt("horas")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

