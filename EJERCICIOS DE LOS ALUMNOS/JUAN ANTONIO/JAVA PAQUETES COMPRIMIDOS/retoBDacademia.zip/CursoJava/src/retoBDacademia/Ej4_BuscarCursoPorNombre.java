package retoBDacademia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Ej4_BuscarCursoPorNombre {
    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in);
             Connection con = DB.conectar()) {

            System.out.print("Nombre del curso a buscar: ");
            String nombre = sc.nextLine();

            String sql = "SELECT * FROM cursos WHERE nombre = ?";

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, nombre);

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {
                        System.out.println("Curso encontrado:");
                        System.out.println(rs.getInt("id") + " | " +
                                           rs.getString("nombre") + " | " +
                                           rs.getString("profesor") + " | " +
                                           rs.getInt("horas"));
                    } else {
                        System.out.println("No existe un curso con ese nombre.");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

