package retoBDacademia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Ej5_ActualizarHoras {
    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in);
             Connection con = DB.conectar()) {

            System.out.print("ID del curso a actualizar: ");
            int id = Integer.parseInt(sc.nextLine());

            System.out.print("Nuevas horas: ");
            int horas = Integer.parseInt(sc.nextLine());

            String sql = "UPDATE cursos SET horas = ? WHERE id = ?";

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, horas);
                ps.setInt(2, id);

                int filas = ps.executeUpdate();
                System.out.println("Filas modificadas: " + filas);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

