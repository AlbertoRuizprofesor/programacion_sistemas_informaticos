package retoBDacademia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Ej6_EliminarCurso {
    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in);
             Connection con = DB.conectar()) {

            System.out.print("ID del curso a eliminar: ");
            int id = Integer.parseInt(sc.nextLine());

            String sql = "DELETE FROM cursos WHERE id = ?";

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, id);

                int filas = ps.executeUpdate();
                System.out.println("Filas eliminadas: " + filas);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
