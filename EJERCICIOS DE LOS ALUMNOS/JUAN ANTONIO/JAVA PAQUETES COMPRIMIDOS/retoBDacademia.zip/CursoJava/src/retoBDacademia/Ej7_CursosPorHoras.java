package retoBDacademia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Ej7_CursosPorHoras {
    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in);
             Connection con = DB.conectar()) {

            System.out.print("Horas mínimas: ");
            int minHoras = Integer.parseInt(sc.nextLine());

            String sql = "SELECT * FROM cursos WHERE horas >= ?";

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, minHoras);

                try (ResultSet rs = ps.executeQuery()) {

                    while (rs.next()) {
                        System.out.println(
                                rs.getInt("id") + " | " +
                                rs.getString("nombre") + " | " +
                                rs.getString("profesor") + " | " +
                                rs.getInt("horas")
                        );
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
