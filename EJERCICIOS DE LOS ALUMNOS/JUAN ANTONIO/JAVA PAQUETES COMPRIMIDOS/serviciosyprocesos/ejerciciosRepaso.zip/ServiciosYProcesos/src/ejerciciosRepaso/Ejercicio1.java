package ejerciciosRepaso;

//Declaración de la clase
public class Ejercicio1 {

 // Método principal: es el punto de entrada del programa
 public static void main(String[] args) {

     try {

         // Crea un objeto ProcessBuilder para abrir la calculadora de Windows
         // "calc.exe" es el ejecutable de la calculadora
         ProcessBuilder pbAbrir = new ProcessBuilder("calc.exe");

         // Ejecuta el proceso (abre la calculadora)
         // start() lanza el programa externo
         Process proceso = pbAbrir.start();

         // Muestra mensaje por consola
         System.out.println("Calculadora abierta");

         // Detiene el hilo actual durante 5 segundos
         // 5000 milisegundos = 5 segundos
         Thread.sleep(5000);

         // Crea otro ProcessBuilder para cerrar la calculadora
         // taskkill es un comando de Windows para finalizar procesos
         ProcessBuilder pbCerrar = new ProcessBuilder(

                 // Comando de Windows para matar procesos
                 "taskkill",

                 // /IM indica el nombre de la imagen (el programa)
                 "/IM",

                 // Nombre del proceso de la calculadora en Windows
                 "CalculatorApp.exe",

                 // /F significa forzar el cierre
                 "/F"
         );

         // Ejecuta el comando para cerrar la calculadora
         pbCerrar.start();

         // Muestra mensaje indicando que se cerró
         System.out.println("Calculadora cerrada");

     } catch (Exception e) {

         // Si ocurre algún error, lo muestra por consola
         e.printStackTrace();

     }

 }

}

