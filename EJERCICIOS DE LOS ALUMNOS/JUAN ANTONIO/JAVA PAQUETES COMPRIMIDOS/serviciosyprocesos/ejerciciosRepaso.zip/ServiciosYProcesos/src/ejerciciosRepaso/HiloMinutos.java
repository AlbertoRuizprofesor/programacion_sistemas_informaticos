package ejerciciosRepaso;

public class HiloMinutos extends Thread{
	private int dias;
	private int horas;
	
	public HiloMinutos(int dias) {
		this.dias = dias;
		this.horas = horas;
	}
	
	public void run() {
		int minutos = dias * 24 * 60;
		System.out.print("Horas: " + horas);
	}
}
