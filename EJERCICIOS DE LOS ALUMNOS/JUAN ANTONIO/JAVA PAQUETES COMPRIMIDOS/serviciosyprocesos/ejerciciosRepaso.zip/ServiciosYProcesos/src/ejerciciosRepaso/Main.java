package ejerciciosRepaso;


	public class Main {

	    public static void main(String[] args) {

	        HiloHoras h = new HiloHoras(2);
	        HiloMinutos m = new HiloMinutos(2);
	        // Aquí se asigna la prioridad
	        h.setPriority(Thread.MAX_PRIORITY);
	        m.setPriority(Thread.MIN_PRIORITY);

	        h.start();
	        m.start();

	    }

	}


