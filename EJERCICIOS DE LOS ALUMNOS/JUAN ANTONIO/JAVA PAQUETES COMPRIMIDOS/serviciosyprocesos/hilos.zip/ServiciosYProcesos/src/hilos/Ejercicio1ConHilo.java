package hilos;

import java.util.Scanner;

/**
 * Clase principal que gestiona la calculadora con hilos.
 * Cada operación matemática se ejecuta en un hilo separado.
 */
public class Ejercicio1ConHilo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double num1, num2;

        // Solicitar al usuario los números
        System.out.print("Introduce el primer número: ");
        num1 = scanner.nextDouble();

        System.out.print("Introduce el segundo número: ");
        num2 = scanner.nextDouble();

        /*
        new HiloSuma(num1, num2).start();
        new HiloResta(num1, num2).start();
        new HiloMultiplicacion(num1, num2).start();
        new HiloDivision(num1, num2).start();
        new HiloPotencia(num1,num2).start();*/
        
        HiloSuma h1 = new HiloSuma(num1, num2);
        HiloResta h2 = new HiloResta(num1, num2);
        HiloMultiplicacion h3 = new HiloMultiplicacion(num1,num2);
        HiloDivision h4 = new HiloDivision(num1, num2);
        HiloPotencia h5 = new HiloPotencia(num1, num2);
        
        h1.setPriority(Thread.MIN_PRIORITY);
        h2.setPriority(Thread.NORM_PRIORITY);
        h3.setPriority(Thread.NORM_PRIORITY);
        h4.setPriority(Thread.MIN_PRIORITY);
        h5.setPriority(Thread.MAX_PRIORITY);
        
        h1.start();
        h2.start();
        h3.start();
        h4.start();
        h5.start();
        
        scanner.close();
    }
}

