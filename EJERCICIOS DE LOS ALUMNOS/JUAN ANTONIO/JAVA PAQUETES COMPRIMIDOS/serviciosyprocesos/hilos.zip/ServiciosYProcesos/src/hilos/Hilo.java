package hilos;

public class Hilo extends Thread{
	
	public void run() {
		for(int i=1; i<=5; i++) {
			System.out.println(i);
		}
	}
	public static void main(String[] args) {
		Hilo h = new Hilo();
		h.start();
	}
}
