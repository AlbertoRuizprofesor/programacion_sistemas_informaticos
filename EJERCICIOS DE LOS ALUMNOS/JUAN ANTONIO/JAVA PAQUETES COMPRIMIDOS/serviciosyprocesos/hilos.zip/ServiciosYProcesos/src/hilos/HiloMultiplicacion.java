package hilos;

/**
 * Hilo para realizar la operación de multiplicación.
 */
class HiloMultiplicacion extends Thread {
    private double num1, num2;

    public HiloMultiplicacion(double num1, double num2) {
        this.num1 = num1;
        this.num2 = num2;
    }
    public void run() {
        System.out.println("Multiplicación: " + (num1 * num2));
    }
}

