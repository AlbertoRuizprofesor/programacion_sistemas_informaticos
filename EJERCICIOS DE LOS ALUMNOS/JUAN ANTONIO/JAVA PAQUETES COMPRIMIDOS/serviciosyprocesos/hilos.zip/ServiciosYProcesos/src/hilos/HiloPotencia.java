package hilos;

/**
 * Hilo para realizar la operación de potencia.
 */
class HiloPotencia extends Thread {
    private double num1, num2;

    public HiloPotencia(double num1, double num2) {
        this.num1 = num1;
        this.num2 = num2;
    }

    public void run() {
        System.out.println("Potencia: " + Math.pow(num1, num2));
    }
}
