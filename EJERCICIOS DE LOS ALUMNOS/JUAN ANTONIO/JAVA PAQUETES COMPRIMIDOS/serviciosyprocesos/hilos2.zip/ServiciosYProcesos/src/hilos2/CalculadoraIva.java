package hilos2;

import java.util.Scanner;

/**
 * Clase principal que gestiona la calculadora con hilos.
 * Cada operación matemática se ejecuta en un hilo separado.
 */
public class CalculadoraIva {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double importe;

        // Solicitar al usuario el importe
        System.out.print("Introduce el importe: ");
        importe = scanner.nextDouble();
        
        Factura1 hilo1 = new Factura1(importe);
        Factura2 hilo2 = new Factura2(importe);
        Factura3 hilo3 = new Factura3(importe);


        hilo1.setPriority(Thread.MIN_PRIORITY);
        hilo2.setPriority(Thread.MIN_PRIORITY);
        hilo3.setPriority(Thread.MAX_PRIORITY);
        hilo1.start();
        hilo2.start();
        hilo3.start();
        
        scanner.close();
    }
}