package hilos2;

/**
 * Hilo para realizar la operación de suma.
 */
class Factura1 extends Thread {
	private double importe;

    public Factura1(double importe) {
        this.importe = importe;
       
    }

    public void run() {
    	double iva = importe * 7 / 100;
        System.out.println("Iva 7%: " + iva);
        System.out.println("El precio total con un 7% de IVA es: " + (importe + iva) + "€");
    }
}
