package hilos2;

/**
 * Hilo para realizar la operación de suma.
 */
class Factura2 extends Thread {
	private double importe;

    public Factura2(double importe) {
        this.importe = importe;
       
    }

    public void run() {
    	double iva = importe * 10 / 100;
        System.out.println("Iva 10%: " + iva);
        System.out.println("El precio total con un 10% de IVA es: " + (importe + iva) + "€");
    }
}
