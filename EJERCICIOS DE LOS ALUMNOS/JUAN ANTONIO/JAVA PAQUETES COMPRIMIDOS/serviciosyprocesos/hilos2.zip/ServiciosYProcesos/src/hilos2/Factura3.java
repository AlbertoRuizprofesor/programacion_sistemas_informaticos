package hilos2;

/**
 * Hilo para realizar la operación de suma.
 */
class Factura3 extends Thread {
	private double importe;

    public Factura3(double importe) {
        this.importe = importe;
       
    }

    public void run() {
    	double iva = importe * 21 / 100;
        System.out.println("Iva 21%: " + iva);
        System.out.println("El precio total con un 21% de IVA es: " + (importe + iva) + "€");
    }
}
