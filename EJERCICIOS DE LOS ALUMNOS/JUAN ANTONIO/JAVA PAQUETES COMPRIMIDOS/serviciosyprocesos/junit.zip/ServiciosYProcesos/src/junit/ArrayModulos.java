package junit;


public class ArrayModulos {

    private String[] modulos = {
        "Lenguaje de Marcas",
        "Entorno",
        "Sistemas",
        "Programación",
        "Base de Datos"
    };

    public String[] getModulos() {
        return modulos;
    }
}
