package junit;



public class Calculadora {

    public static int suma(int a, int b) {
        return a + b;
    }

    public static int resta(int a, int b) {
        return a - b;
    }

    public static double division(double a, double b) {
        return a / b;
    }
}

