package junit;

public class CalculadoraIVA {

    public double calcularIVA4(double base) {
        return base * 0.04;
    }

    public double calcularIVA10(double base) {
        return base * 0.10;
    }

    public double calcularIVA21(double base) {
        return base * 0.21;
    }
}
