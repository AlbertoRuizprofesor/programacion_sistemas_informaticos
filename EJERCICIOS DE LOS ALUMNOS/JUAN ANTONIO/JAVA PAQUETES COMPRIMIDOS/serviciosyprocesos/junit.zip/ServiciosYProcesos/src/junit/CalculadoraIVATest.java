package junit;

import static org.junit.Assert.*;
import org.junit.Test;

public class CalculadoraIVATest {

    CalculadoraIVA calc = new CalculadoraIVA();

    @Test
    public void testIVA4() {
        double base = 100;
        double esperado = 4.0;
        assertEquals(esperado, calc.calcularIVA4(base), 0.001);
    }

    @Test
    public void testIVA10() {
        double base = 100;
        double esperado = 10.0;
        assertEquals(esperado, calc.calcularIVA10(base), 0.001);
    }

    @Test
    public void testIVA21() {
        double base = 100;
        double esperado = 21.0;
        assertEquals(esperado, calc.calcularIVA21(base), 0.001);
    }
}

