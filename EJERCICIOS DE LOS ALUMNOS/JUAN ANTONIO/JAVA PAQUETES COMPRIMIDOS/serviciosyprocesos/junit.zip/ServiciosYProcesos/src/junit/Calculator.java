package junit;

public class Calculator{
    public static int suma(int a, int b) {
         return a + b;
     }
     public static int resta(int a, int b) {
         return a - b;
     }
     public static int multi(int a, int b) {
         return a * b;
    }
 
    public static int division(int a, int b) {
               return a / b;
    }
}


