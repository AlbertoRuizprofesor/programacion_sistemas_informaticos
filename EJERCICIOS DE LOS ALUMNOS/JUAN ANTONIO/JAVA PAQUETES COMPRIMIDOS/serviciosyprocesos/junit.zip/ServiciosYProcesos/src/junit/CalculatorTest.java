package junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculatorTest {

	@Test
	void testSuma() {
		assertEquals(5, Calculator.suma(2, 3));
		
	}

	@Test
	void testResta() {
		assertEquals(1, Calculator.resta(3, 2));
		
	}

	@Test
	void testMulti() {
		assertEquals(6, Calculator.multi(2, 3));
		
	}

	@Test
	void testDivision() {
		assertEquals(2, Calculator.division(4, 2));
		
	}

}
