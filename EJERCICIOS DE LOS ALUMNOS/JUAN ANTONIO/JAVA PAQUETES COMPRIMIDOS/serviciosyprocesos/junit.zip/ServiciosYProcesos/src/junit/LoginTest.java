package junit;

import java.util.Scanner;

public class LoginTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese nombre de usuario: ");
        String usuario = sc.nextLine();

        System.out.print("Ingrese contraseña: ");
        String contrasena = sc.nextLine();

        if (usuario == null || usuario.isEmpty() ||
            contrasena == null || contrasena.isEmpty()) {

            System.out.println("Error: el usuario o la contraseña no pueden ser nulos o vacíos.");
        } else {
            System.out.println("Datos ingresados correctamente.");
        }
        sc.close();
    }
}

