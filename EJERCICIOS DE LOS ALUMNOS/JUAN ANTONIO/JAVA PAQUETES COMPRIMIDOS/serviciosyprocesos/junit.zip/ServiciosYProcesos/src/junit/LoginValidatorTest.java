package junit;

import static org.junit.Assert.*;
import org.junit.Test;

public class LoginValidatorTest {

    @Test
    public void testUsuarioYContrasenaNulos() {
        String usuario = null;
        String contrasena = null;

        boolean resultado = validar(usuario, contrasena);

        assertFalse("Debe fallar cuando usuario y contraseña son nulos", resultado);
    }

    private boolean validar(String usuario, String contrasena) {
        return usuario != null && !usuario.isEmpty()
            && contrasena != null && !contrasena.isEmpty();
    }
}

