package junit;

public class Nota {

    public String calcularNivelNota(int nota) {
        if (nota < 5) {
            return "Suspenso";
        } else {
            return "Aprobado";
        }
    }
}

