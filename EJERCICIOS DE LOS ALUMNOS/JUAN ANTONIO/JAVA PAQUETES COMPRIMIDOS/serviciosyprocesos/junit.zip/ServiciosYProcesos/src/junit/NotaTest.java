package junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class NotaTest {

	@Test
    public void testNotaSuspenso() {
        Nota nota = new Nota();
        String resultado = nota.calcularNivelNota(4);
        assertEquals("Suspenso", resultado);

	}

}
   