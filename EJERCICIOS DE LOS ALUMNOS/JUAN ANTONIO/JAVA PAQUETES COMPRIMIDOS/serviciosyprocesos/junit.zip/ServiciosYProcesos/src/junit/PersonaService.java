package junit;


public class PersonaService {

    public String obtenerNombrePorId(int id) {
        if (id <= 0) {
            return null; // Caso que debe dar assertNull
        }
        return "Juan"; // Caso que debe dar assertNotNull
    }
}
