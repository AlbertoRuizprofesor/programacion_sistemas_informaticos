package junit;



import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class PersonaServiceTest {

    PersonaService service = new PersonaService();

    @Test
    void testAssertNull() {
        String nombre = service.obtenerNombrePorId(0);
        assertNull(nombre); // Pasa porque es null
    }

    @Test
    void testAssertNotNull() {
        String nombre = service.obtenerNombrePorId(5);
        assertNotNull(nombre); // Pasa porque NO es null
    }
}
