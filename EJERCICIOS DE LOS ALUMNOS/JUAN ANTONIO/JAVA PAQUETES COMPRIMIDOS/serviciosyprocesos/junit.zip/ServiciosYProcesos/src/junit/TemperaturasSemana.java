package junit;


public class TemperaturasSemana {

    private double[] temperaturas = {18.5, 20.0, 21.3, 19.8, 22.1, 23.0, 21.7};

    public double[] getTemperaturas() {
        return temperaturas;
    }
}
