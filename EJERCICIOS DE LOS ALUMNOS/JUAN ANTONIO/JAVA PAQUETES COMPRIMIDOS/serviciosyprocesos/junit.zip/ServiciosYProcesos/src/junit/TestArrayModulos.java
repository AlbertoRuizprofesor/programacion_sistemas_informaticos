package junit;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TestArrayModulos {

    @Test
    void testArrayModulos() {
        ArrayModulos array = new ArrayModulos();

        String[] esperados = {
            "Lenguaje de Marcas",
            "Entorno",
            "Sistemas",
            "Programación",
            "Base de Datos"
        };

        String[] obtenidos = array.getModulos();

        assertArrayEquals(esperados, obtenidos);
    }
}

