package junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestArrayPersonas {

	@Test
	void test() {
ArrayPersonas personas = new ArrayPersonas();
		
        String[] nombresEsperados = {"Alberto", "Eva", "Cristina"};
        
        String[] nombresObtenidos = personas.getNombres();
       
        assertArrayEquals(nombresEsperados, nombresObtenidos);
	}

}
