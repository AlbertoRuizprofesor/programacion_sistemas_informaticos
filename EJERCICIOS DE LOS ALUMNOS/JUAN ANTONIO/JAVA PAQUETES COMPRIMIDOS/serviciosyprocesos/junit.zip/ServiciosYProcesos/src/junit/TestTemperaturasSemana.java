package junit;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TestTemperaturasSemana {

    @Test
    void testTemperaturas() {
        TemperaturasSemana semana = new TemperaturasSemana();

        double[] esperadas = {18.5, 20.0, 21.3, 19.8, 22.1, 23.0, 21.7};
        double[] obtenidas = semana.getTemperaturas();

        assertArrayEquals(esperadas, obtenidas);
    }
}
