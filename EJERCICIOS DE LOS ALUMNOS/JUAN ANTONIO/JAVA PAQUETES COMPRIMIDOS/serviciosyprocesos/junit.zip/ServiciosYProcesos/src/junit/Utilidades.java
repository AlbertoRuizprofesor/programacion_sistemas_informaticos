package junit;



public class Utilidades {

    public int sumar(int a, int b) {
        return a + b;
    }

    public boolean esPar(int numero) {
        return numero % 2 == 0;
    }

    public String obtenerMensaje(boolean correcto) {
        if (correcto) {
            return "OK";
        }
        return null;
    }
}

