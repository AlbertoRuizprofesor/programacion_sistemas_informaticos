package junit;



import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class UtilidadesTest {

    Utilidades util = new Utilidades();

    @Test
    void testSumar() {
        assertEquals(7, util.sumar(3, 4));  // assertEquals
    }

    @Test
    void testEsParTrue() {
        assertTrue(util.esPar(10));         // assertTrue
    }

    @Test
    void testEsParFalse() {
        assertFalse(util.esPar(7));         // assertFalse
    }

    @Test
    void testObtenerMensajeNotNull() {
        assertNotNull(util.obtenerMensaje(true));  // assertNotNull
    }

    @Test
    void testObtenerMensajeNull() {
        assertNull(util.obtenerMensaje(false));    // assertNull
    }
}

