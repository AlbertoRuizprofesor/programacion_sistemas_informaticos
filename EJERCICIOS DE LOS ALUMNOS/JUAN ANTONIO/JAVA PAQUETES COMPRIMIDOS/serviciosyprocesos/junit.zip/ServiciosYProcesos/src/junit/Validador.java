package junit;

public class Validador {

    public boolean esMayorDeEdad(int edad) {
        return edad >= 18;
    }
}
