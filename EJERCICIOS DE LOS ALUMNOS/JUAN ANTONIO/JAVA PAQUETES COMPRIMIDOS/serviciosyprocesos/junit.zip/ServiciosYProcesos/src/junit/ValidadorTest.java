package junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ValidadorTest {
	Validador val = new Validador();
	@Test
	void testEsMayorDeEdad() {
		assertTrue(val.esMayorDeEdad(20)); // Debe ser true
	}
	
	@Test void testEsMayorDeEdadFalse() { 
		assertFalse(val.esMayorDeEdad(15)); // Debe ser false 
	}
}


