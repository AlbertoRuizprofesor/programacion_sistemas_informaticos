package junit;



import org.junit.jupiter.api.Test;
import junit.framework.TestCase;

public class testCalculadora extends TestCase {

    public testCalculadora() {}

    @Test
    public void testsuma() {
        assertEquals(5, Calculadora.suma(2, 3));  // Correcto
        double result = Calculadora.division(4, 2);
        assertNotNull(result);
    }
}
