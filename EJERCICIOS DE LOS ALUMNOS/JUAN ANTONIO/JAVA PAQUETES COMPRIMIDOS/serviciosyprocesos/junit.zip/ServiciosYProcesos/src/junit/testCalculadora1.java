package junit;



import org.junit.jupiter.api.Test;
import junit.framework.TestCase;

public class testCalculadora1 extends TestCase {

    public testCalculadora1() {}

    @Test
    public void testresta() {
        assertEquals(1, Calculadora.resta(3, 2));  // Correcto
        double result = Calculadora.resta(10, 5);
        assertNotNull(result);
    }
}

