package procesos;

import java.io.IOException;

public class CmdArray {

	public static void main(String[] args) throws IOException {
		String comandos[] = { "cmd.exe", "/c","ping 8.8.8.8" };

		for (String comando : comandos) {
			ProcessBuilder pb = new ProcessBuilder(comando);
			pb.inheritIO();
			pb.start();
		}
	}
}
