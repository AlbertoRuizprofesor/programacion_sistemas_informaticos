package procesos;

import java.io.IOException;

public class CmdMethod {

	public static void main(String[] args) throws IOException {
		String comandos[] = { "ping 8.8.8.8", "dir", "ipconfig" };
		ejecutarComandos(comandos);

	}

	public static void ejecutarComandos(String[] comandos) throws IOException {

		for (String comand : comandos) {
			ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/c", comand);
			pb.inheritIO();
			pb.start();
		}
	}
}
