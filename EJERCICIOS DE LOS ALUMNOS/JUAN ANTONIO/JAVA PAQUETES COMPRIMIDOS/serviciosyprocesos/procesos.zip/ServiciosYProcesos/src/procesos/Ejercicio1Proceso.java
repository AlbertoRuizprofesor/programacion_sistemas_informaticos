package procesos;

import java.io.IOException;

public class Ejercicio1Proceso {

	public static void main(String[] args) throws IOException {
		ProcessBuilder proceso;
		System.out.println("Abriendo el Bloc de notas");
		proceso = new ProcessBuilder("C:\\Program Files\\HeidiSQL\\heidisql.exe");
		proceso.start();
	}
}
