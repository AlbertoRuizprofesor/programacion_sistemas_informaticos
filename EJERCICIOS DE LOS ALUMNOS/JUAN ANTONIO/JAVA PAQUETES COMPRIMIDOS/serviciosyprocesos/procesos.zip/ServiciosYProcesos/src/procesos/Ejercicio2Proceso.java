package procesos;

import java.io.File;
import java.io.IOException;

public class Ejercicio2Proceso {

	public static void main(String[] args) throws IOException, InterruptedException{
		ProcessBuilder proceso;
		System.out.println("Abriendo el Blocj de notas");
		proceso = new ProcessBuilder("C:/Windows/notepad.exe", "pelis.txt");
		proceso.directory(new File("c:/pruebas"));
		Process p = proceso.start();
		p.waitFor();
		System.out.println("El Bloc de notas se ha cerrado");
	}
}
