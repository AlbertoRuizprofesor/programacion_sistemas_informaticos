package procesos;

import java.io.IOException;

public class EjercicioCmd {

	public static void main(String[] args) throws IOException {
		ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/c", "ping 8.8.8.8");
		pb.inheritIO();
		pb.start();
	}
}
