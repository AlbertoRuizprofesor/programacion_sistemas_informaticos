package procesos;

import java.io.File;
import java.io.IOException;

public class RetoAbrirExcel {

	public static void main(String[] args) throws IOException, InterruptedException{
		ProcessBuilder proceso;
		System.out.println("Abriendo excel");
		proceso = new ProcessBuilder("C:/Program Files/Microsoft Office/root/Office16/EXCEL.EXE","archivo.xlsx");
		proceso.directory(new File("c:/prueba"));
		Process p = proceso.start();
		p.waitFor();
		System.out.println("Excel se ha cerrado");
	}
}
