package procesos;

import java.io.File;
import java.io.IOException;

public class RetoAbrirPowePoint {

	public static void main(String[] args) throws IOException, InterruptedException{
		ProcessBuilder proceso;
		System.out.println("Abriendo excel");
		proceso = new ProcessBuilder("C:/Program Files/Microsoft Office/root/Office16/POWERPNT.EXE","prueba.pptx");
		proceso.directory(new File("c:/prueba"));
		Process p = proceso.start();
		p.waitFor();
		System.out.println("PowerPoint se ha cerrado");
	}
}
