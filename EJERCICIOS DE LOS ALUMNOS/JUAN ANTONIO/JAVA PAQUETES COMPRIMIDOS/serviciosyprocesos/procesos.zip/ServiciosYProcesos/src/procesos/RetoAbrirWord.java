package procesos;

import java.io.File;
import java.io.IOException;

public class RetoAbrirWord {

	public static void main(String[] args) throws IOException, InterruptedException{
		ProcessBuilder proceso;
		System.out.println("Abriendo excel");
		proceso = new ProcessBuilder("C:/Program Files/Microsoft Office/root/Office16/WINWORD.EXE/","prueba.docx");
		proceso.directory(new File("c:/prueba"));
		Process p = proceso.start();
		p.waitFor();
		System.out.println("Word se ha cerrado");
	}
}
