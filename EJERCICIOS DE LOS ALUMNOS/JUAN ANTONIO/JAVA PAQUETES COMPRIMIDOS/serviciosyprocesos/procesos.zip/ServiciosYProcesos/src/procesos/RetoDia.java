package procesos;

import java.io.File;
import java.io.IOException;

public class RetoDia {

	public static void main(String[] args) throws IOException, InterruptedException{
		ProcessBuilder proceso;
		System.out.println("Abriendo excel");
		proceso = new ProcessBuilder("C:/Program Files (x86)/Dia/bin/diaw.exe","Diagrama1.dia");
		proceso.directory(new File("c:/prueba"));
		Process p = proceso.start();
		p.waitFor();
		System.out.println("Dia se ha cerrado");
	}
}
