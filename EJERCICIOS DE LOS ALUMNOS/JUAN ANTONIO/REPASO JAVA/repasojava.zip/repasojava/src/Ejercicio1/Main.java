package Ejercicio1;

public class Main {
    public static void main(String[] args) {

        // Crear un objeto Persona
        Persona p1 = new Persona("Laura", 25);

        // Mostrar sus datos
        p1.mostrarDatos();
    }
}

