package ejercicio10;

public class Main {
    public static void main(String[] args) {

        Movil m1 = new Movil("Samsung", "Galaxy S21", 50);

        m1.mostrarEstado();
        m1.usar(30);
        m1.cargar(60);  // No debe pasar de 100
        m1.usar(200);   // No debe bajar de 0
        m1.mostrarEstado();
    }
}

