package ejercicio10;

public class Movil {

    // Atributos
    private String marca;
    private String modelo;
    private int bateria; // porcentaje 0–100

    // Constructor
    public Movil(String marca, String modelo, int bateria) {
        this.marca = marca;
        this.modelo = modelo;
        this.bateria = Math.min(100, Math.max(0, bateria)); // control inicial
    }

    // Método para cargar batería
    public void cargar(int cantidad) {
        if (cantidad > 0) {
            bateria += cantidad;
            if (bateria > 100) {
                bateria = 100;
            }
            System.out.println("Cargando... Batería actual: " + bateria + "%");
        }
    }

    // Método para usar batería
    public void usar(int cantidad) {
        if (cantidad > 0) {
            bateria -= cantidad;
            if (bateria < 0) {
                bateria = 0;
            }
            System.out.println("Usando el móvil... Batería actual: " + bateria + "%");
        }
    }

    // Mostrar estado actual
    public void mostrarEstado() {
        System.out.println("Móvil: " + marca + " " + modelo);
        System.out.println("Batería: " + bateria + "%");
        System.out.println("---------------------------");
    }
}

