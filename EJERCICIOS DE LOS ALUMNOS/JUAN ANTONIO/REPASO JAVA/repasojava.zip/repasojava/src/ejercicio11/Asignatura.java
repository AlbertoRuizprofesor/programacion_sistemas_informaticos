package ejercicio11;

public class Asignatura {
    private String nombre;
    private String profesor;
    private int horasSemanales;

    // Constructor
    public Asignatura(String nombre, String profesor, int horasSemanales) {
        this.nombre = nombre;
        this.profesor = profesor;
        this.horasSemanales = horasSemanales;
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public String getProfesor() {
        return profesor;
    }

    public int getHorasSemanales() {
        return horasSemanales;
    }

    // Setters
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setProfesor(String profesor) {
        this.profesor = profesor;
    }

    public void setHorasSemanales(int horasSemanales) {
        this.horasSemanales = horasSemanales;
    }

    // Método para mostrar información
    public void mostrarAsignatura() {
        System.out.println("Asignatura: " + nombre);
        System.out.println("Profesor: " + profesor);
        System.out.println("Horas semanales: " + horasSemanales);
        System.out.println("---------------------------");
    }
}
