package ejercicio11;

public class Main {
    public static void main(String[] args) {
        Asignatura a1 = new Asignatura("Programación", "Laura Gómez", 6);
        Asignatura a2 = new Asignatura("Bases de Datos", "Carlos Ruiz", 4);

        a1.mostrarAsignatura();
        a2.mostrarAsignatura();
    }
}
