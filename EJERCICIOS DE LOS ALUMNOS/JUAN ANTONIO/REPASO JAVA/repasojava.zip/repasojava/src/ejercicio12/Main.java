package ejercicio12;

public class Main {
    public static void main(String[] args) {
        Videojuego v1 = new Videojuego("Zelda: Breath of the Wild", "Nintendo Switch", 50);
        Videojuego v2 = new Videojuego("The Witcher 3", "PC", 120);

        v1.mostrarInfo();
        v2.mostrarInfo();

        v1.jugar(5);
        v2.jugar(3);

        v1.mostrarInfo();
        v2.mostrarInfo();
    }
}
