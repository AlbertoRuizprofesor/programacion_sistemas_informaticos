package ejercicio12;

public class Videojuego {
    private String titulo;
    private String plataforma;
    private int horasJugadas;

    // Constructor
    public Videojuego(String titulo, String plataforma, int horasJugadas) {
        this.titulo = titulo;
        this.plataforma = plataforma;
        this.horasJugadas = horasJugadas;
    }

    // Método para jugar X horas
    public void jugar(int horas) {
        if (horas > 0) {
            horasJugadas += horas;
            System.out.println("Has jugado " + horas + " horas a " + titulo);
        } else {
            System.out.println("Las horas deben ser positivas");
        }
    }

    // Método para mostrar información
    public void mostrarInfo() {
        System.out.println("Título: " + titulo);
        System.out.println("Plataforma: " + plataforma);
        System.out.println("Horas jugadas: " + horasJugadas);
        System.out.println("---------------------------");
    }
}

