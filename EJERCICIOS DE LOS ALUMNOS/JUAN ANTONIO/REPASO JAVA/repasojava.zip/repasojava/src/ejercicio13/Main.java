package ejercicio13;


public class Main {
    public static void main(String[] args) {
        Mascota m1 = new Mascota("Luna", "Gato", 3);

        m1.mostrarInfo();
        m1.cumplirAnios();
        m1.mostrarInfo();
    }
}
