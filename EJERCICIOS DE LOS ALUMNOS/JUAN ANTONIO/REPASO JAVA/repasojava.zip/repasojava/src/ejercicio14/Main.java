package ejercicio14;

public class Main {
    public static void main(String[] args) {
        Ordenador o1 = new Ordenador("HP", 8, 512);
        Ordenador o2 = new Ordenador("Lenovo", 16, 1000);
        Ordenador o3 = new Ordenador("Asus", 32, 2000);

        o1.mostrarCaracteristicas();
        o2.mostrarCaracteristicas();
        o3.mostrarCaracteristicas();
    }
}
