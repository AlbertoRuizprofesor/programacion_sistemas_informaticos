package ejercicio14;

public class Ordenador {
    private String marca;
    private int memoriaRAM;     // en GB
    private int discoDuro;      // en GB

    // Constructor
    public Ordenador(String marca, int memoriaRAM, int discoDuro) {
        this.marca = marca;
        this.memoriaRAM = memoriaRAM;
        this.discoDuro = discoDuro;
    }

    // Método para mostrar características
    public void mostrarCaracteristicas() {
        System.out.println("Marca: " + marca);
        System.out.println("Memoria RAM: " + memoriaRAM + " GB");
        System.out.println("Disco duro: " + discoDuro + " GB");
        System.out.println("---------------------------");
    }
}
