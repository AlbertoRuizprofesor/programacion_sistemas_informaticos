package ejercicio15;

public class Main {
    public static void main(String[] args) {
        Pelicula p1 = new Pelicula("Interstellar", "Christopher Nolan", 169);
        Pelicula p2 = new Pelicula("Toy Story", "John Lasseter", 81);

        p1.mostrarInfo();
        p2.mostrarInfo();
    }
}

