package ejercicio15;

public class Pelicula {
    private String titulo;
    private String director;
    private int duracion; // en minutos

    // Constructor
    public Pelicula(String titulo, String director, int duracion) {
        this.titulo = titulo;
        this.director = director;
        this.duracion = duracion;
    }

    // Método para comprobar si dura más de 120 minutos
    public boolean esLarga() {
        return duracion > 120;
    }

    // Mostrar información
    public void mostrarInfo() {
        System.out.println("Título: " + titulo);
        System.out.println("Director: " + director);
        System.out.println("Duración: " + duracion + " minutos");

        if (esLarga()) {
            System.out.println("La película es larga (más de 120 minutos)");
        } else {
            System.out.println("La película NO es larga");
        }

        System.out.println("---------------------------");
    }
}
