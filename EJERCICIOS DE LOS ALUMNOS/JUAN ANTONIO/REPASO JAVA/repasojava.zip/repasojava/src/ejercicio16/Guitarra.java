package ejercicio16;

public class Guitarra {
    private String marca;
    private int numeroCuerdas;
    private String tipo; // acústica, eléctrica, clásica...

    // Constructor
    public Guitarra(String marca, int numeroCuerdas, String tipo) {
        this.marca = marca;
        this.numeroCuerdas = numeroCuerdas;
        this.tipo = tipo;
    }

    // Método afinar
    public void afinar() {
        System.out.println("Afinando la guitarra " + marca + "...");
    }

    // Método tocar
    public void tocar() {
        System.out.println("Tocando la guitarra " + marca + " de tipo " + tipo + ".");
    }

    // Mostrar información
    public void mostrarInfo() {
        System.out.println("Marca: " + marca);
        System.out.println("Número de cuerdas: " + numeroCuerdas);
        System.out.println("Tipo: " + tipo);
        System.out.println("---------------------------");
    }
}
