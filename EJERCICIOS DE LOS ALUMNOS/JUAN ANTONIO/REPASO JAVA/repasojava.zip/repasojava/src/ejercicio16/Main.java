package ejercicio16;

public class Main {
    public static void main(String[] args) {
        Guitarra g1 = new Guitarra("Fender", 6, "Eléctrica");

        g1.mostrarInfo();
        g1.afinar();
        g1.tocar();
    }
}
