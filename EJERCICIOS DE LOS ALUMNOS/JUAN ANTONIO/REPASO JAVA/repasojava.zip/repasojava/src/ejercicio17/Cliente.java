package ejercicio17;

public class Cliente {
    private String nombre;
    private String email;

    // Constructor
    public Cliente(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }

    // Mostrar información
    public void mostrarInfo() {
        System.out.println("Cliente:");
        System.out.println("Nombre: " + nombre);
        System.out.println("Email: " + email);
        System.out.println("---------------------------");
    }
}

