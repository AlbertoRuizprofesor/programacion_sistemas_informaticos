package ejercicio17;

public class Compra {
    private String producto;
    private double precio;

    // Constructor
    public Compra(String producto, double precio) {
        this.producto = producto;
        this.precio = precio;
    }

    // Mostrar información
    public void mostrarInfo() {
        System.out.println("Compra:");
        System.out.println("Producto: " + producto);
        System.out.println("Precio: " + precio + " €");
        System.out.println("---------------------------");
    }
}
