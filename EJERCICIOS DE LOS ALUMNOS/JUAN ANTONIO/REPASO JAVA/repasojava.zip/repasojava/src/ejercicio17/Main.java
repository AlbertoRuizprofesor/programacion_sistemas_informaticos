package ejercicio17;

public class Main {
    public static void main(String[] args) {
        Cliente c1 = new Cliente("Ana López", "ana@example.com");
        Compra compra1 = new Compra("Auriculares Bluetooth", 29.99);

        c1.mostrarInfo();
        compra1.mostrarInfo();
    }
}

