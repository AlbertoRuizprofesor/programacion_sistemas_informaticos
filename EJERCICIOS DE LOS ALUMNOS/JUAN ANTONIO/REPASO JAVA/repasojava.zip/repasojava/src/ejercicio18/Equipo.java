package ejercicio18;

public class Equipo {
    private String nombreEquipo;
    private Jugador[] jugadores; // array de 3 jugadores

    // Constructor
    public Equipo(String nombreEquipo, Jugador[] jugadores) {
        this.nombreEquipo = nombreEquipo;
        this.jugadores = jugadores;
    }

    // Mostrar información del equipo y sus jugadores
    public void mostrarEquipo() {
        System.out.println("Equipo: " + nombreEquipo);
        System.out.println("Jugadores:");

        for (Jugador j : jugadores) {
            j.mostrarInfo();
        }

        System.out.println("---------------------------");
    }
}

