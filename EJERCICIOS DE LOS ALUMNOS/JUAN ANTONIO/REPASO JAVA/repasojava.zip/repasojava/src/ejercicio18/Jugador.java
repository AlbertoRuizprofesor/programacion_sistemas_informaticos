package ejercicio18;

public class Jugador {
    private String nombre;
    private int dorsal;

    // Constructor
    public Jugador(String nombre, int dorsal) {
        this.nombre = nombre;
        this.dorsal = dorsal;
    }

    // Mostrar información
    public void mostrarInfo() {
        System.out.println("Jugador: " + nombre + " | Dorsal: " + dorsal);
    }
}

