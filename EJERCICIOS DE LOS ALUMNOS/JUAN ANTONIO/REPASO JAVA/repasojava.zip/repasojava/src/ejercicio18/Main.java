package ejercicio18;

public class Main {
    public static void main(String[] args) {
        Jugador j1 = new Jugador("Carlos", 7);
        Jugador j2 = new Jugador("Miguel", 10);
        Jugador j3 = new Jugador("Sergio", 4);

        Jugador[] listaJugadores = { j1, j2, j3 };

        Equipo equipo = new Equipo("Los Tigres", listaJugadores);

        equipo.mostrarEquipo();
    }
}

