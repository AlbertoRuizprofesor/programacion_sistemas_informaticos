package ejercicio19;

public class Instituto {
    private String nombre;
    private Profesor profesor;

    // Constructor
    public Instituto(String nombre, Profesor profesor) {
        this.nombre = nombre;
        this.profesor = profesor;
    }

    // Mostrar información del instituto y su profesor
    public void mostrarInfo() {
        System.out.println("Instituto: " + nombre);
        System.out.println("Información del profesor:");
        profesor.mostrarInfo();
        System.out.println("---------------------------");
    }
}

