package ejercicio19;


public class Main {
    public static void main(String[] args) {
        Profesor p1 = new Profesor("María Sánchez", "Programación");
        Instituto inst = new Instituto("IES Tecnológico", p1);

        inst.mostrarInfo();
    }
}
