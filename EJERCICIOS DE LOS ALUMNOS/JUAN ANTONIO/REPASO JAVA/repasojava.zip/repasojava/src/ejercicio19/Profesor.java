package ejercicio19;

public class Profesor {
    private String nombre;
    private String modulo;

    // Constructor
    public Profesor(String nombre, String modulo) {
        this.nombre = nombre;
        this.modulo = modulo;
    }

    // Mostrar información
    public void mostrarInfo() {
        System.out.println("Profesor: " + nombre);
        System.out.println("Módulo: " + modulo);
    }
}
