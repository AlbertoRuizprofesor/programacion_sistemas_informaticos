package ejercicio2;

public class Coche {

    // Atributos
    private String marca;
    private String modelo;
    private String color;

    // Constructor
    public Coche(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    // Método arrancar
    public void arrancar() {
        System.out.println("El coche " + marca + " " + modelo + " ha arrancado.");
    }
}
