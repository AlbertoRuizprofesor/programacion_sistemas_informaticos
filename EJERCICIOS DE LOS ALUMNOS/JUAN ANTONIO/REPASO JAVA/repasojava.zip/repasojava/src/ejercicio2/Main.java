package ejercicio2;

public class Main {
    public static void main(String[] args) {

        // Crear dos coches
        Coche coche1 = new Coche("Toyota", "Corolla", "Rojo");
        Coche coche2 = new Coche("Ford", "Focus", "Azul");

        // Llamar al método arrancar
        coche1.arrancar();
        coche2.arrancar();
    }
}

