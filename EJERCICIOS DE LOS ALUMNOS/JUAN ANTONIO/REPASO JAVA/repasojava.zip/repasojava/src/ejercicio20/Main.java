package ejercicio20;

public class Main {
    public static void main(String[] args) {
        Libro l1 = new Libro("1984", "George Orwell", true);
        Libro l2 = new Libro("El Hobbit", "J.R.R. Tolkien", true);
        Libro l3 = new Libro("Dune", "Frank Herbert", false);

        l1.mostrarEstado();
        l2.mostrarEstado();
        l3.mostrarEstado();

        l1.prestar();
        l2.prestar();
        l3.prestar(); // No debería poder prestarse

        l1.mostrarEstado();
        l2.mostrarEstado();
        l3.mostrarEstado();

        l1.devolver();
        l3.devolver(); // Devolver un libro ya prestado

        l1.mostrarEstado();
        l3.mostrarEstado();
    }
}

