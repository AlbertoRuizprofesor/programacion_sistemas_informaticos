package ejercicio3;


public class Main {
    public static void main(String[] args) {

        // Crear un alumno
        Alumno alumno1 = new Alumno("María", 8.5, 7.0);

        // Mostrar su media
        System.out.println("La media de " + alumno1.calcularMedia());
    }
}
