package ejercicio4;

public class Main {
    public static void main(String[] args) {

        // Crear un rectángulo
        Rectangulo r1 = new Rectangulo(5, 3);

        // Mostrar resultados
        System.out.println("Área: " + r1.calcularArea());
        System.out.println("Perímetro: " + r1.calcularPerimetro());
    }
}
