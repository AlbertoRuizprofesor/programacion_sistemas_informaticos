package ejercicio5;

public class CuentaBancaria {

    // Atributos
    private String titular;
    private double saldo;

    // Constructor
    public CuentaBancaria(String titular, double saldoInicial) {
        this.titular = titular;
        this.saldo = saldoInicial;
    }

    // Método para ingresar dinero
    public void ingresar(double cantidad) {
        if (cantidad > 0) {
            saldo += cantidad;
            System.out.println("Has ingresado " + cantidad + "€. Nuevo saldo: " + saldo + "€");
        } else {
            System.out.println("La cantidad a ingresar debe ser positiva.");
        }
    }

    // Método para retirar dinero
    public void retirar(double cantidad) {
        if (cantidad > 0 && cantidad <= saldo) {
            saldo -= cantidad;
            System.out.println("Has retirado " + cantidad + "€. Nuevo saldo: " + saldo + "€");
        } else {
            System.out.println("No es posible retirar esa cantidad.");
        }
    }

    // Método para mostrar el saldo
    public void mostrarSaldo() {
        System.out.println("Saldo actual de " + titular + ": " + saldo + "€");
    }
}

