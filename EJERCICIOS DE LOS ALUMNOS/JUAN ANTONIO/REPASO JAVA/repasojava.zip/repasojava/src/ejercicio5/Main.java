package ejercicio5;

public class Main {
    public static void main(String[] args) {

        // Crear una cuenta bancaria
        CuentaBancaria cuenta = new CuentaBancaria("Ana López", 500);

        // Operaciones
        cuenta.mostrarSaldo();
        cuenta.ingresar(200);
        cuenta.retirar(100);
        cuenta.retirar(700); // Intento fallido
        cuenta.mostrarSaldo();
    }
}
