package ejercicio6;

public class Main {
    public static void main(String[] args) {

        // Crear dos libros
        Libro libro1 = new Libro("El Quijote", "Miguel de Cervantes", 863);
        Libro libro2 = new Libro("La sombra del viento", "Carlos Ruiz Zafón", 576);

        // Mostrar sus datos
        libro1.mostrarInfo();
        libro2.mostrarInfo();
    }
}

