package ejercicio7;

public class Animal {

    // Atributos
    private String nombre;
    private String tipo;

    // Constructor
    public Animal(String nombre, String tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
    }

    // Método genérico
    public void hacerSonido() {
        System.out.println(nombre + " (" + tipo + ") hace un sonido genérico.");
    }
}

