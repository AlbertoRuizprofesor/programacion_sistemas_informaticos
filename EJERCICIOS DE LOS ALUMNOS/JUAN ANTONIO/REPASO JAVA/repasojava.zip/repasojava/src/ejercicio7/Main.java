package ejercicio7;

public class Main {
    public static void main(String[] args) {

        Animal perro = new Animal("Rex", "Perro");
        Animal gato = new Animal("Misu", "Gato");
        Animal vaca = new Animal("Lola", "Vaca");

        perro.hacerSonido();
        gato.hacerSonido();
        vaca.hacerSonido();
    }
}

