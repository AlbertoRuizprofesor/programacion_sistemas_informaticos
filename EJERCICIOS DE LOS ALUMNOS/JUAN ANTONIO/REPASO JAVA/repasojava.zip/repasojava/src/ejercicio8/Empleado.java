package ejercicio8;

public class Empleado {

    // Atributos
    private String nombre;
    private double sueldoBase;

    // Constructor
    public Empleado(String nombre, double sueldoBase) {
        this.nombre = nombre;
        this.sueldoBase = sueldoBase;
    }

    // Método para calcular el sueldo anual
    public double calcularSueldoAnual() {
        return sueldoBase * 12;
    }

    // Método para mostrar la información
    public void mostrarInfo() {
        System.out.println("Empleado: " + nombre);
        System.out.println("Sueldo mensual: " + sueldoBase + "€");
        System.out.println("Sueldo anual: " + calcularSueldoAnual() + "€");
    }
}

