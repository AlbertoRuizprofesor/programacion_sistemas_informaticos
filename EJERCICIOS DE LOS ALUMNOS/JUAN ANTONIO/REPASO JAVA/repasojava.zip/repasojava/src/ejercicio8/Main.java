package ejercicio8;

public class Main {
    public static void main(String[] args) {

        Empleado emp1 = new Empleado("Carlos Pérez", 1500);

        emp1.mostrarInfo();
    }
}
