package ejercicio9;

public class Main {
    public static void main(String[] args) {

        Producto p1 = new Producto("Teclado", 25.99, 10);
        Producto p2 = new Producto("Ratón", 15.50, 20);
        Producto p3 = new Producto("Monitor", 199.99, 5);

        p1.mostrarInfo();
        p2.mostrarInfo();
        p3.mostrarInfo();
    }
}

