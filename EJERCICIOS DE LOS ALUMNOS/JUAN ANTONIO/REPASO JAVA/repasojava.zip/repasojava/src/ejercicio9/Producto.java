package ejercicio9;

public class Producto {

    // Atributos
    private String nombre;
    private double precio;
    private int cantidad;

    // Constructor
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    // Método para calcular el valor total en almacén
    public double calcularValorTotal() {
        return precio * cantidad;
    }

    // Método para mostrar información del producto
    public void mostrarInfo() {
        System.out.println("Producto: " + nombre);
        System.out.println("Precio: " + precio + "€");
        System.out.println("Cantidad: " + cantidad);
        System.out.println("Valor total en almacén: " + calcularValorTotal() + "€");
        System.out.println("---------------------------");
    }
}
