package ejercicio1;

public class Main {
    public static void main(String[] args) {
    	
        // Instanciación y Creamos el objeto e inicializamos con argumentos
        Persona persona1 = new Persona("Gael", 25);

        // Llamamos al método para mostrar los datos
        persona1.mostrarDatos();
    }
}
