package ejercicio10;

public class Main {

	public static void main(String[] args) {
		
		// Instanciamos. Inicializamos
		Movil movil = new Movil("iphone", "i17", 35);
		
		// Llamada a métodos
		movil.mostrarEstado();
		movil.cargarBateria(80);
		movil.mostrarEstado();
		movil.usarBateria();
		movil.usarBateria();
		movil.usarBateria();
		movil.cargarBateria(100);
		movil.mostrarEstado();
	}
}
