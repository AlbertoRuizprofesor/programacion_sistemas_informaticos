package ejercicio10;

public class Movil {

	// Atributos de clase
	private String marca;
	private String modelo;
	private int bateria;

	// Constructor
	public Movil(String marca, String modelo, int bateriaInicial) {
		this.marca = marca;
		this.modelo = modelo;
		// Validamos que no empiece con carga imposible
		if (bateriaInicial > 100)
			this.bateria = 100;
		else if (bateriaInicial < 0)
			this.bateria = 0;
		else
			this.bateria = bateriaInicial;
	}

	// Método para cargar
	public void cargarBateria(int cantidad) {
		bateria += cantidad;
		if (bateria > 100) { // Controlamos el máximo
			bateria = 100;
		}
		System.out.printf("Cargando... Batería actual: %d%%%n", bateria);
	}

	public void usarBateria() {
		
		if (bateria == 0) {
			System.out.println("¡Móvil apagado! Batería agotada. Cárgalo, Bro.");
		}
		// Generamos un número aleatorio entre 25 y 75 para simular uso o descarga
		// Fórmula: (Math.random() * (max - min + 1)) + min
		int descarga = (int) (Math.random() * (75 - 25 + 1)) + 25; // Casteamos el decimal a (int) 

		bateria -= descarga;

		// Controlamos que no baje de 0
		if (bateria <= 0) {
			descarga += bateria;
			bateria = 0;
			System.out.printf("Has usado un %d%% y la bateria se agotó. Cárgalo, Bro.%n", descarga);
		} else {
			System.out.printf("Has usado el móvil y has gastado un %d%% de batería.%n", descarga);
			System.out.printf("Batería restante: %d%%%n", bateria);
		}
	}

	// Mostrar estado
	public void mostrarEstado() {
		System.out.printf("Móvil %s %s || Batería: %d%%%n", marca, modelo, bateria);
	}
}