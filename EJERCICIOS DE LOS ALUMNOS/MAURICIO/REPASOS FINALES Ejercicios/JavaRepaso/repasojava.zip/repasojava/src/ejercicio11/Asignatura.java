package ejercicio11;

public class Asignatura {
	
	// Atributamos con privacidad y alevosía
	private String nombre;
	private String profesor;
	private int horasSemanales;
	
	// Constructor
	/**
	 * @param nombre : El nombre de la asignatura
	 * @param profesor : El nombre del profe
	 * @param horasSemanales : Horas semanales que se imparte esa asignatura
	 */
	public Asignatura(String nombre, String profesor, int horasSemanales) {
		// super();
		this.nombre = nombre;
		this.profesor = profesor;
		this.horasSemanales = horasSemanales;
	}
	
	// Getters publicos para que todos puedan leer
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getProfesor() {
		return profesor;
	}

	// Setters públicso para que todos puedan modificar
	public void setProfesor(String profesor) {
		this.profesor = profesor;
	}

	public int getHorasSemanales() {
		return horasSemanales;
	}

	public void setHorasSemanales(int horasSemanales) {
		this.horasSemanales = horasSemanales;
	}
	
	// El toString 
	@Override
	public String toString() {
		return "Asignatura [nombre=" + nombre + ", profesor=" + profesor + ", horasSemanales=" + horasSemanales + "]";
	}
	
	// Usamos el toString en el método
	public void mostrarAsignatura() {
	    System.out.println(this.toString());
	}

	
	
}
