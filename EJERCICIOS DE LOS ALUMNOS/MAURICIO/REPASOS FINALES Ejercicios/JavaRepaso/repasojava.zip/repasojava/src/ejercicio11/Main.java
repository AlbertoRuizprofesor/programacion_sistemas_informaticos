package ejercicio11;

public class Main {

	public static void main(String[] args) {
		
		// Instanciamos e inicializamos las dos asignaturas 
		Asignatura asignatura1 = new Asignatura("Historia", "Alberto", 10);
		Asignatura asignatura2 = new Asignatura("Matemáticas", "Elena", 12);
		
		// Mostramos la información inicial usando el método solicitado 
		System.out.println("--- Tablon Informativo ---");
		asignatura1.mostrarAsignatura();
		asignatura2.mostrarAsignatura();
		
		// Cambiamos a Alberto de Historia x Aurelia usando setters
		asignatura1.setProfesor("Aurelia");
		System.out.printf("%nDatos profesor de %s modificados.%n", asignatura1.getNombre());
		
		// Imprimimos solo el nombre de la segunda asignatura para probar el get
		System.out.println("La segunda asignatura es: " + asignatura2.getNombre());
		
		// 5. Mostramos la información actualizada
		System.out.println("\n--- Tablon Informativo Actualizado ---");
		asignatura1.mostrarAsignatura();
		asignatura2.mostrarAsignatura();
	}
}