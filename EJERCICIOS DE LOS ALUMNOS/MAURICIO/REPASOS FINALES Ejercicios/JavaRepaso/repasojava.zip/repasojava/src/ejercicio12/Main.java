package ejercicio12;

public class Main {
	
    public static void main(String[] args) {
    	
        // Instanciamos y Creamos el videojuego con 0 horas iniciales
        Videojuego miJuego = new Videojuego("Elden Ring", "RPG", 0);

        // Mostramos estado inicial
        miJuego.mostrarInformacion();

        // Primera sesión de juego
        miJuego.jugar(5);
        
        // Segunda sesión de juego
        miJuego.jugar(10);

        // Mostramos el resultado final 
        miJuego.mostrarInformacion();
        
        // Tercera sesión de juego
        miJuego.jugar(25);
        
        // Segunda sesión de juego
        miJuego.jugar(18);
        
     // Mostramos el resultado final 
        miJuego.mostrarInformacion();

    }
}
