package ejercicio12;

public class Videojuego {
    
    // Atributos privados
    private String titulo;
    private String genero;
    private int horasJugadas;

    // Constructor
    public Videojuego(String titulo, String genero, int horasJugadas) {
        this.titulo = titulo;
        this.genero = genero;
        this.horasJugadas = horasJugadas;
    }

    // Método para jugar: suma horas al total actual
    public void jugar(int horas) {
        if (horas > 0) {
            this.horasJugadas += horas;
            System.out.printf("¡Has jugado %d horas a %s!%n", horas, titulo);
        } else {
            System.out.println("No se pueden sumar horas negativas, Bro.");
        }
    }

    // Método para mostrar la información (usando el estilo que prefieras)
    public void mostrarInformacion() {
        System.out.println("--- Perfil de Jugador ---");
        System.out.printf("Título: %s%n", titulo);
        System.out.printf("Género: %s%n", genero);
        System.out.printf("Tiempo total: %d horas%n", horasJugadas);
        System.out.println("-------------------------");
    }
}