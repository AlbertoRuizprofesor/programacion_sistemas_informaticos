package ejercicio13;

public class Main {
    public static void main(String[] args) {
        // Instanciamos y Creamos la mascota peluda
        Mascota miMascota = new Mascota("Rodolfo", "Perro", 7);

        // Vemos su estado inicial
        miMascota.mostrarMascota();

        // Simulamos que pasa el tiempo
        System.out.println("\n... Un anio más tarde que pronto ...\n");
        miMascota.cumplirAnios();

        // Comprobamos que rodolfo es un años más viejo
        miMascota.mostrarMascota();
    }
}