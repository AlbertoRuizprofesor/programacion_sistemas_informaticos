package ejercicio13;

public class Mascota {
    
    // Atributos privados
    private String nombre;
    private String especie;
    private int edad;

    // Constructor
    public Mascota(String nombre, String especie, int edadInicial) {
        this.nombre = nombre;
        this.especie = especie;
        this.edad = edadInicial;
    }

    // Método cumplirAnios() - Aumentamos la edad en 1 cada vez que lo llamamos
    public void cumplirAnios() {
        this.edad++; // Operador de incremento, ¡el más elegante en Java!
        System.out.printf("¡Felicidades %s! Hoy cumples años. Ahora tienes %d años.%n", 
                          nombre, edad);
    }

    // Método para mostrar el estado actual
    public void mostrarMascota() {
    		System.out.println("");
        System.out.println("----- Ficha Veterinaria -----");
        System.out.printf("Nombre: %s%n", nombre);
        System.out.printf("Especie: %s%n", especie);
        System.out.printf("Edad actual: %d años%n", edad);
        System.out.println("-----------------------------");
    }
}