package ejercicio14;

public class Main {

	public static void main(String[] args) {
		
		// Instanciamos tres objetos de la clase Ordenador
		// Pasamos los argumentos: marca, memoriaRAM, discoDuro
		Ordenador pc1 = new Ordenador("HP Papilion", 16, 512);
		Ordenador pc2 = new Ordenador("Apple MacBook Pro", 8, 256);
		Ordenador pc3 = new Ordenador("Lenovo Office Gaming", 32, 1024);
		
		// 2. Mostramos los datos de cada uno usando el método de la clase
		System.out.println("");
		System.out.println("--- Lista de Ordenadores Disponibles ---");
		System.out.println("");
		pc1.mostrarCaracteristicas();
		pc2.mostrarCaracteristicas();
		pc3.mostrarCaracteristicas();
		System.out.println("");
		System.out.println("----------------------------------------");
	}
}