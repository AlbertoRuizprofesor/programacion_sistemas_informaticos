package ejercicio14;

public class Ordenador {
    private String marca;
    private int memoriaRAM;
    private int discoDuro;

    public Ordenador(String marca, int memoriaRAM, int discoDuro) {
        this.marca = marca;
        this.memoriaRAM = memoriaRAM;
        this.discoDuro = discoDuro;
    }

    public void mostrarCaracteristicas() {
        System.out.printf("Ordenador %s: %dGB RAM, %dGB Disco Duro.%n", 
                          marca, memoriaRAM, discoDuro);
    }
}
