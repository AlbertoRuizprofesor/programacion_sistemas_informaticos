package ejercicio15;

public class Main {

    public static void main(String[] args) {
        
        // 1. Creamos una película larga (más de 120 min)
        Pelicula p1 = new Pelicula("Oppenheimer", "Nolan", 180);
        
        // 2. Creamos una película más corta (menos de 120 min)
        Pelicula p2 = new Pelicula("Terminator", "Cameron", 81);
        
        // 3. Probamos el método en ambas
        System.out.println("--- Comprobación de duración ---");
        p1.esLargaDuracion();
        p2.esLargaDuracion();
        System.out.println("--------------------------------");
    }
}