package ejercicio15;

public class Pelicula {
    private String titulo;
    private String director;
    private int duracion;

    public Pelicula(String titulo, String director, int duracion) {
        this.titulo = titulo;
        this.director = director;
        this.duracion = duracion;
    }

    public void esLargaDuracion() {
        if (duracion > 120) {
            System.out.println("La película '" + titulo + "' dura más de 120 min.");
        } else {
            System.out.println("La película '" + titulo + "' dura 120 min o menos.");
        }
    }
}