package ejercicio16;

public class Guitarra {
    
    private String marca;
    private int numCuerdas;
    private String tipo; // Eléctrica, Acústica, Española...

    public Guitarra(String marca, int numCuerdas, String tipo) {
        this.marca = marca;
        this.numCuerdas = numCuerdas;
        this.tipo = tipo;
    }

    // Método para simular la acción de afinar
    public void afinar() {
        System.out.printf("Las %d cuerdas de la %s %s afinadas.%n", 
                          numCuerdas, marca, tipo);
    }

    // Método para simular la acción de tocar
    public void tocar() {
        System.out.printf("Tocando 'Creole' con la guitarra %s Stratokaster%n.", marca);
    }
}