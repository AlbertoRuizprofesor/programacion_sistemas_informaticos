package ejercicio16;

public class Main {

    public static void main(String[] args) {
        
        // 1. Instanciamos la guitarra (ejemplo: una Fender Stratocaster)
        Guitarra miGuitarra = new Guitarra("Fender", 6, "Eléctrica");

        // 2. Probamos sus métodos de acción
        System.out.println("--- Sesión de Música ---");
        
        miGuitarra.afinar();
        miGuitarra.tocar();
        
        System.out.println("------------------------");
    }
}