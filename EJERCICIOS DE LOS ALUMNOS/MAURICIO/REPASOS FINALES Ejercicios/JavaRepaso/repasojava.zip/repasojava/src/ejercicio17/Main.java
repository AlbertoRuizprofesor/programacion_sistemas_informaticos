package ejercicio17;

public class Main {
    public static void main(String[] args) {
        
        // 1. Creamos al cliente
        Cliente cliente1 = new Cliente("Juan del Vals", "juanillo@gmail.com");

        // 2. Creamos la compra (independiente por ahora)
        Compra compra1 = new Compra("Zapatillas Adidas", 89.95);

        // 3. Mostramos la información de ambos
        System.out.println("-------- SISTEMA DE VENTAS ---------");
        cliente1.mostrarCliente();
        compra1.mostrarCompra();
        System.out.println("-".repeat(35));
    }
}