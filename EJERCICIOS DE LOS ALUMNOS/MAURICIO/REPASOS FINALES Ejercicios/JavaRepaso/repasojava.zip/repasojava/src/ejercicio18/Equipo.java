package ejercicio18;

public class Equipo {
	
	// Atributos private 
    private String nombreEquipo;
    private Jugador[] jugadores; // Declaramos el array

    public Equipo(String nombre, Jugador j1, Jugador j2, Jugador j3) {
    	
        this.nombreEquipo = nombre;
        this.jugadores = new Jugador[]{j1, j2, j3}; // Inicializamos el array con los 3 jugadores que recibimos
    }

    public void mostrarEquipo() {
        System.out.println("EQUIPO: " + nombreEquipo);
        System.out.println("-".repeat(25));
        // Recorremos el array para mostrar cada jugador
        for (Jugador j : jugadores) {
            System.out.println("Dorsal " + j.dorsal + ": " + j.nombre);
        }
    }
}