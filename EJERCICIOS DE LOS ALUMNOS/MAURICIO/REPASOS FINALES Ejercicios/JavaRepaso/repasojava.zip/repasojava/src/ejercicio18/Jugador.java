package ejercicio18;

public class Jugador {
	
	// Atributos sin private (package-private x defecto)
	// para usarlos más tarde en el método mostrarEquipo()
    String nombre; 
    int dorsal;

    // Constructor
    public Jugador(String nombre, int dorsal) {
        this.nombre = nombre;
        this.dorsal = dorsal;
    }
}