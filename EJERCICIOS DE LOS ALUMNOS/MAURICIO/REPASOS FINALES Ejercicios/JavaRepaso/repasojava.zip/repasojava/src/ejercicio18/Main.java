package ejercicio18;

public class Main {
	
    public static void main(String[] args) {
        
        // Creamos los 3 objetos Jugador
        Jugador j1 = new Jugador("Juanito", 7);
        Jugador j2 = new Jugador("Donatelo", 9);
        Jugador j3 = new Jugador("Guti", 5);

        // Creamos el Equipo y inicializamos con los objetos jugador
        Equipo miEquipo = new Equipo("Real Madrid", j1, j2, j3);

        // Llamamos al método
        // Mostramos la información de miEquipo 
        miEquipo.mostrarEquipo();
    }
}