package ejercicio19;

public class Instituto {
	
	// Atributamos
    private String nombreIes;
    private Profesor profesorDelInsti; // Relación simple (un objeto dentro de otro)

    public Instituto(String nombreIes, Profesor profe) {
        this.nombreIes = nombreIes;
        this.profesorDelInsti = profe;
    }

    public void mostrarInfo() {
        System.out.println("Instituto: " + nombreIes);
        // Accedemos a los datos del objeto profesorAsignado
        System.out.println("Profesor : " + profesorDelInsti.nombre + " (Módulo: " + profesorDelInsti.modulo + ")");
    }
}