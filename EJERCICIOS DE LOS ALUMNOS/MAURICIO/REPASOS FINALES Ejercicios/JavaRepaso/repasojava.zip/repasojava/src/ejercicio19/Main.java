package ejercicio19;

public class Main {
	
	public static void main(String[] args) {
		
		// Instanciar y Inicializar
		// Profe
		Profesor profe = new Profesor("Adelaido", "Ciberseguridad");
		
		// Instanciamos y relacionamos Instituto con Profesor
		Instituto insti = new Instituto("Los Acebuches", profe);
		
		// LLamada al método mostrarInfo() de la clase Instituto
		insti.mostrarInfo();
	}

}
