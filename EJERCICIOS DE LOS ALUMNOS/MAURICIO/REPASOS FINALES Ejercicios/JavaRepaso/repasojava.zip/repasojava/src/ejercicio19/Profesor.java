package ejercicio19;

public class Profesor {
	
	// No privatizamos los atributos 
    String nombre;
    String modulo;

    	// Constructor básico
    public Profesor(String nombre, String modulo) {
        this.nombre = nombre;
        this.modulo = modulo;
    }
}