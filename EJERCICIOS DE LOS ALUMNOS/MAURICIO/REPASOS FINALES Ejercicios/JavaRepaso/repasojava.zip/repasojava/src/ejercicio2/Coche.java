package ejercicio2;

public class Coche {
	
	// Atribitos
	private String marca;
	private String modelo;
	private String color;
	
	// Constructor
	/**
	 * @param marca
	 * @param modelo
	 * @param color
	 */
	public Coche(String marca, String modelo, String color) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.color = color;
	}
	
	// Método arrancar();
	public void arrancar() {
		System.out.printf("Motor encendido, "
				+ "el %s %s de color %s está arrancado.%n",
				marca.substring(0, 1).toUpperCase() + marca.substring(1).toLowerCase(),
				modelo.toUpperCase(),
				color.toLowerCase());
	}
}
