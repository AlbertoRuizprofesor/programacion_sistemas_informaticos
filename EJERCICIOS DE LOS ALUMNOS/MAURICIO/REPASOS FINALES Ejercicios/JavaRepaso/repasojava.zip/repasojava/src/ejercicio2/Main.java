package ejercicio2;

public class Main {

	public static void main(String[] args) {
		
		// Instanciar y Inicializar las Referencias coche1 y coche2
		Coche coche1 = new Coche("audi","bmw320","negro");
		Coche coche2 = new Coche("ferrari","testarosa","rojo");
		
		// Llmamos al metodo arrancar() de la clase Coche
		coche1.arrancar();
		coche2.arrancar();

	}

}
