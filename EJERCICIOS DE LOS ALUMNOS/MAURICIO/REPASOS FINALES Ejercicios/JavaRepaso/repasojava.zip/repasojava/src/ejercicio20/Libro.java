package ejercicio20;

public class Libro {

	// Atributamos
    private String titulo;
    private String autor;
    private boolean disponible; // true = en la estantería, false = prestado
    
    // Constructor
    public Libro(String titulo, String autor) {
        this.titulo = titulo;
        this.autor = autor;
        this.disponible = true; // Al crearlo, le asignamos disponible
    }

    public void prestarLibro() {
        if (disponible) {
            disponible = false;
            System.out.println("Muy bien. Te llevas '" + titulo + "'.");
        } else {
            System.out.println("Lo siento, bro. '" + titulo + "' ya está prestado actualmente.");
        }
    }

    public void devolverLibro() {
        disponible = true;
        System.out.println("Todo ok. Has devuelto '" + titulo + "'. ¡Gracias!");
    }

    public void mostrarEstado() {
        String estado = disponible ? "Disponible" : "Prestado";
        System.out.printf("[%s] %s - %s%n", estado, titulo, autor);
    }
}