package ejercicio20;

public class Main {
	
	public static void main(String[] args) {
		
		// Creacion de libros título, autor disponibilidad (boolean)
		Libro libro1 = new Libro("El Aleph","Borges");
		Libro libro2 = new Libro("Rayuela","Cortazar");
		Libro libro3 = new Libro("El tunel","Sabato");
		Libro libro4 = new Libro("Historias del Kronen","Mañas");
		
		// Llamamos a los metodos
		libro1.prestarLibro();
		libro2.prestarLibro();
		libro1.devolverLibro();
		libro2.prestarLibro(); 
		libro3.prestarLibro();
		libro1.prestarLibro();
		libro2.prestarLibro();
		libro3.devolverLibro();
		libro4.prestarLibro();
		libro1.prestarLibro();
	
		
	}

}
