package ejercicio3;

public class Alumno {
	
	// Atributos
	private String nombre;
	private double nota1;
	private double nota2;
	
	
	// Constructor
	/**
	 * @param nombre
	 * @param nota1
	 * @param nota2
	 */
	public Alumno(String nombre, double nota1, double nota2) {
		this.nombre = nombre;
		this.nota1 = nota1;
		this.nota2 = nota2;
	}
	
	// Método calcularMedia()
	public void calcularMedia() {
		double media = (nota1 + nota2) / 2;
		System.out.printf("La media de %.2f y %.2f es: %.2f", nota1, nota2, media);
	}
}
