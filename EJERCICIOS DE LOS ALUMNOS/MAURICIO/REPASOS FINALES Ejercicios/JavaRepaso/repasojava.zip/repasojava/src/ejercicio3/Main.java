package ejercicio3;

public class Main {

	public static void main(String[] args) {
		
		// Instanciamos e Inicializamos
		Alumno alumno = new Alumno("Andres", 7.5, 8.3);

		// Llamamos al método calcularMedia()
		alumno.calcularMedia();
	}
}
