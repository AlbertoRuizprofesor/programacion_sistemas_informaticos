package ejercicio4;

public class Main {

	public static void main(String[] args) {
		
		// Instancia e Inicialización
		Rectangulo rectangulo = new Rectangulo(10,15);
		
		// LLamada al método
		rectangulo.calcularArea();
		rectangulo.calcularPerimetro();

	}

}
