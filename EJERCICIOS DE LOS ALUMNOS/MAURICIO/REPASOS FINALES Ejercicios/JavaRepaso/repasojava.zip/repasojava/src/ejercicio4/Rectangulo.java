package ejercicio4;

public class Rectangulo {
	
	// Atributos
	private double base;
	private double altura;
	
	// Constructor
	/**
	 * @param base
	 * @param altura
	 */
	public Rectangulo(double base, double altura) {
		// super();
		this.base = base;
		this.altura = altura;
	}
	
	// Métodos
	public void calcularArea() {
		System.out.printf("El area del rectangulo de base: %.2f y altura: %.2f es %.2f%n",
				base, altura, (base*altura));
	}
		
	public void calcularPerimetro() {
		System.out.printf("El perímetro del rectangulo de base: %.2f y altura: %.2f es %.2f%n",
				base, altura, (2*base+2*altura));
	}
	
}
