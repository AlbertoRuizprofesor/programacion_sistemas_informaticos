package ejercicio5;

public class CuentaBancaria {
	
	// Atributos
	private String titular;
	private double saldo;
	
	// Constructor
	/**
	 * @param titular: nombre del cliente
	 * @param saldo: saldo inicial
	 */
	public CuentaBancaria(String titular, double saldo) {
		super();
		this.titular = titular;
		this.saldo = saldo;
	}
	
	// Métodos
	
	public void ingresarDinero(double dinero) {
		if (dinero > 0) {
			saldo += dinero;
			System.out.printf("Los %.2f€ han sido ingresados, en su cuenta señor %s.%n", dinero, titular);
			mostrarSaldo();
		} else {
			System.out.printf("Ingreso no valido señor %s. No hubo cambios en su cuenta.%n", titular);
		}
	}
	public void retirarDinero(double dinero) {
		if (saldo >= dinero) {
			saldo -= dinero;
			System.out.printf("Los %.2f€ han sido retirados de su cuenta señor %s.%n", dinero, titular);
			mostrarSaldo();
		}else {
			System.out.printf("Ingreso no valido señor %s. No hubo cambios en su cuenta.%n", titular);
		}
	}
	public void mostrarSaldo( ) {
		System.out.printf("Señor %s, su saldo actual es: %.2f %n", titular, saldo);

	}

}
