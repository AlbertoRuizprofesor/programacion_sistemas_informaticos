package ejercicio5;

public class Main {
	
	public static void main(String[] args) {
		
		// Instanciamos e Inicializamos
		CuentaBancaria cuenta = new CuentaBancaria("Antonio", 10000);
		
		//Llamanmos a los diferentes metodos
		
		// Ingresar
		cuenta.ingresarDinero(1000);
		// Retirar sin fondos
		cuenta.retirarDinero(20000);
		// Ingesar 30000
		cuenta.ingresarDinero(30000);
		// Retirar 2000
		cuenta.retirarDinero(2000);

		
		
		
	}
	

}
