package ejercicio6;

public class Libro {
    
    // Atributos privados para mantener el encapsulamiento
    private String titulo;
    private String autor;
    private int numPaginas;

    // Constructor para inicializar el objeto
    public Libro(String titulo, String autor, int numPaginas) {
        this.titulo = titulo;
        this.autor = autor;
        this.numPaginas = numPaginas;
    }

    // Método para mostrar la información solicitada
    public void mostrarInformacion() {
        System.out.println("--- Información del Libro ---");
        System.out.println("");
        System.out.printf("Título: %s%n", titulo);
        System.out.printf("Autor: %s%n", autor);
        System.out.printf("Número de páginas: %d%n", numPaginas);
        System.out.println("");
        System.out.println("-----------------------------");
        System.out.println("");
    }
}