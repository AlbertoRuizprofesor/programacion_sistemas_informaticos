package ejercicio6;

public class Main {
    public static void main(String[] args) {
    	
        // Instanciamos y creamos los objetos y sus variables de referencia libro1 y libro2
        Libro libro1 = new Libro("Don Quijote de la Mancha", "Miguel de Cervantes", 1329);
        Libro libro2 = new Libro("Cien años de soledad", "Gabriel García Márquez", 483);

        // Llamamos al método mostrarInformacion() para cada uno
        libro1.mostrarInformacion();
        libro2.mostrarInformacion();
    }
}