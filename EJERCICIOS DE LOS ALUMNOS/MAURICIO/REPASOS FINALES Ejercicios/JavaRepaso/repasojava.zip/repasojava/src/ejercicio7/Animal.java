package ejercicio7;

public class Animal {
    
    // Atributos privados para el encapsulamiento
    private String nombre;
    private String tipo;

    // Constructor
    public Animal(String nombre, String tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
    }

    // Método hacerSonido()
    public void hacerSonido() {
        // Mostramos un mensaje genérico como pide el ejercicio
        System.out.printf("%s que es un %s malo, está again haciendo esos sonidos raros... no te dies de él%n", 
                          nombre, tipo.toLowerCase());
    }
}