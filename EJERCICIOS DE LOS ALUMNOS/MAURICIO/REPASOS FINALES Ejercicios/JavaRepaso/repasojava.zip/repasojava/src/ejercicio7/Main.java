package ejercicio7;

public class Main {
    public static void main(String[] args) {
        // Creamos diferentes instancias de Animal
        Animal animal1 = new Animal("Lolo", "Perro");
        Animal animal2 = new Animal("Michipanero", "Gato");
        Animal animal3 = new Animal("Ovione", "Canguro");
        Animal animal4 = new Animal("Aguliii", "Aguila Americana");
        // Llamamos al método en cada uno
        animal1.hacerSonido();
        animal2.hacerSonido();
        animal3.hacerSonido();
        animal4.hacerSonido();
    }
}