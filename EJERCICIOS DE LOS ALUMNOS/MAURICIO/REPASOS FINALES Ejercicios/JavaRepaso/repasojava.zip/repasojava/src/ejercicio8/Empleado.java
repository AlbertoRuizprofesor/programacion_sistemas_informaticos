package ejercicio8;

public class Empleado {

	// Atributos privados
	private String nombre;
	private double sueldoBase;

	// Constructor
	public Empleado(String nombre, double sueldoBase) {
		this.nombre = nombre;
		this.sueldoBase = sueldoBase;
	}

	// Método para calcular el sueldo anual
	public double calcularSueldoAnual() {
		return sueldoBase * 14;
	}

	// Método para mostrar la información (usando printf para el dinero)
	public void mostrarInformacion() {
		System.out.println("");
		System.out.println("-------------------------------");
		System.out.println("");
		System.out.printf("Empleado: %s%n", nombre);
		System.out.printf("Sueldo Mensual: %.2f€%n", sueldoBase);
		System.out.printf("Sueldo Anual total: %.2f€%n", calcularSueldoAnual());
		System.out.println("");
		System.out.println("-------------------------------");
	}
}