package ejercicio8;

public class Main {
    public static void main(String[] args) {
        // Creamos el objeto empleado
        Empleado actor1 = new Empleado("Lorenzo Lamas", 15000);
        Empleado actor2 = new Empleado("Chus Norris", 30000);
        
        // Llamada al metodo que muestra la informacion de los empleados
        actor1.mostrarInformacion();
        actor2.mostrarInformacion();
        
    }
}