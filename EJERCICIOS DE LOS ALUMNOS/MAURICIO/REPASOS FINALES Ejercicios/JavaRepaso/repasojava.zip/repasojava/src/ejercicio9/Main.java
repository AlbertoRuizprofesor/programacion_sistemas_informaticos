package ejercicio9;

public class Main {
    public static void main(String[] args) {
    	
        // Instanciamos y creamos los productos
        Producto producto1 = new Producto("Teclado IBM", 45.99, 10);
        Producto producto2 = new Producto("Ratón USB", 25.50, 20);
        Producto producto3 = new Producto("Monitor Curvo", 219.99, 5);

        // Mostramos los resultados
        producto1.mostrarProducto();
        producto2.mostrarProducto();
        producto3.mostrarProducto();
    }
}