package ejercicio9;

public class Producto {
    
    // Atributos privates
    private String nombre;
    private double precio;
    private int cantidad;

    // Constructor
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    // Método para calcular el valor total (precio * cantidad) 
    public double calcularValorTotal() {
        return precio * cantidad;
    }

    // Método para mostrar la información
    public void mostrarProducto() {
    		System.out.println("");

        System.out.printf("Producto: %s | Precio: %.2f€ | Stock: %d%n", 
                          nombre, precio, cantidad);
        System.out.printf("Valor total en almacén: %.2f€%n", calcularValorTotal());
		System.out.println("-------------------------------");
		System.out.println("");
    }
}