package Modelo_2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.context.internal.ThreadLocalSessionContext;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.query.Query;

import java.util.List;

public class CrearRegistro {

    public static void main(String[] args) {

        // Configurar la sesión de Hibernate
        SessionFactory sessionFactory = new Configuration()
                .configure()
                .buildSessionFactory();

        // Configurar la sesión en el contexto actual
        ThreadLocalSessionContext context = new ThreadLocalSessionContext((SessionFactoryImplementor) sessionFactory);
        context.bind(sessionFactory.openSession());

        try {
            // Obtener la sesión actual
            Session session = context.currentSession();

            // Iniciar transacción
            session.beginTransaction();

            // Realizar una consulta para obtener los datos antes de la inserción
            String selectHqlBeforeInsert = "FROM Cliente";
            Query<Cliente> selectQueryBeforeInsert = session.createQuery(selectHqlBeforeInsert, Cliente.class);
            List<Cliente> clientesBeforeInsert = selectQueryBeforeInsert.list();

            // Imprimir resultados antes de la inserción
            System.out.println("Registros en la tabla clientes antes de la inserción:");
            for (Cliente c : clientesBeforeInsert) {
                System.out.println(c.toString());
            }

            // Añadir un nuevo registro
            Cliente nuevoCliente = new Cliente();
            nuevoCliente.setNombre("Rosalía");
            nuevoCliente.setCiudad("Málaga"); // Aquí agregamos la ciudad
            // Configura otros atributos según la estructura de tu entidad fabricante

            session.save(nuevoCliente);

            // Realizar una nueva consulta para obtener los datos después de la inserción
            String selectHqlAfterInsert = "FROM Cliente";
            Query<Cliente> selectQueryAfterInsert = session.createQuery(selectHqlAfterInsert, Cliente.class);
            List<Cliente> clientesAfterInsert = selectQueryAfterInsert.list();

            // Imprimir resultados después de la inserción
            System.out.println("Registros en la tabla fabricante después de la inserción:");
            for (Cliente c : clientesAfterInsert) {
                System.out.println(c.toString());
            }

            // Hacer commit de la transacción
            session.getTransaction().commit();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            context.unbind(sessionFactory);
            sessionFactory.close();
        }
    }
}

