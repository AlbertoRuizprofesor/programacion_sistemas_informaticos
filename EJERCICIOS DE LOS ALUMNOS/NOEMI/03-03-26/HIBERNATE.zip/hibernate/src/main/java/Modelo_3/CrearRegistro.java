package Modelo_3;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.context.internal.ThreadLocalSessionContext;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.query.Query;

import java.util.List;

public class CrearRegistro {

    public static void main(String[] args) {

        // Configurar la sesión de Hibernate
        SessionFactory sessionFactory = new Configuration()
                .configure()
                .buildSessionFactory();

        // Configurar la sesión en el contexto actual
        ThreadLocalSessionContext context = new ThreadLocalSessionContext((SessionFactoryImplementor) sessionFactory);
        context.bind(sessionFactory.openSession());

        try {
            // Obtener la sesión actual
            Session session = context.currentSession();

            // Iniciar transacción
            session.beginTransaction();

            // Realizar una consulta para obtener los datos antes de la inserción
            String selectHqlBeforeInsert = "FROM Producto";
            Query<Producto> selectQueryBeforeInsert = session.createQuery(selectHqlBeforeInsert, Producto.class);
            List<Producto> productosBeforeInsert = selectQueryBeforeInsert.list();

            // Imprimir resultados antes de la inserción
            System.out.println("Registros en la tabla productos antes de la inserción:");
            for (Producto p : productosBeforeInsert) {
                System.out.println(p.toString());
            }

            // Añadir un nuevo registro
            Producto nuevoProducto = new Producto();
            nuevoProducto.setNombre("Mouse");
            nuevoProducto.setPrecio(20.90); 
            nuevoProducto.setCodigo_fabricante(12);
            // Configura otros atributos según la estructura de tu entidad fabricante

            session.save(nuevoProducto);

            // Realizar una nueva consulta para obtener los datos después de la inserción
            String selectHqlAfterInsert = "FROM Producto";
            Query<Producto> selectQueryAfterInsert = session.createQuery(selectHqlAfterInsert, Producto.class);
            List<Producto> productosAfterInsert = selectQueryAfterInsert.list();

            // Imprimir resultados después de la inserción
            System.out.println("Registros en la tabla fabricante después de la inserción:");
            for (Producto p : productosAfterInsert) {
                System.out.println(p.toString());
            }

            // Hacer commit de la transacción
            session.getTransaction().commit();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            context.unbind(sessionFactory);
            sessionFactory.close();
        }
    }
}
