package Modelo_4;

import javax.persistence.*;

@Entity
@Table(name = "proveedores")
public class Proveedores {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo")
    private int codigo;

    @Column(name = "nombre")
    private String nombre;

    // Constructor por defecto
    public Proveedores() {}
    

    // Getters y Setters
    public int getCodigo() { return codigo; }
    public void setCodigo(int codigo) { this.codigo = codigo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }


    @Override
    public String toString() {
        return "proveedores{" +
                "codigo=" + codigo +
                ", nombre='" + nombre + '\'' +
          
                '}';
    }
}