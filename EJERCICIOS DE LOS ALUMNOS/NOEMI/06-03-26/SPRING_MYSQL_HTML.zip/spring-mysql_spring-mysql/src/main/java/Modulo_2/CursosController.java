package Modulo_2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/cursos")
public class CursosController {

    @Autowired
    private CursosService cursosService;

    @GetMapping
    public List<Cursos> obtenerTodos() {
        return cursosService.obtenerTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cursos> obtenerPorId(@PathVariable Long id) {
        Cursos curso = cursosService.obtenerPorId(id);
        if (curso == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(curso);
    }

    @PostMapping
    public Cursos guardarCursos(@RequestBody Cursos cursos) {
        return cursosService.guardarCursos(cursos);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarCurso(@PathVariable Long id) {
        cursosService.eliminarCursos(id);
        return ResponseEntity.noContent().build();
    }
}
