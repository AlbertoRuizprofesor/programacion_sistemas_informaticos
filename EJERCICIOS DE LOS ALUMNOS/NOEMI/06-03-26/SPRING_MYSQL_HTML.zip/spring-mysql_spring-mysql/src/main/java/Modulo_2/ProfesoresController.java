package Modulo_2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*") // Permite llamadas desde cualquier origen (frontend)
@RestController
@RequestMapping("/api/profesores") // Ruta base para los endpoints de profesores
public class ProfesoresController {

    @Autowired
    private ProfesoresService profesoresService;

    // Obtener todos los profesores
    @GetMapping
    public List<Profesores> obtenerTodos() {
        return profesoresService.obtenerTodos();
    }

    // Obtener un profesor por ID
    @GetMapping("/{id}")
    public Profesores obtenerPorId(@PathVariable Long id) {
        return profesoresService.obtenerPorId(id);
    }

    // Guardar un nuevo profesor
    @PostMapping
    public Profesores guardarProfesor(@RequestBody Profesores profesor) {
        return profesoresService.guardarProfesor(profesor);
    }

    // Eliminar un profesor por ID
    @DeleteMapping("/{id}")
    public void eliminarProfesor(@PathVariable Long id) {
        profesoresService.eliminarProfesor(id);
    }
}