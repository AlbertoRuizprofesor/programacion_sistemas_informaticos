package ARRAYS;

public class bidimensional {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String [] [] array5= {{"Albert","12"},{"Laura","17"}};
		System.out.println("Array multi");
		
		for (int a=0;a<array5.length;a++) {
			System.out.println("*******");
			for (int b=0;b<array5.length;b++) {
				System.out.println("posicion "+a+b+" "+array5[a][b]);
			}
		}
	}

}
