package ARRAYS;

public class tres_dimensiones {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String [] [] [] array6= {{{"España","Madrid"},{"Italia","Roma"}}
									,{{"China","Beijing"},{"Japon","Tokyo"}}};
		System.out.println("Array multi");
		
		for (int a=0;a<array6.length;a++) {
			System.out.println("*******");
			for (int b=0;b<array6.length;b++) {
				for (int c=0;c<array6.length;c++) {
				System.out.println("posicion "+a+b+c+" "+array6[a][b][c]);
				}

	}

}
}
}