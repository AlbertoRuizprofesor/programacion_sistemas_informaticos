package BUCLES;

public class FIBONACCI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//bucle for
		
		System.out.println("Fibonacci con FOR"); //imprime texto y baja una linea.
		
		int a=0;  //declara la variabla a y le asigna un numero de secuencia,
		int b=1;
		int c=0;
		
		System.out.print(a+" " +b+" ");
		for (int i=3;i<=12;i++) {
			c=a+b;
			System.out.print(c+" ");
			a=b;
			b=c;
		}
		//bucle while
		//Salto de linea
		System.out.println();
		System.out.println("Fibonacci con While");
		int d=0;
		int e=1;
		int f= d+e;
		
		System.out.print(d+" "+e+" ");
		
		while (f<=89) {
			System.out.print(f+" ");
			d=e;
			e=f;
			f=d+e;
		}
		//bucle con do y while
		System.out.println();
		System.out.print("Fibonacci con do/while");
		
		int g=0;
		int h=1;
		int j=g+h;
		
		System.out.println(g+ " "+ h +" ");
		
		do {	
			System.out.print(j+" ");
			g=h;
			h=j;
			j=g+h;
		} while (j<=89);
			
	}
	
}


