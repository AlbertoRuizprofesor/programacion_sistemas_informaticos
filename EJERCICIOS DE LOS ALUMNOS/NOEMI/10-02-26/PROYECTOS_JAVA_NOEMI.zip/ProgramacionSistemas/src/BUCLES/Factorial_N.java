package BUCLES;
import java.util.Scanner;

public class Factorial_N {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner (System.in);
		System.out.println("N (>=o): ");
		int n=c.nextInt();
		
		long fact=1;
		for (int i=2;i<=n;i++) {
			fact*=i;
		}
		
		System.out.println("Factorial="+fact);
		c.close();

	}

}
