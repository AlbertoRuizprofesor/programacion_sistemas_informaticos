package BUCLES;

import java.util.Scanner;

public class Media_5numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		
		double suma=0;
		for (int i=1;i<=5;i++) {
			System.out.print("Numero"+i+": ");
			suma+=c.nextDouble();
		}
		
		System.out.println("Media="+(suma/5));
		
		c.close();

	}

}
