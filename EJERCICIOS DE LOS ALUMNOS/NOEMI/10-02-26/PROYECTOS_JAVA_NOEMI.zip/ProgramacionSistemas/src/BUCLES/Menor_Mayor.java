package BUCLES; //pide varios numeros al usuario y calcula cual es mayor y cual es menor.

import java.util.Scanner;  //permite leer datos que introduce el usuario por teclado

public class Menor_Mayor {

	public static void main(String[] args) {  //todo lo que ejecute estará dentro del MAIN
		Scanner c=new Scanner(System.in); //creamos el objeto para leer numeros
		System.out.println("Cuántos números?: "); //cuantos numeros y los guarda en n
		int n=c.nextInt();
		
		System.out.print("Número 1: "); //leer el primer numero
		int x=c.nextInt();  //ese numero sera mayor y menor para compararlos.
		int mayor=x;
		int menor=x;
		
		//bucle for
		
		for (int i=2;i<=n;i++) {  //empieza en el numero 2, porque el 1 ya se ha leido, sigue hasta n, se repite cada vez por cada numero.
			System.out.print("Número " + i + ": ");
			x = c.nextInt(); //lee cada numero dentro del bucle
			
		//condicional para comparar
			
		 if (x > mayor) mayor = x; 
		 if (x < menor) menor = x;

		}
		
		System.out.println("Mayor: " + mayor);
	    System.out.println("Menor: " + menor);

		
		c.close();
		
		

	}

}
