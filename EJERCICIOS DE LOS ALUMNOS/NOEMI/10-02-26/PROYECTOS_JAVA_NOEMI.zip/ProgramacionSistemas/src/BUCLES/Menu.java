package BUCLES;
import java.util.Scanner;

public class Menu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c = new Scanner(System.in);
		
		boolean codigo=false;
		int opcion;
		
		while (!codigo) {
			System.out.println("Elige una opcion 1 (sumar) 2 (restar) 3 (Salir): ");
			opcion=c.nextInt();
			
				
			switch (opcion) {
			case 1:
				System.out.println("Introduce el primer numero: ");
				int num1=c.nextInt();
				
				System.out.println("Introduce el segundo numero: ");
				int num2=c.nextInt();
				
				System.out.println("Has elegido sumar, el resultado es: "+(num1+num2));
				break;
				
			case 2:
				System.out.println("Introduce el primer numero: ");
				int num3=c.nextInt();
				
				System.out.println("Introduce el segundo numero: ");
				int num4=c.nextInt();
				
				System.out.println("Has elegido restar, el resultado es: "+(num3-num4));
				break;
			case 3:
				System.out.println("Has elegido salir");
				codigo=true;
				break;
			default:
				System.out.println("Error");
				
			}
			
		}
			
			c.close();
			
	}
	

}


