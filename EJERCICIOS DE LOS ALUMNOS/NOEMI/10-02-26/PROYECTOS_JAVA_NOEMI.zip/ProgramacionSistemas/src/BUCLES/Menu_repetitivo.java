package BUCLES;
import java.util.Scanner;

public class Menu_repetitivo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		int op;
		
		do {
			System.out.println("\n1)Saludar");
			System.out.println("2)Mensaje");
			System.out.println("0)Salir");
			System.out.println("Opcion: ");
			op=c.nextInt();
			
			switch (op) {
			case 1 ->System.out.println("!Hola!");
			case 2 ->System.out.println("Sigue practicando bucles.");
			case 0 ->System.out.println("Adios!");
			default ->System.out.println("Opción inválida");
			}
		} while (op!=0);
		
		c.close();

	}

}
