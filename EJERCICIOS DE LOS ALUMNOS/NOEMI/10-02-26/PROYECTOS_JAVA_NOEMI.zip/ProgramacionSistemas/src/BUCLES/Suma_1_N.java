package BUCLES;

import java.util.Scanner;

public class Suma_1_N {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		
		System.out.print("N: ");
		int n=c.nextInt();
		
		int suma=0;
		
		for (int i=1;i<=n;i++) {
			suma+=i;
		}
		System.out.println("Suma= "+suma);
		
		c.close();

	}

}
