package BUCLES;

public class Tabla_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Tabla del 4 (for):");
		for (int i=1;i<=10;i++) {
			System.out.println("4 x "+ i +" = "+(4*i));
		}
		
		//bucle while
		System.out.println();
		System.out.print("Tabla del 4 (while)");
		int a=1;
		while (a<=10) {
			System.out.println(" 4 x "+a+" = "+(4*a));
			a++;
		}
		
		//bucle do y while
		System.out.println();
		System.out.print("Tabla del 4 (do y while)");
		
		int b=1;
		do {
			System.out.println("4 x "+b+" = "+(4*b));
			b++;
		} while (b<=10);
		
	}

}
