package BUCLES;

public class Tabla_del2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
			//Bucle for
		    System.out.print("Tabla del 2 (for)");
			for (int i=1;i<=10;i++) {
				System.out.println("2 x " + i + " = " + (2 * i));
			}
			
			
			//Bucle While
			System.out.println();
			System.out.println("Tabla del 2 (while)");
			int a=1;
			while(a<=10) {
				System.out.println("2 x " + a + " = " + (2 * a));
				a++;
			}
			
			//Bucle do y while
			System.out.println();
			System.out.println("Tabla del 2 (do while)");
			int b=1;
			do {
				System.out.println("2 x " + b + " = " + (2 * b));
				b++;
			} while (b<=10);
			
			
		  }

}


