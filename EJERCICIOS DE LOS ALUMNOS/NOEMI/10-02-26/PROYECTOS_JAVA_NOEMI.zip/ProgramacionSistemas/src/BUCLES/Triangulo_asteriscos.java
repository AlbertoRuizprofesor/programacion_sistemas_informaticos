package BUCLES;
import java.util.Scanner;
public class Triangulo_asteriscos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c = new Scanner(System.in);
	    System.out.print("Altura: ");
	    int h = c.nextInt();

	    for (int i = 1; i <= h; i++) {  //fila
	    	for (int j = 1; j <= i; j++) { //columna //bucle anidado, un bucle dentro de otro
	        System.out.print("*");
	      }
	    	System.out.println(); //baja a la siguiente linea
	    }

	    c.close();
	  }
	}

	