package BUCLES;
import java.util.Scanner;
public class VALIDAR_entrada {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		double nota;
		
		do {
			System.out.print("Nota (0-10): ");
			nota=c.nextDouble();
			} while (nota<0 || nota>10);
	
			System.out.println("Nota válida."+nota);
			c.close();
	}

}
