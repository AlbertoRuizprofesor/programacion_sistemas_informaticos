package BUCLES;

import java.util.Scanner;

public class adivina_numero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		final int secreto=7;
		
		int intentos=0;
		int x;
		
		//bucle do y while
		do {
			System.out.println("Adivina el numero secreto (1-10): ");
			x=c.nextInt();
			intentos++;
			
	    //condicionales
		if (x<secreto) System.out.println("Más alto");
		else if (x>secreto) System.out.println("Más bajo");
	}   while (x!=secreto);  //Haz esto al menos una vez y repite mientras x sea diferente del número secreto”
		
		System.out.println("¡Correcto! numero de intentos: "+intentos); //Esto se ejecuta solo cuando x == secreto, es decir, cuando adivinaste
		c.close();
	}

}
