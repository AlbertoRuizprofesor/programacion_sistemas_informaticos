package BUCLES;

public class bucles_Pruebas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	//Bucle for
	for (int i=1;i<5;i++) {
		System.out.println(i);
	}
	
	//Bucle While
	System.out.println();
	System.out.println("i");
	int a=1;
	while(a<5) {
		a++;
		System.out.println(a);
	}
	
	//Bucle do y while
	System.out.println();
	System.out.println("do while");
	int b=1;
	do {
		System.out.println(b);
		b++;
	} while (b<5);
	
	
  }

}
