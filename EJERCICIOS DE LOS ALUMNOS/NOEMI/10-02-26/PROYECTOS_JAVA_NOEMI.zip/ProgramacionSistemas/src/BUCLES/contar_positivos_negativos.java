package BUCLES;

import java.util.Scanner;

public class contar_positivos_negativos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		System.out.println("Cuántos números?: ");
		int n=c.nextInt();
		
		int pos=0, neg=0, cero=0;
		
		//bucle
		for (int i=1;i<=n;i++) {
			System.out.println("Número "+i+": ");
			int x=c.nextInt();
			if (x>0) pos++;
			else if (x<0) neg++;
			else cero++;
				}
		System.out.println("Positivos: " + pos);
	    System.out.println("Negativos: " + neg);
	    System.out.println("Ceros: " + cero);
	    c.close();

	}

}
