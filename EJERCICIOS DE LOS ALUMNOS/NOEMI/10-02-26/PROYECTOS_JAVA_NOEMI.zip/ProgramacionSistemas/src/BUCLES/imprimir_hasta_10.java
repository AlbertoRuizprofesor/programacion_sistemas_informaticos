package BUCLES;

public class imprimir_hasta_10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for (int i=1; i<=10; i++) {
			System.out.println(i);
		}

	}

}
