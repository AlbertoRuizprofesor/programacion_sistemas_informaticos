package BUCLES;
import java.util.Scanner;

public class multiplos_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
	    System.out.print("N: ");
	    int n=c.nextInt();
	    
	    //creamos una variable contador
	    int contador=0;
	    //creamos un bucle for que recorra los numeros
	    for (int i=1;i<=n;i++) {
	    //creamos una condicional que decimos los multiplos de 3:
	    if (i % 3==0) contador++;
	}
	
		System.out.println("Múltiplos de 3: "+contador);
		c.close();
}
}

