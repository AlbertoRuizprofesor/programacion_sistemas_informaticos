package BUCLES;
import java.util.Scanner;

public class suma_pares_impares {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		System.out.println("Número: ");
		int n=c.nextInt();
		
		int sumapares=0, sumaImpares=0;
		
		for(int i=1;i<=n;i++);
		
		
		

	}

}
