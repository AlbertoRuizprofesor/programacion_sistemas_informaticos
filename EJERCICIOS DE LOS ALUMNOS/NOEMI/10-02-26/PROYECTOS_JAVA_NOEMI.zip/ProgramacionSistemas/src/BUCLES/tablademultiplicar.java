package BUCLES;
import java.util.Scanner;
public class tablademultiplicar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner (System.in);
		System.out.println("Tabla de multiplicar.");
		System.out.println("Introduce el número que quiere multiplicar: ");
		int n=c.nextInt();
		
		for (int i=1;i<=10;i++) {
			System.out.println(n +" x "+i+" = "+(n*i));
		}
		c.close();

	}

}
