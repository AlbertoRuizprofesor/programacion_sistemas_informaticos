package METODOS_DIFERENTES_MANERAS;

public class EDAD {
	public void diferencia_edad (int x) {
		if (x>=18) {
			System.out.println("Es mayor de edad");
		}else {
			System.out.println("Es  menor de edad");
		}
	}

}
