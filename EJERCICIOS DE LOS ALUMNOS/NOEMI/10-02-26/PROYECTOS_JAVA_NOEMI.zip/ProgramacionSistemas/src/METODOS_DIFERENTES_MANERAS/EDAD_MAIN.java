package METODOS_DIFERENTES_MANERAS;


import java.util.Scanner;

public class EDAD_MAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		EDAD e=new EDAD();
		
		System.out.println("Introduce edad: ");
		int d=c.nextInt();
				
		e.diferencia_edad(d);
		

	}

}
