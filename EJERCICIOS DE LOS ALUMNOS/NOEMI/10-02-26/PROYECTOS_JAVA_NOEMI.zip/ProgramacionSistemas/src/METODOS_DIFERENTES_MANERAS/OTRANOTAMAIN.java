package METODOS_DIFERENTES_MANERAS;

import METODO_CON_ARRAYS.OTRANOTA;

public class OTRANOTAMAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OTRANOTA n=new OTRANOTA();
		
		int [] nota=n.pedirDatos();
		n.calculo_notas(nota);
		
		

	}

}
