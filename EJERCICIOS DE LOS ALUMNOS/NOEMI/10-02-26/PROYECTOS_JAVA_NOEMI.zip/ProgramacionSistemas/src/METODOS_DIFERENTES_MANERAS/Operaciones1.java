package METODOS_DIFERENTES_MANERAS;

public class Operaciones1 { 
	public int sumar(int a,int b) {
		return a+b;
	}
	public int restar(int a,int b) {
		return a-b;
	}
	public int mult(int a,int b) {
		return a*b;
	}
	public double div(int a,int b) {
		return a/b;
	}
	public void operaciones(int a, int b) {  //CREAMOS UN VOID QUE META TODO Y ASI SOLO LO LLAMAMOS EN EL MAIN
		int suma=sumar(a,b);
		int resta=restar(a,b);   //esto no se hace es codigo espagetis
		int multi=mult(a,b);
		double divi=div(a,b);
		 
		System.out.println("La suma es "+suma);
		System.out.println("La resta es "+resta);
		System.out.println("La multiplicacion es "+multi);
		System.out.println("La division es "+divi);
	}

}
