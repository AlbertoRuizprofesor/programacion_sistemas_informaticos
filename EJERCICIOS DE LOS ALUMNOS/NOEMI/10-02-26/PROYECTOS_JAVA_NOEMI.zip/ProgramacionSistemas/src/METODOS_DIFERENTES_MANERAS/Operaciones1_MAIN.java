package METODOS_DIFERENTES_MANERAS;

public class Operaciones1_MAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Operaciones1 op=new Operaciones1();
		op.operaciones(5, 7);

	}

}
