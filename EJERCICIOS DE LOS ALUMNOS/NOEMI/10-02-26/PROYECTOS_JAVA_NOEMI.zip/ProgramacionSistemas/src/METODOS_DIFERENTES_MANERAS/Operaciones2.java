package METODOS_DIFERENTES_MANERAS;

import Metodo.Operaciones;

public class Operaciones2 { //esta no se debe hacer nunca

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=34;
		int num2=67;
		
		Operaciones operaciones=new Operaciones();
		
		int sumatorio=operaciones.sumar(num1,num2); //AQUI SE HACE EN DOS LINEAS
		System.out.println("La suma es "+sumatorio);
		
		//operaciones.sumar(num1, num2); //AQUI SE HACE EN UNA SOLA LINEA 
	}

}
