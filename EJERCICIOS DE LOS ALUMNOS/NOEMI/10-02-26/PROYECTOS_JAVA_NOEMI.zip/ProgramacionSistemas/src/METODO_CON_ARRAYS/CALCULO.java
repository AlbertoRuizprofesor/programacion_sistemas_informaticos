package METODO_CON_ARRAYS;

import java.util.Scanner;

public class CALCULO {
	public int[] pedirDatos() {
    Scanner c=new Scanner(System.in);
    int [] numero=new int[2];

    for (int i=0;i<numero.length;i++) {
	    System.out.print("Dime el importe "+(i+1)+" : ");
	    numero[i]=c.nextInt();
}
    
    return numero;

}
	public void calculo_importe(int [] importe) {
		int suma=0;
		for (int i=0;i<importe.length;i++){
			suma+=importe[i];
		}
		double iva=suma*0.21;
		double total=suma+iva;
		
		System.out.println("\nResultados: ");
		System.out.println("Suma de importes: "+suma+"€");
		System.out.printf("IVA (21%%): %.2f€\n",iva);
		System.out.printf("Total con IVA: %.2f€\n",total);
	}
}