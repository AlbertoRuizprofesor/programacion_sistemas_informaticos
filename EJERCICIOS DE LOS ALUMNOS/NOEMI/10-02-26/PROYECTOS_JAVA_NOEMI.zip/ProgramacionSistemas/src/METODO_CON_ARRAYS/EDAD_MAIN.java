package METODO_CON_ARRAYS;

public class EDAD_MAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EDAD e=new EDAD();
		
		int [] edades=e.pedirDatos();
		e.calcular_edades(edades);

	}

}
