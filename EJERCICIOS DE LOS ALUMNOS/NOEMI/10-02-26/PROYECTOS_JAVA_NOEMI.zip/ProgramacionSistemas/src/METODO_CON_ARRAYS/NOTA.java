package METODO_CON_ARRAYS;

import java.util.Scanner;

public class NOTA {
	//Método que pide notas, calcula media y muestra resultados
	public void CalcularMedia() {
		Scanner c=new Scanner(System.in);
		
		//array de asignatura
		String [] asignaturas= {"Programaciom","Base de datos","Sistemas informáticos"};
		double [] notas=new double[asignaturas.length];
		
		//pedir notas
		for (int i=0;i<asignaturas.length;i++) {
			System.out.println("Introduce la nota de "+asignaturas[i]+" : ");
			notas[i]=c.nextDouble();
			
		}
		//calcular media
		double suma=0;
		for (double nota :notas) {
			suma+=nota; //sumamos todas las notas
		}
		double media=suma/notas.length;
		//mostrar todas las notas y la media
		System.out.println("\nResultados");
		for (int i=0;i<asignaturas.length;i++) {
			System.out.printf("%s: %.2f\n", asignaturas[i], notas[i]);
		}
			System.out.printf("Media: %.2f\n",media);
			c.close();
		}
		
	}
	
	
	

