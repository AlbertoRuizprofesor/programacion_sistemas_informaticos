package METODO_CON_ARRAYS;

public class NOTASMAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		NOTA n=new NOTA();
		
		n.CalcularMedia();

	}

}
