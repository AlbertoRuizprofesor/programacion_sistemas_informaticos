package METODO_CON_ARRAYS;
import java.util.Scanner;

public class NOTA_DIFERENTE {
    
    public int[] pedirDatos() {  //para que un return te devuelva mas de un valor hay que crear un array
     	Scanner c=new Scanner(System.in);
     	
     	//arrays asignautas y notas
     	
     	String[] asignaturas= {"Programacion","Entorno de desarrollo","Sistemas","Ciberseguridad","Graficos"};
     	int [] numero=new int[5];
     	
     	//pedir notas al usuario
     	
     	for (int i=0; i<numero.length;i++) {
     		System.out.println("Introduce la nota "+(i+1)+" : ");
     		numero[i]=c.nextInt();	
     	}
     	
     	//calcular media
     	double suma=0;
     	for (int nota : numero) {
     		suma+=nota;
     	}
     	double media=suma/numero.length;
     	
     	//mostrar resultados
     	System.out.println("\nResultados");
     	for (int i=0;i<numero.length;i++) {
     		System.out.printf("%s: %d\n", asignaturas[i], numero[i]);
     	}
     	System.out.printf("Media: %.2f\n", media);
     	
     	c.close();
     	return numero;
    }
    
}
   
	

