package METODO_CON_ARRAYS;

public class NOTA_DIFERENTE_MAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NOTA_DIFERENTE n=new NOTA_DIFERENTE();
		int [] nota=n.pedirDatos();
		
		for (int i=0;i<nota.length;i++) {
			System.out.println("Nota "+(i+1)+" : "+nota[i]);
		}
		
		

	}

}
