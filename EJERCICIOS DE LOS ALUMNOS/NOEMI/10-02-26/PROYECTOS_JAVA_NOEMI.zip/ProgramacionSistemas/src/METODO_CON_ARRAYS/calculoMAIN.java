package METODO_CON_ARRAYS;

public class calculoMAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CALCULO cal=new CALCULO();
		
		int [] importar=cal.pedirDatos();
		cal.calculo_importe(importar);

	}

}
