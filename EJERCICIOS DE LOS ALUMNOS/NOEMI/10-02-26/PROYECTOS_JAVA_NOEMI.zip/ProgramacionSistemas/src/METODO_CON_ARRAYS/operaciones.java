package METODO_CON_ARRAYS;
import java.util.Scanner;

public class operaciones {  // siempre mayúscula para clases
	public int sumar(int a, int b) {
		return a+b;	
	}
	
	public int restar(int a, int b) {
		return a-b;
	}

	public int multiplicacion(int a, int b) {
		return a*b;
	}

	public double division(int a,int b) {
		return a/b;
	}
	public int multiplo(int a,int b) {
		return (a*b*b);
	}
	public int modulo(int a,int b) {
		return a%b;
	}


    // Método que devuelve varias operaciones en un array
    public void lista_Operaciones(int a, int b) {
        double[] op={sumar(a,b),restar(a,b),multiplicacion(a,b),division(a,b),multiplo(a,b),modulo(a,b)}; //dos arrays , uno para operaciones y otro para el texto de la operacion
        String [] nombre_opera= {"Suma","Resta","Multiplicacion","Dividir","Multiplo","Módulo"}; //Esto es texto

       
        
        int i=0;
        for (double numer:op) {
        	
        
        	System.out.println(" la operacion de "+nombre_opera[i]+" es: "+numer);
        	i++;
        }
    }
        
       public int[] pedirDatos() {  //para que un return te devuelva mas de un valor hay que crear un array
        	Scanner c=new Scanner(System.in);
        	int [] numero=new int[2];
        	
        	for (int i=0; i<numero.length;i++) {
        		System.out.println("Introduce el numero "+(i+1)+" : ");
        		numero[i]=c.nextInt();	
        	}
        	c.close();
        	return numero;
       }
       
   }
        	
       
        	

  