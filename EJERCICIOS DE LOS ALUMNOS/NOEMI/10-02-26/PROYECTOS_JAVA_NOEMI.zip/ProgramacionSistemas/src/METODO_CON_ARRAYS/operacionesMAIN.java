package METODO_CON_ARRAYS;

public class operacionesMAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		operaciones o=new operaciones();
		
		int [] numero=o.pedirDatos();
		o.lista_Operaciones(numero[0],numero[1]);
		

	}

}
