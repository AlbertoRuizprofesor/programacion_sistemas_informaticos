package Metodo;

public class Calculadora {    // AQUI CREAMOS EL CALCULO PARA POSTERIORMENTE LLAMARLO EN UN MAIN

	public static int sumar(int numero1, int numero2) {
		return numero1+numero2;

	}
	public static int restar(int numero1, int numero2) {
		return numero1-numero2;
	}
	public static int multiplicar(int numero1, int numero2) {
		return numero1*numero2;
	}
	public static int dividir(int numero1, int numero2) {
		return numero1/numero2;
	}
	
	public void mostrar(int numero1, int numero2) {

	}
	
	  public static void resultado(int total) {
	        System.out.println("El resultado es " + total);
	    }

	    public static void main(String[] args) {

	        int numero1 = 2;
	        int numero2 = 8;

	        int total = sumar(numero1, numero2);
	        resultado(total);
	    }
	}
	