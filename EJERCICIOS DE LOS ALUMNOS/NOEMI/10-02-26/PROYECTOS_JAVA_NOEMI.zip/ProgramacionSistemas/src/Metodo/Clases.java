package Metodo;

public class Clases {   //NOMBRE DE LA CLASE 
	int numero=0;    //VARIABLE DE CLASE (ES GLOBLAR)
	
	public static int sumar(int numero1) {  //METODO 
		return numero1+10;                  //NECESITA RETURN PARA DEVOLVER EL CALCULO
		
	}
	public static void saludar(String nombre) {   //METODO
		System.out.println("Hola " +nombre);   //AL SER VOID NO DEVUELVE NADA, NECESITA EL PRINT
	}

	public static void main(String[] args) {    //METODO
		// TODO Auto-generated method stub
		int numero1=12;                       //DECLARA LA VARIABLE Y LA LLAMA
		System.out.println(sumar(numero1));
		saludar("Alberto");
	}
}
