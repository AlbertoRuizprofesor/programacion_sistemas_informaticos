package Metodo;
import java.util.Scanner;

public class EDAD {
	
	
	
	public int pedirEdad() {
		Scanner c=new Scanner(System.in);
		System.out.print("Introduce tu edad: ");
		int edad = c.nextInt(); 
		return edad;
	
	}
	 public void calcularNacimiento(int edad) {
	        int anioActual = 2026;
	        int anioNacimiento = anioActual - edad;
	        System.out.println("Naciste en: " + anioNacimiento);

	    }
	}
