package Metodo;

public class HORAS {
	
	//atributos
	
	public int dias=30, horas=24, minutos=60;
	
	public int Calcularhoras() {
		int horas=dias*24;
		return horas;
	}
	public int Calularminutos() {
		int minutos=dias*horas*60;    
		return minutos;
	}
		public int Calularsegundos() {
			int segundos= dias * horas*minutos*minutos;   //horas*60 tambien
			return segundos;
	}
	public void resultados() {
		System.out.println("Número de horas en 30 días: "+Calcularhoras()+" horas");
		System.out.println("Número de minutos en 30 días: "+Calularminutos()+" minutos");
		System.out.println("Número de segundos en 30 días: "+Calularsegundos()+" segundos");
	}
	
	
}
