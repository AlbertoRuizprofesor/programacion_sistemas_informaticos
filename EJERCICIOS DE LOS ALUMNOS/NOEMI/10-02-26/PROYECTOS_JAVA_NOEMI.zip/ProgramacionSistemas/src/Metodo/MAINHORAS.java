package Metodo;

public class MAINHORAS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HORAS h=new HORAS();
		h.resultados();

	}

}
