package Metodo;

public class MainCalculadora {   

	public static void main(String[] args) {   //desde las clases se pueden realizar los metodos
		// TODO Auto-generated method stub
		
		Calculadora cal1=new Calculadora();  //ES UN OBJETO
		 int suma = cal1.sumar(6, 5);    //METODOS
	     int resta = cal1.restar(4, 7);
	     int multi = cal1.multiplicar(5, 5);
	     int div = cal1.dividir(10, 2);
		
		System.out.println("La suma es :"+ suma);
		System.out.println("Resta: " + resta);
        System.out.println("Multiplicación: " + multi);
        System.out.println("División: " + div);
        
        cal1.resultado(multi);  //se puede llmar asi tambien a al funcion
        
	}
}
