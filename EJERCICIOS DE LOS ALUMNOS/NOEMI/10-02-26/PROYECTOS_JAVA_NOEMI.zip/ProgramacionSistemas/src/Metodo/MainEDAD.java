package Metodo;

public class MainEDAD {

	public static void main(String[] args) {
		// crear el objeto
		EDAD e=new EDAD();
		
		//llamar al metodo que pide la edad
		int edad=e.pedirEdad();
		
		//llamar al metodo que calcula el año de nacimiento
		e.calcularNacimiento(edad);
	}

}
