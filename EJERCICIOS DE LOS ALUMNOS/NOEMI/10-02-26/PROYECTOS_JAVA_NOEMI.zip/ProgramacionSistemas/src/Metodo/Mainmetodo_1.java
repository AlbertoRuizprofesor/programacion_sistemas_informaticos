package Metodo;

public class Mainmetodo_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numero=100;
		metodo_1 met1=new metodo_1();
		met1.saludarte(" doki doki");
		
		double iva=met1.iva(100);
		
		System.out.println("El iva es: "+iva);
		
		met1.total(numero, iva);

	}

}
