package Metodo;
import java.util.Scanner;

public class Numero_primoConfuncionesMAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		
		System.out.println("Introduce un número entero positivo: ");
		int n= Integer.parseInt(c.nextLine());
		
		Numero_primoConfuncion p=new Numero_primoConfuncion();
		
		if (p.esPrimo(n)==true) {
			System.out.println("El "+n+" es primo.");
		} else {
			System.out.println("El "+n+" no es primo");
		}

	}

}
