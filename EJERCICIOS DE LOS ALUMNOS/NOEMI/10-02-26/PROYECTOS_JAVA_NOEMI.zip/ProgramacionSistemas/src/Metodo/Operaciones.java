package Metodo;

public class Operaciones {
	
	public int sumar(int numero1, int numero2) {
		return numero1+numero2;   //AQUI ME DEVUELVE ESTA OPERACION PERO PARA MOSTRAR POR PANTALLA NECESITO UN SISTEMA PRINT DENTRO DE LA CLASE DONDE USO EL MAIN
	}
	                            //para usar en diferentes lugares, para sumar en varios sitios, para hacer otros tipos de operaciones.
	//Se puede modificar y utilizar en varias clases, es variable y esta en memoria.
	public void resta(int numero1, int numero2) {
		System.out.println("La resta es: "+(numero1-numero2)); //AQUI ME MUESTRA EN LA PANTALLA, PERO DESDE EL OBJETO NO PODRE MODIIFCAR LA RESTA
	}                                                          //para mostrar cosas directamente, sql etc
                              //el void no esta en memoria y no se puede modificar.
	public void operaciones(int numero1,int numero2) {
		int suma=(numero1+numero2);
	System.out.println("La suma es "+suma);
	System.out.println("La resta es "+(numero1-numero2));
	}
}