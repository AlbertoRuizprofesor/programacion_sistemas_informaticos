package Metodo;

public class OperacionesMAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub //asi no se hace tampoco
		int numero1=10;
		int numero2=5;
		Operaciones oper=new Operaciones();
		
		//int suma=oper.sumar(numero1, numero2)  ESTA MAL ESTA PARTE
		//System.out.println("La suma es " +suma);
		
		oper.operaciones(numero1, numero2);

	}
	}


