package Metodo;
import java.util.Scanner;

public class metodo_1 {

	//metodos hay que instanciar la clase
	public void saludarte(String nombre) {
		System.out.println("Hola"+nombre);

	}
	public double iva(int importe) {
		return(importe*0.21);
	}
	public void total(int importe, double iva) { 
	//dentro del total hay tanto importe como iva
		System.out.println("El total es: "+(importe+iva));
	}
}
