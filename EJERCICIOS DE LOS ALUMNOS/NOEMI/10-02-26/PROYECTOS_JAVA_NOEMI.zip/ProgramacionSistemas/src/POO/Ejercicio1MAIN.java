package POO;

public class Ejercicio1MAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ejercicio1 ej=new Ejercicio1("Noemi","González");
		System.out.println(ej.toString());
		
		Ejercicio1 ej2=new Ejercicio1("Jose","Ahmad");
		System.out.println(ej2.toString());
	}

}
