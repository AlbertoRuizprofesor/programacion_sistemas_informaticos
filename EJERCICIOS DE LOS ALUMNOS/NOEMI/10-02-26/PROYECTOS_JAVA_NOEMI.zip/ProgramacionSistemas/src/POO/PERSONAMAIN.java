package POO;

public class PERSONAMAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PERSONA per=new PERSONA("Noemi","Gonzalez",28);
		Alumno al=new Alumno("Nubia","Montesinos",20,"Primero","Sistemas");
		profesor p=new profesor("Alberto","Ruiz",40,"Programacion",3000);
		
		System.out.println(per.toString());
		System.out.println(al.toString());
		System.out.println(p.toString());
	}
}
		

	