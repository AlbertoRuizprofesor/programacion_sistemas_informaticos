package POO.VEHICULO;

public class camion extends vehiculo {
	private int carga;
	private String herramienta;
	public camion(String modelo, String motor, String ruedas, double precio, int carga, String herramienta) {
		super(modelo, motor, ruedas, precio);
		this.carga = carga;
		this.herramienta = herramienta;
	
	}
	public int getCarga() {
		return carga;
	}
	public void setCarga(int carga) {
		this.carga = carga;
	}
	public String getHerramienta() {
		return herramienta;
	}
	public void setHerramienta(String herramienta) {
		this.herramienta = herramienta;
	}
	@Override
	public void acelerar() {
		System.out.println("acelera camion");
	}
	@Override
	public void frenar() {
		System.out.println("Frenando el camion");
	}
	@Override
	public String toString() {
		return "camion [carga=" + carga + ", herramienta=" + herramienta + "]";
	}

}
