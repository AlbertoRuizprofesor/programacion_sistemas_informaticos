package POO.VEHICULO;

public class coche extends vehiculo {
	private String color;
	private double altura;
	public coche(String modelo, String motor, String ruedas, double precio, String color, double altura) {
		super(modelo, motor, ruedas, precio);
		this.color=color;
		this.altura=altura;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public double getAltura() {
		return altura;
	}
	public void setAltura(double altura) {
		this.altura = altura;
	}
	
    @Override
	public void acelerar() {
		System.out.println("El coche acelera...!");
    }
	@Override
	public void frenar() {
		System.out.println("El coche frena de golpe");
	}

	
	@Override
	public String toString() {
		return "coche [color=" + color + ", altura=" + altura + ", getColor()=" + getColor() + ", getAltura()="
				+ getAltura() + ", getModelo()=" + getModelo() + ", getMotor()=" + getMotor() + ", getRuedas()="
				+ getRuedas() + ", getPrecio()=" + getPrecio() + ", toString()=" + super.toString() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + "]";
	}

}
