package POO.VEHICULO;

public class moto extends vehiculo {
	private String seguridad;
	private String velocidad;
	public moto(String modelo, String motor, String ruedas, double precio, String seguridad, String velocidad) {
		super(modelo, motor, ruedas, precio);
		this.seguridad = seguridad;
		this.velocidad = velocidad;
	}
	public String getSeguridad() {
		return seguridad;
	}
	public void setSeguridad(String seguridad) {
		this.seguridad = seguridad;
	}
	public String getVelocidad() {
		return velocidad;
	}
	public void setVelocidad(String velocidad) {
		this.velocidad = velocidad;
	}
	
@Override
	public void acelerar() {
		System.out.println("La moto acelera muuucho!");
	}
	@Override
	public void frenar() {
		System.out.println("Freeena, frenando la mooto");
	}

	@Override
	public String toString() {
		return "moto [seguridad=" + seguridad + ", velocidad=" + velocidad + ", getSeguridad()=" + getSeguridad()
				+ ", getVelocidad()=" + getVelocidad() + ", getModelo()=" + getModelo() + ", getMotor()=" + getMotor()
				+ ", getRuedas()=" + getRuedas() + ", getPrecio()=" + getPrecio() + ", toString()=" + super.toString()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}
}