package POO.VEHICULO;

public class vehiculo {
	private String modelo;
	private String motor;
	private String ruedas;
	private double precio;
	public vehiculo(String modelo, String motor, String ruedas, double precio) {
		
		this.modelo = modelo;
		this.motor = motor;
		this.ruedas = ruedas;
		this.precio = precio;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getMotor() {
		return motor;
	}
	public void setMotor(String motor) {
		this.motor = motor;
	}
	public String getRuedas() {
		return ruedas;
	}
	public void setRuedas(String ruedas) {
		this.ruedas = ruedas;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
		
	}
	public void acelerar() {
		System.out.println("Está acelerando");
	}
	public void frenar() {
		System.out.println("Está frenando");
    }

	@Override
	public String toString() {
		return "vehiculo [modelo=" + modelo + ", motor=" + motor + ", ruedas=" + ruedas + ", precio=" + precio
				+ ", getModelo()=" + getModelo() + ", getMotor()=" + getMotor() + ", getRuedas()=" + getRuedas()
				+ ", getPrecio()=" + getPrecio() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
	

}
