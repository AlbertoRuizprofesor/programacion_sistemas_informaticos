package POO.VEHICULO;

public class vehiculoMAIN {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		vehiculo v=new vehiculo("MarcoPolo","sisik","cassio",1500);
		coche c=new coche("OperCorsa","sisika","naya",12000,"negro metalizado",1);
		moto m=new moto("SUZUKY","sayko","naam",7000,"abs","muy rapida");
		camion ca=new camion("FORD","saka","tyeudj",20000,50,"MARTILLO");
		
		System.out.println(v.toString());
		System.out.println(c.toString());
		System.out.println(m.toString());
		System.out.println(ca.toString());
		v.acelerar();
		v.frenar();
		c.acelerar();
		c.frenar();
		m.acelerar();
		m.frenar();
		ca.acelerar();
		ca.frenar();

	}

}
