package POO;

public class profesor extends PERSONA{
	private String asignatura;
	private double salario;
	public profesor(String nombre, String apellidos, int edad, String asignatura, double salario) {
		super(nombre, apellidos, edad);
		this.asignatura=asignatura;
		this.salario=salario;
		// TODO Auto-generated constructor stub
	}
	public String getAsignatura() {
		return asignatura;
	}
	public void setAsignatura(String asignatura) {
		this.asignatura = asignatura;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	@Override
	public String toString() {
		return "profesor [asignatura=" + asignatura + ", salario=" + salario + "]";
	}
	

}
