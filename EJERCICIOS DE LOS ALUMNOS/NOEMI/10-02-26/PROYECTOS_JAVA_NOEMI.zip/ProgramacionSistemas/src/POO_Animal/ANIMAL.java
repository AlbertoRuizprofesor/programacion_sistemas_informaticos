package POO_Animal;

public class ANIMAL {
	private String carnivoro;
	private String herviboro;
	private String omnivoro;
	public ANIMAL(String carnivoro, String herviboro, String omnivoro) {
		
		this.carnivoro = carnivoro;
		this.herviboro = herviboro;
		this.omnivoro = omnivoro;
	}
	public String getCarnivoro() {
		return carnivoro;
	}
	public void setCarnivoro(String carnivoro) {
		this.carnivoro = carnivoro;
	}
	public String getHerviboro() {
		return herviboro;
	}
	public void setHerviboro(String herviboro) {
		this.herviboro = herviboro;
	}
	public String getOmnivoro() {
		return omnivoro;
	}
	public void setOmnivoro(String omnivoro) {
		this.omnivoro = omnivoro;
	}
	public void alimentacion() {
		System.out.println("ALIMENTACION: CEBRA,CONEJO");
	}
	@Override
	public String toString() {
		return "ANIMAL [carnivoro=" + carnivoro + ", herviboro=" + herviboro + ", omnivoro=" + omnivoro + "]";
	}
}