package POO_Animal;

public class ANIMAL_MAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ANIMAL A=new ANIMAL("Tigre carnivoro","NO","SI");
		mamifero m=new mamifero("Delfin","SI","SI","SI","NO");
		AVE av=new AVE("Aguila","SI","SI","SI","NO");
		
		System.out.println(A.toString());
		System.out.println(m.toString());
		System.out.println(av.toString());
		A.alimentacion();
		m.alimentacion();
		av.alimentacion();

	}

}
