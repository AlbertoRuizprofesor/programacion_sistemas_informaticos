package POO_Animal;

public class AVE extends ANIMAL{
	private String rapaz;
	private String rapiña;
	public AVE(String carnivoro, String herviboro, String omnivoro, String rapaz, String rapiña) {
		super(carnivoro, herviboro, omnivoro);
		this.rapaz = rapaz;
		this.rapiña = rapiña;
	}
	public String getRapaz() {
		return rapaz;
	}
	public void setRapaz(String rapaz) {
		this.rapaz = rapaz;
	}
	public String getRapiña() {
		return rapiña;
	}
	public void setRapiña(String rapiña) {
		this.rapiña = rapiña;
	}
	@Override
	public void alimentacion() {
		System.out.println("Cazadores de ratones");
	}
	@Override
	public String toString() {
		return "AVE [rapaz=" + rapaz + ", rapiña=" + rapiña + "]";
	}
	
}
	
		