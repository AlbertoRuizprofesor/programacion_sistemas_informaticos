package POO_Animal;

public class mamifero extends ANIMAL{
	private String acuatico;
	private String terrestre;
	public mamifero(String carnivoro, String herviboro, String omnivoro, String acuatico, String terrestre) {
		super(carnivoro, herviboro, omnivoro);
		this.acuatico = acuatico;
		this.terrestre = terrestre;
	}
	public String getAcuatico() {
		return acuatico;
	}
	public void setAcuatico(String acuatico) {
		this.acuatico = acuatico;
	}
	public String getTerrestre() {
		return terrestre;
	}
	public void setTerrestre(String terrestre) {
		this.terrestre = terrestre;
	}
	@Override
	public void alimentacion() {
		System.out.println("COMEN DE TODO LO QUE HAY EN EL MAR");
	}
	@Override
	public String toString() {
		return "mamifero [acuatico=" + acuatico + ", terrestre=" + terrestre + "]";
	}
}
