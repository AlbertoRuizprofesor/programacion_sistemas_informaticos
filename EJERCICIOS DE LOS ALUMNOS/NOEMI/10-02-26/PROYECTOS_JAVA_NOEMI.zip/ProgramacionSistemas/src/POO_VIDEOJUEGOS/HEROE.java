package POO_VIDEOJUEGOS;

public class HEROE {
	private String energia;
	private String vida;
	public HEROE(String energia, String vida) {
		this.energia = energia;
		this.vida = vida;
	}
	public String getEnergia() {
		return energia;
	}
	public void setEnergia(String energia) {
		this.energia = energia;
	}
	public String getVida() {
		return vida;
	}
	public void setVida(String vida) {
		this.vida = vida;
	}
	public void fuerza() {
		System.out.println("Fuerza insuperable");
	}
	@Override
	public String toString() {
		return "HEROE [energia=" + energia + ", vida=" + vida + "]";
	}
	

}
