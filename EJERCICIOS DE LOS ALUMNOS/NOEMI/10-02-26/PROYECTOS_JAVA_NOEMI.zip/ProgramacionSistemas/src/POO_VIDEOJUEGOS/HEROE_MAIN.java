package POO_VIDEOJUEGOS;

public class HEROE_MAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HEROE h=new HEROE("MAXIMA ENERGIA","❤❤❤❤❤❤❤");
		guerrero g=new guerrero("Guerrero del castillo energia maxima","❤❤❤❤","resistente","Armas de piedra");
		princesa p=new princesa("Princesa Energía 90%","❤❤❤❤❤","Alta alcurnia","linaje de nobleza");
		
		System.out.println(h.toString());
		System.out.println(g.toString());
		System.out.println(p.toString());
		h.fuerza();
		g.fuerza();
		p.fuerza();

	}

}
