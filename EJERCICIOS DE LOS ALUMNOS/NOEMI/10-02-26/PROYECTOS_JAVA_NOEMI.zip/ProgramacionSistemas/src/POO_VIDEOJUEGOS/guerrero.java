package POO_VIDEOJUEGOS;

public class guerrero extends HEROE{
	private String armadura;
	private String armas;
	public guerrero(String energia, String vida, String armadura, String armas) {
		super(energia, vida);
		this.armadura = armadura;
		this.armas = armas;
	}
	public String getArmadura() {
		return armadura;
	}
	public void setArmadura(String armadura) {
		this.armadura = armadura;
	}
	public String getArmas() {
		return armas;
	}
	public void setArmas(String armas) {
		this.armas = armas;
	}
	@Override //SOBREESCRIBIR
	public void fuerza() {
		System.out.println("Guerrero: Fuerza 80%");
	}
	@Override
	public String toString() {
		return 
				" Guerrero [armadura=" + armadura + ", armas=" + armas + "]";
	}
	
	

}
