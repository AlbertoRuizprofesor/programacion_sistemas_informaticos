package POO_VIDEOJUEGOS;

public class princesa extends HEROE {
	private String virtud;
	private String belleza;
	public princesa(String energia, String vida, String virtud, String belleza) {
		super(energia, vida);
		this.virtud = virtud;
		this.belleza = belleza;
	}
	public String getVirtud() {
		return virtud;
	}
	public void setVirtud(String virtud) {
		this.virtud = virtud;
	}
	public String getBelleza() {
		return belleza;
	}
	public void setBelleza(String belleza) {
		this.belleza = belleza;
	}
	@Override
	public void fuerza() {
		System.out.println("Princesa: Fuerza gentil");
	}
	@Override
	public String toString() {
		return 
				" Princesa [virtud=" + virtud + ", belleza=" + belleza + "]";
	}
	
	

}
