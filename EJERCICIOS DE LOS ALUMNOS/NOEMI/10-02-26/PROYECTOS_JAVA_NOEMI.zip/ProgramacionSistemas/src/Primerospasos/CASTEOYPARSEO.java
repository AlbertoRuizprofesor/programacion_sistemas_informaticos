package Primerospasos;

public class CASTEOYPARSEO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//CASTEO
		double x;
		x=6.90;
		int y=(int)x;
		System.out.println("El resultado es "+y);
		
		
		//PARSEO
		int n= Integer.parseInt("123");
		Double d= Double.parseDouble("3.14");
		System.out.println("El resultado es "+d+ " y " +n);
		
			

	}

}
