package Primerospasos;

import java.util.Scanner; //importar en java

public class Calendario {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//activa el input para meter variables en c
		Scanner c=new Scanner (System.in);
		//pide datos
		System.out.println("Cuanto tiempo dedicas al trabajo cada dia:");
		int trabajo=c.nextInt();
		System.out.println("Cuanto tiempo dedicas a dormir: ");
		int dormir=c.nextInt();
		System.out.println("Cuanto tiempo dedicas a comer: ");
		int comer=c.nextInt();
		System.out.println("Cuanto tiempo dedicas a reprochar: ");
		int reprochar=c.nextInt();
		System.out.println("Cuanto tiempo dedicas a ver la TV: ");
		int tv=c.nextInt();
		System.out.println("Cuanto tiempo dedicas a tus hobbies: ");
		int hobbies=c.nextInt();
		System.out.println("Cuanto tiempo dedicas a tareas del hogar: ");
		int tareas=c.nextInt();
		
		//operaciones
		int trabajosemana=trabajo*5;
		int dormirsemana=dormir*7;
		int comersemana=comer*7;
		int reprocharsemana=reprochar*7;
		int tvsemana=tv*7;
		int hobbiessemana=hobbies*7;
		int tareassemana=tareas*7;
		int total=trabajosemana+dormirsemana+comersemana+reprocharsemana+tvsemana+hobbiessemana+tareassemana;
		
		//Mostrar por pantalla
		
		System.out.println("**************************");
		System.out.println("Horas que dedicas al trabajo a la semana: "+trabajosemana);
		System.out.println("Horas que dedicas a dormir a la semana: "+dormirsemana);
		System.out.println("Horas que dedicas a comer a la semana: "+comersemana);
		System.out.println("Horas que dedicas a reprochar a la semana: "+reprocharsemana);
		System.out.println("Horas que dedicas a ver la TV a la semana: "+tvsemana);
		System.out.println("Horas que dedicas a hobbies a la semana: "+hobbiessemana);
		System.out.println("Horas que dedicas a tareas del hogar a la semana: "+tareassemana);
		System.out.println("Horas en total que sufres a la semana: "+total);
		
		
		
		c.close();
		
		

	}

}
