package Primerospasos;

public class HelloWord {

	public static void main(String[] args) {
		String nombre;
		int edad;
		boolean casado;
		edad=28;
		nombre="Noemi";
		casado=false;
		System.out.println("Hola " +nombre+ ", su edad es " +edad);
		System.out.printf("Hola %s su edad es %d casado? %b",nombre,edad, casado); //Se pone s porque es string y d porque es numero y b de booleano.//
		
		

	}

}
