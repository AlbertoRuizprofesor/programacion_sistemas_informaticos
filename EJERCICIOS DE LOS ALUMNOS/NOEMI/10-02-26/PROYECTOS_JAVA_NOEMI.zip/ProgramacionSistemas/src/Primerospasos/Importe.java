package Primerospasos;

import java.util.Scanner;  //Hay que importar en java

public class Importe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//crear scanner
		Scanner c=new Scanner(System.in);
		//pedir el importe
		System.out.println("Introduce el importe: ");
		double importe=c.nextDouble(); 
		System.out.println("Introduce las unidades: ");
		int unidades=c.nextInt();
		
		//Operaciones
		double iva;
		double total;
		double descuento;
		double totalfinal;
			
		descuento=importe*0.10;
		total=importe-descuento;
		iva=importe*0.21;
		totalfinal=total+iva;
		
		//Salir por pantalla
		System.out.println("Las unidades son: "+unidades);
		System.out.printf("El descuento es del 10%% por lo que se descuenta: %.2f%n",descuento);
		System.out.printf("El total con descuento es: %.2f%n",total);
		System.out.printf("El IVA del 21%% es: %.2f%n",iva);
		System.out.printf("El total a pagar es: %.2f%n ",totalfinal);
		
		
		
		c.close(); //cerrar siempre para que sea seguro
	}

}
