package Primerospasos;

import java.util.Scanner;

public class SCANNER {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//CREAR SCANNER
		Scanner c=new Scanner(System.in); //new scanner es para definir cualquier dato, podria haber sido c u otro cualquier letra.
		//pedir datos por consola
		System.out.println("Introduce numero 1: ");
		int numero1=c.nextInt(); //Se pone asi porque es INT si fuera string seria LINE.
		System.out.println("Introduce numero 2: ");
		int numero2=c.nextInt();
		
		//Operaciones
		int suma, resta, multi,divi;
		suma=numero1+numero2;
		resta=numero1-numero2;
		multi=numero1*numero2;
		divi=numero1/numero2;
		
		//salir por pantalla
		System.out.println("La suma es "+suma);
		System.out.println("La resta es "+resta);
		System.out.println("La multiplicacion es: "+multi);
		System.out.println("La division es: "+divi);
		
		c.close();
	}

}
