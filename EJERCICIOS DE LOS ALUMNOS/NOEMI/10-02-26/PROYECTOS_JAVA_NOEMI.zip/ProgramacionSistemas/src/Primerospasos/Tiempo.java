package Primerospasos;

import java.util.Scanner;  //Hay que importar en java

public class Tiempo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner (System.in);
		//pide la fecha de nacimiento
		System.out.println("Introduce año de nacimiento: ");
		int age=c.nextInt();
		
		//operaciones
	    int actuallyage=2026;
	    int edad;
	    
	    edad=actuallyage-age;
	    long meses=age*12L;
	    Long dias=age*365L;
	    Long horas=dias*24;
	    Long minutos=horas*60;
	    
	    //Mostrar por pantalla
	    
	    System.out.println("El año de nacimiento es "+age);
	    System.out.println("Actualmente es el año "+actuallyage);
	    System.out.println("Su edad es "+edad);
	    System.out.printf("Meses: %,d%n",meses);
	    System.out.printf("Dias: %,d%n",dias);
	    System.out.printf("Horas: %,d%n",horas);
	    System.out.printf("Minutos: %,d%n",minutos);
	    


	    
	    c.close(); //cerrar siempre para que sea seguro
		

	}

}
