package condicionales;

import java.util.Scanner;

public class CASE {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		
		System.out.print("Elige un número: ");
		int numero=c.nextInt();
		
		switch (numero) {
		case 1:
			System.out.println("Has elegido 1");
			break;
		case 2:
			System.out.println("Has elegido 2");
			break;
		default:
		System.out.println("No es válido.");
		}
		c.close();
	}

}
