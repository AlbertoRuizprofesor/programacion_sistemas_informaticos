package condicionales;

import java.util.Scanner;

public class Comparador_Cadenas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		System.out.println("Introduce la primera palabra: ");
		String a=c.nextLine();
		
		System.out.println("Introduce la segunda palabra: ");
		String b=c.nextLine();
		
		//condicionales
		
		if (a.equalsIgnoreCase(b)) {
			System.out.println("Son iguales");
		} else {
			System.out.println("Son distintas");
		}
		
		c.close();

	}

}
