package condicionales;

import java.util.Scanner;

public class Descuento_tipo_cliente {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner (System.in);
		
		System.out.print("Introduzca el importe: ");
		double importe=c.nextDouble();
		
		System.out.print("Introduzca el tipo (N:Normal/P:Premiun/E:Empresa): ");
		char tipo=c.next().toUpperCase().charAt(0);  // touppercase convierte el texto a mayusculas y sigue siendo un string
	    
		
		//CASE condicionales
		double desc;
		switch (tipo) {
		case 'N' ->desc=0.0;
		case 'P'->desc=0.10;
		case 'E' ->desc=0.15;
		default->{
			System.out.println("Error:tipo no válido.");
			c.close();
			return;
		}
	}
		double total=importe*(1-desc);
		System.out.printf("Total:%.2f%n", total);
		c.close();
}

}
