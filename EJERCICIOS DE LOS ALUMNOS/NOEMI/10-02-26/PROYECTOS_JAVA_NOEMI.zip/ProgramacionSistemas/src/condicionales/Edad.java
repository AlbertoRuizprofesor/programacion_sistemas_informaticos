package condicionales;

import java.util.Scanner;

public class Edad {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		
		System.out.println("Introduce su edad: ");
		int edad=c.nextInt();
		
		 // condición
		if (edad >= 65) {
            System.out.println("Eres jubilado/a");
        } else if (edad >= 18) {
            System.out.println("Eres mayor de edad");
        } else if (edad >= 0) {
            System.out.println("Eres menor de edad");
        } else {
            System.out.println("Edad no válida");
        }
	

        c.close(); // cerramos Scanner

	}

}
