package condicionales;
import java.util.Scanner;
public class IMC_clasificacion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner (System.in);
		System.out.println("Introduce su peso(kg): ");
		double kg=c.nextDouble();
		
		System.out.println("Introduce su altura(m): ");
		double m=c.nextDouble();
		
		//condicionales
		
		if (kg<=0 || m<=0) {
			System.out.println("Error, valores no válidos.");
			
			c.close();
			return;
		}
		
		double imc=kg/(m*m);
		System.out.printf("El IMC es: %.2f%n ",imc);
		
		if (imc <18.5) System.out.println("Infrapeso");
		else if (imc<25) System.out.println("Peso normal");
		else if (imc<30) System.out.println("Sobrepeso");
		else System.out.println("Obesidad");
		
		c.close();		

	}

}
