package condicionales;

import java.util.Scanner;

public class Importe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Indicador de descuentos");
		System.out.println("***********************");
		//scanner
		Scanner c=new Scanner(System.in);
		
		//introduce por pantalla
		System.out.println("Introduce el importe para realizar el descuento: ");
		int importe=c.nextInt();
		
		//operaciones
		double descuento1=importe*0.10;
		double total1=importe-descuento1;
		double descuento2=importe*0.20;
		double total2=importe-descuento2;
		
		//condicionales
		
		if (importe>0 && importe<=100) {
			System.out.print("Tienes 0% de descuento, total de importe:"+importe);
		} else if(importe>100 && importe<=1000) {
			System.out.print("Tienes un 10% de descuento, total importe a pagar "+total1);
	    } else if (importe>1000) {
	    	System.out.print("Tienes un 20% de descuento, total importe a pagar "+total2);
	    } else {
	    	System.out.print("No se puede introducir 0");
	    	
	    }
			
		c.close();
		
	}

}
