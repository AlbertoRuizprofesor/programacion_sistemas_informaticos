package condicionales;

import java.util.Scanner;

public class Max3n {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner cs=new Scanner(System.in);
		
		System.out.println("Primer número: ");
		int a=cs.nextInt();
		
		System.out.println("Segundo número: ");
		int b=cs.nextInt();
		
		System.out.println("Tercer número: ");
		int c=cs.nextInt();
		
		//condicionales
		
		int max=a;
		
		if(b>max)max=b;
		if(c>max)max=c;
		
		System.out.println("El número mayor es: "+max);
		
		cs.close();
		
	}
		

}
