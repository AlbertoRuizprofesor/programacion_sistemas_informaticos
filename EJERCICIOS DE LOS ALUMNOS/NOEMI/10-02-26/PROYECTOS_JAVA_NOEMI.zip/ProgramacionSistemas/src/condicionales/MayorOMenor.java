package condicionales;

import java.util.Scanner;

public class MayorOMenor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Pide datos por pantalla y declara variables:
		Scanner c=new Scanner(System.in);
		System.out.print("Primer número: ");
		int a=c.nextInt();
		
		System.out.print("Segundo número: ");
		int b=c.nextInt();
		
		//Condicionales
		
		if (a>b) {
			System.out.println("El primer número es mayor al ser "+a);
		}else if(a<b) {
			System.out.println("El segundo número es mayor al ser "+b);
			
		} else {
			System.out.println("Son iguales");
		}
        c.close();    
	}

}
