package condicionales;

import java.util.Scanner; 

public class Menu_Dia_Semana {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		System.out.println("Introduce el número del dia de la semana (1:Lunes/2:Martes/3:Miercoles/4:Jueves/5:Viernes/6:Sabado/7:Domingo): ");
		int dia=c.nextInt();
		
		String nombre= switch (dia) {
		case 1 ->"Lunes";
		case 2 ->"Martes";
		case 3 ->"Miercoles";
		case 4 ->"Jueves";
		case 5 ->"Viernes";
		case 6 ->"Sabado";
		case 7 ->"Domingo";
		default -> null;
		};
		
		if (nombre==null) System.out.println("Error: día inválido.");
		else System.out.println(nombre);
		
		c.close();		

	}

}
