package condicionales;

import java.util.Scanner;

public class Notas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//scaner
		Scanner c=new Scanner(System.in);
		//pide datos
		System.out.println("Introduce su nota: ");
		int nota=c.nextInt();
		
		//condicion:

		if(nota < 5){
			System.out.println("Estás suspenso");
		}else if(nota <= 6){
			System.out.println("Tienes un bien");
		}else if(nota <= 8){
			System.out.println("Tienes un notable");
		}else if(nota <= 10){
			System.out.println("Tienes un sobresaliente");
		}else{
			System.out.println("Nota no válida");
	}

		c.close();
	}
	

}
