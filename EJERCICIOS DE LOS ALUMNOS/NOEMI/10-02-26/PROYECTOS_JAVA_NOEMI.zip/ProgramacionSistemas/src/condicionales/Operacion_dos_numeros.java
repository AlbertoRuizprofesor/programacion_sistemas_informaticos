package condicionales;

import java.util.Scanner;

public class Operacion_dos_numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		System.out.print("Primer número: ");
		double a=c.nextDouble();
		
		System.out.print("Segundo número: ");
		double b=c.nextDouble();
		
		System.out.print("Elige una operación (+-*/): ");
		String op=c.next();
		
		//CASE CONDICIONALES
		
		switch (op) {
		case "+" -> System.out.println("Resultado: " +(a+b));
		case "-" -> System.out.println("Resultado: "+(a-b));
		case "*" -> System.out.println("Resultado: "+(a*b));
		case "/" -> {
		if (b==0) System.out.println("No se puede dividir por 0");
		else System.out.println("Resultado: "+(a/b));
		}
		
		default -> System.out.println("Error: operador no válido");
		
		}
		
		c.close();
		
	
	}

}
