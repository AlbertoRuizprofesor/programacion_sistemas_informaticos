package condicionales;

import java.util.Scanner;

public class PARoIMPAR {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		
		System.out.println("Introduce un número: ");
		int n=c.nextInt(); 
		
		//condicionales
		
		if (n%2==0) {
			System.out.println("Es Par");
		} else {
			System.out.println("Es Impar");
		}
		
		c.close();
	}

}
