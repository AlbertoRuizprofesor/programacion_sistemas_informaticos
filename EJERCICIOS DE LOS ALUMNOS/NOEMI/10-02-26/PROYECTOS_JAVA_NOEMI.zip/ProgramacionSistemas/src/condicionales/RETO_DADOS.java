package condicionales;

import java.util.Scanner;

public class RETO_DADOS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner (System.in);
		
		//Jugador
		System.out.print("Introduce un número del 1 al 6: ");
		int jugador=c.nextInt();
		
		// Validación
		if (jugador < 1 || jugador > 6) {
				System.out.println("❌ Número inválido. Debes introducir un número entre 1 y 6.");
			} else {
				
		//Máquina
		int maquina=(int)(Math.random()*6)+1;
			
		
		System.out.println("Dado del jugador: "+jugador);
		System.out.println("Dado de la máquina: "+maquina);
		
		//condicionales
		
		if (jugador > maquina) {
			System.out.println("¡Has ganado!");
		
		} else if (jugador < maquina) {
			System.out.println("Ha ganado máquina");
			
		} else {
			System.out.println("Empate");
		}
			} c.close();
	}

}
