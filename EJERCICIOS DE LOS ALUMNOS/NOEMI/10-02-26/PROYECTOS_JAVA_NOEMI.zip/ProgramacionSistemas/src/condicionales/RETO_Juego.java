package condicionales;

import java.util.Scanner;

public class RETO_Juego {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Scanner para poder meter en input
		Scanner c=new Scanner(System.in);
		
		
		//Máquina
		int maquina=(int)(Math.random()*3)+1;
		
		//Jugador
		System.out.println("Elige una opción (1-Piedra/2-Papel/3-Tijeras): ");
		int jugador=c.nextInt();
		
		
	     // Mostrar elecciones
		System.out.println("Jugador ha elegido: "+jugador);
		System.out.println("Máquina ha elegido: "+maquina);
		
		//condicionales
		if (jugador == maquina) {
			System.out.println("Empate");
		} else if (
				(jugador ==1 && maquina ==3) ||
				(jugador ==2 && maquina ==1) ||
				(jugador==3 && maquina==2)
			) {
			System.out.println("Gana la máquina");
		}
			c.close();
		
		

	}

}
