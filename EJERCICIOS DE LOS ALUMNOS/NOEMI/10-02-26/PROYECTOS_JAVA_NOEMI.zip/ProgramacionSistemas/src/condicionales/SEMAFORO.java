package condicionales;

import java.util.Scanner;

public class SEMAFORO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner (System.in);
		System.out.println("Información del Semáforo");
		System.out.println("Introduce para información (R:rojo/A:ámbar/V:verde): ");
		char ch=c.next().toUpperCase().charAt(0); //Upper convierte la cadena en mayusculas, .chatAt(0) toma el primer caracter de la cadena
		
		switch (ch) {
		case 'R' ->System.out.println("STOP");
		case 'A' ->System.out.println("PRECAUCION");
		case 'V'->System.out.println("PASAR");
		default -> System.out.println("Error: color inválido");
		
		}
		
		c.close();
	}

}
