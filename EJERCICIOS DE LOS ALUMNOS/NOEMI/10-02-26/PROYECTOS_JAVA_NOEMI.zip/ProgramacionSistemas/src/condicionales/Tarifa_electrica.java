package condicionales;

import java.util.Scanner;

public class Tarifa_electrica {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		System.out.println("Introduce la cantidad de kWh consumidos: ");
		int kwh=c.nextInt();
		
		//condicionales
		
		if (kwh<0) {
			System.out.println("Error: consumo negativo.");
	
			c.close();
			return;
		}
		
		double precio;
		if (kwh <=100) precio=0.12;
		else if (kwh <=300) precio=0.15;
		else precio=0.20;
		
		double total=kwh*precio;
		System.out.printf("Total: %.2f%n ",total);
		
		c.close();
	}

}
