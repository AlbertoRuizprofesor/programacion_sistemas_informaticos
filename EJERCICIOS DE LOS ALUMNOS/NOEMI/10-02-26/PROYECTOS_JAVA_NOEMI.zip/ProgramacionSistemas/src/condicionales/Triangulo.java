package condicionales;

import java.util.Scanner;

public class Triangulo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner (System.in);
		System.out.println("Introduce el primer lado del triangulo: ");
		double lado1=c.nextDouble();
		
		System.out.println("Introduce el segundo lado del triangulo: ");
		double lado2=c.nextDouble();
		
		System.out.println("Introduce el tercer lado del triángulo: ");
		double lado3=c.nextDouble();
		
		//condicionales:
		
		if (lado1<=0 || lado2<=0 || lado3<=0) {
			System.out.println("Error: lados deben ser mayor a 0.");
		} else if (lado1+lado2<=lado3 || lado1+lado3<=lado2 || lado2+lado3<=lado1) {
			System.out.println("No es un triángulo válido");
		} else if (lado1==lado2 && lado2==lado3) {
			System.out.println("Es un triangulo Equilatero, todos los lados son iguales.");
		} else if (lado1==lado2 || lado2==lado3 || lado1==lado3) {
			System.out.println("Es un triangulo Isosceles, exactamente dos lados iguales");
			
		} else {
			System.out.println("Es un triángulo Escaleno, todos los lados son diferentes");
		}
		
		c.close();
		

	}

}
