package INTERFACES;

public class Calculadora_Main {

	public static void main(String[] args) {
		Calculadora cal=new Calculadora();
		
		cal.mostrar(10, 2);
		

	}

}
