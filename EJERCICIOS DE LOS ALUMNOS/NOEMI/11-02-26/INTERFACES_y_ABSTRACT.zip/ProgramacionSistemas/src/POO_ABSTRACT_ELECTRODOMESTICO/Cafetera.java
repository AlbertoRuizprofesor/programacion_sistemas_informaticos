package POO_ABSTRACT_ELECTRODOMESTICO;

public class Cafetera extends Electrodomesticos {
	private String carga;

	public Cafetera(String tipo, String color, String peso, String marca, String fabricante, double precio,
			String carga) {
		super(tipo, color, peso, marca, fabricante, precio);
		this.carga = carga;
	}

	public String getCarga() {
		return carga;
	}

	public void setCarga(String carga) {
		this.carga = carga;
	}

	@Override
	void encender() {
		System.out.println("Cafetera encendio manual.");
		
	}

	@Override
	void apagar() {
		System.out.println("Cafetera apagado manual.");
		
	}

	@Override
	void comprar() {
		System.out.println("Cafetera: tiene plazos de financiacion.");
		
	}

	@Override
	void devolver() {
		System.out.println("Cafetera: devoluciones antes de los 30 días\n");
		
	}

	@Override
	public String toString() {
		return super.toString()+"Cafetera [carga=" + carga + "]\n";
	}
	

}
