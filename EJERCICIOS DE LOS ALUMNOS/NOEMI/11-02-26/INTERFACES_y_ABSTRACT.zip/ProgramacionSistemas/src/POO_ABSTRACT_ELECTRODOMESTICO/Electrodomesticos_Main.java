package POO_ABSTRACT_ELECTRODOMESTICO;

public class Electrodomesticos_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Lavadora l=new Lavadora("Lavadora. ","Blanca. ","Bosh. ","Fujitsu. ","fau",200,"9kg","9kg");
		 
		Lavadora [] la=new Lavadora[2];
		la[0]=new Lavadora("Lavadora.","Blanca. ","Bosh. ","Fujitsu. ","au",200,"10kg","9kg");
		la[1]=new Lavadora("Lavadora. ","Negra. ","Giops. ","Cetoquec. ","ree",300,"14Kg","10Kg");
		
		//Cafetera f=new Cafetera("Cafereta","Rojo","6kg","Bosh","Fujitsu",100,"Manual");
		Cafetera [] ca=new Cafetera[2];
		ca[0]=new Cafetera("Cafereta","Rojo","6kg","Bosh","Fujitsu",100,"Manual");
		ca[1]=new Cafetera("Cafereta","Azul","4kg","Bosh","Fujitsu",840,"Manual");
		
		Frigorifico [] fri=new Frigorifico[2];
		fri[0]=new Frigorifico("Frigorifico","Blanca","Lender","MAC","rockstar",700,10,2.05);
		fri[1]=new Frigorifico("Frigorifico","Negro","Lender","MAC","rockstar",1920,20,2.40);
		
		for (Lavadora lla:la) {
			System.out.println(lla);
			lla.encender();
			lla.apagar();
			lla.comprar();
			lla.devolver();
		}
		for (Cafetera caf:ca) {
			System.out.println(caf);
			caf.encender();
			caf.apagar();
			caf.comprar();
			caf.devolver();
		}
		for (Frigorifico f:fri) {
			System.out.println(f);
			f.encender();
			f.apagar();
			f.comprar();
			f.devolver();
		}
				
	}
}


