package POO_ABSTRACT_ELECTRODOMESTICO;

public class Frigorifico extends Electrodomesticos {
	private int capacidad;
	private double altura;
	public Frigorifico(String tipo, String color, String peso, String marca, String fabricante, double precio,
			int capacidad, double altura) {
		super(tipo, color, peso, marca, fabricante, precio);
		this.capacidad = capacidad;
		this.altura = altura;
	}
	public int getCapacidad() {
		return capacidad;
	}
	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}
	public double getAltura() {
		return altura;
	}
	public void setAltura(double altura) {
		this.altura = altura;
	}
	@Override
	void encender() {
		System.out.println("Frigorifico encendido!!");
		
	}
	@Override
	void apagar() {
		System.out.println("Frigorifico apagado!!");
		
	}
	@Override
	void comprar() {
		System.out.println("Financiacion al 100%");
		
	}
	@Override
	void devolver() {
		System.out.println("Devoluciones antes de los 60 dñias.\n");
		
	}
	@Override
	public String toString() {
		return super.toString()+"Frigorifico [capacidad=" + capacidad + ", altura=" + altura + "]\n";
	}
	

}
