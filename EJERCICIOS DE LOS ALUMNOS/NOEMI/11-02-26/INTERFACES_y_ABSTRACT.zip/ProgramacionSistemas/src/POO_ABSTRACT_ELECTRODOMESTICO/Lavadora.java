package POO_ABSTRACT_ELECTRODOMESTICO;

public class Lavadora extends Electrodomesticos {
	private String carga;
	private String kilos;
	public Lavadora(String tipo, String color, String peso, String marca, String fabricante, double precio,
			String carga, String kilos) {
		super(tipo, color, peso, marca, fabricante, precio);
		this.carga = carga;
		this.kilos = kilos;
	}
	public String getCarga() {
		return carga;
	}
	public void setCarga(String carga) {
		this.carga = carga;
	}
	public String getKilos() {
		return kilos;
	}
	public void setKilos(String kilos) {
		this.kilos = kilos;
	}
	@Override
	void encender() {
		System.out.println("Lavadora: encendido automático");	
	}
	@Override
	void apagar() {
		System.out.println("Lavadora: apagado automático");
		
	}
	@Override
	void comprar() {
		System.out.println("Lavadora: ventas en todos los establecimientos MEDIAMARK");
		
	}
	@Override
	void devolver() {
		System.out.println("Lavadora: devoluciones en cualquier establecimiento.\n");
		
	}
	@Override
	public String toString() {
		return super.toString()+"Lavadora [carga=" + carga + ", kilos=" + kilos + "]\n";
	}
	

}
