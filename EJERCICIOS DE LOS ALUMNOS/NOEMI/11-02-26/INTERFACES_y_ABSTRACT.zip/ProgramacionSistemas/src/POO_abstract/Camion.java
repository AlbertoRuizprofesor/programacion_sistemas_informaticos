package POO_abstract;

public class Camion extends Vehiculo {
	private String peso;
	private double precio;
	public Camion(String color, int ruedas, String modelo, String peso, double precio) {
		super(color, ruedas, modelo);
		this.peso = peso;
		this.precio = precio;
	}
	public String getPeso() {
		return peso;
	}
	public void setPeso(String peso) {
		this.peso = peso;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	@Override
	void acelerar() {
		System.out.println("El camion acelera mucho.");
		
	}
	@Override
	void frenar() {
		System.out.println("El camion frena");
		
	}
	@Override
	void aparcar() {
		System.out.println("APARCA EL CAMION");
	}
	@Override
	public String toString() {
		return super.toString()+ "Camion [peso=" + peso + ", precio=" + precio + "]";
	}

}
