package POO_abstract;

public class Coche extends Vehiculo {
	private String comodidad;
	private String velocidad;
	
	public Coche(String color, int ruedas, String modelo, String comodidad, String velocidad) {
		super(color, ruedas, modelo);
		this.comodidad = comodidad;
		this.velocidad = velocidad;
	}
	public String getComodidad() {
		return comodidad;
	}
	public void setComodidad(String comodidad) {
		this.comodidad = comodidad;
	}
	public String getVelocidad() {
		return velocidad;
	}
	public void setVelocidad(String velocidad) {
		this.velocidad = velocidad;
	}
	@Override
	void acelerar() {
		System.out.println("El coche acelera");
		
		
		
	}
	@Override
	void aparcar() {
		// TODO Auto-generated method stub
		
	}
	@Override
	void frenar() {
		System.out.println("El coche frena");
		
		
	}
	@Override
	public String toString() {
		return super.toString() + " comodidad=" + comodidad + ", velocidad=" + velocidad + "";
		
	}
}