package POO_abstract;

public class Moto extends Vehiculo {
	public String getSeguridad() {
		return seguridad;
	}
	public void setSeguridad(String seguridad) {
		this.seguridad = seguridad;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	private String seguridad;
	private double precio;
	public Moto(String color, int ruedas, String modelo, String seguridad, double precio) {
		super(color, ruedas, modelo);
		this.seguridad = seguridad;
		this.precio = precio;
	}
	@Override
	void acelerar() {
		System.out.println("La moto acelera");
		
	}
	@Override
	void frenar() {
		System.out.println("La moto frena");
		
		
	}
	@Override
	void aparcar() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public String toString() {
		return super.toString() + " Moto [seguridad=" + seguridad + ", precio=" + precio + "]";
	}
	

}
