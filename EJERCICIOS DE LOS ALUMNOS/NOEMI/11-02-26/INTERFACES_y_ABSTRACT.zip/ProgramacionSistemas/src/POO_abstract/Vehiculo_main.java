package POO_abstract;

public class Vehiculo_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Coche c=new Coche("color",4,"Ford","Confortable","150km/h");
		
		Coche [] co=new Coche[2];
		
		Moto m=new Moto("rojo",2, "Honda","abs" , 6000);
		
		Camion ca=new Camion("amarillo", 6, "Oper", "2 toneladas", 60000);
		
		co[0]=new Coche("verde",4,"OperCorsa","Asiento abatibles","150km/h");
		co[1]=new Coche("morado",4,"BMW","aire acondicionado","250km/h");
		
		
		
		for (Coche car:co) {
			System.out.println(car);
			car.acelerar();
			car.frenar();
			}
	
		System.out.println(m.toString());
		m.acelerar();
		m.frenar();
		m.aparcar();
		
		
		System.out.println(ca.toString());
		ca.acelerar();
		ca.frenar();
		ca.aparcar();
}
}
	


