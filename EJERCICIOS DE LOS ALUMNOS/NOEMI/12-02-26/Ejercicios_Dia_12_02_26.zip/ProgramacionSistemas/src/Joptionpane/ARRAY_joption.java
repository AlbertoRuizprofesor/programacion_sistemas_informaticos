package Joptionpane;

import javax.swing.JOptionPane;

public class ARRAY_joption {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String [] options= {"Rock","Papers", "Scissors", "Game Over"};
			var selection = JOptionPane.showOptionDialog(null, "Select one: ", "Let`s play a game!",0,3,null,options,options[0]);
			
			if (selection == 0) {
				JOptionPane.showConfirmDialog(null, "You chose Rock");
			}
			if (selection == 1) {
				JOptionPane.showConfirmDialog(null, "You chose Papers");
			}
			if (selection ==2) {
				JOptionPane.showConfirmDialog(null, "You chose Scissors");
			}else if (selection == 3) {
                JOptionPane.showMessageDialog(null, "Game Over");
    		} else {
    			JOptionPane.showMessageDialog(null, "You closed the window");
    }

			System.exit(0);
			}
					

	}

