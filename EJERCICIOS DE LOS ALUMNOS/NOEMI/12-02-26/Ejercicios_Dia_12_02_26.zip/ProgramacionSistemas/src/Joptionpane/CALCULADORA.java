package Joptionpane;

import javax.swing.JOptionPane;

public class CALCULADORA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   String dato = JOptionPane.showInputDialog(null,"Introduce el primer numero: ", "Calculadora", JOptionPane.INFORMATION_MESSAGE);  	 	
	        
		    int num1=Integer.parseInt(dato);
		    
		    	//pedir segund numero
		    String dato2=JOptionPane.showInputDialog(null,"Introduce el segundo numero: ");
		    
		    int num2=Integer.parseInt(dato2);
		    
		    	//Operacion
		    int suma=num1+num2;
		    
		    	//Mostrar resultado
		    JOptionPane.showConfirmDialog(null, "La suma es: "+suma);

	}

}
