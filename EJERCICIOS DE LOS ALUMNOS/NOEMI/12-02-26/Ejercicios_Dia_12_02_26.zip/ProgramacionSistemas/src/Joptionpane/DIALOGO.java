package Joptionpane;

import javax.swing.JOptionPane;

public class DIALOGO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String result;
		
		int option;
		do {
		option=JOptionPane.showConfirmDialog(
				null, 
				"¿Apagar sistema?",
				"Opciones", 
				JOptionPane.ERROR_MESSAGE);
		
	if (option==0) {
		result="si";
		JOptionPane.showConfirmDialog(null, "Has pulsado: "+result);
		
		break;
		
	}else {
		result="no";
	}
	
	JOptionPane.showMessageDialog(null, "Has pulsado: "+result);

	}while(option!=0);

}
}