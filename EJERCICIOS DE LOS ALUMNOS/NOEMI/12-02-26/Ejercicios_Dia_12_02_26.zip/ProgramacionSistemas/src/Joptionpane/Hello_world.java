package Joptionpane;

import javax.swing.JOptionPane;

public class Hello_world {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null,"Hello World!");  	 	
        

        
        	

	}

}
