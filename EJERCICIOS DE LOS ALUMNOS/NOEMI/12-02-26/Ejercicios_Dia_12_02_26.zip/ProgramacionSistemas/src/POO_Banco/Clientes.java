package POO_Banco;

public class Clientes implements Datos_cliente{
	private String nombre;
	private String dni;
	private String telefono;
	private Cuenta_bancaria cuenta;  //esto es lo mismo que hacer el join , asociar con otra clase
	public Clientes(String nombre, String dni, String telefono, Cuenta_bancaria cuenta) {
		super();
		this.nombre = nombre;
		this.dni = dni;
		this.telefono = telefono;
		this.cuenta = cuenta;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public Cuenta_bancaria getCuenta() {
		return cuenta;
	}
	public void setCuenta(Cuenta_bancaria cuenta) {
		this.cuenta = cuenta;
		
	}
	@Override
	public void mostrarDatos_cliente() {
		
	
		System.out.println("Nombre: " + nombre + ", DNI: " + dni + ", Teléfono: " + telefono);
		System.out.println("Cuenta: " + cuenta.getNumero_cuenta() + ", Saldo: " + cuenta.getSaldo_inicial());
		
	}
	@Override
	public String toString() {
		return "Clientes [nombre=" + nombre + ", dni=" + dni + ", telefono=" + telefono + ", cuenta=" + cuenta + "]";
	}
	
	

}
