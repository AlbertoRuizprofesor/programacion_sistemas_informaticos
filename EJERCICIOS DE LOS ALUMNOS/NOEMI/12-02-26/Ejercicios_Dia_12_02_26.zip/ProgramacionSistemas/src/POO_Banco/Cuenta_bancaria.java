package POO_Banco;

public class Cuenta_bancaria extends Banco{
	private int numero_cuenta;
	private double saldo_inicial;
	public Cuenta_bancaria(String nombre_banco, int numero_cuenta, double saldo_inicial) {
		super(nombre_banco);
		this.numero_cuenta = numero_cuenta;
		this.saldo_inicial = saldo_inicial;
	}
	public int getNumero_cuenta() {
		return numero_cuenta;
	}
	public void setNumero_cuenta(int numero_cuenta) {
		this.numero_cuenta = numero_cuenta;      //asociamos dos clases
	}
	public double getSaldo_inicial() {
		return saldo_inicial;
	}
	public void setSaldo_inicial(double saldo_inicial) {
		this.saldo_inicial = saldo_inicial;
	}
	
	 // 1) Ingresar
    public void ingresar(double importe) {
        if (importe <= 0) {
            System.out.println("❌ El importe a ingresar debe ser mayor que 0.");
            return;
        }
        saldo_inicial += importe;
        System.out.println("✅ Ingreso realizado: +" + importe);
    }

    // 2) Sacar (retirar)
    public void sacar(double importe) {
        if (importe <= 0) {
            System.out.println("❌ El importe a retirar debe ser mayor que 0.");
            return;
        }
        if (importe > saldo_inicial) {
            System.out.println("❌ Saldo insuficiente. Saldo actual: " + saldo_inicial);
            return;
        }
        saldo_inicial -= importe;
        System.out.println("✅ Retirada realizada: -" + importe);
    }

    // 3) Mostrar saldo
    public void mostrarSaldo() {
        System.out.println("💰 Saldo actual: " + saldo_inicial);
    }

}
