package POO_Banco;

public interface Datos_cliente {
	void mostrarDatos_cliente();
		
}

