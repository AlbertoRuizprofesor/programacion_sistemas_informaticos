package POO_Banco;

public enum DiaSemana {
	Lunes,
	Martes,
	Miercoles,
	Jueves,
	Viernes,
	Sabado,
	Domingo;
	

}
