package POO_Banco;

public class MAIN_BANCO {

	public static void main(String[] args) {

		
	Cuenta_bancaria c1 = new Cuenta_bancaria("Banco Central", 12345, 1000.0);
	Clientes c = new Clientes("Antonio", "12345678A", "600123123", c1);
	
	DiaSemana hoy=DiaSemana.Domingo;
			System.out.println("Hoy es "+hoy+"\n");

	
	c.mostrarDatos_cliente();

	
		     c.getCuenta().ingresar(500);
		     c.getCuenta().sacar(200);
		      c.getCuenta().mostrarSaldo();
		    }
		
		
	}


