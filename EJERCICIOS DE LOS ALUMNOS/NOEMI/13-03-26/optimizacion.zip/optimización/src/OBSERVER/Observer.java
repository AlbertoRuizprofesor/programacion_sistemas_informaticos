package OBSERVER;

public interface Observer {

}
