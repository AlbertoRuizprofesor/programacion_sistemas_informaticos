package OBSERVER;

public class barradeestado {

}
