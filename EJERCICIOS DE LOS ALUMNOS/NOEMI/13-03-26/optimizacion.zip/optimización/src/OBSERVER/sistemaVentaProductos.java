package OBSERVER;

public class sistemaVentaProductos {

}
