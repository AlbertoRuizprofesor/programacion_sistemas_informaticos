package Strategy;

public class ContextoPago {

}
