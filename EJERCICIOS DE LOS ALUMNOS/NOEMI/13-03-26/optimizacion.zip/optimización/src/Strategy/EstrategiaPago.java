package Strategy;

public interface EstrategiaPago {

}
