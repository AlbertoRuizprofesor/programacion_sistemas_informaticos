package Strategy;

public class PagoPaypal {

}
