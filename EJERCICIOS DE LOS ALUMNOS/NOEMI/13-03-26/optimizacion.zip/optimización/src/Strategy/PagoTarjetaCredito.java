package Strategy;

public class PagoTarjetaCredito {

}
