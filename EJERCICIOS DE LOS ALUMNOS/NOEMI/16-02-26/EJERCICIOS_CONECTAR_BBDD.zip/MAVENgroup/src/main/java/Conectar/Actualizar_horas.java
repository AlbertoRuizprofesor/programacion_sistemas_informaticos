package Conectar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Actualizar_horas {

    public static void main(String[] args) {

        Connection conn = null;
        PreparedStatement pstmt = null;
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el ID del curso: ");
        int id = sc.nextInt();

        System.out.print("Ingrese el nuevo número de horas: ");
        int horas = sc.nextInt();

        String sql = "UPDATE cursos SET horas = ? WHERE id = ?";

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/Academia", "root", "");
            pstmt = conn.prepareStatement(sql);

            // Primer ? → horas
            pstmt.setInt(1, horas);

            // Segundo ? → id
            pstmt.setInt(2, id);

            int filasModificadas = pstmt.executeUpdate();

            if (filasModificadas > 0) {
                System.out.println("Curso actualizado correctamente.");
                System.out.println("Filas modificadas: " + filasModificadas);
            } else {
                System.out.println("No existe un curso con ese ID.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error en la conexión: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            sc.close();
        }
    }
}
