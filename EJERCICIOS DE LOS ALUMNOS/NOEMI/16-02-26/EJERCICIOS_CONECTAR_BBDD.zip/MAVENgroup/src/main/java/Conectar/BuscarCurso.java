package Conectar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class BuscarCurso {

    public static void main(String[] args) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el nombre del curso: ");
        String nombreCurso = sc.nextLine();

        String sql = "SELECT * FROM cursos WHERE nombre = ?";

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/Academia", "root", "");
            pstmt = conn.prepareStatement(sql);

            // Aquí usamos setString para reemplazar el "?" por el nombre del curso
            pstmt.setString(1, nombreCurso);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                // Si existe, mostramos los datos
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String profesor = rs.getString("profesor");
                int horas = rs.getInt("horas");

                System.out.println("Curso encontrado:");
                System.out.println("ID: " + id);
                System.out.println("Nombre: " + nombre);
                System.out.println("Profesor: " + profesor);
                System.out.println("Horas: " + horas);
            } else {
                System.out.println("El curso '" + nombreCurso + "' no existe.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error en la conexión: " + e.getMessage());
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            sc.close();
        }
    }
}
