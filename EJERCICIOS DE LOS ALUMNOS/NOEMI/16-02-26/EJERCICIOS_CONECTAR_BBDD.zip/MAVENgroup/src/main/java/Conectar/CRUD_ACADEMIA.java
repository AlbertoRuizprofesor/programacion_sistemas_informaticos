package Conectar;

import java.sql.*;
import java.util.Scanner;

public class CRUD_ACADEMIA {

    static final String URL = "jdbc:mysql://localhost/Academia";
    static final String USER = "root";
    static final String PASS = "";

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n===== MENÚ ACADEMIA =====");
            System.out.println("1. Insertar curso");
            System.out.println("2. Mostrar cursos");
            System.out.println("3. Buscar curso");
            System.out.println("4. Actualizar curso");
            System.out.println("5. Eliminar curso");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (opcion) {

            case 1:
                insertarCurso(sc);
                break;

            case 2:
                Crud_clase_normal.mostrarCursos();
                break;

            case 3:
                Crud_clase_normal.buscarCurso(sc);
                break;

            case 4:
                Crud_clase_normal.actualizarCurso(sc);
                break;

            case 5:
                Crud_clase_normal.eliminarCurso(sc);
                break;


            case 0:
                System.out.println("Saliendo del programa...");
                break;

            default:
                System.out.println("Opción inválida");
        }



        } while (opcion != 0);

        sc.close();
    }

    // ================= INSERTAR =================
    static void insertarCurso(Scanner sc) {
        String sql = "INSERT INTO cursos (nombre, profesor, horas) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            System.out.print("Nombre: ");
            String nombre = sc.nextLine();

            System.out.print("Profesor: ");
            String profesor = sc.nextLine();

            System.out.print("Horas: ");
            int horas = sc.nextInt();
            sc.nextLine();

            pstmt.setString(1, nombre);
            pstmt.setString(2, profesor);
            pstmt.setInt(3, horas);

            int filas = pstmt.executeUpdate();
            System.out.println("Curso insertado. Filas afectadas: " + filas);

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
