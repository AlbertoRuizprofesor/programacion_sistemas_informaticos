package Conectar;
import java.sql.*; 



public class Crear_bd{

	public static void main(String[] args)  throws SQLException {
		// TODO Auto-generated method stub
		Connection conn=null;
		PreparedStatement stmt=null; //objeto utilizado para crear setencias
		String sql="Create DATABASE if not exists academia";
		try {
			//desde aqui se encarga del driver JDBC
			conn = DriverManager.getConnection("jdbc:mysql://localhost/","root","");
			//controlamos que la conexion ha sido ok
			stmt=conn.prepareStatement(sql); //creamos 	 un canal que comunica es como prparar el prompt
			stmt.execute(sql);
			System.out.println("Tabla clientes creada");
			conn.close();
			stmt.close();
		}
		catch(SQLException e) {
			{e.printStackTrace();			
			System.out.println("Error en la conexion "+((Throwable) e).getMessage());
			
			}
	}
}
}
