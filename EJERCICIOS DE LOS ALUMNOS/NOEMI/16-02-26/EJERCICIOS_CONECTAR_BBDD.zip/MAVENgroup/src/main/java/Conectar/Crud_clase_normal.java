package Conectar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Crud_clase_normal  {

    // ================= MOSTRAR =================
    static void mostrarCursos() {
        String sql = "SELECT * FROM cursos";

        try (Connection conn =Conexion.getConexion();
 
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            System.out.println("\n--- LISTA DE CURSOS ---");

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                        " | Nombre: " + rs.getString("nombre") +
                        " | Profesor: " + rs.getString("profesor") +
                        " | Horas: " + rs.getInt("horas"));
            }

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // ================= BUSCAR =================
    static void buscarCurso(Scanner sc) {
        String sql = "SELECT * FROM cursos WHERE nombre = ?";

        try (Connection conn = Conexion.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            System.out.print("ID del curso: ");
            int id = sc.nextInt();

            pstmt.setInt(1, id);
            ResultSet rs1 = pstmt.executeQuery();

            if (rs1.next()) {
                System.out.println("Curso encontrado:");
                System.out.println("ID: " + rs1.getInt("id"));
                System.out.println("Profesor: " + rs1.getString("profesor"));
                System.out.println("Horas: " + rs1.getInt("horas"));
            } else {
                System.out.println("No existe ese curso.");
            }

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // ================= ACTUALIZAR =================
    static void actualizarCurso(Scanner sc) {
        String sql = "UPDATE cursos SET horas = ? WHERE id = ?";

        try (Connection conn = Conexion.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            System.out.print("ID del curso: ");
            int id = sc.nextInt();

            System.out.print("Nuevo número de horas: ");
            int horas = sc.nextInt();
            sc.nextLine();

            pstmt.setInt(1, horas);
            pstmt.setInt(2, id);

            int filas = pstmt.executeUpdate();

            if (filas > 0)
                System.out.println("Curso actualizado.");
            else
                System.out.println("No existe ese ID.");

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // ================= ELIMINAR =================
    static void eliminarCurso(Scanner sc) {
        String sql = "DELETE FROM cursos WHERE id = ?";

        try (Connection conn = Conexion.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            System.out.print("ID del curso a eliminar: ");
            int id = sc.nextInt();
            sc.nextLine();

            pstmt.setInt(1, id);

            int filas = pstmt.executeUpdate();

            if (filas > 0)
                System.out.println("Curso eliminado.");
            else
                System.out.println("No existe ese ID.");

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}



