package Conectar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Eliminar_curso {

    public static void main(String[] args) {

        Connection conn = null;
        PreparedStatement pstmt = null;
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el ID del curso a eliminar: ");
        int id = sc.nextInt();

        String sql = "DELETE from cursos WHERE id = ?";

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/Academia", "root", "");
            pstmt = conn.prepareStatement(sql);

            // Primer ? → horas
            pstmt.setInt(1, id);

            int filasEliminadas=pstmt.executeUpdate();

            if (filasEliminadas > 0) {
                System.out.println("Curso eliminado correctamente.");
                System.out.println("Filas eliminadas: " + filasEliminadas);
            } else {
                System.out.println("No existe un curso con ese ID.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error en la conexión: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            sc.close();
        }
    }
}

