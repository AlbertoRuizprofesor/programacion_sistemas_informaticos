package Conectar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class INSERTAR {

    public static void main(String[] args) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        String sql = "INSERT INTO cursos (id, nombre, profesor, horas) VALUES (?, ?, ?, ?)";

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/Academia","root","");
            pstmt = conn.prepareStatement(sql);

            // Curso 1
            pstmt.setInt(1, 1); //id
            pstmt.setString(2, "Matemáticas");
            pstmt.setString(3, "Juan Pérez");
            pstmt.setInt(4, 40);
            pstmt.executeUpdate();

            // Curso 2
            pstmt.setInt(1, 2);
            pstmt.setString(2, "Física");
            pstmt.setString(3, "Ana Gómez");
            pstmt.setInt(4, 35);
            pstmt.executeUpdate();

            // Curso 3
            pstmt.setInt(1, 3);
            pstmt.setString(2, "Programación");
            pstmt.setString(3, "Carlos López");
            pstmt.setInt(4, 50);
            pstmt.executeUpdate();

            System.out.println("Cursos insertados correctamente");

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error en la conexion: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}
