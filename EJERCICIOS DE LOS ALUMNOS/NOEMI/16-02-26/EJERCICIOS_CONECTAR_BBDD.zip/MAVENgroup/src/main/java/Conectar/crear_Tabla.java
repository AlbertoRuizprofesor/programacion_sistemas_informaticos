package Conectar;
import java.sql.PreparedStatement;


	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;
	import java.sql.Statement;

	public class crear_Tabla {

		public static void main(String[] args) throws SQLException {
			// TODO Auto-generated method stub
			// TODO Auto-generated method stub
			Connection conn=null;
			PreparedStatement stmt=null; //objeto utilizado para crear setencias
			String sql="CREATE TABLE IF NOT EXISTS cursos (id INT PRIMARY KEY,"
					+ "nombre VARCHAR(50) NOT NULL,"
					+ "profesor VARCHAR(50) NOT NULL,"
					+ "horas INT (60))";
			try {
				//desde aqui se encarga del driver JDBC
				conn = DriverManager.getConnection("jdbc:mysql://localhost/academia","root","");
				//controlamos que la conexion ha sido ok
				stmt=conn.prepareStatement(sql); //creamos 	 un canal que comunica es como prparar el prompt
				stmt.execute(sql);
				System.out.println("Tabla creada");
				conn.close();
				stmt.close();
			}
			catch(SQLException e) {
				{e.printStackTrace();			
				System.out.println("Error en la conexion "+((Throwable) e).getMessage());
				
				}
		}

	}
	}



