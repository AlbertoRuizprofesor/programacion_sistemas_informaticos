package Conectar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class mostrar_cursos_horas_mayoroigual {

    public static void main(String[] args) {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el número mínimo de horas: ");
        int horasMinimas = sc.nextInt();

        String sql = "SELECT * FROM cursos WHERE horas >= ?";

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/Academia", "root", "");
            pstmt = conn.prepareStatement(sql);

            // Reemplaza el ?
            pstmt.setInt(1, horasMinimas);

            rs = pstmt.executeQuery();

            boolean hayResultados = false;

            System.out.println("\nCursos encontrados:\n");

            while (rs.next()) {
                hayResultados = true;

                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String profesor = rs.getString("profesor");
                int horas = rs.getInt("horas");

                System.out.println("ID: " + id +
                                   " | Nombre: " + nombre +
                                   " | Profesor: " + profesor +
                                   " | Horas: " + horas);
            }

            if (!hayResultados) {
                System.out.println("No hay cursos con " + horasMinimas + " horas o más.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error en la conexión: " + e.getMessage());
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            sc.close();
        }
    }
}
