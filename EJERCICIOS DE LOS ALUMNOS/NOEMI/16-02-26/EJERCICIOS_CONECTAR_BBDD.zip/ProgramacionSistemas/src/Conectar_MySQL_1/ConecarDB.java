package Conectar_MySQL_1;
import java.sql.*;



public class ConecarDB {

	public static void main(String[] args)  throws SQLException {
		// TODO Auto-generated method stub
		Connection conn=null;
		try {
			//desde aqui se encarga del driver JDBC
			conn = DriverManager.getConnection("jdbc:mysql://localhost/tienda_fp_techstore","root","");
			//controlamos que la conexion ha sido ok
			if (conn !=null) {
				System.out.println("Conexion a base de datos Ok");
				conn.close();
			}
		}
		catch(SQLException e) {
			System.out.println("Error en la conexion "+((Throwable) e).getMessage());
	}

}
}
