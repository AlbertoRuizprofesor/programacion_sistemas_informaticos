package Conectar_MySQL_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Inset {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		Connection conn=null;
		Statement stmt=null; //objeto utilizado para crear setencias
		String sql="INSERT INTO clientes2 (id, "
				+ "nif, nombre, edad)"+
				" VALUES (2,'11112','Nubia',20)";
		try {
			//desde aqui se encarga del driver JDBC
			conn = DriverManager.getConnection("jdbc:mysql://localhost/tienda_fp_techstore","root","");
			//controlamos que la conexion ha sido ok
			stmt=conn.createStatement(); //creamos 	 un canal que comunica es como prparar el prompt
			stmt.executeUpdate(sql); //se cambia aqui lo que se quiere hacer
			System.out.println("Conexion base de datos ok");
			conn.close();
			stmt.close();
		}
		catch(SQLException e) {
			{e.printStackTrace();			
			System.out.println("Error en la conexion "+((Throwable) e).getMessage());
			
			}
	}

}
}

