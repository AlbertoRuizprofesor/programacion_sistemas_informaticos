package Conectar_MySQL_2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Crear_Tabla {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		Connection conn=null;
		Statement stmt=null; //objeto utilizado para crear setencias
		String sql="CREATE TABLE proveedores (id INT PRIMARY KEY,"
				+ "nombre VARCHAR(60) NOT NULL,"
				+ "telefono INT (9),"
				+ "email VARCHAR(20))";
		try {
			//desde aqui se encarga del driver JDBC
			conn = DriverManager.getConnection("jdbc:mysql://localhost/empresa1","root","");
			//controlamos que la conexion ha sido ok
			stmt=conn.createStatement(); //creamos 	 un canal que comunica es como prparar el prompt
			stmt.execute(sql);
			System.out.println("Tabla creada");
			conn.close();
			stmt.close();
		}
		catch(SQLException e) {
			{e.printStackTrace();			
			System.out.println("Error en la conexion "+((Throwable) e).getMessage());
			
			}
	}

}
}
