package Conectar_MySQL_2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Mostrar_Datos {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		Connection conn=null;
		Statement stmt=null; //objeto utilizado para crear setencias
		String sql="SELECT * FROM proveedores";
		try {
			//desde aqui se encarga del driver JDBC
			conn = DriverManager.getConnection("jdbc:mysql://localhost/empresa1","root","");
			//controlamos que la conexion ha sido ok
			stmt=conn.createStatement(); //creamos 	 un canal que comunica es como prparar el prompt
		    ResultSet rs=stmt.executeQuery(sql); //creamos un objeto para mostrar tdo, query es consulta en ingles
		
			while (rs.next()) {	
			int id=rs.getInt("id");
			String nombre=rs.getString("nombre");
			int telefono=rs.getInt("telefono");
			String email=rs.getString("email");
			System.out.println("id: "+id+", nombre: "+nombre+"Telefono: "+telefono+" Email: "+email);
			}
			conn.close();
			stmt.close();
			rs.close();
		
		}
		catch(SQLException e) {
			{e.printStackTrace();			
			System.out.println("Error en la conexion "+((Throwable) e).getMessage());
			
			}
	
}
}
}