package Adapter;

public class CelsiusTemperature {
	private double value;
	
	public CelsiusTemperature(double value) {
		this.value = value;
	}

	public double getValue() {
		return value;
	}
	
	

}
