package Adapter;

public class CelsiusToFahrenheitConverter implements TemperatureConverter {
	 @Override
	 public double convertCelciusToFahrenheit(double celsius) {
	     return (celsius * 9 / 5) + 32;
	 }
	}
