package Adapter;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double temp=25;
		CelsiusTemperature celsiusTemp=new CelsiusTemperature(temp);
		
		TemperatureAdapter adapter=new TemperatureAdapter(celsiusTemp);
		
		double fahrenheitTemp = adapter.convertCelciusToFahrenheit(celsiusTemp.getValue());
		
		System.out.println("la temperatura en grados es: "+temp);
	    System.out.println("La temperatura en Fahrenheit: " + fahrenheitTemp);




	}

}
