package Adapter;

public class TemperatureAdapter implements TemperatureConverter{
	private CelsiusTemperature celsiusTemperature;

	 public TemperatureAdapter(CelsiusTemperature celsiusTemperature) {
	     this.celsiusTemperature = celsiusTemperature;
	 }

	 @Override
	 public double convertCelciusToFahrenheit(double celsius) {
	     return new CelsiusToFahrenheitConverter().convertCelciusToFahrenheit(celsiusTemperature.getValue());
	 }
	}

