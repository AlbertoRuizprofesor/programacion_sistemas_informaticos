package Adapter;

public interface TemperatureConverter {
	double convertCelciusToFahrenheit(double celsius);

}
