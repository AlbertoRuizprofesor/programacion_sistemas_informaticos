package Adapter_2;

public class DistanciaAdapter implements DistanciaConverter {
	private KmMillas kmMillas;

	public DistanciaAdapter(KmMillas kmMillas) {
		this.kmMillas = kmMillas;
	}
	@Override
	public double convertKmToMillas(double km) {
		return new KmToMillasConverter().convertKmToMillas(kmMillas.getValue());
	}
	

}
