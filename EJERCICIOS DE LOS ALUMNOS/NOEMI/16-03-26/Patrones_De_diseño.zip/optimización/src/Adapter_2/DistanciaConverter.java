package Adapter_2;

public interface DistanciaConverter {
	double convertKmToMillas(double km);

}
