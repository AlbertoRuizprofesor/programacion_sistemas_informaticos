package Adapter_2;

public class KmMillas {
	private double value;

	public KmMillas(double value) {
		this.value = value;
		
		
	}

	public double getValue() {
		return value;
	}
	
	

}
