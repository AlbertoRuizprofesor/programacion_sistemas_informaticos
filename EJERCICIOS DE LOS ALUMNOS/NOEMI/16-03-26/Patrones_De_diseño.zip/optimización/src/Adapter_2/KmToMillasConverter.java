package Adapter_2;

public class KmToMillasConverter implements DistanciaConverter {
	@Override
	public double convertKmToMillas(double km) {
		return (km*0.621371);
	}

}
