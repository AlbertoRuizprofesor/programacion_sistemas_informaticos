package Adapter_2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double distancia=10;
		KmMillas kmMillas=new KmMillas(distancia);
		
		DistanciaAdapter adapter=new DistanciaAdapter(kmMillas);
		
		double millasdistancia= adapter.convertKmToMillas(kmMillas.getValue());
		
		System.out.println("La distancia en kilometros es: "+distancia);
		System.out.println("La distancia en millas es: "+millasdistancia);

	}

}
