package Builder;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Producto producto= new ProductoBuilder()
							.nombre("Camiseta")
							.precio(20.0)
							.color("Rosa")
							.talla(36.5)
							.fabricante("Primark")
							.modelo("Skinner")
							.build();
		
		producto.imprimirDetalles();

	}

}
