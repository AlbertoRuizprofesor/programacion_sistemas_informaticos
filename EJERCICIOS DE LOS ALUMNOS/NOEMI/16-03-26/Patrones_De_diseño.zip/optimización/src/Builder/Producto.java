package Builder;

public class Producto {
	private String nombre;
	private double precio;
	private String color;
	private double talla;
	private String fabricante;
	private String modelo;
	
	
	public Producto(String nombre, double precio, String color, double talla, String fabricante, String modelo) {
		this.nombre = nombre;
		this.precio = precio;
		this.color = color;
		this.talla = talla;
		this.fabricante = fabricante;
		this.modelo = modelo;
	
	
	}
	public String getNombre() {
		return nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public String getColor() {
		return color;
	}
	public double getTalla() {
		return talla;
	}
	public String getFabricante() {
		return fabricante;
	}
	public String getModelo() {
		return modelo;
	}
	public void imprimirDetalles() {
		System.out.println("|- Nombre: "+nombre+
							". \n|- Precio: "+precio+
							". \n|- Color: "+color+
							". \n|- Talla: "+talla+
							". \n|- fabricante: "+fabricante+
							". \n|- Modelo: "+modelo+".");
	}

}
