package Builder_2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Producto producto= new ProductoBuilder2()
							.nombre("Kindomg Hearts")
							.año(2006)
							.precio(80.0)
							.plataforma("Juego de plataforma")
							.sipnosis("Jugador en Disney")
							.requerimientos_minimos("Play Station 2")
							.build();
								
								
		producto.imprimirDetalles();

	}

}
