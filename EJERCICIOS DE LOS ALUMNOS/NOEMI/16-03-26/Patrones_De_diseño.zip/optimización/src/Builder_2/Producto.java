package Builder_2;

public class Producto {
	private String nombre;
	private int año;
	private double precio;
	private String plataforma;
	private String sipnosis;
	private String requerimientos_minimos;
	
	public Producto(String nombre, int año, double precio, String plataforma, String sipnosis,
			String requerimientos_minimos) {
		super();
		this.nombre = nombre;
		this.año = año;
		this.precio = precio;
		this.plataforma = plataforma;
		this.sipnosis = sipnosis;
		this.requerimientos_minimos = requerimientos_minimos;
	}

	public String getNombre() {
		return nombre;
	}

	public int getAño() {
		return año;
	}

	public double getPrecio() {
		return precio;
	}

	public String getPlataforma() {
		return plataforma;
	}

	public String getSipnosis() {
		return sipnosis;
	}

	public String getRequerimientos_minimos() {
		return requerimientos_minimos;
	}
	
	public void imprimirDetalles() {
		System.out.println("|- Nombre: "+nombre+
							". \n|- Año: "+año+
							". \n|- Precio: "+precio+
							". \n|- Plataforma: "+plataforma+
							". \n|- Sipnosis: "+sipnosis+
							". \n|- Requerimientos mínimos: "+requerimientos_minimos+"."
							);
}
	}
	
	

	

