package Builder_2;


public class ProductoBuilder2 {
	private String nombre;
	private int año;
	private double precio;
	private String plataforma;
	private String sipnosis;
	private String requerimientos_minimos;
	
	public ProductoBuilder2 nombre(String nombre) {
		this.nombre = nombre;
		return this;
	
	}
	public ProductoBuilder2 año(int año) {
		this.año=año;
		return this;
	}
		public ProductoBuilder2 precio(double precio) {
			this.precio=precio;
			return this;
	}
	public ProductoBuilder2 plataforma(String plataforma) {
		this.plataforma=plataforma;
		return this;
	}
	public ProductoBuilder2 sipnosis(String sipnosis) {
		this.sipnosis=sipnosis;
		return this;
	}
	public ProductoBuilder2 requerimientos_minimos(String requerimientos_minimos) {
		this.requerimientos_minimos=requerimientos_minimos;
		return this;
	}
	public Producto build() {
		return new Producto(nombre, año, precio, plataforma, sipnosis,requerimientos_minimos);
	}

}
