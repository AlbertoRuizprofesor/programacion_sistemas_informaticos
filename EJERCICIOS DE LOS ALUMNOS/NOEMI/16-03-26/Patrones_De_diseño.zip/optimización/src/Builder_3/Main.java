package Builder_3;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cocina cocina=new Cocina();
		PizzaBuilder builder= new PizzaBarbacoa();
		
		PizzaBuilder builder2=new PizzaCarbonara();
		
		cocina.setBuilder(builder);
		cocina.construirPizza();
		Pizza pizza =cocina.getPizza();
		pizza.mostrar();
		
		cocina.setBuilder(builder2);
		cocina.construirPizza();
		Pizza pizza2=cocina.getPizza();
		pizza2.mostrar();

	}

}
