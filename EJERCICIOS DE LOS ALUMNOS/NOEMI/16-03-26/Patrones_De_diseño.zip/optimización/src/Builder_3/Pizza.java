package Builder_3;

class Pizza {
     String masa;
	 String salsa;
	 String relleno;
	 String size;
	
	public Pizza(String masa, String salsa, String relleno, String size) {
		super();
		this.masa = masa;
		this.salsa = salsa;
		this.relleno = relleno;
	
	}


	public void mostrar() {
		System.out.println("Pizza: Masa-" + masa + ", Salsa-" + salsa + ", Relleno-" + relleno
				   +" ,Size:"+size);
	}
}