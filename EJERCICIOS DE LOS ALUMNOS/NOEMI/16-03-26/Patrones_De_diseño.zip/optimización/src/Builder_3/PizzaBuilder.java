package Builder_3;

public interface PizzaBuilder {
	void construirMasa();
	void construirSalsa();
	void construirRelleno();
	
	Pizza getPizza();
	void construirSize();

}
