package Builder_3;

public class PizzaCarbonara implements PizzaBuilder {
	private Pizza pizza;
	
	public PizzaCarbonara() {
		pizza=new Pizza("ancha","Nata","Bacon","Familiar");
		
	}
	@Override
	public void construirMasa() {
		pizza.masa="masa grande";
		
	}
	@Override
	public void construirSalsa() {
		pizza.salsa="Nata";
	}
	@Override
	public void construirRelleno() {
		pizza.relleno="Bacon de pavo";
	
	}
	@Override
	public void construirSize() {
		pizza.size="Mediana";
	}
	@Override
	public Pizza getPizza() {
		return pizza;
	}
}
