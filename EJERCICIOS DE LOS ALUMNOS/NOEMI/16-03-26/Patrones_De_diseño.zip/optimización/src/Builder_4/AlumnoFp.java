package Builder_4;

public interface AlumnoFp {
	void describir();

}
