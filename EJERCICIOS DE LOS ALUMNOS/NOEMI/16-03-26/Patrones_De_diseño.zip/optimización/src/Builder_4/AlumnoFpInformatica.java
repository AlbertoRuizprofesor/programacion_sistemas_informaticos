package Builder_4;

public class AlumnoFpInformatica implements AlumnoFp{
	public void describir() {
		System.out.println("Alumno de la rama Informatica");
	}

}
