package Builder_4;

public class AlumnoFpSanitaria implements AlumnoFp{
	public void describir()  {
		System.out.println("Alumno de la rama Sanitaria");
	}

}
