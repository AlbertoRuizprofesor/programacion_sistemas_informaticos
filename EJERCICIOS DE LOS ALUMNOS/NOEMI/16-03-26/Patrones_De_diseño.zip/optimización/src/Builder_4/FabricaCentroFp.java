package Builder_4;

interface FabricaCentroFp {
	ProfesorFp crearProfesor();
	AlumnoFp crearAlumno();
	

}
