package Builder_4;

public class FabricaCentroFpInformatica implements FabricaCentroFp {
	public ProfesorFp crearProfesor() {
		return new ProfesorFpInformatica();
	}
	public AlumnoFp crearAlumno() {
		return new AlumnoFpInformatica();
	}

}
