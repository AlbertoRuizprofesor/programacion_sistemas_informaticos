package Builder_4;

public class FabricaCentroFpSanitaria implements FabricaCentroFp{
	public ProfesorFp crearProfesor() {
		return new ProfesorFpSanitaria();
	}
	public AlumnoFp crearAlumno() {
		return new AlumnoFpSanitaria();
	}

}
