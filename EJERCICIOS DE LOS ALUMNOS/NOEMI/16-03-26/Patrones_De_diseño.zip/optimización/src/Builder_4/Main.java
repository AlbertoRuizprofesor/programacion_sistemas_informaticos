package Builder_4;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FabricaCentroFp fabrica=new FabricaCentroFpInformatica();
		
		ProfesorFp profesor= fabrica.crearProfesor();
		AlumnoFp alumno=fabrica.crearAlumno();
		
		profesor.describir();
		alumno.describir();
		System.out.println("********************");
		
		FabricaCentroFp fabrica2=new FabricaCentroFpSanitaria();
		
		ProfesorFp profesor2=fabrica2.crearProfesor();
		AlumnoFp alumno2=fabrica2.crearAlumno();
		
		profesor2.describir();
		alumno2.describir();

	}

}
