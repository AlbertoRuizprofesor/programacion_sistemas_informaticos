package Builder_4;

public interface ProfesorFp {
	void describir();

}
