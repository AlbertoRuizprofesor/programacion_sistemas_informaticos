package Builder_4;

public class ProfesorFpInformatica implements ProfesorFp{
	public void describir() {
		System.out.println("Profesor de la rama Informática");
	}

}
