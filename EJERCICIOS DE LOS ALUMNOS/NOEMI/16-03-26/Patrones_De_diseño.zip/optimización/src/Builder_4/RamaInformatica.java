package Builder_4;

public class RamaInformatica implements ProfesorFp{
	public void describir() {
		  System.out.println("Profesor de la rama Informatica");
	}

}
