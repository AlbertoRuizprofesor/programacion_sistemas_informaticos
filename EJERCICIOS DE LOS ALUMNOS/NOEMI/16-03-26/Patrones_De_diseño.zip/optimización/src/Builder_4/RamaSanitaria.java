package Builder_4;

public class RamaSanitaria implements ProfesorFp {
	public void describir() {
		  System.out.println("Profesor de la rama sanitaria");
	}

}
