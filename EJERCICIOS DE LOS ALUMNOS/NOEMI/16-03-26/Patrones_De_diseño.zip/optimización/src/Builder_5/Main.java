package Builder_5;

public class Main {

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		Persona personaOriginal=new Persona ("Noemi");
		
		Persona personaClonada=(Persona) personaOriginal.clone();
		
        System.out.println("Persona original: " + personaOriginal.getNombre());
        System.out.println("Persona clonada: " + personaClonada.getNombre());

        personaClonada.setNombre("Sara");
        
        System.out.println("Persona original después de modificar el clon: " + personaOriginal.getNombre());
        System.out.println("Persona clonada después de modificarla: " + personaClonada.getNombre());


	}

}
