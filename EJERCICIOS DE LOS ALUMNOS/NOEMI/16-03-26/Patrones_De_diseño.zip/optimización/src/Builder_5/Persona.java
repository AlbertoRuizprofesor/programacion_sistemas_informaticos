package Builder_5;

class Persona implements Cloneable {
	private String nombre;

	public Persona(String nombre) {
		super();
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	// Sobrescribir el método clone() que da la interfaz cloneable
	 @Override
	 public Object clone() throws CloneNotSupportedException {
	     return super.clone();
	 }
	

}
