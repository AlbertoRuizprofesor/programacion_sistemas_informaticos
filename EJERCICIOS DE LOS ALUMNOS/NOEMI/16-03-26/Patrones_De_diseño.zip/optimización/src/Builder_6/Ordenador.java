package Builder_6;

public interface Ordenador extends Cloneable {
	Ordenador clonar();
	void especificaciones();

}
