package Command_Pattern;

public class EncenderLuz implements Command{
	private Luz luz;
	
	public EncenderLuz (Luz luz) {
		this.luz=luz;
	}

	@Override
	public void ejecutar() {
		luz.encender();
		
	}
	
}
