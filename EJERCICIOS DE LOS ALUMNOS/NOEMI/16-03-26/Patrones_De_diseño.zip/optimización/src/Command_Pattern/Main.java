package Command_Pattern;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Luz luz=new Luz();
		
		Command comandoencender=new EncenderLuz(luz);
		Command comandoapagar=new ApagarLuz(luz);
		
		ControlRemoto control=new ControlRemoto();
		
		control.setComando(comandoencender);
		control.presionarBoton();
		
		control.setComando(comandoapagar);
		control.presionarBoton();
	}

}
