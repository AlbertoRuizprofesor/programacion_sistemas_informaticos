package Command_Pattern_2;

public class ApagarPC implements Comando{
	private Ordenador pc;


	public ApagarPC(Ordenador pc) {
		this.pc = pc;
	
	}

	@Override
	public void ejecutar() {
		pc.apagado();
		
	}
	
	

}
