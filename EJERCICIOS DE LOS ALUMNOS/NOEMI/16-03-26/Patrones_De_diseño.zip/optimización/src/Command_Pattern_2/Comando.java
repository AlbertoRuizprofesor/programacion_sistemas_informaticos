package Command_Pattern_2;

public interface Comando {
	void ejecutar();

}
