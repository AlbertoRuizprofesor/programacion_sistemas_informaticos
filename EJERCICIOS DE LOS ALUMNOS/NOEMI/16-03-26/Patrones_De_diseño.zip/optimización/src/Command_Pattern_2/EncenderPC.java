package Command_Pattern_2;

public class EncenderPC implements Comando {
	private Ordenador pc;

	public EncenderPC(Ordenador pc) {
		this.pc = pc;
	}

	@Override
	public void ejecutar() {
		pc.encendido();
		
	}
	

}
