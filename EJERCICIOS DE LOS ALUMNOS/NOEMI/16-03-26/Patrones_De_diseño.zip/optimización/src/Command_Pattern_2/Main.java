package Command_Pattern_2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ordenador pc=new Ordenador();
		
		Comando encender=new EncenderPC(pc);
		Comando apagar=new ApagarPC(pc);
		
		ControlRemoto control=new ControlRemoto();
		
		control.setComando(encender);
		control.presionarBoton();
		
		control.setComando(apagar);
		control.presionarBoton();
		


	}

}
