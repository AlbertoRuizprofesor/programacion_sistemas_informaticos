package Command_Pattern_2;

public class Ordenador {
	public void encendido() {
		System.out.println("Ordenador encendido");
    }

    public void apagado() {
        System.out.println("Ordenador apagado");


		
	}

}
