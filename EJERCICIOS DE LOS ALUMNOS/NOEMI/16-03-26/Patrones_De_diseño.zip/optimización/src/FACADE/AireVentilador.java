package FACADE;

public class AireVentilador {
	public void encender() {
		System.out.println("ventilador encendido");

	}

}
