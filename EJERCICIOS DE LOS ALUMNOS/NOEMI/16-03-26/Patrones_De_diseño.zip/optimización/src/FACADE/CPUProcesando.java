package FACADE;

public class CPUProcesando {
	public void procesar() {
		System.out.println("CPU Procesando...");
	}

}
