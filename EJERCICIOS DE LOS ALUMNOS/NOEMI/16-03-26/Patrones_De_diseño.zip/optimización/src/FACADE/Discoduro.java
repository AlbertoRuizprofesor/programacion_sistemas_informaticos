package FACADE;

public class Discoduro {
	public void cargar() {
		System.out.println("Disco duro cargando....");
	}

}
