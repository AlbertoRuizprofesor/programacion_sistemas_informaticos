package FACADE;

public class FacadePortatil {
	private Portatil portatil;
	private CPUProcesando cpuprocesando;
	private AireVentilador aireventilador;
	private Discoduro discoduro;
	private Servicioscerrados servicioscerrados;
	
	public FacadePortatil() {
		this.portatil = new Portatil();
		this.cpuprocesando = new CPUProcesando();
		this.aireventilador = new  AireVentilador();
		this.discoduro = new Discoduro();
		this.servicioscerrados = new Servicioscerrados();
		
	}
	
	public void encenderPortatil() {
		portatil.encender();
		cpuprocesando.procesar();
		discoduro.cargar();
		aireventilador.encender();
		System.out.println("Windows iniciado");
	}
	public void apagarPortatil() {
		servicioscerrados.cerrar();
		portatil.apagar();
		System.out.println("Windows cerrado.");
	}
	
	
	}

