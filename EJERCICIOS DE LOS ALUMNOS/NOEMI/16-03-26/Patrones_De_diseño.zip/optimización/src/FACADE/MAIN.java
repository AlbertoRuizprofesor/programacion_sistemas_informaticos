package FACADE;

public class MAIN {

	public static void main(String[] args) {
		FacadePortatil portatil=new FacadePortatil();
		
		portatil.encenderPortatil();
		System.out.println("*".repeat(30));
		portatil.apagarPortatil();

	}

}
