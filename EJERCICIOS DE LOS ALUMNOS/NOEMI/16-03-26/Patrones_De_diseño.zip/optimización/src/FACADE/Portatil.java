package FACADE;

public class Portatil {
	public void encender() {
		System.out.println("Portatil encendido");
	}
	public void apagar() {
		System.out.println("Portatil apagado");
	}

}
