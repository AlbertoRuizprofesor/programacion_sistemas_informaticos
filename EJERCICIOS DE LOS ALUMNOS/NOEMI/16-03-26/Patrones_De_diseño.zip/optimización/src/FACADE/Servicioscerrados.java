package FACADE;

public class Servicioscerrados {
	public void cerrar() {
		System.out.println("Servicios cerrados.");
	}

}
