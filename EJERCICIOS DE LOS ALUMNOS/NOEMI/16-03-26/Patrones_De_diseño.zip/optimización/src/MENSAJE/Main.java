package MENSAJE;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mensaje mensaje = new MensajeBasico("Buenos días corazón de melón.");
		
		Mensaje mensajeDecorado= new MensajeConPieDePagina ( new MensajeConResumen ( new MensajeConEncabezado (mensaje, "****Titulo****"), "Resumen breve del  mensaje"), 1);
		
		System.out.println(mensajeDecorado.obtenerContenido());

		//Mensaje mensajeConEncabezado = new MensajeConEncabezado(mensaje, "Es importante.");

		// Agregamos pie de página con número de página
		//Mensaje mensajeConPie = new MensajeConPieDePagina(mensajeConEncabezado, 1);

		//System.out.println(mensajeConPie.obtenerContenido());
	}

}
