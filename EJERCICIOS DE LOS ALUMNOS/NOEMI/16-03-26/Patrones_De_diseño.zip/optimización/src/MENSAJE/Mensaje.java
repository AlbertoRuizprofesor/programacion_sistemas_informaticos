package MENSAJE;

public interface Mensaje {
	String obtenerContenido();
	
	

}
