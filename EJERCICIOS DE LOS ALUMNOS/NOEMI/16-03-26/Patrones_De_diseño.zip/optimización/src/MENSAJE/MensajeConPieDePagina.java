package MENSAJE;

public class MensajeConPieDePagina implements Mensaje {
	private Mensaje mensaje;
	private int piedepagina;
	
	public MensajeConPieDePagina(Mensaje mensaje, int piedepagina) {
		this.mensaje = mensaje;
		this.piedepagina = piedepagina;
	}

	@Override
	public String obtenerContenido() {
		 String contenido = mensaje.obtenerContenido();

	        // Formatear para que la página salga alineada a la derecha (asumiendo ancho 50)
	        int ancho = 50;
	        String paginaStr = "Página " + piedepagina;
	        int espacios = ancho - paginaStr.length();
	        if (espacios < 0) espacios = 0;
	        String alineado = " ".repeat(espacios) + paginaStr;

	        return contenido + "\n" + alineado +".";
	}
	
	
	

}
