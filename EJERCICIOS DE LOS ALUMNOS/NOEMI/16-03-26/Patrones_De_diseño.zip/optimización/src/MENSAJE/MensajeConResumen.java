package MENSAJE;

public class MensajeConResumen implements Mensaje {
	private Mensaje mensaje;
	private String Mensajeconresumen;
	
	public MensajeConResumen(Mensaje mensaje, String mensajeconresumen) {
		this.mensaje = mensaje;
		Mensajeconresumen = mensajeconresumen;
		
		
	}

	@Override
	public String obtenerContenido() {
		String contenido = mensaje.obtenerContenido();
		return contenido + "\nResumen: "+ Mensajeconresumen;
		}
	
	
	
	

}
