package OBSERVER;

public class Barradeestado implements Observer{
	private SistemaVentaProductos sistemaVentaProductos;

	public Barradeestado(SistemaVentaProductos sistemaVentaProductos) {
		this.sistemaVentaProductos = sistemaVentaProductos;
		this.sistemaVentaProductos.agregarObservador(this);
	}

	@Override
	public void actualizar(int cantidadVendida) {
		System.out.println("Se vendió un producto. Total de ventas: "+cantidadVendida);
		
	}


	
	}

