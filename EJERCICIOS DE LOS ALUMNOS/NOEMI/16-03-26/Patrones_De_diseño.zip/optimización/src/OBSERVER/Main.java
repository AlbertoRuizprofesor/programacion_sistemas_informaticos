package OBSERVER;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SistemaVentaProductos sistemaventaproductos=new SistemaVentaProductos();
		
		Barradeestado barraestado=new Barradeestado(sistemaventaproductos);
		
		sistemaventaproductos.venderProducto(5);
		
		sistemaventaproductos.eliminarObservador(barraestado);
		
		sistemaventaproductos.venderProducto(3);
		
		sistemaventaproductos.agregarObservador(barraestado);
		
		sistemaventaproductos.venderProducto(2);
		
		

	}

}
