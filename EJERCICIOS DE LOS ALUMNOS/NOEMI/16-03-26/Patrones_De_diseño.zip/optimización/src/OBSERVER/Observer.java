package OBSERVER;

public interface Observer {
	void actualizar(int cantidadVendida);

}
