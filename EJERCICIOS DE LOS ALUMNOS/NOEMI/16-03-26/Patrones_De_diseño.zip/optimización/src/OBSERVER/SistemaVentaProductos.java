package OBSERVER;

import java.util.ArrayList;
import java.util.List;

public class SistemaVentaProductos {
	private List<Observer> observadores =new ArrayList<>();
	
	private int totalVentas= 0;
	
	public void agregarObservador(Observer observador) {
		observadores.add(observador);
	}
	public void eliminarObservador(Observer observador) {
		observadores.remove(observador);
	}
	public void venderProducto(int cantidad) {
		totalVentas += cantidad;
		
		notificarObservadores(cantidad);
	}
	
	private void notificarObservadores(int cantidadVentidad) {
		for (Observer observador : observadores) {
			observador.actualizar(cantidadVentidad);
		}
		
		
	}

}
