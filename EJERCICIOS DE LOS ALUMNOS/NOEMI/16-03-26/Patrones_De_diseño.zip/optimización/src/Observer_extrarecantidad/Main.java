package Observer_extrarecantidad;

public class Main {

	public static void main(String[] args) {
		SistemadeLimite sistema=new SistemadeLimite();
		
		Usuario cenec = new Usuario(30);
		sistema.agregarObservador(cenec);
		
		sistema.setCantidad(1800);
		sistema.setCantidad(200);
		

	}

}
