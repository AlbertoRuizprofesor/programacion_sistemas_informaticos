package Observer_extrarecantidad;

public interface Observer {
	void actualizar(double cantidad);

}
