package Observer_extrarecantidad;

import java.util.ArrayList;
import java.util.List;

public class SistemadeLimite {
	private List<Observer> observadores=new ArrayList<>();
	private double cantidad;
	private double limitedinero = 1000;
	
	public void agregarObservador(Observer observador) {
		observadores.add(observador);
	}
	public void eliminarObservador(Observer observador) {
		observadores.remove(observador);
	}
	public void setCantidad (double cantidad) {
		
		this.cantidad=cantidad;
		
		if (cantidad >= limitedinero) {
		notificarObservadores(cantidad);
	}
	}
	private void notificarObservadores(double cantidad) {
		for (Observer observador : observadores)
		observador.actualizar(cantidad);
		}
		
	}
	
	

