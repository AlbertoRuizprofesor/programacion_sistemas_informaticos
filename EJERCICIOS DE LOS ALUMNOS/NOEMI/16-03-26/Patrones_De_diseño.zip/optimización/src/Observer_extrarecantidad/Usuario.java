package Observer_extrarecantidad;

public class Usuario implements Observer{
	private double limite;

	public Usuario(double limite) {
		this.limite = limite;
	}

	@Override
	public void actualizar(double cantidad) {
		if (cantidad > limite) {
			System.out.println("Error ha excecido el limite de su credito- 1000, no puede solicitar la cantidad: $"+cantidad);
		}
		
	}
	
	
	

}
