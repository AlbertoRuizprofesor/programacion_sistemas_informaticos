package Observer_temperatura;

public class Barradeestado implements Observer{
	
	private SistemaDeTemperatura sistemadetemperatura;

 
    public Barradeestado(SistemaDeTemperatura sistemadetemperatura) {
		this.sistemadetemperatura = sistemadetemperatura;
	
	}

    // Método de la interfaz Observer que se llama cuando se actualiza el estado del observable
    public void actualizar(double temperatura) {
    	System.out.println("⚠ ALERTA: Temperatura superada!");
        System.out.println("Temperatura actual: " + temperatura + "°C");
    }
}
