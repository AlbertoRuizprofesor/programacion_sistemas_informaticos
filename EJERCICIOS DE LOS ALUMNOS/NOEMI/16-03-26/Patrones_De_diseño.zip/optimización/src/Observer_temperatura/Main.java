package Observer_temperatura;

public class Main {

	public static void main(String[] args) {
		SistemaDeTemperatura sistemadetemperatura = new SistemaDeTemperatura();
		
		Barradeestado barradeestado= new Barradeestado(sistemadetemperatura);
		
		sistemadetemperatura.agregarObservador(barradeestado);
		
		sistemadetemperatura.setTemperatura(20);
		sistemadetemperatura.setTemperatura(30);
		sistemadetemperatura.setTemperatura(90);
		

	}

}
