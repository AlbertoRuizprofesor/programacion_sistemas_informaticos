package Observer_temperatura;

public interface Observer {
	void actualizar(double temperatura);

}
