package Observer_temperatura;

import java.util.ArrayList;
import java.util.List;

public class SistemaDeTemperatura {
	private List<Observer> observadores = new ArrayList<>();
   
    private double temperaturamaxima = 30;

  
    public void agregarObservador(Observer observador) {
        observadores.add(observador);
    }


    public void eliminarObservador(Observer observador) {
        observadores.remove(observador);
    }
    
    public void setTemperatura(double temperatura) {
    	if (temperatura >= temperaturamaxima) {
    		notificarObservadores(temperatura);
    	}
    }
    
     private void notificarObservadores(double temperaturamaxima) {
            // Recorre la lista de observadores y llama al método actualizar de cada uno
            for (Observer observador : observadores) {
                // Se pasa la cantidad vendida como parámetro
                observador.actualizar(temperaturamaxima);
            }
        }
    }
