package Patrones_de_diseño;

public class Electrodomestico implements Producto {
	@Override
    public void venta() {
        System.out.println("venta de electrodoméstico.");
	}

}
