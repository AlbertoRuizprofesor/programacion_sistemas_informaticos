package Patrones_de_diseño;

public abstract class Fabrica {

    public abstract Producto crearProducto();
	}

