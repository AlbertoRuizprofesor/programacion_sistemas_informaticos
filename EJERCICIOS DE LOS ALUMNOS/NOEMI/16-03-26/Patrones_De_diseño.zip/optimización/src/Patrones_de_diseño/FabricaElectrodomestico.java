package Patrones_de_diseño;

public class FabricaElectrodomestico extends Fabrica {
    @Override
    public Producto crearProducto() {
        return new Electrodomestico();
    }


}
