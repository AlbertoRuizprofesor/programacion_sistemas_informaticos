package Patrones_de_diseño;

public class FabricaRopa extends Fabrica {

    @Override
    public Producto crearProducto() {
        return new Ropa();
    }

}
