package Patrones_de_diseño;

public class FabricaVehiculo extends Fabrica {
	   @Override
	    public Producto crearProducto() {
	        return new Vehiculo();
	    }

}
