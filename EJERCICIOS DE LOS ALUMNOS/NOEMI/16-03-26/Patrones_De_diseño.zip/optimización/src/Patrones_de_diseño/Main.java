package Patrones_de_diseño;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Fabrica fabricaElectrodomesticos = new FabricaElectrodomestico();
        // Utilizar la fábrica para crear un electrodoméstico
        Producto electrodomestico = fabricaElectrodomesticos.crearProducto();
        // Operar con el electrodoméstico
        electrodomestico.venta();

        
        
        
        // Crear una fábrica de ropa
        Fabrica fabricaRopa = new FabricaRopa();
        // Utilizar la fábrica para crear ropa
        Producto ropa = fabricaRopa.crearProducto();
        // Operar con la ropa
        ropa.venta();
        
        
        
        
        
        Fabrica fabricaVehiculo = new FabricaVehiculo();
        Producto vehiculo = fabricaVehiculo.crearProducto();
        vehiculo.venta();
    }


	}

