package Patrones_de_diseño;

public interface Producto {
	void venta();
	}

