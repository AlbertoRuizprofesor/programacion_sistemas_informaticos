package Patrones_de_diseño;

public class Ropa implements Producto {
	@Override
    public void venta() {
        System.out.println("venta de ropa.");
    }


}
