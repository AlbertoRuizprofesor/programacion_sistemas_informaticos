package Patrones_de_diseño;

public class Vehiculo implements Producto {
	@Override
    public void venta() {
        System.out.println("venta de vehiculo.");

}
}