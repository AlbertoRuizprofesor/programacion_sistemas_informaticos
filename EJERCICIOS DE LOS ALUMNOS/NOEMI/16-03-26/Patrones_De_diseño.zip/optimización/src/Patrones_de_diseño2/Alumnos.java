package Patrones_de_diseño2;

public class Alumnos implements Persona {
	@Override
    public void accion() {
        System.out.println("El alumno asiste a clases.");

}
}
