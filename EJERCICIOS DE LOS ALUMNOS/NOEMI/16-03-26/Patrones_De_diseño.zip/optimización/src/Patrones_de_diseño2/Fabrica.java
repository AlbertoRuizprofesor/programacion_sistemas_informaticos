package Patrones_de_diseño2;

public abstract class Fabrica {
	public abstract Persona crearPersona();

}
