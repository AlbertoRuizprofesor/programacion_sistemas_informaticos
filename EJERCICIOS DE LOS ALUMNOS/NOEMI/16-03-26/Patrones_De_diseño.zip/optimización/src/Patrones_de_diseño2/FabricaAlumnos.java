package Patrones_de_diseño2;


public class FabricaAlumnos extends Fabrica { 
	@Override
    public Persona crearPersona() {
        return new Alumnos();
}
}