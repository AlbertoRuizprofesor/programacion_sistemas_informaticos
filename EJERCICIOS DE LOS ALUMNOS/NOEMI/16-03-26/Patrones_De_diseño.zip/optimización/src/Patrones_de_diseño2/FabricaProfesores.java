package Patrones_de_diseño2;


public class FabricaProfesores extends Fabrica {
	@Override
    public Persona crearPersona() {
        return new Profesores();

}
}