package Patrones_de_diseño2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Fabrica fabricaAlumnos=new FabricaAlumnos();
		
		Persona alumnos= fabricaAlumnos.crearPersona();
		alumnos.accion();
		
		Fabrica fabricaprofesores=new FabricaProfesores();
		Persona profesores= fabricaprofesores.crearPersona();
		profesores.accion();
		
		

	}

}
