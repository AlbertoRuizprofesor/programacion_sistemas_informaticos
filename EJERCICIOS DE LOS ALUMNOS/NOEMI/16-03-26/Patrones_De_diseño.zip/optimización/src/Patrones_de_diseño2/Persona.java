package Patrones_de_diseño2;

public interface Persona {
	void accion();

}
