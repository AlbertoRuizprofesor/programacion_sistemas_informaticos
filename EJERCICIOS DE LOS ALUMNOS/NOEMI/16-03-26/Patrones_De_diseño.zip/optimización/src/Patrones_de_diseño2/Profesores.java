package Patrones_de_diseño2;

public class Profesores implements Persona{
	@Override
	public void accion() {
		 System.out.println("El profesor da clases.");
	}

}
