package Patrones_de_diseño3;

public interface FabricaMuebles {
	Silla crearSilla();
	Sofa crearSofa();
	Mesa crearMesa();

}
