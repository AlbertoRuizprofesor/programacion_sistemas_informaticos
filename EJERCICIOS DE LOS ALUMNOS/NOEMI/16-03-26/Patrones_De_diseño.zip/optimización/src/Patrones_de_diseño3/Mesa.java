package Patrones_de_diseño3;

public interface Mesa {
	void describir();

}
