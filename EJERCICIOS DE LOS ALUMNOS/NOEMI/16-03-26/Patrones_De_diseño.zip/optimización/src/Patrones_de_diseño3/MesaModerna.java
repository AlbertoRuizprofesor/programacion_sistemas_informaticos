package Patrones_de_diseño3;

public class MesaModerna implements Mesa {
	@Override
	public void describir() {
		System.out.println("Es una mesa Moderna");
	}

}
