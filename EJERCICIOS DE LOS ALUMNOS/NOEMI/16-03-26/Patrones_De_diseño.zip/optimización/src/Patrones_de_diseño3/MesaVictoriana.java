package Patrones_de_diseño3;

public class MesaVictoriana implements Mesa {
	public void describir() {
		System.out.println("Esta es una mesa victoriana");
	}

}
