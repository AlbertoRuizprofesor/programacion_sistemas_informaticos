package Patrones_de_diseño3;

public interface Silla {
	void describir();
	}
