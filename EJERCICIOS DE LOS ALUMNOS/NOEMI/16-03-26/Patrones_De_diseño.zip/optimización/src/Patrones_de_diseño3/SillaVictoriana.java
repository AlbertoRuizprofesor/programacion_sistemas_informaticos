package Patrones_de_diseño3;

public class SillaVictoriana implements Silla {
    @Override
    public void describir() {
        System.out.println("Esta es una silla victoriana.");
    }


}
