package Patrones_de_diseño3;

public interface Sofa {
	void describir();

}
