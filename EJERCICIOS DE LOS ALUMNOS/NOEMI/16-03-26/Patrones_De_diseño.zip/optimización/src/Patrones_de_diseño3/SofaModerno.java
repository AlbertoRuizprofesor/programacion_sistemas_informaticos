package Patrones_de_diseño3;

public class SofaModerno implements Sofa {
    @Override
    public void describir() {
        System.out.println("Este es un sofá moderno.");
    }


}
