package Patrones_de_diseño3;

public class SofaVictoriano implements Sofa {
    @Override
    public void describir() {
        System.out.println("Este es un sofá victoriano.");
    }
}


