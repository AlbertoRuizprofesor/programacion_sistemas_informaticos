package Patrones_de_diseño3;

public class abstractfatory1 {
	public static void main(String[] args) {
        // Crear una fábrica de muebles modernos
        FabricaMuebles fabricaModernos = new FabricaMueblesModernos();
        // Utilizar la fábrica para crear muebles modernos
        Silla sillaModerna = fabricaModernos.crearSilla();
        Sofa sofaModerno = fabricaModernos.crearSofa();
        Mesa mesaModerna= fabricaModernos.crearMesa();

        sillaModerna.describir();
        sofaModerno.describir();
        mesaModerna.describir();
        System.out.println("********************************");

        // Crear una fábrica de muebles victorianos
        FabricaMuebles fabricaVictorianos = new FabricaMueblesVictorianos();
        // Utilizar la fábrica para crear muebles victorianos
        Silla sillaVictoriana = fabricaVictorianos.crearSilla();
        Sofa sofaVictoriano = fabricaVictorianos.crearSofa();
        Mesa mesaVictoriana = fabricaVictorianos.crearMesa();

        sillaVictoriana.describir();
        sofaVictoriano.describir();
        mesaVictoriana.describir();
        
       
        
	}
}


