package Proxy;

public interface Documento {
	void mostrar();

}
