package Proxy;

public class MAIN {

	public static void main(String[] args) {
		Documento documento= new ProxyDocumento( "documento.pdf");
		
		documento.mostrar();
		
		documento.mostrar();
		

	}

}
