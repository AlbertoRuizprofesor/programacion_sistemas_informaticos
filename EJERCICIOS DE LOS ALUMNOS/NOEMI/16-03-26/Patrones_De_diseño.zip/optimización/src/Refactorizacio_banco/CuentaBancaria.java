package Refactorizacio_banco;

public class CuentaBancaria {
	    private double saldo;
		public double setSaldo;

	    public CuentaBancaria(double saldoInicial) {
	        this.setSaldo(saldoInicial);
	    }

	    public double getSaldo() {
	        return saldo;
	    }

		public void setSaldo(double saldo) {
			this.saldo = saldo;
		}}



