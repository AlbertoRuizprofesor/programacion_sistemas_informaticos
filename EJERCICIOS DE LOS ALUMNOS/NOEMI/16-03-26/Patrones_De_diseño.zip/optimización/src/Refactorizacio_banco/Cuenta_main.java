package Refactorizacio_banco;

public class Cuenta_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        CuentaBancaria cuenta = new CuentaBancaria(1000.0);
        Transaccion transaccion = new Transaccion(cuenta);
        transaccion.realizarRetiro(500.0);


	}

}
