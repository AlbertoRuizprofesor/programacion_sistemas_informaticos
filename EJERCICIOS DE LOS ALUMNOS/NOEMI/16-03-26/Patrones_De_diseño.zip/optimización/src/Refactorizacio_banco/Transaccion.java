package Refactorizacio_banco;

public class Transaccion {
	private CuentaBancaria cuenta;

    public Transaccion(CuentaBancaria cuenta) {
        this.cuenta = cuenta;
        
    }
    public CuentaBancaria getCuenta() {
		return cuenta;
	}
	public void setCuenta(CuentaBancaria cuenta) {
		this.cuenta = cuenta;
	}
	public void realizarRetiro(double cantidad) {
        double saldo = cuenta.getSaldo();
        if (cantidad > saldo) {
            System.out.println("Saldo insuficiente");
        } else {
            cuenta.setSaldo -= cantidad;
            System.out.println("Retiro exitoso de " + cantidad + " unidades");
            System.out.println("Saldo restante: " + cuenta.setSaldo);

		}
	}

}
