package Refactorización;

public class ClaseDestino2 {
	  public void metodoDestino() {
	        System.out.println("Este es el método de la clase de destino2");
	    }


}
