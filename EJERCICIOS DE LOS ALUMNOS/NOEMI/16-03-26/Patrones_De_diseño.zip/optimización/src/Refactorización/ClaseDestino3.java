package Refactorización;

public class ClaseDestino3 {
    public static void main(String[] args) {
        ClaseOrigen3 origen = new ClaseOrigen3();
        System.out.println("Dato en ClaseDestino antes del movimiento: " + origen.dato);
        origen.metodoOrigen();
    }


}