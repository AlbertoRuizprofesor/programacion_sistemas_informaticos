package Refactorización;

public class ClaseDestino4 {
	int dato = 9;

    public void metodoDestino() {
        System.out.println("Dato en ClaseDestino: " + dato);
    }

public static void main(String[] args) {
    ClaseDestino4 destino = new ClaseDestino4();
    System.out.println("Dato en ClaseDestino después del movimiento: " + destino.dato);
    destino.metodoDestino();
}
}
