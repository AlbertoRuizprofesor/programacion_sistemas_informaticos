package Refactorización;

public class ClaseOrigen2 {

    public static void main(String[] args) {
        ClaseDestino2 destino = new ClaseDestino2();
        destino.metodoDestino();
    }
}

