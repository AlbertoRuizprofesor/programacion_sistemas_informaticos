package Refactorización;

public class ClaseOrigen3 {
    int dato = 5;

    public void metodoOrigen() {
        System.out.println("Dato en ClaseOrigen: " + dato);
    }
}
