package Refactorización;

public class CuentaBancaria {
	private double saldo;

    public CuentaBancaria(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public void realizarRetiro(double cantidad) {
        if (cantidad > saldo) {
            System.out.println("Saldo insuficiente");
        } else {
            saldo -= cantidad;
            System.out.println("Retiro exitoso de " + cantidad + " unidades");
            System.out.println("Saldo restante: " + saldo);
        }
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CuentaBancaria cuenta=new CuentaBancaria(10000.0);
		cuenta.realizarRetiro(500.0);

	}

}
