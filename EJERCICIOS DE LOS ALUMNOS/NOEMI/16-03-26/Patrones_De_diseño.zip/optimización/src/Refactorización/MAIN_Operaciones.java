package Refactorización;

public class MAIN_Operaciones {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OperacionesMatematicas m=new OperacionesMatematicas();
	    int num1 = 10;
	    int num2 = 5;
	    
	    int suma = m.sumar(num1, num2);
	    int resta = m.restar(num1, num2);
	    
	    m.mostrarResultado(suma);
	    m.mostrarResultado(resta);


	}

}
