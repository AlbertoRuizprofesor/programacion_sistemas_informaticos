package Refactorización;

public class Operacion2 {
    public static void main(String[] args) {
        int resultado = multiplicar(3, 4);
        System.out.println("El resultado de la multiplicación es: " + resultado);
    }

    public static int multiplicar(int a, int b) {
        return a * b;
    }
}



