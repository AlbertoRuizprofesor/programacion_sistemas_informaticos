package Refactorización;
public class OperacionesMatematicas {
  
  public int sumar(int num1, int num2) {
    return num1 + num2;
  }
    public int restar(int num1, int num2) {
    return num1 - num2;
  }
    public void mostrarResultado(int resultado) {
    System.out.println("El resultado es: " + resultado);
  }
}
