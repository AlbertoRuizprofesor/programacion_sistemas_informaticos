package Refactorizar_Persona;

public class Persona {
	private String nombre;
	private int edad;
	private String genero;
	
	public Persona(String nombre, int edad, String genero) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.genero = genero;
	}
	
	public void mostrarDetalles() {
		System.out.println("-Nombre: " + nombre +
							"|- Edad: " + edad +
							"|- Género: "+ genero);
	}
	
}
