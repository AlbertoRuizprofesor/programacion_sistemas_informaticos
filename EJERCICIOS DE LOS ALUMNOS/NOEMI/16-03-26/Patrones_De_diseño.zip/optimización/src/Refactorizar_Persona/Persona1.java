package Refactorizar_Persona;

public class Persona1 {
	private Detallespersona detalles;
	
	

	
	public Persona1(Detallespersona detalles) {
		this.detalles = detalles;
	}




	public void mostrarDetalles() {
			System.out.println("-Nombre: " + detalles.getNombre() +
								"|- Edad: " + detalles.getEdad() +
								"|- Género: "+ detalles.getGenero());
		
	}

}
