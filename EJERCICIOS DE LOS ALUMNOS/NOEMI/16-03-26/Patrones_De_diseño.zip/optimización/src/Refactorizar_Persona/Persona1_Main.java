package Refactorizar_Persona;

public class Persona1_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Detallespersona detalles = new Detallespersona("Noemi",29,"Femenina");
        Persona1 persona = new Persona1(detalles);
        persona.mostrarDetalles();


	}

}
