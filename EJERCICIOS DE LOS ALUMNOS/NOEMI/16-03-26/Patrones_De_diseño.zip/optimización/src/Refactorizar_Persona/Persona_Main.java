package Refactorizar_Persona;
import java.util.Scanner;

public class Persona_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stu
		Scanner c=new Scanner(System.in);
		
		System.out.println("Introduce su nombre: ");
		String nombre=c.nextLine();
		
		System.out.println("Introduce su edad: ");
		int edad=c.nextInt();
		c.nextLine(); //limpiar el buffet
		
		System.out.println("Introduce su género: ");
		String genero=c.nextLine();
		
		Persona p=new Persona(nombre, edad, genero);
		p.mostrarDetalles();
		
		c.close();
	}

}
