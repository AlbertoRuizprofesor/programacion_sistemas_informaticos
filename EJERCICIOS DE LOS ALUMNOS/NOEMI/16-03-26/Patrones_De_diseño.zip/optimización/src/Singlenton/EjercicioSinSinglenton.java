package Singlenton;

public class EjercicioSinSinglenton {
	public EjercicioSinSinglenton() {}
		
	    public void mostrarMensaje() {
	        System.out.println("Soy un objeto sin Singleton.");
	    }

	    public static void main(String[] args) {
	            // Crear dos instancias del objeto
	    		EjercicioSinSinglenton objeto1 = new EjercicioSinSinglenton();
	    		EjercicioSinSinglenton objeto2 = new EjercicioSinSinglenton();
	    		
	    		objeto1.mostrarMensaje();
	    		objeto2.mostrarMensaje();
	    		
	    		if (objeto1==objeto2) {
	    			System.out.println("Es la misma instancia");
	    			
	    		}else {
	    			System.out.println("Son instancias diferentes. La instancia 1: "+objeto1+
	    								"y la instancia 2: "+objeto2);
	    			
	    		}

			
		}
	}


