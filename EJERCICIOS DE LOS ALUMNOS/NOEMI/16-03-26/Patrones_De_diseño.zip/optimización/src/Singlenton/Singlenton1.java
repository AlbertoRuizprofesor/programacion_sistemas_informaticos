package Singlenton;

public class Singlenton1 {
	private static Singlenton1 instance;
	
	private Singlenton1() {}

    // Método estático para obtener la única instancia de la clase
    public static Singlenton1 getInstance() {
        if (instance == null) {
            instance = new Singlenton1();
        }
        return instance;
    }
    public void mostrarMensaje() {
        System.out.println("¡Hola! Soy un Singleton en verdad ave.");
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Singlenton1 singleton = Singlenton1.getInstance();
        Singlenton1 singleton1=Singlenton1.getInstance();
        // Usar la instancia para llamar al método showMessage
        singleton.mostrarMensaje();
        singleton1.mostrarMensaje();
        if (singleton1==singleton) {
        	System.out.println("es la misma instancia");
        }else {
        	System.out.println("es diferente");	
        	}
        	
        }
    }
