package Singlenton_2;

import Singlenton.EjercicioSinSinglenton;

public class Singleton_SIN {
	private String talla;
	private String color;
    private String tipo;
    private double precio;
    
	public Singleton_SIN(String talla, String color, String tipo, double precio) {
		super();
		this.talla = talla;
		this.color = color;
		this.tipo = tipo;
		this.precio = precio;
	}
	
	 public void mostrarDetalles() {
	        System.out.println("Prenda: " + tipo);
	        System.out.println("Talla: " + talla);
	        System.out.println("Color: " + color);
	        System.out.println("Precio: $" + precio);
	 }
	        public static void main(String[] args) {
	            // Crear dos instancias diferentes
	        	Singleton_SIN ejemplo1 = new Singleton_SIN("L", "VERDE", "Pantalón", 40.00);
	        	Singleton_SIN ejemplo2 = new Singleton_SIN("S", "ROJO", "Camiseta", 20.00);

	            // Mostrar detalles
	            System.out.println("Ejemplo 1:");
	            ejemplo1.mostrarDetalles();
	            System.out.println();

	            System.out.println("Ejemplo 2:");
	            ejemplo2.mostrarDetalles();
	            System.out.println();

	            // Comparar referencias
	            if (ejemplo1 == ejemplo2) {
	                System.out.println("Es la misma instancia");
	            } else {
	                System.out.println("Son instancias diferentes. Ejemplo1: " + ejemplo1 + 
	                                   " Ejemplo2: " + ejemplo2);
	            }
	
}
	
}