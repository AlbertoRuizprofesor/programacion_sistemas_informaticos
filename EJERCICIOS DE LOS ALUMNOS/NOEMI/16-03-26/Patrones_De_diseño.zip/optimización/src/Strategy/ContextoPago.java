package Strategy;

public class ContextoPago {
	private EstrategiaPago estrategiapago;

	public ContextoPago(EstrategiaPago estrategiapago) {
		this.estrategiapago = estrategiapago;
	}
	
	public void pagar(double cantidad) {
		estrategiapago.pagar(cantidad);
	}
	
}
