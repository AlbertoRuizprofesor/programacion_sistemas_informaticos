package Strategy;

public interface EstrategiaPago {
	void pagar(double cantidad);

}
