package Strategy;

public class Main {

	public static void main(String[] args) {


	EstrategiaPago estrategiaTarjeta =
            new PagoTarjetaCredito("1234 5678 9012 3456", "12/25", "123");
	
	EstrategiaPago estrategiapaypal=new PagoPaypal("Noemi@gmail.com","1255");
	
	EstrategiaPago estrategiabitcoin=new PagoBitcoin ("3948");
	
	ContextoPago contexto = new ContextoPago(estrategiaTarjeta);
    contexto.pagar(100.0);

    contexto = new ContextoPago(estrategiapaypal);
    contexto.pagar(50.0);
    
    contexto =new ContextoPago(estrategiabitcoin);
    contexto.pagar(20.0);

	
	}
	
}