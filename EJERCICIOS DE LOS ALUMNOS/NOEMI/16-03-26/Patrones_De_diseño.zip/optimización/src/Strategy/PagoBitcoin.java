package Strategy;

public class PagoBitcoin implements EstrategiaPago{
	private String codigo;

	public PagoBitcoin(String codigo) {
		this.codigo = codigo;
	}

	@Override
	public void pagar(double cantidad) {
		System.out.println("Pagando " + cantidad + " € con Bitcoin: " + codigo);
		
	}
	
	
	

}
