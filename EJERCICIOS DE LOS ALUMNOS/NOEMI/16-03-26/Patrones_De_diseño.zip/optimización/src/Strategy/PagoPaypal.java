package Strategy;

public class PagoPaypal implements EstrategiaPago{
	private String correo;
	private String contrasena;
	
	public PagoPaypal(String correo, String contrasena) {
		super();		this.correo = correo;
		this.contrasena = contrasena;
	}

	@Override
	public void pagar(double cantidad) {
		System.out.println("Pagando "+cantidad+" € usando PayPal: "+ correo);
		
	}
	
	
}
