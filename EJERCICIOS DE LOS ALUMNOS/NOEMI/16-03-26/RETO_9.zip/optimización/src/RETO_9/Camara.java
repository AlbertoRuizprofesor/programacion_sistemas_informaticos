package RETO_9;

public class Camara implements Funciones{
	 @Override
	    public void mostrar() {
	        System.out.println("Mostrando cámara");
	    }

	    @Override
	    public void encender() {
	        System.out.println("Cámara encendida");
	    }

	    @Override
	    public void apagar() {
	        System.out.println("Cámara apagada");
	    }
	}
	


