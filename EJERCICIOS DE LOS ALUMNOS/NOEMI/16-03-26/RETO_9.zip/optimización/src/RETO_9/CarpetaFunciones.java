package RETO_9;

import java.util.ArrayList;
import java.util.List;

public class CarpetaFunciones {
	private String nombre;
	private List<Funciones> listaFunciones=new ArrayList<>();
	
	public CarpetaFunciones(String nombre) {
		this.nombre = nombre;

	}
	
	public void agregar(Funciones funcion) {
		listaFunciones.add(funcion);
	}
	  public void mostrar() {
	        System.out.println("Carpeta: " + nombre);
	        for (Funciones f : listaFunciones) {
	            f.mostrar();
	        }
	    }

	    public void encender() {
	        System.out.println("Encendiendo carpeta: " + nombre);
	        for (Funciones f : listaFunciones) {
	            f.encender();
	        }
	    }

	    public void apagar() {
	        System.out.println("Apagando carpeta: " + nombre);
	        for (Funciones f : listaFunciones) {
	            f.apagar();
	        }
	    }
}