package RETO_9;

public interface Funciones {
	
	void mostrar();

	 void encender();

	void apagar();

}
