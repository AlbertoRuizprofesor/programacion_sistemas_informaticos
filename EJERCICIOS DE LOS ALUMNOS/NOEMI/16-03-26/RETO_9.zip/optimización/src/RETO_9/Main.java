package RETO_9;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// COMPOSITE
        CarpetaFunciones carpetaRedes = new CarpetaFunciones("Redes Sociales");
        carpetaRedes.agregar(new Musica());
        carpetaRedes.agregar(new Wifi());
        carpetaRedes.mostrar();
        carpetaRedes.encender();
        carpetaRedes.apagar();

        System.out.println("\n--- PROXY ---");
        ProxyCamara camaraSegura = new ProxyCamara(false);
        camaraSegura.encender(); // acceso denegado
        ProxyCamara camaraAdmin = new ProxyCamara(true);
        camaraAdmin.encender(); // acceso permitido

        System.out.println("\n--- FACADE ---");
        MovilFacade movil = new MovilFacade();
        movil.modoViaje();
        movil.apagarTodo();
    
	}

}
