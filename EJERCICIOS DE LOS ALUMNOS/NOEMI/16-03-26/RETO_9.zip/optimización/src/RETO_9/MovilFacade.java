package RETO_9;

public class MovilFacade {
	 private Camara camara = new Camara();
	    private Musica musica = new Musica();
	    private Wifi wifi = new Wifi();

	    public void modoViaje() {
	        System.out.println("=== Modo viaje activado ===");
	        wifi.encender();
	        camara.encender();
	        musica.encender();
	    }

	    public void apagarTodo() {
	        System.out.println("=== Apagando todo ===");
	        wifi.apagar();
	        camara.apagar();
	        musica.apagar();
	    }
	

}
