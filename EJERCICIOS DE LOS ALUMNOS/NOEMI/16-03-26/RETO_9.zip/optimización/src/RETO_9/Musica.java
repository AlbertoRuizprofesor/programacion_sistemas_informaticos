package RETO_9;

public class Musica implements Funciones{

	@Override
	public void mostrar() {
		 System.out.println("Mostrando música");
    }
		
	

	@Override
	public void encender() {
		System.out.println("Reproductor de música encendido");
		
	}

	@Override
	public void apagar() {
		System.out.println("Reproductor de música apagado");
		
	}
	

}
