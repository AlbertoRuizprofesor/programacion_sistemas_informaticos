package RETO_9;

public class ProxyCamara implements Funciones {
	private Camara camara;
	private boolean permitido;
	
	public ProxyCamara(boolean permitido) {
		this.permitido=permitido;
	}
		
		 @Override
		    public void mostrar() {
		        if (permitido) {
		            if (camara == null) camara = new Camara();
		            camara.mostrar();
		        } else {
		            System.out.println("Acceso denegado a la cámara");
		        }
		    }

		    @Override
		    public void encender() {
		        if (permitido) {
		            if (camara == null) camara = new Camara();
		            camara.encender();
		        } else {
		            System.out.println("Acceso denegado a la cámara");
		        }
		    }

		    @Override
		    public void apagar() {
		        if (permitido) {
		            if (camara == null) camara = new Camara();
		            camara.apagar();
		        } else {
		            System.out.println("Acceso denegado a la cámara");
		        }
		    }
		}