package RETO_9;

public class Wifi implements Funciones{

	@Override
	public void mostrar() {
        System.out.println("Mostrando WiFi");

	}

	@Override
	public void encender() {
        System.out.println("encender WiFi");

		
	}

	@Override
	public void apagar() {
        System.out.println("apagar WiFi");

		
	}
	

}
