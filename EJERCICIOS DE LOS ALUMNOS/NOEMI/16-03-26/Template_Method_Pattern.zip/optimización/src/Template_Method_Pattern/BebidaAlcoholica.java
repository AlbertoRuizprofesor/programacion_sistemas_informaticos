package Template_Method_Pattern;

public abstract class BebidaAlcoholica {
	public final void prepararReceta() {
		nombrebebida();
		preparar();
		agregarCondimentos();
	}
	
	public void nombrebebida() {

		
	}
	abstract void preparar();
	abstract void agregarCondimentos();

}



