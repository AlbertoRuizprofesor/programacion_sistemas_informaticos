package Template_Method_Pattern;

public abstract class BebidaConCafeina {
	public final void prepararReceta(){
		nombrebebida();
		hervirAgua();
		preparar();
		servirEnTaza();
		agregarCondimentos();
	}
		
	public void nombrebebida() {
		System.out.println("Preparando bebida...");
	
	}
	public void hervirAgua() {
		System.out.println("Hirviendo agua");
	
	}
	public void servirEnTaza() {
		System.out.println("Sirviendo en la taza");
		
	}
	abstract void preparar();
	abstract void agregarCondimentos();
		


}