package Template_Method_Pattern;

public class Cafe extends BebidaConCafeina{
	
	

	@Override
	public void nombrebebida() {
		System.out.println("-━ ◦ ❖ ◦━--____Cafe____--━ ◦ ❖ ◦━--");
	}

	@Override
	void preparar() {
        System.out.println("Filtrando el café");		
	}

	@Override
	void agregarCondimentos() {
        System.out.println("Agregando azúcar y leche");		
	}
	

}
