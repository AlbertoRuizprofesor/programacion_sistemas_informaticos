package Template_Method_Pattern;

public class Licor43 extends BebidaAlcoholica {
	
	

	@Override
	public void nombrebebida() {
		System.out.println("---°。°。°。°。°。°。-___Licor 43___--°。°。°。°。°。°。--");

	}

	@Override
	void preparar() {
		System.out.println(" ╰┈➤ Mezclar Alcohol con Red Bull.");
		
	}

	@Override
	void agregarCondimentos() {
		System.out.println("Agregando HierbaBuena");
		
	}
	

}
