package Template_Method_Pattern;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BebidaConCafeina te=new Te();
		te.prepararReceta();
		
		System.out.println("************▒▒▒▒▒▒▒▒▒▒ 100% ᴄᴏᴍᴘʟᴇᴛᴇ!*****************");
		
		BebidaConCafeina cafe=new Cafe();
		cafe.prepararReceta();
		
		System.out.println("*************▒▒▒▒▒▒▒▒▒▒ 100% ᴄᴏᴍᴘʟᴇᴛᴇ!****************");
		
		BebidaSinCafeina rooibos=new Rooibos();
		rooibos.prepararReceta();
		
		System.out.println("***********▒▒▒▒▒▒▒▒▒▒ 100% ᴄᴏᴍᴘʟᴇᴛᴇ!******************");
		
		BebidaAlcoholica licor43=new Licor43();
		licor43.prepararReceta();
		System.out.println("***********▒▒▒▒▒▒▒▒▒▒ 100% ᴄᴏᴍᴘʟᴇᴛᴇ!******************");
	}

}
