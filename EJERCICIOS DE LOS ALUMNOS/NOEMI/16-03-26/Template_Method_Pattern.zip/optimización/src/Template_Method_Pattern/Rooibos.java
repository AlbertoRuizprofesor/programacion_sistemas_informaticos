package Template_Method_Pattern;

public class Rooibos extends BebidaSinCafeina {
	
	

	@Override
	public void nombrebebida() {
		System.out.println("--✼ ҉ ✼ ҉ ✼---____Rooibos____---✼ ҉ ✼ ҉ ✼-");
	}

	@Override
	void preparar() {
        System.out.println("Remojando Rooibos");
		
	}

	@Override
	void agregarCondimentos() {
        System.out.println("Agregando Canela");		
	}
	

}
