package Template_Method_Pattern;

public class Te extends BebidaConCafeina{
	
	
	@Override
	public void nombrebebida() {
		System.out.println("--••●••---____Te____---••●••--");
	}

	@Override
	void preparar() {
        System.out.println("Remojando el té");
		
	}

	@Override
	void agregarCondimentos() {
        System.out.println("Agregando limón");		
	}
	

}
