package MCV_MYSQL_2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Controlador {
	private Connection conn;
	private ArrayList<Proveedores> listaProveedores;
	private Vista vista;
	
	public Controlador(Vista vista) {
		this.vista = vista;
		listaProveedores=new ArrayList();
		
	try {
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/empresa1","root","");
		System.out.println("Conexion correcta");
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}
	public void cargarProveedores() {
		try {
			String sql = "SELECT * FROM proveedores";
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs= ps.executeQuery();
			
			while (rs.next()) {
				Proveedores pro=new Proveedores(
						rs.getInt("Id"),
						rs.getString("Nombre"),
						rs.getInt("Telefono"),
						rs.getString("Email"));
						
		listaProveedores.add(pro);
		
	 }
   } catch (SQLException e) {
	   e.printStackTrace();
   }
	
}
	public void mostrarProveedores() {
		vista.mostrarProveedores(listaProveedores);
	}
}

