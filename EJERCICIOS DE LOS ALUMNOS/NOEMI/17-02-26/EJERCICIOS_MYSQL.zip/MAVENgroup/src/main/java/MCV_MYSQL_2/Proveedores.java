package MCV_MYSQL_2;

public class Proveedores {
	private int id;
	private String nombre;
	private int telefono;
	private String email;
	public Proveedores(int id, String nombre, int telefono, String email) {
		this.id = id;
		this.nombre = nombre;
		this.telefono = telefono;
		this.email = email;
	}
	public int getId() {
		return id;

	}
	public String getNombre() {
		return nombre;
	}
	public int getTelefono() {
		return telefono;
	
	}
	public String getEmail() {
		return email;

	}

}
