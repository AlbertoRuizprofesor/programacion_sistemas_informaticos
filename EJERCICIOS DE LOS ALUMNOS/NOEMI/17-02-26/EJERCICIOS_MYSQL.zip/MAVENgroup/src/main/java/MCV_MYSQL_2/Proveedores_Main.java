package MCV_MYSQL_2;

public class Proveedores_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vista v=new Vista();
		
		Controlador c=new Controlador(v);
		
		c.cargarProveedores();
		c.mostrarProveedores();

	}

}
