package MCV_MYSQL_2;
import java.util.ArrayList;

public class Vista {
	public void mostrarProveedores(ArrayList<Proveedores> listaProveedores) {
		System.out.println("Listado de proveedores");
		
		for (Proveedores p:listaProveedores) {
			System.out.println(" |- ID: "+p.getId()
								+".|- Nombre: "+p.getNombre()
								+". |- Telefono: "+p.getTelefono()
								+". |- Email: "+p.getEmail());
		}
	}

}
