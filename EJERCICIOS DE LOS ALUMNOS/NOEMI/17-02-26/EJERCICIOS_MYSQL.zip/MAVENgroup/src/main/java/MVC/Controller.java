package MVC;

public class Controller {
	private Persona modelo;          //creamos la asociacion asi
	private VIEW vista;
	
	public Controller(Persona modelo, VIEW vista) {  //es un campo
		this.modelo = modelo;
		this.vista = vista;
	}
	public void actualizarVista() {       //creamos este metodo con get
		vista.mostrarPersona(modelo.getNombre(), modelo.getApellidos(), modelo.getEdad());
	
	}


}
