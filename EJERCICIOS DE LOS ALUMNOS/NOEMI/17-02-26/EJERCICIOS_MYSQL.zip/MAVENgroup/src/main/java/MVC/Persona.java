package MVC;

public class Persona {
	private String nombre;
	private String apellidos;
	private int edad;

	public Persona(String nombre, String apellidos, int edad) {

		this.nombre = nombre;
		this.apellidos = apellidos;
		this.edad = edad;
	}
                                               //estamos trabajando con asociaciones
	public String getNombre() {          //aqui esta el constructor
		return nombre;             //podemos eliminar el setter, y no meter el tostring.
	}
	public String getApellidos() {
		return apellidos;
	}

	public int getEdad() {
		return edad;
	}


}
