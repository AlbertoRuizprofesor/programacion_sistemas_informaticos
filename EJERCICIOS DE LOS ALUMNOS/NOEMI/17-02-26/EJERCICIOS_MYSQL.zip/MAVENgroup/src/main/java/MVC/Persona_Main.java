package MVC;

public class Persona_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Persona p=new Persona("Noemi","González Ruiz",28);
		
		VIEW v=new VIEW();
	
		Controller c=new
				Controller(p,v);
		c.actualizarVista();
	}

}
