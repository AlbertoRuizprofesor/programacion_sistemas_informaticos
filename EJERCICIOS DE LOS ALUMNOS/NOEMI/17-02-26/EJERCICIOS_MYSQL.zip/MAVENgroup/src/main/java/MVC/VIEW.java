package MVC;

public class VIEW {
                //MOSTRAR PERSONAS
	public void mostrarPersona(String nombre, String apellidos, int edad) {
		System.out.println("Nombre: "+nombre);
		System.out.println("Apellidos: "+apellidos);
		System.out.println("Edad: "+edad);
	}
}
