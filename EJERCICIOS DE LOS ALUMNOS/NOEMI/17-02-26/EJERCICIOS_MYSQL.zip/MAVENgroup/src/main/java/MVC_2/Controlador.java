package MVC_2;

public class Controlador {
	private Producto modelo;
	private Vista vista;
	public Controlador(Producto modelo, Vista vista) {
		this.modelo = modelo;
		this.vista = vista;
	}
	public void ActualizarVista() {
		vista.mostrarDatos(modelo.getCodigo(), modelo.getNombre(), modelo.getPrecio());
	}
	

}
