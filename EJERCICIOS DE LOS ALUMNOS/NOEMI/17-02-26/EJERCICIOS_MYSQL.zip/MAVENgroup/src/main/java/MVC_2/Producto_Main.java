package MVC_2;

public class Producto_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Producto p=new Producto(1,"Microsoft",40000);
		
		Vista v=new Vista();
		
		Controlador c=new 
				Controlador(p,v);
		c.ActualizarVista();
				

	}

}
