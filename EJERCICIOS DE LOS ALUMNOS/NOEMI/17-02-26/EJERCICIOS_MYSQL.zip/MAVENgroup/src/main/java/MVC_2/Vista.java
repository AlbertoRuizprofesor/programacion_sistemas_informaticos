package MVC_2;

public class Vista {
	public void mostrarDatos(int codigo, String nombre, double precio) {
		System.out.println("Codigo: "+1234);
		System.out.println("Nombre: "+nombre);
		System.out.println("Precio: "+precio);
	}

}
