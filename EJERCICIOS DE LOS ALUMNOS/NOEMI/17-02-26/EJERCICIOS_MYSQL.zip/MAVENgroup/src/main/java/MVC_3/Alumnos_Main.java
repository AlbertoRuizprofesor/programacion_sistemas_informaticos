package MVC_3;
import java.util.ArrayList;
import java.util.Scanner;

public class Alumnos_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		
		ArrayList<Alumnos> lista=new ArrayList<>();
		
		System.out.println("Cuanto alumnos quieres introducir? ");
		int n=c.nextInt();
		
		for (int i=0;i<n;i++) {
			System.out.println("\nAlumno " + (i + 1));

	        System.out.print("ID: ");
	        int id = c.nextInt();
	        c.nextLine();

	        System.out.print("Nombre: ");
	        String nombre = c.nextLine();

	        System.out.print("Apellidos: ");
	        String apellidos = c.nextLine();

	        System.out.print("Curso: ");
	        String curso = c.nextLine();

	        System.out.print("Nota: ");
	        double nota = c.nextDouble();
	        c.nextLine();

	        // Crear alumno y añadir a la lista
	        lista.add(new Alumnos(id, nombre, apellidos, curso, nota));
	    }
		
		Vista v=new Vista();
		
		for (Alumnos a:lista) {
			Controlador co=new Controlador(a,v);
			co.ActualizarVista();
		}
		c.close();
}
		
		
		

	}


