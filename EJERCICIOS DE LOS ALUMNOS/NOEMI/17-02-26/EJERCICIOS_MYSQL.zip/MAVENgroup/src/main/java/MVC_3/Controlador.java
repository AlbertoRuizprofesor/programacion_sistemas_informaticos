package MVC_3;

public class Controlador {
	private Alumnos modelo;
	private Vista vista;
	public Controlador(Alumnos modelo, Vista vista) {
		this.modelo = modelo;
		this.vista = vista;
	}
	public void ActualizarVista() {
		vista.mostrarAlumnos(modelo.getId(), modelo.getNombre() , modelo.getApellidos(), modelo.getAsignatura(), modelo.getNota());
	}
	

}
