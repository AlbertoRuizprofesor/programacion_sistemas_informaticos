package MVC_3;

public class Vista {
	public void mostrarAlumnos(int id, String nombre, String apellidos, String asignatura, double nota) {
		System.out.println("- ID : "+id+
							".|- Nombre: "+nombre+
							".|- Apellidos: "+apellidos+
							".|- Asignatura: "+asignatura+
							".|- Nota: "+nota);
	}
}
