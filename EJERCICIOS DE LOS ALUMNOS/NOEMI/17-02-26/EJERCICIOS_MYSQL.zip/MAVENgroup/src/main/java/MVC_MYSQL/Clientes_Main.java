package MVC_MYSQL;

public class Clientes_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vista v=new Vista();
		
		Controlador c=new Controlador(v);
		
		c.cargarClientes();
		c.mostrarClientes();

	}

}
