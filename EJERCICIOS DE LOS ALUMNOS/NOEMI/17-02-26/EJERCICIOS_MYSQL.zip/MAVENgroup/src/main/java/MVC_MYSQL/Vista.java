package MVC_MYSQL;

import java.util.ArrayList;

public class Vista {
	public void mostrarClientes(ArrayList<Clientes> listaClientes) {
		//arraylist, bucle for , system 
		System.out.println("Listado de clientes");
		
		for (Clientes c:listaClientes) {
			System.out.println(
					"ID: "+c.getId()
					+ " | NIF: "+c.getNif()
					+ " | Nombre: "+c.getNombre()
					+ " | Edad: "+c.getEdad());
		}
	}

}
