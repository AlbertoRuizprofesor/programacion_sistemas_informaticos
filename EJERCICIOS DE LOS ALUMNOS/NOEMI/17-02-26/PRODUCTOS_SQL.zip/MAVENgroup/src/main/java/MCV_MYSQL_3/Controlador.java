package MCV_MYSQL_3;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Controlador {
	private Connection conn;
	private ArrayList<Productos> listaProductos;
	private Vista vista;
	
	public Controlador(Vista vista) {
		this.vista = vista;
		listaProductos=new ArrayList();
		
	try {
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/empresa1","root","");
		System.out.println("Conexion correcta");
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}
	public void cargarProductos() {
		try {
			String sql = "SELECT * FROM productos";
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs= ps.executeQuery();
			
			while (rs.next()) {
				Productos pr=new Productos(
						rs.getInt("Id"),
						rs.getString("Nombre"),
						rs.getInt("Precio"));
						
		listaProductos.add(pr);
		
	 }
   } catch (SQLException e) {
	   e.printStackTrace();
   }
	
}
	public void mostrarProductos() {
		vista.mostrarProductos(listaProductos);
	}
}

