package MCV_MYSQL_3;

public class Productos_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Vista v=new Vista();
		
		Controlador c=new Controlador(v);
		
		c.cargarProductos();
		c.mostrarProductos();

	}

}
