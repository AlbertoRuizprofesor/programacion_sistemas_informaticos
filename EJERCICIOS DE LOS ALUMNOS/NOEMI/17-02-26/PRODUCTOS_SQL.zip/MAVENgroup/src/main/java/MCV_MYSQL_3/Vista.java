package MCV_MYSQL_3;

import java.util.ArrayList;

public class Vista {
	public void mostrarProductos(ArrayList<Productos> listaProductos) {
		System.out.println("Lista de productos");
		
		for (Productos pro:listaProductos) {
			System.out.println(" ID: "+pro.getId()+". Nombre: "+pro.getNombre()+". Precio: "+pro.getPrecio());
		}
	}

}
