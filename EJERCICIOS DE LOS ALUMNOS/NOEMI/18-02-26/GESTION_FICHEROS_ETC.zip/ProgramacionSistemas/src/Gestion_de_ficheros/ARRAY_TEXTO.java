package Gestion_de_ficheros;

import java.io.*;

public class ARRAY_TEXTO {

    public static void main(String[] args) {
        try {
            BufferedWriter fichero = new BufferedWriter(new FileWriter ("C:\\Users\\2-DAW\\Desktop\\Ejercicio1\\fichero3.txt"));
            for (int i=1;i<21;i++) {
            // Escribimos varias líneas de texto
            fichero.write("Fila numero: "+i);
            fichero.newLine(); //escribe un salto de linea
            }
            // Cerramos para que se guarde correctamente
            fichero.close();
            
            System.out.println("CORRECTO");

        } catch (FileNotFoundException fn) {
        				System.out.println("No se encuentra el fichero");}
        catch (IOException io) {
            System.out.println("Error de E/S");}
        }
        }
