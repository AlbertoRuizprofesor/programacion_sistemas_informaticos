package Gestion_de_ficheros;

import java.io.File;

public class Borrar_fichero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String ruta = "C:\\Users\\2-DAW\\Desktop\\Ejercicio1";
        String nombreFichero = "fichero1.txt"; // Nombre del fichero que deseas borrar

        // Combinar la ruta del directorio con el nombre del fichero
        String rutaFichero = ruta + File.separator + nombreFichero;

        File fichero = new File(rutaFichero);

        if (fichero.exists()) {
            boolean borrado = fichero.delete();
            if (borrado) {
                System.out.println("El fichero ha sido borrado con éxito.");
            } else {
                System.out.println("No se pudo borrar el fichero.");
            }
        } else {
            System.out.println("El fichero no existe en la ubicación especificada.");
        }
    }


	}
