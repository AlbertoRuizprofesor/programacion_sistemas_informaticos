package Gestion_de_ficheros;
import java.io.*;

public class CrearDirectorio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ruta="C:\\Users\\2-DAW\\Desktop\\Prueba";
		String carpeta="pa";
		File directorio=new File(ruta+File.separator+carpeta);
		if (directorio.exists()==true) {
			System.out.println("La carpeta ya existe");
		} else {
			directorio.mkdir();
			System.out.println("Carpeta creada");
			}

	}

}
