package Gestion_de_ficheros;

import java.io.File;
import java.io.IOException;

public class Crear_fichero {
    public static void main(String[] args) {
        String ruta = "C:\\Users\\2-DAW\\Desktop\\Prueba\\PRODUCTOS";
        String nombreFichero = "PRODUCTOS.txt"; // Nombre del fichero que deseas crear

        // Combinar la ruta del directorio con el nombre del fichero
        String rutaFichero = ruta + File.separator + nombreFichero;

        File fichero = new File(rutaFichero);

        if (fichero.exists()) {
            System.out.println("El fichero ya existe.");
        } else {
            try {
                boolean creado = fichero.createNewFile();
                if (creado) {
                    System.out.println("El fichero ha sido creado con éxito.");
                } else {
                    System.out.println("No se pudo crear el fichero.");
                }
            } catch (IOException e) {
                System.out.println("Error al crear el fichero: " + e.getMessage());
            }
        }
    }
}



