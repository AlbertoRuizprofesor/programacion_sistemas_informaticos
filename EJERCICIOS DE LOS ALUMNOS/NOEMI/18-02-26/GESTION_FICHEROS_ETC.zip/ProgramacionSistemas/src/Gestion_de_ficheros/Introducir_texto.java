package Gestion_de_ficheros;

import java.io.*;

public class Introducir_texto {

    public static void main(String[] args) {
        try {
            BufferedWriter fichero = new BufferedWriter(new FileWriter ("C:\\Users\\2-DAW\\Desktop\\Prueba\\PRODUCTOS\\PRODUCTOS.txt"));
           
            fichero.write("Productos: Office, Gemini, Iphone 17 pro");
            fichero.newLine(); //escribe un salto de linea
            
            // Cerramos para que se guarde correctamente
            fichero.close();
            
            System.out.println("CORRECTO");

        } catch (FileNotFoundException fn) {
        				System.out.println("No se encuentra el fichero");}
        catch (IOException io) {
            System.out.println("Error de E/S");}
        }
        }
