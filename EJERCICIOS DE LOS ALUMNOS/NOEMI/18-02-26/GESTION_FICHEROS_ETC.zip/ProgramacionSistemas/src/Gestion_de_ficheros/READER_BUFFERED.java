package Gestion_de_ficheros;

import java.io.*;

public class READER_BUFFERED {

    public static void main(String[] args) {
        String ruta = "C:\\Users\\2-DAW\\Desktop\\Ejercicio1\\fichero3.txt";

        // Escribir en el fichero
        try {
            BufferedWriter fichero = new BufferedWriter(new FileWriter(ruta));
            for (int i = 1; i < 21; i++) {
                fichero.write("Fila numero: " + i);
                fichero.newLine(); // salto de línea
            }
            fichero.close();
            System.out.println("Escritura correcta");
        } catch (FileNotFoundException fn) {
            System.out.println("No se encuentra el fichero");
        } catch (IOException io) {
            System.out.println("Error de E/S");
        }

        // Leer el fichero con BufferedReader
        try {
            BufferedReader br = new BufferedReader(new FileReader(ruta));
            String linea;
            System.out.println("\nContenido del fichero:");
            while ((linea = br.readLine()) != null) {
                System.out.println(linea); // mostrar cada línea
            }
            br.close();
        } catch (FileNotFoundException fn) {
            System.out.println("No se encuentra el fichero");
        } catch (IOException io) {
            System.out.println("Error de E/S");
        }
    }
}
