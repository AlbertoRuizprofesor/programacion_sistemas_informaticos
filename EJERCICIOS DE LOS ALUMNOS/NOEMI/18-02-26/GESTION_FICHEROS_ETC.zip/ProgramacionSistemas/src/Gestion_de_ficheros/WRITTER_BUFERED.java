package Gestion_de_ficheros;

import java.io.*;

public class WRITTER_BUFERED {

    public static void main(String[] args) {
        File fichero = new File("C:\\Users\\2-DAW\\Desktop\\Ejercicio1\\fichero1.txt");

        try {
            // FileWriter en modo append para no sobrescribir
            FileWriter fw = new FileWriter(fichero, true);
            BufferedWriter bw = new BufferedWriter(fw);

            // Escribimos varias líneas de texto
            bw.write("Hola, este es un ejemplo de texto.\n");
            bw.write("Otra línea más de información.\n");

            // Cerramos para que se guarde correctamente
            bw.close();

            System.out.println("Texto escrito correctamente en el fichero.");

        } catch (IOException e) {
            System.out.println("Error al escribir en el fichero: " + e.getMessage());
        }
    }
}
