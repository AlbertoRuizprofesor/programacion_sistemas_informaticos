package Serializacion;
import java.io.*;
public class EjercicioSerializacion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//crear el objeto persona.
		Persona persona=new Persona("Ana",27);
		
		//serializar 
		try {
			FileOutputStream archivoSalida=new FileOutputStream
					("C:\\prueba\\persona.ser");
			ObjectOutputStream objetoSalida=new ObjectOutputStream
					(archivoSalida);
			
			objetoSalida.writeObject(persona);
			objetoSalida.close();
			archivoSalida.close();
			
			System.out.println("Objeto serializado correctamente.");
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			FileInputStream archivoEntrada=new FileInputStream
					("C:\\prueba\\persona.ser");
			ObjectInputStream objetoEntrada=new ObjectInputStream
					(archivoEntrada);
			EjercicioSerializacion personaDeserializada=(EjercicioSerializacion) objetoEntrada.readObject();
			objetoEntrada.close();
			archivoEntrada.close();
			System.out.println("Objeto deserializado correctamente.");
			System.out.println(personaDeserializada);
			
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();

		}
	}
}



