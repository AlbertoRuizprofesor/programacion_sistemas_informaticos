package Serializacion;
import java.io.*;

//Clase que implementa Serializable
class Persona1 implements Serializable {
	
 private String nombre;
 private int edad;
 public Persona1(String nombre, int edad) {
     this.nombre = nombre;
     this.edad = edad;
 }
 public String toString() {
     return "Persona: " + nombre + ", Edad: " + edad;
 }
}
public class Serializacion2 {
 public static void main(String[] args) {
     // Crear un objeto Persona
     Persona1 persona = new Persona1("Noemi", 28);
     // Serializar el objeto
     try {
    	 
         FileOutputStream archivoSalida = new FileOutputStream
        		 ("c:\\prueba\\personajor.txt");
         ObjectOutputStream objetoSalida = new ObjectOutputStream
        		 (archivoSalida);
         
         objetoSalida.writeObject(persona);
         objetoSalida.close();
         archivoSalida.close();
         
         System.out.println("Objeto serializado correctamente.");
         
     } catch (IOException e) {
         e.printStackTrace();
     }
     // Deserializar el objeto
     try {
    	 
         FileInputStream archivoEntrada = new FileInputStream
        		 ("c:\\prueba\\personajor.txt");
         ObjectInputStream objetoEntrada = new ObjectInputStream
        		 (archivoEntrada);
         Persona1 personaDeserializada = (Persona1) objetoEntrada.readObject();
         objetoEntrada.close();
         archivoEntrada.close();
         System.out.println("Objeto deserializado correctamente.");
         System.out.println(personaDeserializada);
         
     } catch (IOException | ClassNotFoundException e) {
         e.printStackTrace();
     }
 }
}
