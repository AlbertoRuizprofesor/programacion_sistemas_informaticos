package Serializacion_2;

import java.io.*;


public class EjercicioSerializacion2 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Videjojuegos videojuegos=new Videjojuegos(1,"Kindomg Hearts","80,90 €.");
		// Serializar el objeto
	     try {
	    	 
	         FileOutputStream archivoSalida = new FileOutputStream
	        		 ("c:\\videojuegos\\videojuegos.txt");
	         ObjectOutputStream objetoSalida = new ObjectOutputStream
	        		 (archivoSalida);
	         
	         objetoSalida.writeObject(videojuegos);
	         objetoSalida.close();
	         archivoSalida.close();
	         
	         System.out.println("Objeto serializado correctamente.");
	         
	     } catch (IOException e) {
	         e.printStackTrace();
	     }
	      // Deserializar el objeto
	         try {
	        	 
	             FileInputStream archivoEntrada = new FileInputStream
	            		 ("c:\\videojuegos\\videojuegos.txt");
	             ObjectInputStream objetoEntrada = new ObjectInputStream
	            		 (archivoEntrada);
	             Videjojuegos VideojuegosDeserializada = (Videjojuegos) objetoEntrada.readObject();
	             objetoEntrada.close();
	             archivoEntrada.close();
	             System.out.println("Objeto deserializado correctamente.");
	             System.out.println(VideojuegosDeserializada);
	             
	         } catch (IOException | ClassNotFoundException e) {
	             e.printStackTrace();
	         }
	     }
	    }
