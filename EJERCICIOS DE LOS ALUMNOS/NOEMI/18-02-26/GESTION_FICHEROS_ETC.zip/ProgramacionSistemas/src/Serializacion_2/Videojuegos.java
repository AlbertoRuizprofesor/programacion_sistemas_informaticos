package Serializacion_2;

import java.io.Serializable;

//Clase que implementa Serializable
class Videjojuegos implements Serializable {
private int codigo;
private String nombre;
private String precio;


public Videjojuegos(int codigo, String nombre, String precio) {
	this.codigo = codigo;
	this.nombre = nombre;
	this.precio = precio;
}

public String toString() {
	return "Videjojuegos [codigo=" + codigo + ", nombre=" + nombre + ", precio=" + precio + "]";

}
}
