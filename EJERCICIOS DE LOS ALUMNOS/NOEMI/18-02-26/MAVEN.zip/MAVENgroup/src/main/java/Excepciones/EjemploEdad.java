package Excepciones;

public class EjemploEdad {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int resultado=edad(50);
			System.out.println("El resultado es: "+resultado);
		}catch (ArithmeticException e) {
			System.out.println("Error "+e.getMessage());
		}
	}
		 // Método que valida la edad
	    public static int edad(int a) throws ArithmeticException {
	        if (a < 18) {
	            // lanzamos una excepción si es menor de 18
	            throw new ArithmeticException("Menor de edad");
	        }
	        return a; // si es válida, devolvemos la edad
		}

	
}
