package Serializacion_ARRAY;
import java.io.*;

public class Videojuegos1 implements Serializable{
	private int codigo;
	private String nombre;
	private String precio;
	public Videojuegos1(int codigo, String nombre, String precio) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.precio = precio;
	}
	@Override
	public String toString() {
		return "Videojuegos1 [codigo=" + codigo + ", nombre=" + nombre + ", precio=" + precio + "]\n";
	}

}
