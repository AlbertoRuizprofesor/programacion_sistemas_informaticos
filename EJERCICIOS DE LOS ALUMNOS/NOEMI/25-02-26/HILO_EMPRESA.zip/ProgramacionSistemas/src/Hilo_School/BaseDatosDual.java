package Hilo_School;

 class BaseDatosDual extends Thread{
	private int notas;
	
	public BaseDatosDual(int notas) {
		this.notas=notas;
	}

	public void run() {
		double empresa=(notas*20)/100;
	
	        System.out.println("Nota empresa, Base Datos dual: " + empresa);
	        System.out.println("Nota centro, Base Datos dual: " + (notas - empresa));
	       
	}
}
