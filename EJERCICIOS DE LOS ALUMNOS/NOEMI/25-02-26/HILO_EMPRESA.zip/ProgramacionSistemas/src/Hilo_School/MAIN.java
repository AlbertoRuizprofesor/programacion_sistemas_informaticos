package Hilo_School;
import java.util.Scanner;

public class MAIN {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		int nota;
		
		System.out.println("Introduce la nota: ");
		nota=scanner.nextInt();
		
		BaseDatosDual b=new BaseDatosDual(nota);
		
		ProgramacionSistemas p=new ProgramacionSistemas(nota);
		
		b.setPriority(Thread.MAX_PRIORITY);
		b.start();
		b.join();
		
		
		System.out.println("***********************");
		
		p.setPriority(Thread.MIN_PRIORITY);
		p.start();
		p.join();
		

		
		scanner.close();
		

	}

}
