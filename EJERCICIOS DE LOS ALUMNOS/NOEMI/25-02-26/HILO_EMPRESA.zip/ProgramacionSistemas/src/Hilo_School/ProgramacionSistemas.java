package Hilo_School;

 class ProgramacionSistemas extends Thread {
	private int notas;
	
	public ProgramacionSistemas(int notas) {
		this.notas=notas;
		
	}
	
	public void run() {
		double empresa=(notas*40)/100;
		
	        System.out.println("Nota empresa, Programacion de Sistemas: " + empresa);
	        System.out.println("Nota centro, Programacion de Sistemas: " + (notas - empresa));
	     

	}

}
