package HEIDI;

import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class CrudProductoSwing extends JFrame {

    private static final String DB_NAME = "empresa1"; 
    private static final String TABLE = "productos";
    private static final String URL = "jdbc:mysql://localhost:3306/" + DB_NAME + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASS = ""; 

    private final JTextField txtId = new JTextField();  
    private final JTextField txtNombre = new JTextField();
    private final JTextField txtPrecio = new JTextField();
  
    private final DefaultTableModel modelo = new DefaultTableModel(
            new Object[] { "ID", "NOMBRE", "PRECIO" }, 0
    ) {
        @Override public boolean isCellEditable(int row, int col) { return false; }
    };

    private final JTable tabla = new JTable(modelo);
    private final JButton btnInsertar   = new JButton("Insertar");
    private final JButton btnActualizar = new JButton("Actualizar");
    private final JButton btnEliminar   = new JButton("Eliminar");
    private final JButton btnBuscar     = new JButton("Buscar (ID)");
    private final JButton btnListar     = new JButton("Listar");
    private final JButton btnLimpiar    = new JButton("Limpiar");

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } 
        catch (Exception ignored) {}
        // CORRECCIÓN AQUÍ: Nombre de la clase correcto
        SwingUtilities.invokeLater(CrudProductoSwing::new); 
    }

    public CrudProductoSwing() {
        setTitle("CRUD Productos - " + DB_NAME);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(860, 520);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        add(crearPanelFormulario(), BorderLayout.NORTH);
        add(crearPanelTabla(), BorderLayout.CENTER);
        add(crearPanelBotones(), BorderLayout.SOUTH);

        configurarEventos();
        cargarTabla();
        setVisible(true);
    }

    private JPanel crearPanelFormulario() {
        JPanel p = new JPanel(new GridLayout(2, 3, 10, 10));
        p.setBorder(new TitledBorder("Datos del Producto"));
        p.add(new JLabel("ID:"));
        p.add(new JLabel("NOMBRE:"));
        p.add(new JLabel("PRECIO:"));
        p.add(txtId);
        p.add(txtNombre);
        p.add(txtPrecio);
        return p;
    }

    private JScrollPane crearPanelTabla() {
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        return new JScrollPane(tabla);
    }

    private JPanel crearPanelBotones() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        p.add(btnInsertar); p.add(btnActualizar); p.add(btnEliminar);
        p.add(btnBuscar); p.add(btnListar); p.add(btnLimpiar);
        return p;
    }

    private void configurarEventos() {
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() != -1) {
                int fila = tabla.getSelectedRow();
                txtId.setText(String.valueOf(modelo.getValueAt(fila, 0)));
                txtNombre.setText(String.valueOf(modelo.getValueAt(fila, 1)));
                txtPrecio.setText(String.valueOf(modelo.getValueAt(fila, 2)));
            }
        });

        btnInsertar.addActionListener(e -> {
            if (!validarCampos()) return;
            if (insertar(Integer.parseInt(txtId.getText()), txtNombre.getText(), txtPrecio.getText())) {
                JOptionPane.showMessageDialog(this, "Insertado.");
                cargarTabla(); limpiar();
            }
        });

        btnActualizar.addActionListener(e -> {
            if (!validarCampos()) return;
            if (actualizar(Integer.parseInt(txtId.getText()), txtNombre.getText(), txtPrecio.getText())) {
                JOptionPane.showMessageDialog(this, "Actualizado.");
                cargarTabla(); limpiar();
            }
        });

        btnEliminar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText());
                if (eliminar(id)) { cargarTabla(); limpiar(); }
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "ID inválido"); }
        });

        btnBuscar.addActionListener(e -> {
            String idTxt = JOptionPane.showInputDialog("ID a buscar:");
            if (idTxt != null) {
                String[] fila = buscarPorId(Integer.parseInt(idTxt));
                if (fila != null) {
                    txtId.setText(fila[0]); txtNombre.setText(fila[1]); txtPrecio.setText(fila[2]);
                } else { JOptionPane.showMessageDialog(this, "No encontrado"); }
            }
        });

        btnListar.addActionListener(e -> cargarTabla());
        btnLimpiar.addActionListener(e -> limpiar());
    }

    private boolean validarCampos() {
        if (txtId.getText().isEmpty() || txtNombre.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "ID y Nombre son obligatorios");
            return false;
        }
        return true;
    }

    private void cargarTabla() {
        modelo.setRowCount(0);
        for (String[] fila : listarTodos()) modelo.addRow(fila);
    }

    private void limpiar() {
        txtId.setText(""); txtNombre.setText(""); txtPrecio.setText("");
        tabla.clearSelection();
    }

    // =========================
    // LÓGICA DAO (CORREGIDA)
    // =========================
    private static Connection getConexion() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    private boolean insertar(int id, String nombre, String precio) {
        String sql = "INSERT INTO " + TABLE + " (id, nombre, precio) VALUES (?, ?, ?)";
        try (Connection cn = getConexion(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setString(2, nombre);
            ps.setString(3, precio);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) { mostrarErrorSQL("INSERTAR", e); return false; }
    }

    private boolean actualizar(int id, String nombre, String precio) {
        String sql = "UPDATE " + TABLE + " SET nombre=?, precio=? WHERE id=?";
        try (Connection cn = getConexion(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, nombre);
            ps.setString(2, precio);
            ps.setInt(3, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) { mostrarErrorSQL("ACTUALIZAR", e); return false; }
    }

    private boolean eliminar(int id) {
        String sql = "DELETE FROM " + TABLE + " WHERE id=?";
        try (Connection cn = getConexion(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) { mostrarErrorSQL("ELIMINAR", e); return false; }
    }

    private String[] buscarPorId(int id) {
        String sql = "SELECT * FROM " + TABLE + " WHERE id=?";
        try (Connection cn = getConexion(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return new String[]{ rs.getString("id"), rs.getString("nombre"), rs.getString("precio") };
        } catch (SQLException e) { mostrarErrorSQL("BUSCAR", e); }
        return null;
    }

    private List<String[]> listarTodos() {
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT * FROM " + TABLE;
        try (Connection cn = getConexion(); Statement st = cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(new String[]{ rs.getString("id"), rs.getString("nombre"), rs.getString("precio") });
        } catch (SQLException e) { mostrarErrorSQL("LISTAR", e); }
        return lista;
    }

    private void mostrarErrorSQL(String op, SQLException e) {
        JOptionPane.showMessageDialog(this, "Error en " + op + ": " + e.getMessage());
    }
}