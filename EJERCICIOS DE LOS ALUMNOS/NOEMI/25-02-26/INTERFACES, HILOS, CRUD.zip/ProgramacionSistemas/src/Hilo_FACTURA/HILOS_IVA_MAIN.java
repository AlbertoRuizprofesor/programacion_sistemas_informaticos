package Hilo_FACTURA;
import java.util.Scanner;

public class HILOS_IVA_MAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		double importe;
		
		
		System.out.println("Introduce el importe: ");
		importe=scanner.nextDouble();
		
		IVA1 hilo1=new IVA1(importe);
		IVA2 hilo2=new IVA2(importe);
		IVA3 hilo3=new IVA3(importe);
		
		//LE PONEMOS PRIORIDADES CREANDO VARIABLES Y LLAMANDOLES
		
		hilo1.setPriority(Thread.MIN_PRIORITY);
		hilo1.start();
		
		hilo2.setPriority(Thread.MAX_PRIORITY);
		hilo2.start();
		
		hilo3.setPriority(Thread.NORM_PRIORITY);
		hilo3.start();
		
		
		scanner.close();
	}

}
