package Hilo_FACTURA;



class IVA1 extends Thread {
    private double importe ;

    public IVA1(double importe) {
        this.importe = importe;
        
    }

    public void run() {
        System.out.println("Importe con 7% de IVA: "+(importe*0.07)); 
      
    }
}