package Hilo_FACTURA;

class IVA2 extends Thread {
	
		private double importe;
		
		public IVA2(double importe) {
			this.importe=importe;
		}
		public void run() {
			System.out.println("Importe con 10% de IVA: "+(importe*0.10));
			
		}
		
		

	}



