package Hilo_FACTURA;

class IVA3 extends Thread {
	
		private double importe;
		
		public IVA3(double importe) {
			this.importe=importe;
		}
		public void run() {
			System.out.println("Importe con 21% de IVA: "+(importe*0.21));
			
		}
		
		

	}



