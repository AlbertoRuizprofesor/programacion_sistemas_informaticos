
package Hilos;

class Division extends Thread {
    private double num1, num2;

    public Division(double num1, double num2) {
        this.num1 = num1;
        this.num2 = num2;
    }
    public void run() {
        if (num2 != 0) {
            System.out.println("División: " + (num1 / num2));
        } else {
            System.out.println("Error: División por cero.");
        }
    }
  
    }
