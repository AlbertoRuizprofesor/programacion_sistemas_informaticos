package Hilos;

import java.util.Scanner;



public class HILOS_CALCULADORA {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		double num1,num2;
		
		// Solicitar al usuario los números
        System.out.print("Introduce el primer número: ");
		num1 = scanner.nextDouble();

        System.out.print("Introduce el segundo número: ");
        num2 = scanner.nextDouble();

        // Crear y arrancar hilos para cada operación
        new SUMA(num1, num2).start();
        new RESTA(num1, num2).start();
        new Multiplicacion(num1, num2).start();
        new Division(num1, num2).start();
        new Potencia(num1,num2).start();
        scanner.close();
        
        
        //para ponerles prioridad
        SUMA hilo1=new SUMA(num1,num2);
        hilo1.setPriority(Thread.MAX_PRIORITY);
        hilo1.start();
        
        scanner.close();
         
    }
}
