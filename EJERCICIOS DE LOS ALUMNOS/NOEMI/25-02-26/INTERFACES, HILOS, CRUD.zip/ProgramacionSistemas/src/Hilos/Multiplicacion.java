
package Hilos;

class Multiplicacion extends Thread {
    private double num1, num2;

    public Multiplicacion(double num1, double num2) {
        this.num1 = num1;
        this.num2 = num2;
    }

    public void run() {
        System.out.println("Multiplicacion: " + (num1 * num2));
      
    }
}