package Hilos;

class Potencia extends Thread {
    private double num1, num2;

    public Potencia(double num1, double num2) {
        this.num1 = num1;
        this.num2 = num2;
    }

    public void run() {
        System.out.println("Potencia: " + Math.pow(num1, num2));
      
    }
}