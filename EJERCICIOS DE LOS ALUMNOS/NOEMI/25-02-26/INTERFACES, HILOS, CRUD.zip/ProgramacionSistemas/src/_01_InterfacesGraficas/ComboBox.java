package _01_InterfacesGraficas;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionListener;


public class ComboBox extends JFrame {
	private JComboBox<String> comboBox;
	
	public ComboBox() {
		setTitle("Titulo de la ventana");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		setLayout(null); 
		setSize(300, 100); 
		
		JLabel label = new JLabel("Selecciona un lenguaje:");
		label.setBounds(10, 10, 150, 20); 
		add(label); 
		
		String[] opciones = {"", "Java☆", "Kotlin", "PHP", "JAVASCRIPT"};
		comboBox = new JComboBox<>(opciones); 
		comboBox.setBounds(160, 10, 120, 20); 
		add(comboBox); 
		
		comboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedIndex = comboBox.getSelectedIndex(); 
                
                String seleccion = opciones[selectedIndex]; 
                mostrarMensaje("Indica el código", "Has elegido: " + seleccion); 
            }
				// TODO Auto-generated method stub
				
			
        });

        setLocationRelativeTo(null);
    }
	private void mostrarMensaje(String titulo, String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }


	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> {
            new ComboBox().setVisible(true); 
        });
    }
}