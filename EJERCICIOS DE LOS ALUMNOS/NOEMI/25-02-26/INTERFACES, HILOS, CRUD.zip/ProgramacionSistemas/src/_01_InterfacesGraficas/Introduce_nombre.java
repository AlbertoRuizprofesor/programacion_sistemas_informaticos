package _01_InterfacesGraficas;
import javax.swing.*; 

public class Introduce_nombre extends JFrame  {
	
	public Introduce_nombre() {
		setTitle("TITULO DE LA VENTANA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		setSize(400,200);
		
		//etiqueta
		JLabel label=new JLabel("Indica tu nombre:");
		label.setBounds(10,10,150,20);
		add(label);
		
		//campo de texto
		JTextField textField=new JTextField();
		textField.setBounds(160,10,120,20);
		add(textField);
		
		  // Botón
        JButton boton = new JButton("Enviar");
        boton.setBounds(90, 50, 100, 30);
        add(boton);
        
        // Acción del botón
        boton.addActionListener(e -> {
            String nombre = textField.getText(); // obtiene el texto del JTextField
            if (!nombre.isEmpty()) {  //si no esta vacio el texto muestra:
                JOptionPane.showMessageDialog(this, "Perfecto, " + nombre + "!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Por favor, introduce tu nombre.", "Error", JOptionPane.WARNING_MESSAGE);
            }
        });
		
		setLocationRelativeTo(null);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> {
			new Introduce_nombre().setVisible(true);
		});
		}

	}


