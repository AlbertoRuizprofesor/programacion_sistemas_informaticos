package _01_InterfacesGraficas;
import javax.swing.*;

import javax.swing.*;

public class Introducir_datos_personales extends JFrame {

    public Introducir_datos_personales() {

        setTitle("Datos personales");
        setSize(350, 300);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Nombre
        JLabel l1 = new JLabel("Nombre:");
        l1.setBounds(20, 20, 100, 20);
        add(l1);

        JTextField t1 = new JTextField();
        t1.setBounds(120, 20, 150, 20);
        add(t1);

        // Edad
        JLabel l2 = new JLabel("Edad:");
        l2.setBounds(20, 60, 100, 20);
        add(l2);

        JTextField t2 = new JTextField();
        t2.setBounds(120, 60, 150, 20);
        add(t2);

        // Teléfono
        JLabel l3 = new JLabel("Teléfono:");
        l3.setBounds(20, 100, 100, 20);
        add(l3);

        JTextField t3 = new JTextField();
        t3.setBounds(120, 100, 150, 20);
        add(t3);

        // Botón
        JButton b = new JButton("Aceptar");
        b.setBounds(100, 160, 120, 30);
        add(b);

        // Acción del botón
        b.addActionListener(e -> {

            String nombre = t1.getText();
            String edad = t2.getText();
            String telefono = t3.getText();

            if (nombre.isEmpty() || edad.isEmpty() || telefono.isEmpty()) {

                JOptionPane.showMessageDialog(null, "Rellena todos los campos");

            } else {

                // Texto ordenado con saltos de línea
                String mensaje = "DATOS INTRODUCIDOS:\n\n"
                        + "Nombre: " + nombre + "\n"
                        + "Edad: " + edad + "\n"
                        + "Teléfono: " + telefono;

                JOptionPane.showMessageDialog(null, mensaje);
            }
        });

        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        new Introducir_datos_personales().setVisible(true);
    }
}
