package _01_InterfacesGraficas;

import javax.swing.*;

public class RETO extends JFrame {

    private JComboBox<String> comboBox;
    private JTextField nombre1, apellidos1, direccion1;
    private JRadioButton radio1, radio2;
    private ButtonGroup group;

    public RETO() {

        setTitle("Formulario");
        setSize(380, 450);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // ===== Nombre =====
        JLabel nombre = new JLabel("Nombre:");
        nombre.setBounds(20, 20, 100, 20);
        add(nombre);

        nombre1 = new JTextField();
        nombre1.setBounds(120, 20, 180, 25);
        add(nombre1);

        // ===== Apellidos =====
        JLabel apellidos = new JLabel("Apellidos:");
        apellidos.setBounds(20, 60, 100, 20);
        add(apellidos);

        apellidos1 = new JTextField();
        apellidos1.setBounds(120, 60, 180, 25);
        add(apellidos1);

        // ===== Dirección =====
        JLabel direccion = new JLabel("Dirección:");
        direccion.setBounds(20, 100, 100, 20);
        add(direccion);

        direccion1 = new JTextField();
        direccion1.setBounds(120, 100, 180, 25);
        add(direccion1);

        // ===== Modalidad =====
        JLabel modalidad = new JLabel("Modalidad:");
        modalidad.setBounds(20, 140, 100, 20);
        add(modalidad);

        radio1 = new JRadioButton("Online");
        radio2 = new JRadioButton("Presencial");

        group = new ButtonGroup();
        group.add(radio1);
        group.add(radio2);

        JPanel panel = new JPanel();
        panel.setBounds(120, 135, 200, 40);
        panel.add(radio1);
        panel.add(radio2);

        add(panel);

        // ===== Estudios (JComboBox) =====
        JLabel label = new JLabel("Estudios:");
        label.setBounds(20, 185, 100, 20);
        add(label);

        String[] opciones = {"", "DAM", "DAW", "ASIR"};
        comboBox = new JComboBox<>(opciones);
        comboBox.setBounds(120, 180, 180, 25);
        add(comboBox);

        // ===== Botones =====
        JButton aceptar = new JButton("Aceptar");
        aceptar.setBounds(70, 250, 110, 35);
        add(aceptar);

        JButton cancelar = new JButton("Cancelar");
        cancelar.setBounds(200, 250, 110, 35);
        add(cancelar);

        // ===== Acción Aceptar =====
        aceptar.addActionListener(e -> validarFormulario());

        // ===== Acción Cancelar =====
        cancelar.addActionListener(e -> cancelarFormulario());

        setLocationRelativeTo(null);
        setVisible(true);
    }

    // =========================
    // MÉTODO VALIDAR FORMULARIO
    // =========================
    private void validarFormulario() {

        String nom = nombre1.getText().trim();
        String ape = apellidos1.getText().trim();
        String direc = direccion1.getText().trim();
        String estudios = (String) comboBox.getSelectedItem();

        if (nom.isEmpty() || ape.isEmpty() || direc.isEmpty()
                || (!radio1.isSelected() && !radio2.isSelected())
                || estudios.equals("")) {

            JOptionPane.showMessageDialog(this,
                    "Debes rellenar todos los campos",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String modalidadSeleccionada = radio1.isSelected()
                ? "Online"
                : "Presencial";

        String mensaje = "Datos introducidos:\n\n"
                + "Nombre: " + nom + "\n"
                + "Apellidos: " + ape + "\n"
                + "Dirección: " + direc + "\n"
                + "Modalidad: " + modalidadSeleccionada + "\n"
                + "Estudios: " + estudios;

        JOptionPane.showMessageDialog(this,
                mensaje,
                "Información",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // =========================
    // MÉTODO CANCELAR FORMULARIO
    // =========================
    private void cancelarFormulario() {

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                "¿Seguro que quieres cancelar?",
                "Confirmar cancelación",
                JOptionPane.YES_NO_OPTION
        );

        if (confirmacion == JOptionPane.YES_OPTION) {

            nombre1.setText("");
            apellidos1.setText("");
            direccion1.setText("");
            group.clearSelection();
            comboBox.setSelectedIndex(0);

            JOptionPane.showMessageDialog(this,
                    "Formulario reiniciado correctamente");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RETO());
    }
}