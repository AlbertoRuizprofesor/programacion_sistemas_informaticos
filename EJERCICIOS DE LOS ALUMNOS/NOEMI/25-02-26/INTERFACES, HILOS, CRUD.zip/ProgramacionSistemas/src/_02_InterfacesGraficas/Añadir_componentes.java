package _02_InterfacesGraficas;
import java.awt.BorderLayout;

import javax.swing.*;
public class Añadir_componentes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame ventana=new JFrame("♥♥♥♥♥♥");
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setSize(300,200);
		
		JPanel panel=new JPanel();
		JLabel etiqueta=new JLabel("♥♥♥♥♥ HOLA MI AMOR! ♥♥♥♥♥♥");
		
		JLabel etiqueta2=new JLabel("♥♥♥♥♥ Te quiero Jose ♥♥♥♥♥♥");
		
        etiqueta2.add(new JButton(), BorderLayout.CENTER);
        		
		ventana.setLocationRelativeTo(null);
		
		panel.add(etiqueta);
		panel.add(etiqueta2);
		ventana.add(panel);
		
		ventana.setVisible(true);
		

	}

}
