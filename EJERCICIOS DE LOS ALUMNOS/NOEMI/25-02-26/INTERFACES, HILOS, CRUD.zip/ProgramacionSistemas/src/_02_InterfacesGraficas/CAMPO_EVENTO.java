package _02_InterfacesGraficas;

import javax.swing.*;

public class CAMPO_EVENTO {

    public static void main(String[] args) {
        // Crear ventana
        JFrame ventana = new JFrame("Validación de correo");
        ventana.setSize(400, 200);
        ventana.setLayout(null);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Campo de texto
        JTextField campoCorreo = new JTextField();
        campoCorreo.setBounds(50, 50, 200, 30);

        // Botón
        JButton botonValidar = new JButton("Validar");
        botonValidar.setBounds(270, 50, 100, 30);

        // Etiqueta para resultados
        JLabel etiqueta = new JLabel();
        etiqueta.setBounds(50, 90, 320, 30);

        // Acción del botón
        botonValidar.addActionListener(e -> {
            String texto = campoCorreo.getText();

            if (texto.contains("@")) {
                etiqueta.setText("Correo válido ✅");
                JOptionPane.showMessageDialog(ventana, "Correo válido: " + texto, "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                etiqueta.setText("Correo inválido ❌");
                JOptionPane.showMessageDialog(ventana, "Correo inválido: falta @", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Agregar componentes a la ventana
        ventana.add(campoCorreo);
        ventana.add(botonValidar);
        ventana.add(etiqueta);

        ventana.setVisible(true);
    }
}
