package _02_InterfacesGraficas;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.*;

public class EjemploGridLayout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame ventana=new JFrame("Ventana");
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setSize(300,200);
		ventana.setVisible(true);
		
		ventana.setLayout(new GridLayout(2, 3)); //diseño de cuadricula (tabla) 2 filas, 3 columnas
		
		
		
		ventana.add(new JButton("Uno"));
        ventana.add(new JButton("Dos"));
        ventana.add(new JButton("Tres"));
        ventana.add(new JButton("Cuatro"));
        ventana.add(new JButton("Cinco"));
        ventana.add(new JButton("Seis"));

		
		
		ventana.setLocationRelativeTo(null);
		  
		ventana.setVisible(true);

	}

}
