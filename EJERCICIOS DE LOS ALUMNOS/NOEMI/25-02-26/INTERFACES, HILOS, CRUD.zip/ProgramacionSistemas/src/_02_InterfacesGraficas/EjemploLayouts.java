package _02_InterfacesGraficas;

import javax.swing.*;
import java.awt.*;

public class EjemploLayouts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame ventana=new JFrame("Combinacion de Layouts");
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setSize(500,400);
		ventana.setVisible(true);
		
		ventana.setLayout(new BorderLayout()); //para ordenar
		
		JPanel norte=new JPanel(new FlowLayout()); //coloca los componentes en una fila
		norte.add(new JButton("Botón 1"));
		norte.add(new JButton("Botón 2"));
		norte.add(new JButton("Botón 3"));
		
		JPanel centro=new JPanel(new GridLayout(2,2)); //filas y columnas
		centro.add(new JLabel(" Nombre: "));
		centro.add(new JTextField(10));
		centro.add(new JLabel(" Edad: "));
		centro.add(new JTextField(3));
		
		JPanel sur=new JPanel(new FlowLayout());
		sur.add(new JButton("Enviar"));
		sur.add(new JButton("Cancelar"));
		
		ventana.add(norte, BorderLayout.NORTH);
		ventana.add(centro,BorderLayout.CENTER);
		ventana.add(sur, BorderLayout.SOUTH);
		
		ventana.setLocationRelativeTo(null);
		
		ventana.setVisible(true);
		
		

	}

}
