package _02_InterfacesGraficas;

import javax.swing.*;

public class Evento_boton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame ventana = new JFrame("Evento");
        ventana.setSize(400, 200);
        ventana.setLayout(null);
        
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //boton 1:
        JButton boton = new JButton("Haz clic");
        boton.setBounds(50, 50, 100, 30);  //setbounds es la opsicion

        JLabel etiqueta = new JLabel();
        etiqueta.setBounds(50, 100, 200, 30); //fila eje x, eje y, anchura y altura
        
        boton.addActionListener(e -> etiqueta.setText("¡Botón clicado!")); //queda a la espera para que clicles

        boton.addActionListener(e -> { etiqueta.setText("¡Botón 1 clicado!"); //escucha si ha clicado
        
        
        //OTRA VENTANA DIFERENTE
        JOptionPane.showMessageDialog(
                ventana,
                "Has pulsado el botón 1",
                "Información",
                JOptionPane.INFORMATION_MESSAGE
        );
    });
        //boton 2:
        
        JButton boton2 = new JButton("AQUI!");
        boton2.setBounds(150, 50, 120, 30);
        
        
        boton2.addActionListener(e -> etiqueta.setText("¡Muy bien!")); 
        boton2.addActionListener(e -> { etiqueta.setText("¡Botón 1 clicado!"); //escucha si ha clicado
        
        
        //OTRA VENTANA DIFERENTE
        JOptionPane.showMessageDialog(
                ventana,
                "Has pulsado el botón 1",
                "Información",
                JOptionPane.INFORMATION_MESSAGE
        );
    });
        
        //boton 3:
        JButton boton3=new JButton("DAMELO!");
        boton3.setBounds(270, 50, 100, 30);
        boton3.addActionListener(e -> etiqueta.setText("ALLÁ VAMOOS!"));
        
        boton3.addActionListener(e -> { etiqueta.setText("¡Botón 1 clicado!"); //escucha si ha clicado
        
        
        //OTRA VENTANA DIFERENTE
        JOptionPane.showMessageDialog(
                ventana,
                "Has pulsado el botón 1",
                "Información",
                JOptionPane.INFORMATION_MESSAGE
        );
    });
        
        
        //MOSTRAR EN PANTALLA
        ventana.add(boton);
        ventana.add(etiqueta);
        
        ventana.add(boton2);
        
        ventana.add(boton3);
   
        

        ventana.setVisible(true);
    }


		

	}

