package _02_InterfacesGraficas;

import java.awt.event.*;
import javax.swing.*;

public class Evento_boton2 {

    public static void main(String[] args) {
        JFrame ventana = new JFrame("Evento");
        ventana.setSize(400, 250);
        ventana.setLayout(null);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Botón 1
        JButton boton1 = new JButton("Haz clic");
        boton1.setBounds(50, 50, 100, 30);
        JLabel etiqueta1 = new JLabel();
        etiqueta1.setBounds(50, 90, 200, 30);

        boton1.addActionListener(e -> {
            etiqueta1.setText("¡Botón 1 clicado!");
            JOptionPane.showMessageDialog(ventana, "Has pulsado el botón 1", "Información", JOptionPane.INFORMATION_MESSAGE);
        });

        // JTextField para escuchar teclas
        JTextField campo = new JTextField();
        campo.setBounds(50, 130, 200, 30);

        campo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                etiqueta1.setText("Tecla: " + e.getKeyChar());
                if (e.getKeyChar() == 'a') {
                    JOptionPane.showMessageDialog(ventana, "Has pulsado la tecla 'a'", "Información", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Botón 2
        JButton boton2 = new JButton("AQUI!");
        boton2.setBounds(150, 50, 100, 30);
        JLabel etiqueta2 = new JLabel();
        etiqueta2.setBounds(150, 90, 200, 30);

        boton2.addActionListener(e -> {
            etiqueta2.setText("¡Botón 2 clicado!");
            JOptionPane.showMessageDialog(ventana, "Has pulsado el botón 2", "Información", JOptionPane.INFORMATION_MESSAGE);
        });

        // Botón 3
        JButton boton3 = new JButton("DAMELO!");
        boton3.setBounds(250, 50, 100, 30);
        JLabel etiqueta3 = new JLabel();
        etiqueta3.setBounds(250, 90, 200, 30);

        boton3.addActionListener(e -> {
            etiqueta3.setText("¡Botón 3 clicado!");
            JOptionPane.showMessageDialog(ventana, "Has pulsado el botón 3", "Información", JOptionPane.INFORMATION_MESSAGE);
        });

        // Agregar todo
        ventana.add(boton1);
        ventana.add(etiqueta1);
        ventana.add(campo);
        ventana.add(boton2);
        ventana.add(etiqueta2);
        ventana.add(boton3);
        ventana.add(etiqueta3);

        ventana.setVisible(true);
    }
}
