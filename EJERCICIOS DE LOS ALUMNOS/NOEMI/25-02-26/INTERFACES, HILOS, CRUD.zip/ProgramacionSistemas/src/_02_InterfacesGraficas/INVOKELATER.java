package _02_InterfacesGraficas;
import javax.swing.*;

public class INVOKELATER extends JFrame {  //es para crear hilos, multihilos

	public INVOKELATER () {
		// TODO Auto-generated method stub
		setTitle("Ventana segura");
		setSize(200,150);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		add(new JButton("Hola"));
		
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(()->
		new INVOKELATER().setVisible(true)
		);
		
		

	}

}
