package _02_InterfacesGraficas;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.*;

public class VentanaSimple {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame ventana=new JFrame("Mi ventana");
		ventana.setSize(400,300);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //para q cierra la ventana si le das a Cerrar
		ventana.setVisible(true); //para que no se creen ventanas ocultas
		JPanel panel = new JPanel(new FlowLayout());

        panel.add(new JButton("Uno"));
        panel.add(new JButton("Dos"));
        panel.add(new JButton("Tres"));
        panel.add(new JButton("Cuatro"));
        panel.add(new JButton("Cinco"));
        panel.add(new JButton("Seis"));
        
        ventana.setLocationRelativeTo(null);  //localizacion en medio de la pantalla
        ventana.add(new JButton("Elige una opción"), BorderLayout.NORTH);
        ventana.add(new JButton("NO SE VE"), BorderLayout.CENTER);


        ventana.add(panel);
        ventana.setVisible(true);
  
    
 
	}

}
