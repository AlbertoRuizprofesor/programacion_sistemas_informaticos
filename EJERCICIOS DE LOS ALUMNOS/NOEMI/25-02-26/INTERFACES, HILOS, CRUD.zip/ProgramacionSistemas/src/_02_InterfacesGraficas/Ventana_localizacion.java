package _02_InterfacesGraficas;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Ventana_localizacion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame ventana=new JFrame("Mi ventana");
		ventana.setSize(400,300);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //para q cierra la ventana si le das a Cerrar
		ventana.setVisible(true); //para que no se creen ventanas ocultas
		JPanel panel = new JPanel(new GridLayout(3,2)); //para que se vean los paneles completos , con gridlayout es filas columnas

        panel.add(new JButton("Uno"), BorderLayout.NORTH);
        panel.add(new JButton("Dos"), BorderLayout.SOUTH);
        panel.add(new JButton("Tres"), BorderLayout.EAST);
        panel.add(new JButton("Cuatro"), BorderLayout.WEST);  //añadir localizacion dentro de contenedor
        panel.add(new JButton("Cinco"), BorderLayout.WEST);
        panel.add(new JButton("Seis"), BorderLayout.WEST);
        
        ventana.setLocationRelativeTo(null);  //localizacion en medio de la pantalla
        //ventana.add(new JButton("Elige una opción"), BorderLayout.NORTH);
       // ventana.add(new JButton("NO SE VE"), BorderLayout.CENTER);


        ventana.add(panel);
        ventana.setVisible(true);
  
        

	}

}
