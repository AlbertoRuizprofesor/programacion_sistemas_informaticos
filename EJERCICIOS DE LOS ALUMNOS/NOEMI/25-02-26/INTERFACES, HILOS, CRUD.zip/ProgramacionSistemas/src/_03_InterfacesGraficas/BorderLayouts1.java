package _03_InterfacesGraficas;
import javax.swing.*;
import java.awt.*;


public class BorderLayouts1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame ventana=new JFrame("Ventana emergente");
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setSize(400,300);
		
		
		ventana.setLayout(new BorderLayout());
		
		JButton b1=new JButton("Norte");
		JButton b2=new JButton("Centro");
		JButton b3=new JButton("Este");
		JButton b4=new JButton("Oeste");
		JButton b5=new JButton("Sur");
		
		
		ventana.add(b1, BorderLayout.NORTH);
		ventana.add(b2, BorderLayout.CENTER);
		ventana.add(b3, BorderLayout.EAST);
		ventana.add(b4, BorderLayout.WEST);
		ventana.add(b5, BorderLayout.SOUTH);
		
		
		ventana.setLocationRelativeTo(null);
		ventana.setVisible(true);
		
		

	}

}
