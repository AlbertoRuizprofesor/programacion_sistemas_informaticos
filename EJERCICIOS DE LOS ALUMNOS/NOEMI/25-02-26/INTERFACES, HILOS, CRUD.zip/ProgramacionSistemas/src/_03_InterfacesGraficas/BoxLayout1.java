package _03_InterfacesGraficas;

import javax.swing.*;
import java.awt.Component;

public class BoxLayout1 extends JFrame {

    public BoxLayout1() {
        setTitle("BoxLayout Example");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // vertical

        JButton button1 = new JButton("Botón 1");
        JButton button2 = new JButton("Botón 2");
        JButton button3 = new JButton("Botón 3");

        // Centrar los botones horizontalmente
        button1.setAlignmentX(Component.CENTER_ALIGNMENT);
        button2.setAlignmentX(Component.CENTER_ALIGNMENT);
        button3.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Añadir botones al panel (sin espacios fijos)
        panel.add(button1);
        panel.add(button2);
        panel.add(button3);

        add(panel);
        setLocationRelativeTo(null); // centrar ventana
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BoxLayout1 ventana = new BoxLayout1();
            ventana.setVisible(true);
        });
    }
}