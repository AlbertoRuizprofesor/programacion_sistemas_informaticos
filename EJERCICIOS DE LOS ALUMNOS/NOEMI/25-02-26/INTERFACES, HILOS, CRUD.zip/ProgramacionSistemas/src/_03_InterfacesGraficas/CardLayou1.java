package _03_InterfacesGraficas;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class CardLayou1 extends JFrame {
	private JPanel cardPanel; // Panel que contiene los "cards"
	private CardLayout cardLayout; // Layout del cardPanel, permite apilar y mostrar solo uno a la vez
	private JButton nextButton; //mostrar siguiente card
	private JButton prevButton;  //mostrar card anterior
	
	public CardLayou1() {
		setTitle("Ventana emergente");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300,400);
		setLayout(new BorderLayout());
		
		  // ===== PANEL DE CARDS =====
		cardLayout = new CardLayout();
		cardPanel = new JPanel(cardLayout);
		
		// Crear cada "card"
		JPanel card1=new JPanel();
		JLabel label1=new JLabel("Card 1");
		JTextArea textArea1=new JTextArea(10,25);
		card1.add(label1, BorderLayout.NORTH);
		card1.add(textArea1, BorderLayout.CENTER);
		
		
		
		JPanel card2=new JPanel();
		JLabel label2=new JLabel("Card 2");
		JTextArea textArea2=new JTextArea(10,25);
		card2.add(label2, BorderLayout.NORTH);
		card2.add(textArea2, BorderLayout.CENTER);
		
		
		JPanel card3=new JPanel();
		JLabel label3=new JLabel("Card 3");
		JTextArea textArea3=new JTextArea(10,25);
		card3.add(label3, BorderLayout.NORTH);
		card3.add(textArea3, BorderLayout.CENTER);
		
		//añadir cards al panel
		cardPanel.add(card1, "1");
		cardPanel.add(card2, "2");
		cardPanel.add(card3, "3");
		
		 // ===== PANEL DE BOTONES =====
        JPanel buttonPanel = new JPanel();
        prevButton = new JButton("Previous");
        nextButton = new JButton("Next");
        
        // Eventos de los botones
        prevButton.addActionListener(e -> cardLayout.previous(cardPanel));
        nextButton.addActionListener(e -> cardLayout.next(cardPanel));

        // Añadir botones al panel de botones
        buttonPanel.add(prevButton);
        buttonPanel.add(nextButton);

        // ===== AÑADIR AL FRAME =====
        add(cardPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null); // Centrar ventana
    }
      
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 CardLayou1 ventana = new CardLayou1();
	     ventana.setVisible(true);

	}

}
