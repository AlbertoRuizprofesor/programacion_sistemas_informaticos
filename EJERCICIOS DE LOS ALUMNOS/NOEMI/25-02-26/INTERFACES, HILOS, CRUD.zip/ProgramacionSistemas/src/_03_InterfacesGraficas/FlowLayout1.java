package _03_InterfacesGraficas;
import javax.swing.*;
import java.awt.*;

public class FlowLayout1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame=new JFrame("FlowLayout Example");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300,200);
		
		JPanel panel=new JPanel();
        panel.setLayout(new FlowLayout());
		
		JButton button1=new JButton("Botón 1");
		JButton button2=new JButton("Botón 2");
		JButton button3=new JButton("Botón 3");
		JButton button4=new JButton("Botón 4");
		JButton button5=new JButton("Botón 5");
		
		//añadir botones al panel
		
		panel.add(button1);
		panel.add(button2);
		panel.add(button3);
		panel.add(button4);
		panel.add(button5);
		
		//añadir  panel al marco
		frame.add(panel);
		
		//visible la ventana
		frame.setVisible(true);
		
		frame.setLocationRelativeTo(null);

	}

}
