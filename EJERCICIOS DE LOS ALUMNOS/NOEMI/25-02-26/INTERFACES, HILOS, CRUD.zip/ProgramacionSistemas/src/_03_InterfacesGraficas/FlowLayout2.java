package _03_InterfacesGraficas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FlowLayout2 {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Formulario Validación");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(550, 300);

        JPanel panel = new JPanel();
        panel.setLayout(null); // Layout manual
        frame.add(panel);

        // ===== NOMBRE =====
        JLabel label1 = new JLabel("Nombre:");
        label1.setBounds(30, 30, 80, 25);
        panel.add(label1);

        JTextField t1 = new JTextField();
        t1.setBounds(120, 30, 150, 25);
        panel.add(t1);

        JButton b1 = new JButton("Validar Nombre");
        b1.setBounds(300, 30, 150, 25);
        panel.add(b1);

        // ===== EMAIL =====
        JLabel label2 = new JLabel("Email:");
        label2.setBounds(30, 80, 80, 25);
        panel.add(label2);

        JTextField t2 = new JTextField();
        t2.setBounds(120, 80, 150, 25);
        panel.add(t2);

        JButton b2 = new JButton("Validar Email");
        b2.setBounds(300, 80, 150, 25);
        panel.add(b2);

        // ===== NIF =====
        JLabel label3 = new JLabel("NIF:");
        label3.setBounds(30, 130, 80, 25);
        panel.add(label3);

        JTextField t3 = new JTextField();
        t3.setBounds(120, 130, 150, 25);
        panel.add(t3);

        JButton b3 = new JButton("Validar NIF");
        b3.setBounds(300, 130, 150, 25);
        panel.add(b3);

        // ===== PANEL RESULTADO =====
        JPanel panelResultado = new JPanel();
        panelResultado.setBounds(0, 190, 550, 40);
        panelResultado.setLayout(null);
        panel.add(panelResultado);

        JLabel labelResultado = new JLabel("");
        labelResultado.setBounds(220, 5, 200, 30);
        panelResultado.add(labelResultado);

        // ===== EVENTOS =====
        b1.addActionListener(e -> labelResultado.setText("Nombre válido"));
        b2.addActionListener(e -> labelResultado.setText("Email válido"));
        b3.addActionListener(e -> labelResultado.setText("NIF válido"));

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}