package _03_InterfacesGraficas;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.*;

public class GridBagLayout1 extends JFrame{
	private String nombre;
	private String Email;
	private String telefono;
	private JPanel jpanel;

	public GridBagLayout1() {
		setTitle("Ventana emergente");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400,300);
		
		
		JPanel panel=new JPanel(new GridBagLayout());
		
		GridBagConstraints gbc = new GridBagConstraints(); //objeto para gestionar posiciones
		
		//crear componentes de la interfaz del usuario
		JLabel namelabel=new JLabel("Nombre: ");
		JTextField namet=new JTextField(15);
		
		JLabel emailabel=new JLabel("Email: ");
		JTextField emailt=new JTextField(15);
		
		JLabel telelabel=new JLabel("Teléfono: ");
		JTextField telet=new JTextField(15);
		
		JLabel mensajelabel=new JLabel("Mensaje: ");
		JTextArea mensajet = new JTextArea(5, 20); // 5 filas, 20 columnas
		panel.add(new JScrollPane(mensajet), gbc);
		
		JButton b=new JButton("Enviar");
		
		//margenes de espaciado entre componentes
		gbc.insets=new Insets(5,5,5,5);
		
		// Añadir y posicionar los componentes utilizando GridBagConstraints

        // Posicionar la etiqueta "Nombre"
		gbc.gridx=0; //columna 0
		gbc.gridy=0; //fila 0
		panel.add(namelabel,gbc);
		
		//posicionar el campo de texto para nombre
		gbc.gridx=1;
		panel.add(namet,gbc);
		
		// Posicionar la etiqueta "Email"
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 1; // Fila 1
        panel.add(emailabel, gbc);

        // Posicionar el campo de texto para "Email"
        gbc.gridx = 1; // Columna 1
        panel.add(emailt, gbc);

        // Posicionar la etiqueta "Teléfono"
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 2; // Fila 2
        panel.add(telelabel, gbc);

        // Posicionar el campo de texto para "Teléfono"
        gbc.gridx = 1; // Columna 1
        panel.add(telet, gbc);

     // Posicionar la etiqueta "Mensaje"
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2; // Ocupa dos columnas
        panel.add(mensajelabel, gbc);

        // Área de texto para mensaje (más grande)
        gbc.gridy = 4;
        gbc.fill = GridBagConstraints.BOTH; // Expande el área de texto
        panel.add(new JScrollPane(mensajet), gbc);

     // Posicionar el botón "Enviar"
        gbc.gridy = 5; // Fila 5
        gbc.fill = GridBagConstraints.NONE; // No expandir el botón
        gbc.anchor = GridBagConstraints.CENTER; // Centrar el botón horizontalmente
        panel.add(b, gbc);

        add(panel);
		
		setLocationRelativeTo(null);
		
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> new GridLayout2());
		GridBagLayout1 ventana=new GridBagLayout1();
		ventana.setVisible(true);

	}

}
