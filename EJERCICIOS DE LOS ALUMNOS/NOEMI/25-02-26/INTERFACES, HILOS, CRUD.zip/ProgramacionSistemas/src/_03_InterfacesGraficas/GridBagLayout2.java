package _03_InterfacesGraficas;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.*;

public class GridBagLayout2 extends JFrame {
    // Atributos de los campos
    private JTextField namet, apet, emailt, telet, telet2, domt, ciutat, provt;
    private JTextArea mensajet;
    private JButton b;

    public GridBagLayout2() {
        setTitle("Formulario Completo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700,500);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5); // Márgenes entre componentes

        // ==== CREAR COMPONENTES ====
        JLabel namelabel = new JLabel("Nombre:");
        namet = new JTextField(15);

        JLabel apelabel = new JLabel("Apellidos:");
        apet = new JTextField(15);

        JLabel emailabel = new JLabel("Email:");
        emailt = new JTextField(15);

        JLabel telelabel = new JLabel("Teléfono 1:");
        telet = new JTextField(15);

        JLabel tele2label = new JLabel("Teléfono 2:");
        telet2 = new JTextField(15);

        JLabel domlabel = new JLabel("Domicilio:");
        domt = new JTextField(15);

        JLabel ciudadlabel = new JLabel("Ciudad:");
        ciutat = new JTextField(15);

        JLabel provlabel = new JLabel("Provincia:");
        provt = new JTextField(15);

        JLabel mensajelabel = new JLabel("Mensaje:");
        mensajet = new JTextArea(5, 30); // área de texto grande

        b = new JButton("Enviar");

        // ==== POSICIONAR COMPONENTES ====
        int fila = 0;

        // Nombre
        gbc.gridx = 0; gbc.gridy = fila;
        panel.add(namelabel, gbc);
        gbc.gridx = 1;
        panel.add(namet, gbc);

        // Apellidos
        fila++;
        gbc.gridx = 0; gbc.gridy = fila;
        panel.add(apelabel, gbc);
        gbc.gridx = 1;
        panel.add(apet, gbc);

        // Email
        fila++;
        gbc.gridx = 0; gbc.gridy = fila;
        panel.add(emailabel, gbc);
        gbc.gridx = 1;
        panel.add(emailt, gbc);

        // Teléfono 1
        fila++;
        gbc.gridx = 0; gbc.gridy = fila;
        panel.add(telelabel, gbc);
        gbc.gridx = 1;
        panel.add(telet, gbc);

        // Teléfono 2
        fila++;
        gbc.gridx = 0; gbc.gridy = fila;
        panel.add(tele2label, gbc);
        gbc.gridx = 1;
        panel.add(telet2, gbc);

        // Domicilio
        fila++;
        gbc.gridx = 0; gbc.gridy = fila;
        panel.add(domlabel, gbc);
        gbc.gridx = 1;
        panel.add(domt, gbc);

        // Ciudad
        fila++;
        gbc.gridx = 0; gbc.gridy = fila;
        panel.add(ciudadlabel, gbc);
        gbc.gridx = 1;
        panel.add(ciutat, gbc);

        // Provincia
        fila++;
        gbc.gridx = 0; gbc.gridy = fila;
        panel.add(provlabel, gbc);
        gbc.gridx = 1;
        panel.add(provt, gbc);

        // Mensaje
        fila++;
        gbc.gridx = 0; gbc.gridy = fila;
        gbc.gridwidth = 2; // Ocupa dos columnas
        panel.add(mensajelabel, gbc);

        fila++;
        gbc.gridy = fila;
        gbc.fill = GridBagConstraints.BOTH; // Expande el área de texto
        panel.add(new JScrollPane(mensajet), gbc);

        // Botón Enviar
        fila++;
        gbc.gridy = fila;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(b, gbc);

        add(panel);
        setLocationRelativeTo(null); // Centrar ventana
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GridBagLayout2 ventana = new GridBagLayout2();
            ventana.setVisible(true);
        });
    }
}