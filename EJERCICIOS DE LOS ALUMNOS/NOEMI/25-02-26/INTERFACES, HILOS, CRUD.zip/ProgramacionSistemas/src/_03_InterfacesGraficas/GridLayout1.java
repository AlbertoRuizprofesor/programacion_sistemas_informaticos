package _03_InterfacesGraficas;
import javax.swing.*;
import java.awt.*;


public class GridLayout1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame ventana=new JFrame("Ventana emergente");
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setSize(300,400);
		
		
		JTextField t1=new JTextField();
		ventana.add(t1,BorderLayout.NORTH);
		
		JPanel panel=new JPanel();
		panel.setLayout(new GridLayout(4,4,2,2));
		
		String[] buttons= {
				"7", "8", "9", "/",
				"4", "5", "6", "*",
				"1", "2", "3", "-",
				"0", "C", "=", "+"
		

	};
		
		for(String Text : buttons) {
			panel.add(new JButton(Text));
		}
		ventana.setLocationRelativeTo(null);
		ventana.add(panel, BorderLayout.CENTER);
		ventana.setVisible(true);
	}
}
