package _03_InterfacesGraficas;
import javax.swing.*;

import _01_InterfacesGraficas.RETO;

import java.awt.*;


public class GridLayout2 extends JFrame {
	private JTextField t1;
	private JPanel panel;
	
	public GridLayout2() {
		setTitle("Ventana emergente");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(600,400);
		setLayout(new BorderLayout());
		
		//panel con grid para botones
		
		panel=new JPanel();
		panel.setLayout(new GridLayout(7,4,2,2));
		
		String[] buttons = {
				"a", "b", "c", "d",
				"e", "f", "g", "h", 
				"i", "j", "k", "l",
				"m", "n", "ñ", "o",
				"p", "q", "r", "s",
				"t", "u", "v", "w", 
				"y","z", "Aceptar", "Cancelar"
		

	};
		
		for (String text : buttons) {
			panel.add(new JButton(text));
		}
		
		add(panel, BorderLayout.CENTER);
		
		setLocationRelativeTo(null);
		
	}
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> new GridLayout2());
		GridLayout2 ventana=new GridLayout2();
		ventana.setVisible(true);
		
	
		
		
		

	}

}
