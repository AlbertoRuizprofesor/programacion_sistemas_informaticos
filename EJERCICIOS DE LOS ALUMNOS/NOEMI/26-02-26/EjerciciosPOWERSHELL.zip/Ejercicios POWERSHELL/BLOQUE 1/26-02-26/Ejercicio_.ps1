function  Saludar {
    param ($nombre,$edad)
    "Hola, $nombre, tienes $edad años"
}
$nombre = Read-Host "Como te llamas?"
$edad= Read-Host "Cuantos años tienes?"

saludar -nombre $nombre -edad $edad #INVOCA ASI LA FUNCION 