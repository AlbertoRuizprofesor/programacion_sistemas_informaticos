$n=Read-Host("dime el numero: ")
$numeros=1..10   #n es el 1 y el numero es el 10
foreach ($n in $numeros) {
    $resultado=$n*$tabla
    Write-Host "Número: $n x $tabla = $resultado"
}