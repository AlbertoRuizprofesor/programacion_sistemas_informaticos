for ($i =1; $i -le 5; $i++){  #menor o igual que 5 el -le
    Write-Host "Valor: $i"
}