$i =1
do {
    Write-Host "Ejercicio numero $i"
    $i++
} while ($i -le 5)