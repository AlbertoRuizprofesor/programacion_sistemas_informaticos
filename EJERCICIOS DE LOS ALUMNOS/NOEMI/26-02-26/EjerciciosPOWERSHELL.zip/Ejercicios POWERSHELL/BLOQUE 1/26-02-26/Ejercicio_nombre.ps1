function Saludar {
 $nombre=Read-Host "Cual es tu nombre?"

  "Hola, $nombre"
}

Saludar -nombre "Alberto"