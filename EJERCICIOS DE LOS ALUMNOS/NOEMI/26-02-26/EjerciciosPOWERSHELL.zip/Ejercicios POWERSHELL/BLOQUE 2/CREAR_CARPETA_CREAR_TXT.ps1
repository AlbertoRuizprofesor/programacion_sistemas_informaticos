New-Item -Path C:\Backup -ItemType Directory || Write-Host "El directorio ya existe"


New-Item -Path C:\Reportes\resumen.txt -ItemType File || Write-Host "El archivo ya existe"
