Get-Process | Export-Csv -Path "C:\Users\2-DAW\Desktop\procesos.csv" -NoTypeInformation 


Get-Service | Out-File "C:\Users\2-DAW\Desktop\servicios.txt" 



Get-Process | ConvertTo-Json | Out-File "C:\Users\2-DAW\Desktop\procesos.json" 

