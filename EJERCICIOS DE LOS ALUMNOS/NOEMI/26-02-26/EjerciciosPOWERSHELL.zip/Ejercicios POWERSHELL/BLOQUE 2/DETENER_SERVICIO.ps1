Get-Process 
Write-Host "Detener Spooler"
Stop-Service Spooler
Get-Service Spooler
Write-Host "Iniciando Spooler"
Start-Service Spooler
Get-Service Spooler