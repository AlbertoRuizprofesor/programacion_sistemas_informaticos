

Copy-Item C:\Backup || "Ya está copiado"

Copy-Item C:\INFORMESPROCESOS || "Ya está copiado"

Copy-Item C:\INFORMESSERVICIOS || "Ya está copiado"

Move-Item C:\Backup  C:\EjercicioPOWERSHELL|| "Ya existe"

Move-Item C:\INFORMESPROCESOS  C:\EjercicioPOWERSHELL|| "Ya existe"

Move-Item C:\INFORMESSERVICIOS  C:\EjercicioPOWERSHELL|| "Ya existe"