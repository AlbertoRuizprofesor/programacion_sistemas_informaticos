#CREAR TRES CARPETAS : servicios, procesos, backup.
#CREAR LOS ARCHIVOS servicios.txt, procesos.txt 
#METEMOS LOS DOS ARCHIVOS EN BACKUP.


#CREAR CARPETAS

New-Item -Path C:\Ejercicio2 -ItemType Directory || Write-Host "El directorio ya existe"

New-Item -Path C:\Ejercicio2\Backup -ItemType Directory || Write-Host "El directorio ya existe"
New-Item -Path C:\Ejercicio2\servicios -ItemType Directory || Write-Host "El directorio ya existe"
New-Item -Path C:\Ejercicio2\procesos -ItemType Directory || Write-Host "El directorio ya existe"


#METER DENTRO DE UN TXT LOS SERVICIOS Y PROCESOS DEL PC

Get-Service | Out-File "C:\Ejercicio2\servicios\servicios.txt" 
Get-Process | Out-File "C:\Ejercicio2\procesos\procesos.txt" 

# COPIAR LOS TXT Y METERLO EN OTRA CARPETA SIN BORRAR LOS ORIGINALES
Copy-Item C:\Ejercicio2\servicios\servicios.txt C:\Ejercicio2\Backup || "Ya está copiado"  #SI HACE ESTO SE COPIA Y TAL PERO NO SE ELIMINA DE LA ORIGINAL

Copy-Item C:\Ejercicio2\procesos\procesos.txt C:\Ejercicio2\Backup

#ELIMINAR TODO
Remove-Item C:\Ejercicio2 -Recurse -Force
