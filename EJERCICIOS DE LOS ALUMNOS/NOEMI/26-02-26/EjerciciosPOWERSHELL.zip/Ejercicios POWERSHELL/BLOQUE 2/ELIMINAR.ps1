Remove-Item C:\EjercicioPOWERSHELL -Recurse -Force
