Copy-Item C:\Reportes\resumen.txt C:\Backup || "Ya está copiado"  #SI HACE ESTO SE COPIA Y TAL PERO NO SE ELIMINA DE LA ORIGINAL

Move-Item C:\Reportes\resumen.txt C:\Backup || "Ya existe"  #SI HAGO ESTO, SE ELIMINA TAMBIEN DE LA CARPETA ORIGINAL








