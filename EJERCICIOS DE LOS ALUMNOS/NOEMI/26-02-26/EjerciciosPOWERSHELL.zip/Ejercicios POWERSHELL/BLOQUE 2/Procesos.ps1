Get-Process | Where-Object { $_.CPU -gt 100}

Get-Process | Where-Object { $_.WorkingSet -gt 100MB }

