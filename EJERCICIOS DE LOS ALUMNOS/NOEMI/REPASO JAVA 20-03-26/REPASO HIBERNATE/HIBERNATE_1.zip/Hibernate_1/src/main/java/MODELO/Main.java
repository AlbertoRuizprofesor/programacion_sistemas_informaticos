package MODELO;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = factory.openSession();

        List<Alumno> alumnos = session.createQuery("FROM Alumno", Alumno.class).list();

        for (Alumno a : alumnos) {
            System.out.println(a.getId() + " " + a.getNombre() + " " + a.getCurso());
        }

        session.close();
        factory.close();
    }
}