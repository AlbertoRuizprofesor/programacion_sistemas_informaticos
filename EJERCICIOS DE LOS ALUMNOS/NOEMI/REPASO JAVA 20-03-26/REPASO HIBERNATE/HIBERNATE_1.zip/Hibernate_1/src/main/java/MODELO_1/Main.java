package MODELO_1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        SessionFactory factory = new Configuration().configure("hibernate_tienda.cfg.xml").buildSessionFactory();
        Session session = factory.openSession();

        List<Producto> productos = session.createQuery("FROM Producto", Producto.class).list();

        for (Producto p : productos) {
            System.out.println(p.getId() + " " + p.getNombre() + " " + p.getPrecio() + " " + p.getStock());
        }

        session.close();
        factory.close();
    }
}
