package MODELO_3;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        SessionFactory factory = new Configuration().configure("hibernate_biblioteca.cfg.xml").buildSessionFactory();
        Session session = factory.openSession();

        List<Libro> libros = session.createQuery("FROM Libro", Libro.class).list();

        for (Libro l : libros) {
            System.out.println("|- ID:  "+ l.getId() + ".|- Título: " + l.getTitulo() + ".|- Autor: " + l.getAutor() + ".|- Páginas: " + l.getPaginas());
        }

        session.close();
        factory.close();
    }


	}


