package MODELO_4;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        SessionFactory factory = new Configuration().configure("hibernate_empleados.cfg.xml").buildSessionFactory();
        Session session = factory.openSession();

        List<Empleado> empleados = session.createQuery("FROM Empleado", Empleado.class).list();

        for (Empleado e : empleados) {
            System.out.println("|- ID:  "+ e.getId() + ". |- Nombre: " + e.getNombre() + ". |- Puesto: " + e.getPuesto() + ". |- Salario: " + e.getSalario());
        }

        session.close();
        factory.close();
    }


	}

