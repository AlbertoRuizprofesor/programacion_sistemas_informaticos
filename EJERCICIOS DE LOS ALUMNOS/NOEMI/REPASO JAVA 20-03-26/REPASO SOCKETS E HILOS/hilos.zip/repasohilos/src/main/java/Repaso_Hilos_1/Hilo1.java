package Repaso_Hilos_1;


public class Hilo1 extends Thread {
    @Override
    public void run() {
        System.out.println("Hilo 1 en ejecución");
    }
}