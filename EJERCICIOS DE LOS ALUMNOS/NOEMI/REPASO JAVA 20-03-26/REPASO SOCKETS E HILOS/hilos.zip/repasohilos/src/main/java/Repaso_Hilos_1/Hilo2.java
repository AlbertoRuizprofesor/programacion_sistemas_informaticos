package Repaso_Hilos_1;

public class Hilo2 extends Thread {
    @Override
    public void run() {
        System.out.println("Hilo 2 en ejecución");
    }
}