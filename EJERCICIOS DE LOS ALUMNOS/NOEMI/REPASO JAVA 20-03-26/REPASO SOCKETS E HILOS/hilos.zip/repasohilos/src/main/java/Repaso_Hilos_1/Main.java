package Repaso_Hilos_1;

public class Main {

	    public static void main(String[] args) {

	        // Crear los hilos
	        Hilo1 hilo1 = new Hilo1();
	        Hilo2 hilo2 = new Hilo2();

	        // Iniciar los hilos
	        hilo1.start();
	        hilo2.start();

	        // Mensaje del hilo principal
	        System.out.println("Hilo principal en ejecución");
	    }
	}

