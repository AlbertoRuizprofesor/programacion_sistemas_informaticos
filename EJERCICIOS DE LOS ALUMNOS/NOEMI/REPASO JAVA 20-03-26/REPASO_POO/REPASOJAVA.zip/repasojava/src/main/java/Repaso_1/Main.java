package Repaso_1;

public class Main {

	public static void main(String[] args) {
		Persona p=new Persona("Noemi",28);
		
		p.mostrarDatos();
		
		

	}

}
