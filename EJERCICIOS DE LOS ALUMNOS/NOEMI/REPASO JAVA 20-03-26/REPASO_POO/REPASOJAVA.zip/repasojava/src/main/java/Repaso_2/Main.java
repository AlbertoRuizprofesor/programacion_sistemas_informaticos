package Repaso_2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Coche c=new Coche("Corsa","OPEN CORSA","Rojo");
		System.out.println(c.toString());
		c.arrancar();
		
		
		System.out.println("*************************************");
		
		Coche c2 = new Coche("Focus", "FORD FOCUS", "Azul");
		System.out.println(c2.toString());
	    System.out.println("El segundo coche está arrancando...");
	    c2.arrancar();
	    
		
		

	}

}
