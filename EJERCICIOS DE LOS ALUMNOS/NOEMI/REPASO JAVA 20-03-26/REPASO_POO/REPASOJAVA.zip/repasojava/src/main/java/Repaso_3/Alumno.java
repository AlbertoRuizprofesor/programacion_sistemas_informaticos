package Repaso_3;

public class Alumno {
	private String nombre;
	private int nota1;
	private int nota2;
	public Alumno(String nombre, int nota1, int nota2) {
		super();
		this.nombre = nombre;
		this.nota1 = nota1;
		this.nota2 = nota2;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getNota1() {
		return nota1;
	}
	public void setNota1(int nota1) {
		this.nota1 = nota1;
	}
	public int getNota2() {
		return nota2;
	}
	public void setNota2(int nota2) {
		this.nota2 = nota2;
	}
	
	public void calcularMedia() {
		double media = (nota1 + nota2) / 2.0;
		System.out.println("La nota media de "+nombre+" es: "+media);
		
	}
	@Override
	public String toString() {
		return "Alumno [nombre= " + nombre + ", Primera nota= " + nota1 + ", segunda nota= " + nota2 + "]";
	}
	

}
