package Repaso_3;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Alumno a=new Alumno("Rocio",7,8);
		
		System.out.println(a.toString());
		a.calcularMedia();

	}

}
