package Repaso_4;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangulo r=new Rectangulo(1,6);
		System.out.println(r.toString());
		r.calcularArea();
		r.calcularPerimetro();

	}

}
