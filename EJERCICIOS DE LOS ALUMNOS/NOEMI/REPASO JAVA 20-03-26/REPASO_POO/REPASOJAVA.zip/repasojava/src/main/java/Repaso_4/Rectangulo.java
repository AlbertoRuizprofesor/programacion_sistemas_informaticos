package Repaso_4;

public class Rectangulo {
	private double base;
	private double altura;
	public Rectangulo(double base, double altura) {
		super();
		this.base = base;
		this.altura = altura;
	}
	public double getBase() {
		return base;
	}
	public void setBase(double base) {
		this.base = base;
	}
	public double getAltura() {
		return altura;
	}
	public void setAltura(double altura) {
		this.altura = altura;
	}
	
	public void calcularArea() {
		 double total= base * altura;
		 System.out.println("El total del Área es: "+total);
	}
	public void calcularPerimetro() {
		double total1=2*(base+altura);
		System.out.println("El total del perímtro es: "+total1);
	}
	@Override
	public String toString() {
		return "Rectangulo [base=" + base + ", altura=" + altura + "]";
	}

}
