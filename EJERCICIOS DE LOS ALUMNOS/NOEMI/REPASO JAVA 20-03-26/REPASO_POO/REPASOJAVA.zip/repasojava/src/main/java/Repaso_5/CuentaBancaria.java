package Repaso_5;

public class CuentaBancaria {
	private String titular;
	private double saldo;
	public CuentaBancaria(String titular, double saldo) {
		super();
		this.titular = titular;
		this.saldo = saldo;
	}
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public void IngresarDinero(double cantidad) {
		if (cantidad > 0) {
			saldo+=cantidad;
			 System.out.println("Has ingresado: " + cantidad + "€. Saldo actual: " + saldo + "€");
	    } else {
	        System.out.println("Cantidad inválida. No se puede ingresar dinero negativo.");
	  }
	
	
}
	
	public void RetirarDinero(double cantidad) {
		if (cantidad >0) {
			if(saldo >= cantidad) {
			saldo-=cantidad;
			 System.out.println("Has retirado: " + cantidad + "€. Saldo actual: " + saldo + "€");
			} else {
	            System.out.println("Saldo insuficiente. No se puede retirar " + cantidad + "€");
	        }
			} else {
	        System.out.println("Cantidad inválida. No se puede retirar dinero negativo.");
	   }
			
	}
		
	
	
	public void mostrarSaldo() {
		System.out.println("Titular: " + titular + " | Saldo actual: " + saldo + "€");
		
		
	}
	@Override
	public String toString() {
		return "CuentaBancaria [titular=" + titular + ", saldo=" + saldo + "]";
	}
	
	

}
