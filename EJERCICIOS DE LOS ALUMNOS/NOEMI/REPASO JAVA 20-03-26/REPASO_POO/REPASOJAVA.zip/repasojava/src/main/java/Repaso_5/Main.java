package Repaso_5;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CuentaBancaria cb=new CuentaBancaria("Noemi",20939);
		System.out.println(cb.toString());
		cb.IngresarDinero(304);
		cb.RetirarDinero(32);
		cb.mostrarSaldo();
		
		

	}

}
