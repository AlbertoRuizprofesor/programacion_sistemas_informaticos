package Repaso_6;

public class Libro {
	private String titulo;
	private String autor;
	private int numero_paginas;
	public Libro(String titulo, String autor, int numero_paginas) {
		super();
		this.titulo = titulo;
		this.autor = autor;
		this.numero_paginas = numero_paginas;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public int getNumero_paginas() {
		return numero_paginas;
	}
	public void setNumero_paginas(int numero_paginas) {
		this.numero_paginas = numero_paginas;
	}
	@Override
	public String toString() {
		return "Libro [titulo=" + titulo + ", autor=" + autor + ", numero_paginas=" + numero_paginas + "]";
	}
	
	

}
