package Repaso_6;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Libro l=new Libro("IT","Stephen King",800);
		
		System.out.println(l.toString());
		
		Libro l2=new Libro("Bel: amor más allá de la muerte","Care Santos",240);
		System.out.println(l2.toString());

	}

}
