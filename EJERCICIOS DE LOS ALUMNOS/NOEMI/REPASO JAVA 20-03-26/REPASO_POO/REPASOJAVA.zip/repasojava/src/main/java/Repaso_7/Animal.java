package Repaso_7;

public class Animal {
	private String nombre;
	private String tipo;
	public Animal(String nombre, String tipo) {
		super();
		this.nombre = nombre;
		this.tipo = tipo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public void hacerSonido() {
		System.out.println("Los animales para comunicarse hacen diferentes sonidos.");
		

	}
	@Override
	public String toString() {
		return "Animal [nombre=" + nombre + ", tipo=" + tipo + "]";
	}
	

}
