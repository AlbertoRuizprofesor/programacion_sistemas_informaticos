package Repaso_7;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal a=new Animal("León","Mamífero");
		System.out.println(a.toString());
		
		Animal a2=new Animal("Perro","Mamífero");
		System.out.println(a2.toString());
		
		Animal a3=new Animal("Gato","Mamífero");
		System.out.println(a3.toString());
		
		a.hacerSonido();

	}

}
