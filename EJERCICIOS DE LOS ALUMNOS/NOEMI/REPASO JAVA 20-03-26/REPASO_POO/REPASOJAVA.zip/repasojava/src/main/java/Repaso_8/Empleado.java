package Repaso_8;

public class Empleado {
	private String nombre;
	private double sueldoBase;
	public Empleado(String nombre, double sueldoBase) {
		super();
		this.nombre = nombre;
		this.sueldoBase = sueldoBase;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getSueldoBase() {
		return sueldoBase;
	}
	public void setSueldoBase(double sueldoBase) {
		this.sueldoBase = sueldoBase;
	}
	
	public void calcularSueldoAnual() {
		double total= sueldoBase * 14;
		 System.out.println("Sueldo anual: " + total);
	}
	
	
	@Override
	public String toString() {
		return "Empleado [nombre=" + nombre + ", sueldoBase=" + sueldoBase + "]";
	}
	
	

}
