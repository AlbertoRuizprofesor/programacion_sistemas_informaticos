package Repaso_8;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Empleado e=new Empleado("Jose",1500);
		System.out.println(e.toString());
		e.calcularSueldoAnual();

	}

}
