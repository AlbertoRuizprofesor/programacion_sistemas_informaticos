package Repaso_9;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Producto p=new Producto("Ordenador",1200.0,3);
		System.out.println(p.toString());
		p.CalcularValorTotalProductoAlmacen();

	}

}
