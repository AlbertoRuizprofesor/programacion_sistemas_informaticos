package conectarmysql;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class MostrarDatosProductos {



		   //declaramos los diferentes objetos necesarios para nuestra conexión
		   
		   public static void main(String[] args) throws SQLException  {
		      Connection conn = null;
		      Statement stmt=null;
		      String sql="SELECT * FROM productos";
		      
		      try {
		    	 //Desde aquí se encarga del driver JDBC    
		         conn = DriverManager.getConnection("jdbc:mysql://localhost/empresa1","root","");
		         //controlamos que la conexión ha sido ok
		         stmt=conn.createStatement();
		         ResultSet rs=stmt.executeQuery(sql);
		         
		         while (rs.next()) {
		        	 int id=rs.getInt("id");
		        	 String nombre=rs.getString("nombre");
		        	 double precio=rs.getDouble("precio");
		        	 System.out.println("id: " + id + ", nombre: " + nombre + ", precio: " + precio);
		        }
		         
		         conn.close();
		         stmt.close();
		         rs.close();
		      }
		      
		      catch(SQLException e)                   
		         {e.printStackTrace();  
		      }
		 }
	}

