package sobrecarga;

public class Sobrecarga {
	private String nombre;
	private int edad;
	private double ingresos;
	
	public Sobrecarga(String nombre, int edad, double ingresos) {
		this.nombre=nombre;
		this.edad=edad;
		this.ingresos=ingresos;
	}
	public Sobrecarga(String nombre, int edad) {
		this.nombre=nombre;
		this.edad=edad;
	}
	public Sobrecarga(String nombre) {
		this.nombre=nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
	public double getIngresos() {
		return ingresos;
	}
	public void setIngresos(double ingresos) {
		this.ingresos=ingresos;
	}
	public void mostrar() {
		System.out.println("Sobrecarga \n -nombre: "+getNombre()+"\n -Edad: "+getEdad()+"\n -Ingresos: "+ingresos);
	}
}
