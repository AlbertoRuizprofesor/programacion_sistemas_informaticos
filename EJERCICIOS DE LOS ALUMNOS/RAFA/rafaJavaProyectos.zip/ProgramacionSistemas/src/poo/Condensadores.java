package poo;

public class Condensadores {

}
