package poo;

public class Inductancias {

}
