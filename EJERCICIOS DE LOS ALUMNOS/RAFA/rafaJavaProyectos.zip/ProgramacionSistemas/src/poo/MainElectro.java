package poo;

public class MainElectro {
	public static void main(String[] args) {
		
		//Componentes componente=new Componentes("500 mW", "10 v", "50 mA");
		Transistores transistor=new Transistores("500 mW", "10 v", "50 mA", "BJT", "superficie");
		System.out.println(componente.toString());
		System.out.println(transistor.toString());
	}

}
