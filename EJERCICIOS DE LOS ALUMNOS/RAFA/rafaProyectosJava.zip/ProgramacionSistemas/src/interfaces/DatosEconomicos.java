package interfaces;

public interface DatosEconomicos {
	String pagar(String nombre);
	
}
