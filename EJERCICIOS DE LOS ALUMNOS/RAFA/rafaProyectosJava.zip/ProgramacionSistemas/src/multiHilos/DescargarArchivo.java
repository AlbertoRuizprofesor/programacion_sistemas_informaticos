package multiHilos;

class DescargarArchivo implements Runnable {
    @Override
    public void run() {
        System.out.println("Descargando archivo...");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Descarga completa");
    }
}