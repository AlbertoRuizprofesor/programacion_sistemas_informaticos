package conectar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.PreparedStatement;

public class Academia {

    public static void main(String[] args) {

        Scanner c = new Scanner(System.in);

        System.out.println("Introduce id:");
        int dato1 = c.nextInt();
        c.nextLine();

        System.out.println("Introduce nombre:");
        String dato2 = c.nextLine();

        System.out.println("Introduce profesor:");
        String dato3 = c.nextLine();

        System.out.println("Introduce horas:");
        int dato4 = c.nextInt();

        String sql = "INSERT INTO cursos (id, nombre, profesor, horas) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost/academia", "root", "");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, dato1);
            pstmt.setString(2, dato2);
            pstmt.setString(3, dato3);
            pstmt.setInt(4, dato4);

            pstmt.executeUpdate();

            System.out.println("Curso insertado correctamente");

        } catch (SQLException e) {
            e.printStackTrace();
        }

        c.close();
    }
}
