package banco;

public class CuentaBancaria extends Banco {
	private String numeroCuenta;
	private String saldoInicial;
	public CuentaBancaria(String nombreBanco,String numeroCuenta,String saldoInicial) {
		super(nombreBanco);
		// TODO Auto-generated constructor stub
		this.numeroCuenta=numeroCuenta;
		this.saldoInicial=saldoInicial;
		
	}
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	public String getSaldoInicial() {
		return saldoInicial;
	}
	public void setSaldoInicial(String saldoInicial) {
		this.saldoInicial = saldoInicial;
	}
	@Override
	public String toString() {
		return "CuentaBancaria [numeroCuenta=" + numeroCuenta + ", saldoInicial=" + saldoInicial + ", getNombreBanco()="
				+ getNombreBanco() + ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + "]";
	}
	
	
}
