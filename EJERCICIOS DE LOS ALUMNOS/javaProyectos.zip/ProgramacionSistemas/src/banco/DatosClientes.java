package banco;

public interface DatosClientes {
	
}
